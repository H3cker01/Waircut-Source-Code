using System.Windows.Forms;

internal delegate void Delegate169(object object_0, ref Message message_0);
