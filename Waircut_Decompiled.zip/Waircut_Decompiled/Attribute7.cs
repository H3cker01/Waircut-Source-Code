using System;

internal class Attribute7 : Attribute
{
	internal readonly int int_0;

	internal Attribute7(int int_1)
	{
		int_0 = (int_1 ^ -1884960511 ^ -1588626610) * -913126795;
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
