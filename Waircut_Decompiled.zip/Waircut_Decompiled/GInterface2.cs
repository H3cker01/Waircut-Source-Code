using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[ComImport]
[CompilerGenerated]
[Guid("21575140-6672-4DCB-B4B5-4856BD3C91E5")]
[TypeIdentifier]
public interface GInterface2
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	[return: MarshalAs(UnmanagedType.Interface)]
	GInterface12 imethod_0();
}
