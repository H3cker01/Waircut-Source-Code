namespace ns0;

internal delegate object Delegate24(object object_0, string string_0);
