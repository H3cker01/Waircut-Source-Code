namespace ns0;

internal delegate bool Delegate21(object object_0);
