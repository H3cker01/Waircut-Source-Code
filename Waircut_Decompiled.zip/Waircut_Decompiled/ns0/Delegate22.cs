namespace ns0;

internal delegate void Delegate22(object object_0);
