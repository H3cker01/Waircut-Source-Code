namespace ns0;

internal delegate void Delegate26(object object_0, string string_0, object object_1);
