using System;

namespace ns0;

internal delegate DateTime Delegate25(object object_0);
