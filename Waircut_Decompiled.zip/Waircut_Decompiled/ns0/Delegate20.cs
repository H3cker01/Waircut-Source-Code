using System.Configuration;

namespace ns0;

internal delegate object Delegate20(SettingsBase settingsBase_0);
