internal delegate string Delegate149(byte byte_0);
