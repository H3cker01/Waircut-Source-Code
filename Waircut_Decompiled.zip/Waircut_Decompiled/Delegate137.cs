internal delegate string Delegate137(string string_0, object object_0, object object_1);
