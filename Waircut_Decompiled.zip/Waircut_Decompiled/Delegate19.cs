internal delegate object Delegate19(object object_0, string string_0, object object_1);
