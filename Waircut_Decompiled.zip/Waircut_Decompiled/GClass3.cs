using System;
using System.Diagnostics;
using System.Linq;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Waircut;
using ns0;
using ns1;

[StandardModule]
public sealed class GClass3
{
	public enum GEnum0
	{
		Nothing = -1,
		ZAO = 0,
		FTE = 1,
		EasyBox = 2,
		dLINK = 3,
		TrendNet = 4,
		AiroConru = 5,
		Asus = 6,
		LiveBox = 7,
		PinNull = 8,
		d28bit = 10,
		d32bit = 11,
		d36bit = 12,
		d40bit = 13,
		d44bit = 14,
		d48bit = 15,
		d24rhbit = 16,
		d32rhbit = 17,
		d48rhbit = 18,
		d24rnbit = 19,
		d32rnbit = 20,
		d48rnbit = 21
	}

	public static int smethod_0(int int_0)
	{
		int num = 0;
		if (int_0 > 9999999)
		{
			goto IL_004d;
		}
		goto IL_00d9;
		IL_004d:
		int num2 = -1691985419;
		goto IL_0099;
		IL_0099:
		while (true)
		{
			uint num3;
			switch ((num3 = (uint)num2 ^ 0xE4202234u) % 8)
			{
			case 6u:
				int_0 /= 10;
				checked
				{
					num += unchecked(int_0 % 10);
				}
				num2 = (int)((num3 * 1854174872) ^ 0x5BA344E0);
				continue;
			case 4u:
				int_0 /= 10;
				num2 = (int)(num3 * 802472953) ^ -1171436147;
				continue;
			case 3u:
				break;
			case 2u:
				checked
				{
					num += 3 * unchecked(int_0 % 10);
					num2 = -263850326;
					continue;
				}
			case 1u:
				int_0 = checked((int)Delegate69.delegate69_0((double)int_0 / 10.0));
				num2 = ((int)num3 * -457132858) ^ 0x77D0E93A;
				continue;
			case 0u:
				num2 = ((int)num3 * -152169438) ^ 0x7F826AF9;
				continue;
			case 5u:
				goto IL_00d9;
			default:
				return checked(10 - unchecked(num % 10)) % 10;
			}
			break;
		}
		goto IL_004d;
		IL_00d9:
		int num4;
		if (int_0 != 0)
		{
			num2 = -61455658;
			num4 = -61455658;
		}
		else
		{
			num2 = -133299317;
			num4 = -133299317;
		}
		goto IL_0099;
	}

	public static string smethod_1(string string_0)
	{
		int int_ = 0;
		string[] array = new string[7];
		array = Delegate70.smethod_0((object)string_0, new char[1] { ':' });
		while (true)
		{
			int num = 1010146900;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x1773F6C2u) % 3)
				{
				case 1u:
					goto IL_001d;
				case 0u:
					break;
				default:
					return int_.ToString(global::_003CModule_003E.smethod_20<string>(3716503941u, 198482745u)) + smethod_0(int_);
				}
				break;
				IL_001d:
				int_ = Delegate72.delegate72_0(Delegate71.delegate71_0(array[3], array[4], array[5]), 16);
				int_ %= 10000000;
				num = ((int)num2 * -1084342974) ^ 0x62906EDE;
			}
		}
	}

	public static string smethod_2()
	{
		return "";
	}

	public static string smethod_3(string string_0)
	{
		string[] array = new string[7];
		array = Delegate70.smethod_0((object)string_0, new char[1] { ':' });
		string text = Delegate57.delegate57_1(Delegate57.delegate57_1(Delegate57.delegate57_1(Delegate57.delegate57_1(Delegate57.delegate57_1(Delegate57.delegate57_1(Delegate73.delegate73_0(checked(Delegate72.delegate72_0(array[0], 16) + Delegate72.delegate72_0(array[1], 16)) % 10), Delegate73.delegate73_0(checked(Delegate72.delegate72_0(array[1], 16) + Delegate72.delegate72_0(array[2], 16)) % 10)), Delegate73.delegate73_0(checked(Delegate72.delegate72_0(array[2], 16) + Delegate72.delegate72_0(array[3], 16)) % 10)), Delegate73.delegate73_0(checked(Delegate72.delegate72_0(array[3], 16) + Delegate72.delegate72_0(array[4], 16)) % 10)), Delegate73.delegate73_0(checked(Delegate72.delegate72_0(array[4], 16) + Delegate72.delegate72_0(array[5], 16)) % 10)), Delegate73.delegate73_0(checked(Delegate72.delegate72_0(array[5], 16) + Delegate72.delegate72_0(array[0], 16)) % 10)), Delegate73.delegate73_0(checked(Delegate72.delegate72_0(array[0], 16) + Delegate72.delegate72_0(array[1], 16)) % 10));
		return text + Delegate75.smethod_0(Delegate74.smethod_0(text));
	}

	public static object smethod_4(string string_0)
	{
		int num = Delegate72.delegate72_0(Delegate77.delegate77_0(Delegate76.delegate76_0(string_0, global::_003CModule_003E.smethod_22<string>(3900288055u, 47016484u), ""), 6, 6), 16);
		int num2 = 0;
		num2 = num ^ 0x55AA55;
		num2 ^= checked(((num2 & 0xF) << 4) + ((num2 & 0xF) << 8) + ((num2 & 0xF) << 12) + ((num2 & 0xF) << 16) + ((num2 & 0xF) << 20));
		while (true)
		{
			int num3 = -2134362728;
			while (true)
			{
				uint num4;
				switch ((num4 = (uint)num3 ^ 0xB04E75F5u) % 3)
				{
				case 1u:
					goto IL_006a;
				case 2u:
					break;
				default:
				{
					string text = num2.ToString().PadLeft(7, '0');
					return text + Conversions.ToString(smethod_0(Conversions.ToInteger(text)));
				}
				}
				break;
				IL_006a:
				num2 %= 10000000;
				num3 = ((int)num4 * -303939450) ^ 0x5CA2FD5B;
			}
		}
	}

	public static string smethod_5(string string_0)
	{
		string text = "";
		int num8 = default(int);
		int num3 = default(int);
		byte[] array2 = default(byte[]);
		byte[] array3 = default(byte[]);
		int num4 = default(int);
		byte[] array = default(byte[]);
		string text2 = default(string);
		int num9 = default(int);
		string text3 = default(string);
		int num5 = default(int);
		while (true)
		{
			int num = 1553787584;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x7107F893u) % 24)
				{
				case 23u:
					num8 = 0;
					num = (int)((num2 * 621691949) ^ 0x3E36ABDE);
					continue;
				case 22u:
					num3 = checked((byte)unchecked((uint)(checked((byte)unchecked((uint)(checked((byte)unchecked((uint)(array2[1] + array2[2]))) + array3[10]))) + array3[11]))) % 16;
					num4 = checked((byte)unchecked((uint)(checked((byte)unchecked((uint)(checked((byte)unchecked((uint)(array2[3] + array2[4]))) + array3[8]))) + array3[9]))) % 16;
					num = (int)((num2 * 737663969) ^ 0x70C3D605);
					continue;
				case 21u:
					checked
					{
						array[6] = (byte)unchecked((num3 ^ array2[2]) % 16);
						text2 = "";
						num9 = 0;
					}
					num = ((int)num2 * -1316190944) ^ -418587207;
					continue;
				case 20u:
					checked
					{
						array[3] = (byte)unchecked((num4 ^ array3[10]) % 16);
					}
					num = ((int)num2 * -2122736053) ^ 0x7AE02100;
					continue;
				case 19u:
					text3 = Delegate76.delegate76_0(string_0, global::_003CModule_003E.smethod_21<string>(3545203245u, 1779080655u), "");
					num = ((int)num2 * -2107543785) ^ 0x2CFF0003;
					continue;
				case 18u:
					array2 = new byte[5];
					num = (int)((num2 * 1758169736) ^ 0x15B431FC);
					continue;
				case 17u:
					num8 = checked(num8 + 1);
					num = (int)((num2 * 1506545007) ^ 0xCAA5072);
					continue;
				case 16u:
					array3 = new byte[12];
					num = ((int)num2 * -1695151754) ^ 0x1E796C1E;
					continue;
				case 15u:
					checked
					{
						array[4] = (byte)unchecked((array3[10] ^ array2[4]) % 16);
						array[5] = (byte)unchecked((array3[11] ^ array2[3]) % 16);
					}
					num = (int)((num2 * 1530491891) ^ 0x32DFBD2B);
					continue;
				case 14u:
				{
					int num12;
					int num13;
					if (num8 <= 4)
					{
						num12 = 1073104409;
						num13 = 1073104409;
					}
					else
					{
						num12 = 907936497;
						num13 = 907936497;
					}
					num = num12 ^ (int)(num2 * 1480022406);
					continue;
				}
				case 13u:
					text = Delegate72.delegate72_0(Delegate77.delegate77_0(text3, 8, 4), 16).ToString(global::_003CModule_003E.smethod_18<string>(524369188u, 3619472429u));
					num = ((int)num2 * -1097119654) ^ 0x2CAA1409;
					continue;
				case 12u:
					text2 = (Convert.ToInt32(text2, 16) % 10000000).ToString();
					num = (int)((num2 * 1140897593) ^ 0x4B05F2A3);
					continue;
				case 10u:
					text2 += Conversion.Hex(array[num9]);
					num = 1595052138;
					continue;
				case 9u:
					num9 = checked(num9 + 1);
					num = ((int)num2 * -466036733) ^ 0x78344CAA;
					continue;
				case 8u:
					checked
					{
						array = new byte[7]
						{
							(byte)unchecked((num3 ^ array2[4]) % 16),
							0,
							0,
							0,
							0,
							0,
							0
						};
					}
					num = ((int)num2 * -2005399015) ^ -1135093101;
					continue;
				case 6u:
					array2[num8] = checked((byte)Convert.ToInt32(text.Substring(num8, 1), 16));
					num = 1117124914;
					continue;
				case 5u:
					num5 = 0;
					num = (int)((num2 * 184625816) ^ 0x705DA378);
					continue;
				case 4u:
					text2 += Conversions.ToString(smethod_0(Conversions.ToInteger(text2.PadLeft(7, '0'))));
					num = (int)(num2 * 1731026553) ^ -712770904;
					continue;
				case 3u:
					array3[num5] = checked((byte)Convert.ToInt32(text3.Substring(num5, 1), 16));
					num = 1627466082;
					continue;
				case 2u:
				{
					int num10;
					int num11;
					if (num9 > 6)
					{
						num10 = 568592321;
						num11 = 568592321;
					}
					else
					{
						num10 = 1675920063;
						num11 = 1675920063;
					}
					num = num10 ^ (int)(num2 * 1978394715);
					continue;
				}
				case 1u:
				{
					num5 = checked(num5 + 1);
					int num6;
					int num7;
					if (num5 > 11)
					{
						num6 = -1524925375;
						num7 = -1524925375;
					}
					else
					{
						num6 = -179298208;
						num7 = -179298208;
					}
					num = num6 ^ (int)(num2 * 933979680);
					continue;
				}
				case 0u:
					checked
					{
						array[1] = (byte)unchecked((num3 ^ array2[3]) % 16);
						array[2] = (byte)unchecked((num4 ^ array3[9]) % 16);
					}
					num = ((int)num2 * -2072906465) ^ 0x74042157;
					continue;
				case 11u:
					break;
				default:
					return text2.PadLeft(8, '0');
				}
				break;
			}
		}
	}

	public static string smethod_6(string string_0, string string_1)
	{
		string text = "";
		byte[] array2 = default(byte[]);
		int num4 = default(int);
		byte[] array3 = default(byte[]);
		byte[] array = default(byte[]);
		int num9 = default(int);
		int num10 = default(int);
		int num7 = default(int);
		ulong value = default(ulong);
		string text2 = default(string);
		string text3 = default(string);
		int num8 = default(int);
		int num3 = default(int);
		string result = default(string);
		while (true)
		{
			int num = -2100992909;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xE1475789u) % 29)
				{
				case 28u:
					array2 = new byte[9];
					num4 = 0;
					num = ((int)num2 * -689459977) ^ -1147720989;
					continue;
				case 27u:
					num = (int)((num2 * 1007481612) ^ 0x622D166E);
					continue;
				case 26u:
					checked
					{
						array3[5] = (byte)unchecked((array[0] ^ array2[1]) % 16);
					}
					num = ((int)num2 * -703363203) ^ 0x5B7AE756;
					continue;
				case 25u:
					checked
					{
						array3 = new byte[7]
						{
							(byte)unchecked((num9 ^ array2[0]) % 16),
							0,
							0,
							0,
							0,
							0,
							0
						};
					}
					num = (int)(num2 * 246922664) ^ -1518564385;
					continue;
				case 24u:
					num9 = checked((byte)unchecked((uint)(checked((byte)unchecked((uint)(checked((byte)unchecked((uint)(array2[2] + array2[3]))) + array[0]))) + array[1]))) % 16;
					num10 = checked((byte)unchecked((uint)(checked((byte)unchecked((uint)(checked((byte)unchecked((uint)(array2[0] + array2[1]))) + array[2]))) + array[3]))) % 16;
					num = ((int)num2 * -415136488) ^ 0x54D91668;
					continue;
				case 23u:
					num7 = checked(num7 + 1);
					num = (int)((num2 * 1575319032) ^ 0x2C2B3EF6);
					continue;
				case 22u:
					value = Convert.ToUInt64(decimal.Subtract(new decimal(value), 2m));
					text2 = value.ToString(global::_003CModule_003E.smethod_20<string>(3475054082u, 2700312990u));
					num = (int)((num2 * 1349208936) ^ 0x5D14F924);
					continue;
				case 21u:
					checked
					{
						array3[6] = (byte)unchecked((num9 ^ array2[2]) % 16);
						text3 = "";
						num7 = 0;
					}
					num = ((int)num2 * -1547130165) ^ 0x13135C68;
					continue;
				case 20u:
				{
					int num13;
					int num14;
					if (!Delegate21.delegate21_5(Delegate77.delegate77_0(string_1, 1, 9)))
					{
						num13 = 1307402176;
						num14 = 1307402176;
					}
					else
					{
						num13 = 2073042713;
						num14 = 2073042713;
					}
					num = num13 ^ ((int)num2 * -1523921132);
					continue;
				}
				case 19u:
					text3 = num8.ToString();
					text3 += Conversions.ToString(smethod_0(Conversions.ToInteger(text3.PadLeft(7, '0'))));
					num = (int)((num2 * 531232816) ^ 0x7F99FAB8);
					continue;
				case 18u:
				{
					int num17;
					int num18;
					if (num7 > 6)
					{
						num17 = -521589458;
						num18 = -521589458;
					}
					else
					{
						num17 = -1792955545;
						num18 = -1792955545;
					}
					num = num17 ^ (int)(num2 * 1416123615);
					continue;
				}
				case 16u:
				{
					num3 = checked(num3 + 1);
					int num15;
					int num16;
					if (num3 <= 11)
					{
						num15 = 691768528;
						num16 = 691768528;
					}
					else
					{
						num15 = 951651977;
						num16 = 951651977;
					}
					num = num15 ^ ((int)num2 * -135072088);
					continue;
				}
				case 15u:
					result = text3.PadLeft(8, '0');
					num = ((int)num2 * -1905435089) ^ -92935499;
					continue;
				case 14u:
					num8 = Convert.ToInt32(text3, 16) % 10000000;
					num = (int)((num2 * 49239957) ^ 0x134E762A);
					continue;
				case 13u:
					num3 = 0;
					num = ((int)num2 * -963327157) ^ 0x5D79CF81;
					continue;
				case 12u:
					text3 += Conversion.Hex(array3[num7]);
					num = -1264002428;
					continue;
				case 11u:
				{
					num4 = checked(num4 + 1);
					int num11;
					int num12;
					if (num4 > 8)
					{
						num11 = -525759485;
						num12 = -525759485;
					}
					else
					{
						num11 = -1745191077;
						num12 = -1745191077;
					}
					num = num11 ^ ((int)num2 * -1846636474);
					continue;
				}
				case 10u:
					value = checked((ulong)Delegate78.delegate78_0(text2, 16));
					num = ((int)num2 * -1279601534) ^ -1176095435;
					continue;
				case 9u:
					checked
					{
						array3[1] = (byte)unchecked((num9 ^ array2[1]) % 16);
						array3[2] = (byte)unchecked((num10 ^ array[2]) % 16);
					}
					num = ((int)num2 * -1893751113) ^ 0x54F2E215;
					continue;
				case 8u:
					array = new byte[12];
					num = (int)(num2 * 1239968333) ^ -1222040057;
					continue;
				case 7u:
					text = string_1.Substring(1, 9);
					num = (int)((num2 * 1783181763) ^ 0x271CC28F);
					continue;
				case 6u:
					checked
					{
						array3[3] = (byte)unchecked((num10 ^ array[1]) % 16);
						array3[4] = (byte)unchecked((array[1] ^ array2[0]) % 16);
					}
					num = ((int)num2 * -24587695) ^ 0x6BBEA6A6;
					continue;
				case 5u:
				{
					int num5;
					int num6;
					if (Delegate17.delegate17_7(string_1) < 10)
					{
						num5 = 1214274734;
						num6 = 1214274734;
					}
					else
					{
						num5 = 1975507991;
						num6 = 1975507991;
					}
					num = num5 ^ (int)(num2 * 1196113891);
					continue;
				}
				case 4u:
					checked
					{
						array2[8 - num4] = (byte)Convert.ToInt32(text.Substring(num4, 1), 16);
						num = -1140244699;
						continue;
					}
				case 3u:
					text2 = Delegate76.delegate76_0(string_0, global::_003CModule_003E.smethod_22<string>(3900288055u, 1128398395u), "");
					num = -1040786543;
					continue;
				case 2u:
					checked
					{
						array[11 - num3] = (byte)Convert.ToInt32(text2.Substring(num3, 1), 16);
						num = -23677029;
						continue;
					}
				case 1u:
					result = "";
					num = -314014458;
					continue;
				case 17u:
					break;
				default:
					return result;
				}
				break;
			}
		}
	}

	public static string smethod_7(string string_0)
	{
		string[] array = new string[7];
		while (true)
		{
			int num = -1733957036;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x8E916DDEu) % 3)
				{
				case 2u:
					goto IL_0009;
				case 0u:
					break;
				default:
				{
					string text = Delegate72.delegate72_0(Delegate71.delegate71_0(array[5], array[4], array[3]), 16).ToString().PadLeft(7, '0');
					string text2 = text.Substring(checked(text.Length - 7), 7);
					return text2 + Conversions.ToString(smethod_0(Conversions.ToInteger(text2)));
				}
				}
				break;
				IL_0009:
				array = Delegate70.smethod_0((object)string_0, new char[1] { ':' });
				num = (int)(num2 * 1462870540) ^ -975447804;
			}
		}
	}

	public static string[] smethod_8(string string_0)
	{
		string[] array = new string[3]
		{
			global::_003CModule_003E.smethod_21<string>(2188535534u, 6497597u),
			global::_003CModule_003E.smethod_22<string>(1816240832u, 3784492288u),
			global::_003CModule_003E.smethod_21<string>(2188535534u, 4276664113u)
		};
		int num = Delegate72.delegate72_0(Delegate77.delegate77_0(Delegate76.delegate76_0(string_0, global::_003CModule_003E.smethod_19<string>(635370773u, 2239678660u), ""), 6, 6), 16) % 10000000;
		while (true)
		{
			int num2 = -421054485;
			while (true)
			{
				uint num3;
				switch ((num3 = (uint)num2 ^ 0xDB276AFDu) % 4)
				{
				case 3u:
					array[2] = checked(num + 14).ToString(global::_003CModule_003E.smethod_20<string>(3366795561u, 2947295487u));
					array[2] += Conversions.ToString(smethod_0(Conversions.ToInteger(array[2])));
					num2 = (int)(num3 * 180404292) ^ -1151076132;
					continue;
				case 2u:
					array[0] = num.ToString(global::_003CModule_003E.smethod_22<string>(3923758349u, 3086266820u));
					array[0] += Conversions.ToString(smethod_0(Conversions.ToInteger(array[0])));
					array[1] = checked(num + 8).ToString(global::_003CModule_003E.smethod_22<string>(3923758349u, 39527464u));
					array[1] += Conversions.ToString(smethod_0(Conversions.ToInteger(array[1])));
					num2 = ((int)num3 * -153793883) ^ 0x7FB5AAE4;
					continue;
				case 0u:
					break;
				default:
					return array;
				}
				break;
			}
		}
	}

	public static string smethod_9(string string_0, string string_1)
	{
		checked
		{
			string text = (unchecked(Delegate72.delegate72_0(Delegate57.delegate57_1(Delegate77.delegate77_0(Delegate76.delegate76_0(string_0, global::_003CModule_003E.smethod_22<string>(3900288055u, 3840081787u), ""), 6, 4), Delegate77.delegate77_0(string_1, 6, 2)), 16) % 10000000) + 7).ToString(global::_003CModule_003E.smethod_21<string>(1180798111u, 123594019u));
			return (text + Conversions.ToString(smethod_0(Conversions.ToInteger(text)))).PadLeft(7, '0');
		}
	}

	public static string smethod_10(string string_0)
	{
		string object_ = Delegate76.delegate76_0(string_0, global::_003CModule_003E.smethod_19<string>(635370773u, 4055884069u), "");
		string text = default(string);
		int num6 = default(int);
		int num3 = default(int);
		byte[] array2 = default(byte[]);
		int[] array = default(int[]);
		while (true)
		{
			int num = 1891725257;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x635A32DCu) % 14)
				{
				case 13u:
					text = text.ToString().PadLeft(7, '0');
					text = text.Substring(0, 7);
					num = (int)(num2 * 80206123) ^ -2083467859;
					continue;
				case 12u:
					num6 = 0;
					num = ((int)num2 * -1570682947) ^ 0xA65728E;
					continue;
				case 10u:
					text += Conversions.ToString(smethod_0(Conversions.ToInteger(text)));
					num = (int)(num2 * 1347813421) ^ -460376408;
					continue;
				case 9u:
					num6 = checked(num6 + 1);
					num = ((int)num2 * -1440737274) ^ -394176163;
					continue;
				case 8u:
					text = "";
					num3 = 0;
					num = ((int)num2 * -82304380) ^ -1807456430;
					continue;
				case 7u:
				{
					int num7;
					int num8;
					if (num6 <= 7)
					{
						num7 = 528810126;
						num8 = 528810126;
					}
					else
					{
						num7 = 2022840347;
						num8 = 2022840347;
					}
					num = num7 ^ ((int)num2 * -1012420188);
					continue;
				}
				case 5u:
					num3 = checked(num3 + 1);
					num = ((int)num2 * -666838063) ^ -1382358953;
					continue;
				case 4u:
					checked
					{
						array2[num6] = (byte)unchecked(checked(array[unchecked(num6 % 6)] + array[5]) % checked(10 - unchecked(checked(num6 + array[1] + array[2] + array[3] + array[4] + array[5]) % 7)));
						text += array2[num6].ToString(global::_003CModule_003E.smethod_21<string>(1768458028u, 2551065936u));
						num = 1843863983;
						continue;
					}
				case 3u:
					array2 = new byte[8];
					num = (int)(num2 * 849741196) ^ -1292618106;
					continue;
				case 2u:
				{
					int num4;
					int num5;
					if (num3 <= 5)
					{
						num4 = -189245294;
						num5 = -189245294;
					}
					else
					{
						num4 = -341508488;
						num5 = -341508488;
					}
					num = num4 ^ (int)(num2 * 1460739362);
					continue;
				}
				case 1u:
					array = new int[6];
					num = (int)(num2 * 141054996) ^ -1220544877;
					continue;
				case 0u:
					array[num3] = Delegate72.delegate72_0(Delegate77.delegate77_0(object_, checked(num3 * 2), 2), 16);
					num = 595294779;
					continue;
				case 11u:
					break;
				default:
					return text;
				}
				break;
			}
		}
	}

	public static string smethod_11(string string_0)
	{
		ulong num = Delegate79.delegate79_0(Delegate76.delegate76_0(string_0, global::_003CModule_003E.smethod_22<string>(3900288055u, 91601915u), ""), 16);
		checked
		{
			num = (ulong)unchecked((checked((long)num) & 0xFFFFFFL) % 10000000L);
			return Convert.ToUInt64(decimal.Add(decimal.Multiply(new decimal(num), 10m), new decimal(smethod_0(Conversions.ToInteger(num.ToString(global::_003CModule_003E.smethod_18<string>(3936179164u, 4274930200u))))))).ToString(global::_003CModule_003E.smethod_18<string>(4250180449u, 867052282u));
		}
	}

	public static string smethod_12(string string_0)
	{
		ulong num = Delegate79.delegate79_0(Delegate76.delegate76_0(string_0, global::_003CModule_003E.smethod_20<string>(2863696683u, 1614175849u), ""), 16);
		while (true)
		{
			int num2 = 602007825;
			while (true)
			{
				uint num3;
				switch ((num3 = (uint)num2 ^ 0xB793A9Bu) % 3)
				{
				case 1u:
					goto IL_002e;
				case 2u:
					break;
				default:
					return Convert.ToUInt64(decimal.Add(decimal.Multiply(new decimal(num), 10m), new decimal(smethod_0(Conversions.ToInteger(num.ToString(global::_003CModule_003E.smethod_21<string>(1180798111u, 3734851343u))))))).ToString(global::_003CModule_003E.smethod_19<string>(2546799666u, 2367802944u));
				}
				break;
				IL_002e:
				checked
				{
					num = (ulong)unchecked((checked((long)num) & 0xFFFFFFFL) % 10000000L);
				}
				num2 = (int)((num3 * 1202885421) ^ 0x2BCB14E0);
			}
		}
	}

	public static string smethod_13(string string_0)
	{
		ulong value = Delegate79.delegate79_0(Delegate76.delegate76_0(string_0, global::_003CModule_003E.smethod_19<string>(635370773u, 1356292773u), ""), 16);
		value = Convert.ToUInt64(decimal.Remainder(decimal.Remainder(new decimal(value), 4294967296m), 10000000m));
		return Convert.ToUInt64(decimal.Add(decimal.Multiply(new decimal(value), 10m), new decimal(smethod_0(Conversions.ToInteger(value.ToString(global::_003CModule_003E.smethod_22<string>(3923758349u, 656397142u))))))).ToString(global::_003CModule_003E.smethod_20<string>(1142616664u, 295509780u));
	}

	public static string smethod_14(string string_0)
	{
		ulong value = Delegate79.delegate79_0(Delegate76.delegate76_0(string_0, global::_003CModule_003E.smethod_20<string>(2863696683u, 3191670566u), ""), 16);
		value = Convert.ToUInt64(decimal.Remainder(decimal.Remainder(new decimal(value), 68719476736m), 10000000m));
		return Convert.ToUInt64(decimal.Add(decimal.Multiply(new decimal(value), 10m), new decimal(smethod_0(Conversions.ToInteger(value.ToString(global::_003CModule_003E.smethod_22<string>(3923758349u, 1860607188u))))))).ToString(global::_003CModule_003E.smethod_22<string>(1816240832u, 1464141800u));
	}

	public static string smethod_15(string string_0)
	{
		ulong value = Delegate79.delegate79_0(Delegate76.delegate76_0(string_0, global::_003CModule_003E.smethod_21<string>(3545203245u, 1813707970u), ""), 16);
		while (true)
		{
			int num = -1886245791;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xE0ABC91Du) % 3)
				{
				case 2u:
					goto IL_002e;
				case 0u:
					break;
				default:
					return Convert.ToUInt64(decimal.Add(decimal.Multiply(new decimal(value), 10m), new decimal(smethod_0(Conversions.ToInteger(value.ToString(global::_003CModule_003E.smethod_21<string>(1180798111u, 3110954694u))))))).ToString(global::_003CModule_003E.smethod_18<string>(4250180449u, 512702565u));
				}
				break;
				IL_002e:
				value = Convert.ToUInt64(decimal.Remainder(decimal.Remainder(new decimal(value), 1099511627776m), 10000000m));
				num = (int)((num2 * 1218760130) ^ 0x2F64EAA0);
			}
		}
	}

	public static string smethod_16(string string_0)
	{
		ulong value = Delegate79.delegate79_0(Delegate76.delegate76_0(string_0, global::_003CModule_003E.smethod_21<string>(3545203245u, 3155022818u), ""), 16);
		value = Convert.ToUInt64(decimal.Remainder(decimal.Remainder(new decimal(value), 17592186044416m), 10000000m));
		return Convert.ToUInt64(decimal.Add(decimal.Multiply(new decimal(value), 10m), new decimal(smethod_0(Conversions.ToInteger(value.ToString(global::_003CModule_003E.smethod_18<string>(3936179164u, 2378995184u))))))).ToString(global::_003CModule_003E.smethod_19<string>(2546799666u, 910933729u));
	}

	public static string smethod_17(string string_0)
	{
		ulong value = Delegate79.delegate79_0(Delegate76.delegate76_0(string_0, global::_003CModule_003E.smethod_22<string>(3900288055u, 2770292313u), ""), 16);
		while (true)
		{
			int num = -2102731137;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xD63EF838u) % 3)
				{
				case 2u:
					goto IL_0031;
				case 0u:
					break;
				default:
					return value.ToString(global::_003CModule_003E.smethod_18<string>(4250180449u, 1228974810u));
				}
				break;
				IL_0031:
				value = Convert.ToUInt64(decimal.Remainder(decimal.Remainder(new decimal(value), 281474976710656m), 10000000m));
				value = Convert.ToUInt64(decimal.Add(decimal.Multiply(new decimal(value), 10m), new decimal(smethod_0(Conversions.ToInteger(value.ToString(global::_003CModule_003E.smethod_21<string>(1180798111u, 776844802u)))))));
				num = (int)(num2 * 333607080) ^ -1177614034;
			}
		}
	}

	public static string smethod_18(string string_0)
	{
		ulong num = 0uL;
		string[] array = new string[7];
		while (true)
		{
			int num2 = 294222073;
			while (true)
			{
				uint num3;
				switch ((num3 = (uint)num2 ^ 0x2C21C15Fu) % 3)
				{
				case 1u:
					goto IL_0013;
				case 0u:
					break;
				default:
					num = Delegate79.delegate79_0(Delegate71.delegate71_0(array[5], array[4], array[3]), 16);
					num = Convert.ToUInt64(decimal.Remainder(new decimal(num), 10000000m));
					return num.ToString(global::_003CModule_003E.smethod_21<string>(3182507491u, 1322174498u)) + smethod_0(checked((int)num));
				}
				break;
				IL_0013:
				array = Delegate70.smethod_0((object)string_0, new char[1] { ':' });
				num2 = (int)((num3 * 1377374302) ^ 0x7C54DB54);
			}
		}
	}

	public static string smethod_19(string string_0)
	{
		ulong num = 0uL;
		while (true)
		{
			int num2 = 1018875153;
			while (true)
			{
				uint num3;
				switch ((num3 = (uint)num2 ^ 0x1433364Bu) % 4)
				{
				case 3u:
					num = Convert.ToUInt64(decimal.Remainder(new decimal(num), 10000000m));
					num2 = ((int)num3 * -104980862) ^ -512687240;
					continue;
				case 2u:
				{
					string[] array = new string[7];
					array = Delegate70.smethod_0((object)string_0, new char[1] { ':' });
					num = Delegate79.delegate79_0(Delegate80.delegate80_0(array[5], array[4], array[3], array[2]), 16);
					num2 = ((int)num3 * -1477486492) ^ -575839956;
					continue;
				}
				case 0u:
					break;
				default:
					return num.ToString(global::_003CModule_003E.smethod_20<string>(3716503941u, 3846306939u)) + smethod_0(checked((int)num));
				}
				break;
			}
		}
	}

	public static string smethod_20(string string_0)
	{
		ulong value = 0uL;
		string[] array = new string[7];
		while (true)
		{
			int num = 347302461;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x5ACEE167u) % 4)
				{
				case 2u:
					array = Delegate70.smethod_0((object)string_0, new char[1] { ':' });
					num = ((int)num2 * -1496227990) ^ 0x2515A086;
					continue;
				case 1u:
					value = Delegate79.smethod_0(Delegate37.smethod_0(new string[6]
					{
						array[5],
						array[4],
						array[3],
						array[2],
						array[1],
						array[0]
					}), 16);
					num = ((int)num2 * -1988409994) ^ 0x67A58186;
					continue;
				case 0u:
					break;
				default:
					value = Convert.ToUInt64(decimal.Remainder(new decimal(value), 10000000m));
					return value.ToString(global::_003CModule_003E.smethod_18<string>(4146555432u, 2063820922u)) + smethod_0(checked((int)value));
				}
				break;
			}
		}
	}

	public static string smethod_21(string string_0)
	{
		return Delegate81.delegate81_1(Delegate81.delegate81_0(string_0));
	}

	public static string smethod_22(string string_0)
	{
		return Delegate81.delegate81_2(Delegate81.delegate81_0(string_0));
	}

	public static string smethod_23(string string_0)
	{
		return Delegate81.delegate81_3(Delegate81.delegate81_0(string_0));
	}

	private static string smethod_24(string string_0)
	{
		string[] array = new string[7];
		int num3 = default(int);
		while (true)
		{
			int num = 1772344294;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x2EFBB261u) % 6)
				{
				case 5u:
				{
					int num4;
					int num5;
					if (num3 <= 5)
					{
						num4 = 1525672788;
						num5 = 1525672788;
					}
					else
					{
						num4 = 1746097711;
						num5 = 1746097711;
					}
					num = num4 ^ ((int)num2 * -996695620);
					continue;
				}
				case 3u:
					array[num3] = string.Join("", array[num3].Reverse());
					num3 = checked(num3 + 1);
					num = 1658707438;
					continue;
				case 2u:
					num3 = 0;
					num = (int)((num2 * 1966736139) ^ 0x699F59D4);
					continue;
				case 1u:
					array = Delegate70.smethod_0((object)string_0, new char[1] { ':' });
					num = ((int)num2 * -1663154352) ^ -512800931;
					continue;
				case 4u:
					break;
				default:
					return Delegate11.delegate11_1(global::_003CModule_003E.smethod_21<string>(3545203245u, 3376777788u), array);
				}
				break;
			}
		}
	}

	public static string smethod_25(GClass9 gclass9_0, GEnum0 genum0_0)
	{
		string result = "";
		GEnum0 gEnum = default(GEnum0);
		while (true)
		{
			int num = 173307285;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x4FFB5313u) % 37)
				{
				case 36u:
					result = Delegate81.delegate81_2(Delegate15.delegate15_9(gclass9_0));
					num = 1287534061;
					continue;
				case 35u:
					goto IL_002b;
				case 34u:
					goto IL_004b;
				case 33u:
					goto IL_0076;
				case 32u:
					num = (int)(num2 * 1108861689) ^ -124061631;
					continue;
				case 31u:
					goto IL_0098;
				case 30u:
					goto IL_00c2;
				case 29u:
					goto IL_00e2;
				case 28u:
					gEnum = genum0_0;
					num = (int)((num2 * 919226457) ^ 0x6F1C54C3);
					continue;
				case 27u:
					goto IL_0116;
				case 26u:
					goto IL_0136;
				case 25u:
					goto IL_0156;
				case 24u:
					num = (int)(num2 * 1534987639) ^ -750037989;
					continue;
				case 23u:
					num = (int)((num2 * 251803261) ^ 0x3671A95C);
					continue;
				case 22u:
					num = ((int)num2 * -261121351) ^ 0x5E65124B;
					continue;
				case 21u:
					goto IL_01ac;
				case 20u:
					goto IL_01cc;
				case 19u:
					goto IL_01ec;
				case 18u:
					num = ((int)num2 * -1686182375) ^ -2079196614;
					continue;
				case 17u:
					num = (int)(num2 * 706104338) ^ -312759187;
					continue;
				case 15u:
					num = ((int)num2 * -1905096801) ^ -1866849282;
					continue;
				case 14u:
					goto IL_0242;
				case 13u:
					goto IL_0262;
				case 12u:
					num = ((int)num2 * -417723820) ^ 0x20977FD9;
					continue;
				case 11u:
					num = ((int)num2 * -1831180848) ^ -676628635;
					continue;
				case 10u:
					num = ((int)num2 * -1787398691) ^ -547727566;
					continue;
				case 9u:
					switch (gEnum)
					{
					case GEnum0.d32rhbit:
						break;
					case GEnum0.d32bit:
						goto IL_002b;
					case GEnum0.FTE:
						goto IL_004b;
					case GEnum0.PinNull:
						goto IL_0076;
					case GEnum0.dLINK:
						goto IL_0098;
					case GEnum0.Asus:
						goto IL_00c2;
					case GEnum0.d28bit:
						goto IL_00e2;
					case GEnum0.AiroConru:
						goto IL_0116;
					case GEnum0.d32rnbit:
						goto IL_0136;
					case GEnum0.d24rnbit:
						goto IL_0156;
					case GEnum0.d44bit:
						goto IL_01ac;
					case GEnum0.d40bit:
						goto IL_01cc;
					case GEnum0.d24rhbit:
						goto IL_01ec;
					case GEnum0.TrendNet:
						goto IL_0242;
					case GEnum0.EasyBox:
						goto IL_0262;
					default:
						goto IL_0316;
					case GEnum0.ZAO:
						goto IL_0328;
					case GEnum0.LiveBox:
						goto IL_0348;
					case GEnum0.d36bit:
						goto IL_0373;
					case GEnum0.d48bit:
						goto IL_0390;
					case GEnum0.d48rhbit:
						goto IL_03ad;
					case GEnum0.d48rnbit:
						goto IL_03ca;
					case (GEnum0)9:
						goto IL_04b3;
					}
					goto case 36u;
				case 8u:
					goto IL_0328;
				case 1u:
					goto IL_0348;
				case 0u:
					goto IL_0373;
				case 6u:
					goto IL_0390;
				case 3u:
					goto IL_03ad;
				case 2u:
					goto IL_03ca;
				case 7u:
					num = ((int)num2 * -1246856856) ^ -2029747611;
					continue;
				case 5u:
					num = ((int)num2 * -1544269118) ^ 0x13134567;
					continue;
				case 16u:
					break;
				default:
					goto IL_04b3;
					IL_04b3:
					return result;
					IL_03ca:
					result = Delegate81.delegate81_17(Delegate15.delegate15_9(gclass9_0));
					num = 1548166173;
					continue;
					IL_03ad:
					result = Delegate81.delegate81_3(Delegate15.delegate15_9(gclass9_0));
					num = 1065838421;
					continue;
					IL_0390:
					result = Delegate81.delegate81_14(Delegate15.delegate15_9(gclass9_0));
					num = 353451118;
					continue;
					IL_0373:
					result = Delegate81.delegate81_11(Delegate15.delegate15_9(gclass9_0));
					num = 983277004;
					continue;
					IL_0348:
					result = Delegate57.delegate57_3(Delegate15.delegate15_9(gclass9_0), Delegate15.delegate15_11(gclass9_0));
					num = 1065838421;
					continue;
					IL_0328:
					result = Delegate81.delegate81_4(Delegate15.delegate15_9(gclass9_0));
					num = 861016497;
					continue;
					IL_0316:
					num = ((int)num2 * -147114730) ^ -1238352477;
					continue;
					IL_0262:
					result = Delegate81.delegate81_6(Delegate15.delegate15_9(gclass9_0));
					num = 362491055;
					continue;
					IL_0242:
					result = Delegate81.delegate81_5(Delegate15.delegate15_9(gclass9_0));
					num = 1065838421;
					continue;
					IL_01ec:
					result = Delegate81.delegate81_1(Delegate15.delegate15_9(gclass9_0));
					num = 1065838421;
					continue;
					IL_01cc:
					result = Delegate81.delegate81_12(Delegate15.delegate15_9(gclass9_0));
					num = 1065838421;
					continue;
					IL_01ac:
					result = Delegate81.delegate81_13(Delegate15.delegate15_9(gclass9_0));
					num = 1047610470;
					continue;
					IL_0156:
					result = Delegate81.delegate81_15(Delegate15.delegate15_9(gclass9_0));
					num = 1065838421;
					continue;
					IL_0136:
					result = Delegate81.delegate81_16(Delegate15.delegate15_9(gclass9_0));
					num = 1065838421;
					continue;
					IL_0116:
					result = Delegate81.delegate81_7(Delegate15.delegate15_9(gclass9_0));
					num = 1065838421;
					continue;
					IL_00e2:
					result = Delegate81.delegate81_9(Delegate15.delegate15_9(gclass9_0));
					num = 265065428;
					continue;
					IL_00c2:
					result = Delegate81.delegate81_8(Delegate15.delegate15_9(gclass9_0));
					num = 447542784;
					continue;
					IL_0098:
					result = Delegate15.delegate15_2(Delegate12.delegate12_3(Delegate15.delegate15_9(gclass9_0)));
					num = 1352350122;
					continue;
					IL_0076:
					result = Delegate36.smethod_0();
					num = 1065838421;
					continue;
					IL_004b:
					result = Delegate57.delegate57_2(Delegate15.delegate15_9(gclass9_0), Delegate15.delegate15_10(gclass9_0));
					num = 1241283780;
					continue;
					IL_002b:
					result = Delegate81.delegate81_10(Delegate15.delegate15_9(gclass9_0));
					num = 1065838421;
					continue;
				}
				break;
			}
		}
	}

	public static string smethod_26(ref GClass9 gclass9_0, string string_0)
	{
		return Delegate81.delegate81_18(Delegate57.delegate57_1(Delegate71.delegate71_0(Delegate71.delegate71_0(Delegate71.delegate71_0(Delegate71.delegate71_0(Delegate71.delegate71_0(Delegate71.delegate71_0(Delegate57.delegate57_1(global::_003CModule_003E.smethod_19<string>(2903423562u, 3915874552u), Delegate15.delegate15_12(gclass9_0)), global::_003CModule_003E.smethod_18<string>(1555930007u, 512483544u), Delegate15.delegate15_13(gclass9_0)), global::_003CModule_003E.smethod_19<string>(4020339654u, 2637482469u), Delegate15.delegate15_14(gclass9_0)), global::_003CModule_003E.smethod_21<string>(1362145988u, 8322420u), Delegate15.delegate15_15(gclass9_0)), global::_003CModule_003E.smethod_19<string>(842288450u, 950977849u), Delegate15.delegate15_16(gclass9_0)), global::_003CModule_003E.smethod_18<string>(2901492111u, 1936941493u), Delegate15.delegate15_17(gclass9_0)), global::_003CModule_003E.smethod_20<string>(1532723364u, 520326698u), Delegate15.delegate15_18(gclass9_0)), string_0));
	}

	public static string smethod_27(string string_0)
	{
		Process process_ = (Process)Delegate3.delegate3_44();
		return Delegate82.delegate82_0(string_0, ref process_);
	}

	public static string smethod_28(string string_0, ref Process process_0)
	{
		WaitSplashProcess waitSplashProcess = (WaitSplashProcess)Delegate24.delegate24_1(Delegate7.delegate7_84(Delegate7.delegate7_0(Delegate3.delegate3_1())), Delegate36.delegate36_6());
		Process process = default(Process);
		DateTime dateTime_ = default(DateTime);
		while (true)
		{
			int num = -1121376685;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xA028E494u) % 16)
				{
				case 15u:
				{
					int num10;
					if (!process.HasExited)
					{
						num = -424484038;
						num10 = -424484038;
					}
					else
					{
						num = -1968160233;
						num10 = -1968160233;
					}
					continue;
				}
				case 14u:
				{
					Delegate51.smethod_0();
					int num7;
					if (Delegate84.delegate84_0(Delegate64.delegate64_0(), dateTime_).TotalSeconds <= 2.0)
					{
						num = -851868981;
						num7 = -851868981;
					}
					else
					{
						num = -2025368564;
						num7 = -2025368564;
					}
					continue;
				}
				case 13u:
					num = (int)((num2 * 811234909) ^ 0x78B6C25C);
					continue;
				case 11u:
					waitSplashProcess.Refresh();
					num = -851868981;
					continue;
				case 10u:
				{
					int num5;
					int num6;
					if (waitSplashProcess.IsDisposed)
					{
						num5 = 189541920;
						num6 = 189541920;
					}
					else
					{
						num5 = 1367948805;
						num6 = 1367948805;
					}
					num = num5 ^ (int)(num2 * 1040508908);
					continue;
				}
				case 9u:
					waitSplashProcess.Dispose();
					num = (int)((num2 * 1688963047) ^ 0x29930767);
					continue;
				case 8u:
				{
					int num8;
					int num9;
					if (waitSplashProcess.IsDisposed)
					{
						num8 = -1415310151;
						num9 = -1415310151;
					}
					else
					{
						num8 = -1807023368;
						num9 = -1807023368;
					}
					num = num8 ^ ((int)num2 * -365393503);
					continue;
				}
				case 7u:
					process = process_0;
					Delegate8.delegate8_100(process, Delegate83.delegate83_0(global::_003CModule_003E.smethod_21<string>(955833948u, 3887228240u), string_0));
					num = (int)((num2 * 566727272) ^ 0x749680DC);
					continue;
				case 5u:
					process.Kill();
					num = -851868981;
					continue;
				case 4u:
				{
					int num3;
					int num4;
					if (waitSplashProcess.Visible)
					{
						num3 = 1993305831;
						num4 = 1993305831;
					}
					else
					{
						num3 = 1458789918;
						num4 = 1458789918;
					}
					num = num3 ^ ((int)num2 * -1991924878);
					continue;
				}
				case 3u:
					process = null;
					num = ((int)num2 * -553003233) ^ -136199645;
					continue;
				case 2u:
					waitSplashProcess.Show();
					num = ((int)num2 * -287114662) ^ 0x6CA36BBB;
					continue;
				case 1u:
					dateTime_ = Delegate64.delegate64_0();
					Delegate21.delegate21_6(process);
					num = ((int)num2 * -1387319039) ^ 0x16332E4A;
					continue;
				case 0u:
				{
					object object_ = Delegate7.delegate7_85(process);
					Delegate5.smethod_0(object_, bool_0: true);
					Delegate5.smethod_1(object_, bool_0: false);
					Delegate5.smethod_2(object_, bool_0: true);
					num = ((int)num2 * -864515729) ^ -132699335;
					continue;
				}
				case 6u:
					break;
				default:
					return process_0.StandardOutput.ReadToEnd();
				}
				break;
			}
		}
	}
}
