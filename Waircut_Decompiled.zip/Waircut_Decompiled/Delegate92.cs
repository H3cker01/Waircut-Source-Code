internal delegate byte[] Delegate92(string string_0);
