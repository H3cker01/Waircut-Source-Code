internal delegate byte[] Delegate67(object object_0);
