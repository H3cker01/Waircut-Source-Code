internal delegate string Delegate143(GEnum16 genum16_0);
