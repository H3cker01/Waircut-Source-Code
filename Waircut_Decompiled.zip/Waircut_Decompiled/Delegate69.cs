internal delegate double Delegate69(double double_0);
