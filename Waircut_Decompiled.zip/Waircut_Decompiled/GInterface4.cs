using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[ComImport]
[CompilerGenerated]
[InterfaceType(1)]
[Guid("0AC1AF15-ED13-4E43-966C-9D838C6F6B97")]
[TypeIdentifier]
public interface GInterface4
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void OnJswApiTraceMessage([In] int threadID, [In][MarshalAs(UnmanagedType.BStr)] string message);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void OnJswApiEvent([In] GEnum8 @event, [In][MarshalAs(UnmanagedType.BStr)] string evtString);
}
