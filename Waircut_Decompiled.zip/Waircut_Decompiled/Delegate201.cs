using System;

internal delegate void Delegate201(string string_0, DateTime dateTime_0);
