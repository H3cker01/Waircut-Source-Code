internal delegate object Delegate154(string string_0, GClass3.GEnum0 genum0_0, object object_0);
