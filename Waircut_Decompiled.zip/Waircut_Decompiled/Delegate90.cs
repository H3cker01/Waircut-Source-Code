using System.Security.Cryptography;

internal delegate object Delegate90(object object_0, object object_1, CryptoStreamMode cryptoStreamMode_0);
