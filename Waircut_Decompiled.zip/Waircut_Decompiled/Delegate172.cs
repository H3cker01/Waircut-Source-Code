internal delegate string Delegate172(char char_0);
