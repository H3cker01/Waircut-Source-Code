internal delegate string Delegate73(int int_0);
