using System.Runtime.CompilerServices;
using System.Threading;
using ns1;

public class GClass6 : GInterface9
{
	public delegate void GDelegate2(GEnum17 @event, int evtData, string evtString, string message);

	public string string_0;

	[CompilerGenerated]
	private GDelegate2 gdelegate2_0;

	public event GDelegate2 Event_0
	{
		[CompilerGenerated]
		add
		{
			GDelegate2 gDelegate = gdelegate2_0;
			GDelegate2 gDelegate2 = default(GDelegate2);
			while (true)
			{
				int num = -2111166053;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xA1F5612Bu) % 5)
					{
					case 3u:
					{
						int num3;
						int num4;
						if ((object)gDelegate == gDelegate2)
						{
							num3 = -526857957;
							num4 = -526857957;
						}
						else
						{
							num3 = -2144651469;
							num4 = -2144651469;
						}
						num = num3 ^ ((int)num2 * -2014725367);
						continue;
					}
					case 1u:
						gDelegate2 = gDelegate;
						num = -558567638;
						continue;
					case 0u:
					{
						GDelegate2 value2 = (GDelegate2)Delegate95.delegate95_0(gDelegate2, value);
						gDelegate = Interlocked.CompareExchange(ref gdelegate2_0, value2, gDelegate2);
						num = (int)((num2 * 198988161) ^ 0x6C3275C2);
						continue;
					}
					default:
						return;
					case 2u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
		[CompilerGenerated]
		remove
		{
			GDelegate2 gDelegate = gdelegate2_0;
			GDelegate2 gDelegate2 = default(GDelegate2);
			GDelegate2 value2 = default(GDelegate2);
			while (true)
			{
				int num = 1480951369;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x313653B0u) % 5)
					{
					case 2u:
						gDelegate2 = gDelegate;
						value2 = (GDelegate2)Delegate95.delegate95_1(gDelegate2, value);
						num = 1815298977;
						continue;
					case 1u:
						gDelegate = Interlocked.CompareExchange(ref gdelegate2_0, value2, gDelegate2);
						num = ((int)num2 * -1582282117) ^ -14087860;
						continue;
					case 0u:
					{
						int num3;
						int num4;
						if ((object)gDelegate != gDelegate2)
						{
							num3 = -135630348;
							num4 = -135630348;
						}
						else
						{
							num3 = -272842212;
							num4 = -272842212;
						}
						num = num3 ^ ((int)num2 * -1550869109);
						continue;
					}
					default:
						return;
					case 3u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	public GClass6()
	{
		string_0 = "";
	}

	void GInterface9.OnJswSupplicantEvent(GEnum17 @event, int evtData, string evtString)
	{
		GEnum16 gEnum = default(GEnum16);
		GDelegate2 gDelegate = default(GDelegate2);
		while (true)
		{
			int num = 1140272532;
			while (true)
			{
				uint num2;
				ref string reference;
				ref string reference2;
				ref string reference5;
				ref string reference6;
				ref string reference7;
				ref string reference8;
				GEnum16 gEnum2;
				ref string reference9;
				switch ((num2 = (uint)num ^ 0x49CF2ED2u) % 21)
				{
				case 20u:
				{
					ref string reference4 = ref string_0;
					reference4 = Delegate57.delegate57_1(reference4, global::_003CModule_003E.smethod_21<string>(4162713982u, 3652107649u));
					num = 1899234281;
					continue;
				}
				case 19u:
				{
					ref string reference3 = ref string_0;
					reference3 = Delegate80.delegate80_0(reference3, global::_003CModule_003E.smethod_20<string>(710847112u, 920594747u), gEnum.ToString(), global::_003CModule_003E.smethod_18<string>(2151107120u, 905175484u));
					num = ((int)num2 * -331484492) ^ 0x39ECD4E9;
					continue;
				}
				case 18u:
					goto IL_0088;
				case 17u:
					gDelegate(@event, evtData, evtString, string_0);
					num = (int)(num2 * 1624609229) ^ -859006426;
					continue;
				case 16u:
					goto IL_00b7;
				case 14u:
					num = ((int)num2 * -2039778196) ^ -775529539;
					continue;
				case 12u:
					goto IL_0116;
				case 11u:
					num = ((int)num2 * -225814641) ^ 0x592CF446;
					continue;
				case 10u:
					goto IL_0157;
				case 9u:
					goto IL_0185;
				case 8u:
					goto IL_01b3;
				case 7u:
				{
					int num3;
					int num4;
					if (gDelegate == null)
					{
						num3 = 277609125;
						num4 = 277609125;
					}
					else
					{
						num3 = 1541290077;
						num4 = 1541290077;
					}
					num = num3 ^ ((int)num2 * -1836255852);
					continue;
				}
				case 6u:
					gDelegate = gdelegate2_0;
					num = 1572735522;
					continue;
				case 5u:
					num = ((int)num2 * -875926803) ^ 0x58A890CE;
					continue;
				case 4u:
					goto IL_022f;
				case 3u:
					num = ((int)num2 * -44599922) ^ -1992876115;
					continue;
				case 2u:
					num = ((int)num2 * -2134005459) ^ 0x4B0BA292;
					continue;
				case 1u:
					switch (@event)
					{
					case GEnum17.JswSuppEvt_ProtocolFailure:
						break;
					case GEnum17.JswSuppEvt_SentMessage:
						goto IL_0088;
					case GEnum17.JswSuppEvt_ReceivedMessage:
						goto IL_00b7;
					case GEnum17.JswSuppEvt_ProtocolWillSucceed:
						goto IL_0116;
					case GEnum17.JswSuppEvt_None:
						goto IL_0157;
					case GEnum17.JswSuppEvt_ProtocolFailurePIN:
						goto IL_0185;
					case GEnum17.JswSuppEvt_ReceivedCredentials:
						goto IL_01b3;
					case GEnum17.JswSuppEvt_ProtocolSuccess:
						goto IL_022f;
					default:
						goto IL_02a7;
					case GEnum17.JswSuppEvt_ProtocolFailureTimeout:
						goto IL_02b7;
					}
					goto case 20u;
				case 0u:
					goto IL_02b7;
				default:
					return;
				case 15u:
					break;
				case 13u:
					return;
					IL_02b7:
					reference = ref string_0;
					reference = Delegate57.delegate57_1(reference, global::_003CModule_003E.smethod_18<string>(1815774108u, 115493221u));
					num = 1791578717;
					continue;
					IL_02a7:
					num = ((int)num2 * -1260349545) ^ 0x236558DF;
					continue;
					IL_022f:
					reference2 = ref string_0;
					reference2 = Delegate57.delegate57_1(reference2, global::_003CModule_003E.smethod_22<string>(646154198u, 2428774638u));
					num = 1899234281;
					continue;
					IL_0088:
					gEnum = (GEnum16)evtData;
					num = 3222034;
					continue;
					IL_01b3:
					reference5 = ref string_0;
					reference5 = Delegate57.delegate57_1(reference5, global::_003CModule_003E.smethod_20<string>(582389431u, 474745586u));
					num = 1899234281;
					continue;
					IL_0185:
					reference6 = ref string_0;
					reference6 = Delegate57.delegate57_1(reference6, global::_003CModule_003E.smethod_21<string>(411790317u, 112037847u));
					num = 786129715;
					continue;
					IL_0157:
					reference7 = ref string_0;
					reference7 = Delegate57.delegate57_1(reference7, global::_003CModule_003E.smethod_19<string>(2085919908u, 1231631077u));
					num = 1899234281;
					continue;
					IL_0116:
					reference8 = ref string_0;
					reference8 = Delegate57.delegate57_1(reference8, global::_003CModule_003E.smethod_22<string>(4102332477u, 1643059953u));
					num = 536707100;
					continue;
					IL_00b7:
					gEnum2 = (GEnum16)evtData;
					reference9 = ref string_0;
					reference9 = Delegate80.delegate80_0(reference9, global::_003CModule_003E.smethod_21<string>(1906189619u, 278097796u), gEnum2.ToString(), global::_003CModule_003E.smethod_19<string>(2282670531u, 3301787648u));
					num = 1839218993;
					continue;
				}
				break;
			}
		}
	}
}
