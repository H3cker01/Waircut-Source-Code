internal delegate string Delegate18(object object_0, string string_0, object object_1);
