using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[ComImport]
[CompilerGenerated]
[InterfaceType(1)]
[Guid("F170B8DD-13A9-456B-B10B-04430660A0D2")]
[TypeIdentifier]
public interface GInterface8
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void OnJswEngineEvent([In] GEnum14 @event, [In] int evtData, [In][MarshalAs(UnmanagedType.BStr)] string evtString);
}
