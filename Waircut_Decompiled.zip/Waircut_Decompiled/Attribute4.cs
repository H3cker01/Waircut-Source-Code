using System;

internal class Attribute4 : Attribute
{
	internal readonly int int_0;

	internal Attribute4(int int_1)
	{
		while (true)
		{
			int num = 50828003;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xEDAAA97u) % 3)
				{
				case 1u:
					goto IL_0008;
				default:
					return;
				case 2u:
					break;
				case 0u:
					return;
				}
				break;
				IL_0008:
				int_0 = ~int_1 ^ 0x92D5B10 ^ 0x57EB4C57;
				num = ((int)num2 * -2025068490) ^ 0x668E38B8;
			}
		}
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
