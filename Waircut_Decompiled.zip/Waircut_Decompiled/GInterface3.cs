using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[ComImport]
[CompilerGenerated]
[Guid("6C2216B4-6018-42B9-866B-2F795BD61B66")]
[TypeIdentifier]
public interface GInterface3
{
	void _VtblGap1_1();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void imethod_0();

	void _VtblGap2_3();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	[return: MarshalAs(UnmanagedType.Interface)]
	GInterface13 imethod_1();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	[return: MarshalAs(UnmanagedType.Interface)]
	GInterface11 imethod_2([In][MarshalAs(UnmanagedType.Interface)] GInterface12 ginterface12_0);

	void _VtblGap3_2();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	[return: MarshalAs(UnmanagedType.Interface)]
	GInterface7 imethod_3([In] GEnum15 genum15_0, [In][MarshalAs(UnmanagedType.Interface)] GInterface11 ginterface11_0, [In][MarshalAs(UnmanagedType.Interface)] GInterface10 ginterface10_0);
}
