using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
[TypeIdentifier("c9178c19-99cf-4f6d-85c6-3ef5a176f9fb", "JSWSCAPILib.JswSupplicantEvent")]
public enum GEnum17
{
	JswSuppEvt_None,
	JswSuppEvt_ReceivedCredentials,
	JswSuppEvt_ProtocolSuccess,
	JswSuppEvt_ProtocolFailure,
	JswSuppEvt_ProtocolFailurePIN,
	JswSuppEvt_ProtocolFailureTimeout,
	JswSuppEvt_ReceivedMessage,
	JswSuppEvt_SentMessage,
	JswSuppEvt_ProtocolWillSucceed
}
