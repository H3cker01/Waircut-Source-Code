internal delegate object Delegate94(byte[] byte_0);
