using System.Diagnostics;

internal delegate string Delegate82(string string_0, ref Process process_0);
