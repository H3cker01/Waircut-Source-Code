internal delegate void Delegate145(object object_0, ref GInterface5 ginterface5_0, GEnum16 genum16_0);
