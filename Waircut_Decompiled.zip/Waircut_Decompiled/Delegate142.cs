internal delegate string Delegate142(string string_0, object[] object_0);
