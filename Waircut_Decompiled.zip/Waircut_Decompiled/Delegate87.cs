using System;

internal delegate object Delegate87(Array array_0, Array array_1);
