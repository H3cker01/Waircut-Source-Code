internal delegate double Delegate171(string string_0);
