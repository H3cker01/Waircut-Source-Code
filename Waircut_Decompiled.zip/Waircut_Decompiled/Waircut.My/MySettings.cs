using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic.ApplicationServices;
using ns0;

namespace Waircut.My;

[CompilerGenerated]
[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "14.0.0.0")]
[EditorBrowsable(EditorBrowsableState.Advanced)]
internal sealed class MySettings : ApplicationSettingsBase
{
	private static MySettings mySettings_0 = (MySettings)Delegate20.delegate20_0((SettingsBase)Delegate3.delegate3_5());

	private static bool bool_0;

	private static object object_0;

	public static MySettings Default
	{
		get
		{
			if (!bool_0)
			{
				object obj = default(object);
				while (true)
				{
					int num = 148067132;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x55ECC1C9u) % 4)
						{
						case 1u:
							obj = object_0;
							num = (int)((num2 * 1099198141) ^ 0x1C02E420);
							continue;
						case 0u:
							Delegate22.delegate22_1(obj);
							num = ((int)num2 * -66982635) ^ -729777201;
							continue;
						case 3u:
							break;
						default:
							goto end_IL_005a;
						}
						break;
					}
					continue;
					end_IL_005a:
					break;
				}
				bool flag = false;
				try
				{
					Delegate23.delegate23_0(obj, ref flag);
					while (true)
					{
						IL_0104:
						int num3 = 1755601521;
						while (true)
						{
							uint num2;
							switch ((num2 = (uint)num3 ^ 0x55ECC1C9u) % 5)
							{
							case 4u:
								bool_0 = true;
								num3 = (int)(num2 * 153349932) ^ -1215393398;
								continue;
							case 2u:
							{
								int num4;
								int num5;
								if (bool_0)
								{
									num4 = 448318922;
									num5 = 448318922;
								}
								else
								{
									num4 = 1265110399;
									num5 = 1265110399;
								}
								num3 = num4 ^ (int)(num2 * 1995050296);
								continue;
							}
							case 1u:
								Delegate8.delegate8_2(Delegate3.delegate3_0(), (ShutdownEventHandler)([DebuggerNonUserCode] [EditorBrowsable(EditorBrowsableState.Advanced)] (object sender, EventArgs e) =>
								{
									if (Delegate21.delegate21_0(Delegate3.delegate3_0()))
									{
										while (true)
										{
											int num7 = -1210727517;
											while (true)
											{
												uint num8;
												switch ((num8 = (uint)num7 ^ 0xF63D2AEEu) % 3)
												{
												case 1u:
													goto IL_0018;
												default:
													return;
												case 2u:
													break;
												case 0u:
													return;
												}
												break;
												IL_0018:
												Delegate22.delegate22_0(Delegate3.delegate3_7());
												num7 = ((int)num8 * -1157102208) ^ -442168053;
											}
										}
									}
								}));
								num3 = (int)(num2 * 323116583) ^ -381406285;
								continue;
							default:
								goto end_IL_00df;
							case 3u:
								break;
							case 0u:
								goto end_IL_00df;
							}
							goto IL_0104;
							continue;
							end_IL_00df:
							break;
						}
						break;
					}
				}
				finally
				{
					if (flag)
					{
						while (true)
						{
							IL_0147:
							int num6 = 1667343659;
							while (true)
							{
								uint num2;
								switch ((num2 = (uint)num6 ^ 0x55ECC1C9u) % 3)
								{
								case 2u:
									goto IL_0112;
								default:
									goto end_IL_012a;
								case 0u:
									break;
								case 1u:
									goto end_IL_012a;
								}
								goto IL_0147;
								IL_0112:
								Delegate22.delegate22_2(obj);
								num6 = ((int)num2 * -1878408139) ^ 0x38662C90;
								continue;
								end_IL_012a:
								break;
							}
							break;
						}
					}
				}
			}
			return mySettings_0;
		}
	}

	[DefaultSettingValue("01/31/2017 21:23:00")]
	[UserScopedSetting]
	[DebuggerNonUserCode]
	public DateTime LastDateNewsWatched
	{
		get
		{
			return Delegate25.delegate25_0(Delegate24.delegate24_0(this, global::_003CModule_003E.smethod_21<string>(485180492u, 3424005585u)));
		}
		set
		{
			Delegate26.delegate26_0(this, global::_003CModule_003E.smethod_22<string>(2581905466u, 1559273569u), value);
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("0")]
	public int ServiceHours
	{
		get
		{
			return Delegate17.delegate17_1(Delegate24.delegate24_0(this, global::_003CModule_003E.smethod_22<string>(2022712788u, 4247649982u)));
		}
		set
		{
			Delegate26.delegate26_0(this, global::_003CModule_003E.smethod_21<string>(3198515914u, 1554430329u), value);
		}
	}

	[DebuggerNonUserCode]
	[DefaultSettingValue("0")]
	[UserScopedSetting]
	public int nRigth
	{
		get
		{
			return Delegate17.delegate17_1(Delegate24.delegate24_0(this, global::_003CModule_003E.smethod_19<string>(2178946018u, 1014671763u)));
		}
		set
		{
			Delegate26.delegate26_0(this, global::_003CModule_003E.smethod_21<string>(1254188286u, 3871125707u), value);
		}
	}

	[DefaultSettingValue("0")]
	[UserScopedSetting]
	[DebuggerNonUserCode]
	public int nWrong
	{
		get
		{
			return Delegate17.delegate17_1(Delegate24.delegate24_0(this, global::_003CModule_003E.smethod_19<string>(3744980767u, 131876253u)));
		}
		set
		{
			Delegate26.delegate26_0(this, global::_003CModule_003E.smethod_21<string>(3379863791u, 3338979392u), value);
		}
	}

	[DebuggerNonUserCode]
	[DefaultSettingValue("01/31/1990 21:42:00")]
	[UserScopedSetting]
	public DateTime LastDateOnlineNews
	{
		get
		{
			return Delegate25.delegate25_0(Delegate24.delegate24_0(this, global::_003CModule_003E.smethod_21<string>(3967523708u, 3463798619u)));
		}
		set
		{
			Delegate26.delegate26_0(this, global::_003CModule_003E.smethod_22<string>(3954036522u, 3091680352u), value);
		}
	}

	[DefaultSettingValue("")]
	[UserScopedSetting]
	[DebuggerNonUserCode]
	public string Culture
	{
		get
		{
			return Delegate15.delegate15_2(Delegate24.delegate24_0(this, global::_003CModule_003E.smethod_21<string>(2385891834u, 3721449574u)));
		}
		set
		{
			Delegate26.delegate26_0(this, global::_003CModule_003E.smethod_19<string>(889332854u, 424169089u), value);
		}
	}

	[DebuggerNonUserCode]
	[DefaultSettingValue("False")]
	[UserScopedSetting]
	public bool mbl
	{
		get
		{
			return Delegate21.delegate21_1(Delegate24.delegate24_0(this, global::_003CModule_003E.smethod_18<string>(2667669088u, 2206173758u)));
		}
		set
		{
			Delegate26.delegate26_0(this, global::_003CModule_003E.smethod_19<string>(2800761747u, 3294788547u), value);
		}
	}

	[DefaultSettingValue("2016-02-20")]
	[UserScopedSetting]
	[DebuggerNonUserCode]
	public DateTime StartTime
	{
		get
		{
			return Delegate25.delegate25_0(Delegate24.delegate24_0(this, global::_003CModule_003E.smethod_21<string>(2436390853u, 3181914673u)));
		}
		set
		{
			Delegate26.delegate26_0(this, global::_003CModule_003E.smethod_20<string>(1876433555u, 3196588412u), value);
		}
	}

	[DefaultSettingValue("6")]
	[UserScopedSetting]
	[DebuggerNonUserCode]
	public int ScanTime
	{
		get
		{
			return Delegate17.delegate17_1(Delegate24.delegate24_0(this, global::_003CModule_003E.smethod_21<string>(492063225u, 1019462040u)));
		}
		set
		{
			Delegate26.delegate26_0(this, global::_003CModule_003E.smethod_19<string>(3100174185u, 734878033u), value);
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("01/31/1990 21:42:00")]
	public DateTime LastDBDate
	{
		get
		{
			return Delegate25.delegate25_0(Delegate24.delegate24_0(this, global::_003CModule_003E.smethod_21<string>(1079723142u, 4044702423u)));
		}
		set
		{
			Delegate26.delegate26_0(this, global::_003CModule_003E.smethod_21<string>(1079723142u, 4092366000u), value);
		}
	}

	static MySettings()
	{
		while (true)
		{
			int num = -1486151091;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xB6D43C27u) % 3)
				{
				case 2u:
					goto IL_0020;
				default:
					return;
				case 0u:
					break;
				case 1u:
					return;
				}
				break;
				IL_0020:
				object_0 = Delegate7.delegate7_2(Delegate3.delegate3_6());
				num = (int)(num2 * 1170190286) ^ -334712048;
			}
		}
	}

	[DebuggerNonUserCode]
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	private static void smethod_0(object sender, EventArgs e)
	{
		if (!Delegate21.delegate21_0(Delegate3.delegate3_0()))
		{
			return;
		}
		while (true)
		{
			int num = -1210727517;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xF63D2AEEu) % 3)
				{
				case 1u:
					goto IL_0018;
				default:
					return;
				case 2u:
					break;
				case 0u:
					return;
				}
				break;
				IL_0018:
				Delegate22.delegate22_0(Delegate3.delegate3_7());
				num = ((int)num2 * -1157102208) ^ -442168053;
			}
		}
	}
}
