using System.IO;
using System.Security.Cryptography;
using ns0;

public class GClass4
{
	private TripleDESCryptoServiceProvider tripleDESCryptoServiceProvider_0;

	private byte[] method_0(string string_0, int int_0)
	{
		Delegate87 delegate87_ = Delegate87.delegate87_0;
		Delegate86 delegate86_ = Delegate86.delegate86_0;
		object object_ = Delegate3.delegate3_45();
		byte[] byte_ = Delegate85.delegate85_0(Delegate3.delegate3_46(), string_0);
		return (byte[])delegate87_(delegate86_(object_, byte_), new byte[checked(int_0 - 1 + 1)]);
	}

	public GClass4(string string_0)
	{
		while (true)
		{
			int num = 113468295;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x4AE4EC06u) % 4)
				{
				case 2u:
					Delegate89.delegate89_1(tripleDESCryptoServiceProvider_0, Delegate88.delegate88_0(this, "", Delegate17.delegate17_9(tripleDESCryptoServiceProvider_0) / 8));
					num = (int)((num2 * 734907241) ^ 0x614C9370);
					continue;
				case 1u:
					tripleDESCryptoServiceProvider_0 = (TripleDESCryptoServiceProvider)Delegate3.delegate3_47();
					Delegate89.delegate89_0(tripleDESCryptoServiceProvider_0, Delegate88.delegate88_0(this, string_0, Delegate17.delegate17_8(tripleDESCryptoServiceProvider_0) / 8));
					num = (int)(num2 * 1097998663) ^ -156445853;
					continue;
				default:
					return;
				case 3u:
					break;
				case 0u:
					return;
				}
				break;
			}
		}
	}

	public byte[] method_1(ref byte[] byte_0)
	{
		MemoryStream object_ = (MemoryStream)Delegate3.delegate3_42();
		object object_2 = Delegate90.delegate90_0(object_, Delegate7.delegate7_86(tripleDESCryptoServiceProvider_0), CryptoStreamMode.Write);
		Delegate91.smethod_0(object_2, byte_0, 0, byte_0.Length);
		Delegate22.smethod_0(object_2);
		return Delegate67.delegate67_0(object_);
	}

	public byte[] method_2(ref byte[] byte_0)
	{
		MemoryStream object_ = (MemoryStream)Delegate3.delegate3_42();
		object object_2 = Delegate90.delegate90_0(object_, Delegate7.delegate7_87(tripleDESCryptoServiceProvider_0), CryptoStreamMode.Write);
		Delegate91.smethod_0(object_2, byte_0, 0, byte_0.Length);
		Delegate22.smethod_0(object_2);
		return Delegate67.delegate67_0(object_);
	}

	public MemoryStream method_3(string string_0)
	{
		Delegate94 delegate94_ = Delegate94.delegate94_0;
		Delegate93 delegate93_ = Delegate93.delegate93_0;
		byte[] byte_ = Delegate92.delegate92_0(string_0);
		return (MemoryStream)delegate94_(delegate93_(this, ref byte_));
	}
}
