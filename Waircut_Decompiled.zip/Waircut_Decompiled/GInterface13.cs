using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[ComImport]
[CompilerGenerated]
[Guid("21575140-6672-4DCB-B4B5-4856BD3C91E5")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface GInterface13 : GInterface2
{
}
