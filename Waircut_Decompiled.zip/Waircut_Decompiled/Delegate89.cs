internal delegate void Delegate89(object object_0, byte[] byte_0);
