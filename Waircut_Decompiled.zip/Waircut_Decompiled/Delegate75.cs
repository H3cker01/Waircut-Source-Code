internal delegate int Delegate75(int int_0);
