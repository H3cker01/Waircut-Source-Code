using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
[TypeIdentifier("c9178c19-99cf-4f6d-85c6-3ef5a176f9fb", "JSWSCAPILib.JswEngineEvents")]
public enum GEnum14
{
	JswEngEvt_None,
	JswEngEvt_FailedInitialize,
	JswEngEvt_Starting,
	JswEngEvt_ScanningForAps,
	JswEngEvt_NoCandidateApsFound,
	JswEngEvt_SelectedAp,
	JswEngEvt_Associating,
	JswEngEvt_AssociationFailed,
	JswEngEvt_StartProtocol,
	JswEngEvt_ProtocolSuccess,
	JswEngEvt_ProtocolFailed,
	JswEngEvt_MultipleApsInPbMode,
	JswEngEvt_ReceivedCredentials,
	JswEngEvt_PushButtonTimeout,
	JswEngEvt_SupplicantReceivedMsg,
	JswEngEvt_SupplicantSentMsg,
	JswEngEvt_ProtocolAttemptFailed,
	JswEngEvt_ProtocolFailedResetPin,
	JswEngEvt_ApInSetupLockedState,
	JswEngEvt_Initializing,
	JswEngEvt_FailedDeviceInitialize,
	JswEngEvt_ProtocolTimeout
}
