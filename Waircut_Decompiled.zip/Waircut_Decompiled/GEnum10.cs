using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
[TypeIdentifier("c9178c19-99cf-4f6d-85c6-3ef5a176f9fb", "JSWSCAPILib.JswConfigurationError")]
public enum GEnum10
{
	JswConfigError_NoError,
	JswConfigError_OOBInterfaceReadError,
	JswConfigError_DecryptionCRCFailure,
	JswConfigError_24ChannelNotSupported,
	JswConfigError_50ChannelNotSupported,
	JswConfigError_SignalTooWeak,
	JswConfigError_NetworkAuthenticationFailure,
	JswConfigError_NetworkAssociationFailure,
	JswConfigError_NoDHCPResponse,
	JswConfigError_FailedDHCPConfig,
	JswConfigError_IPAddressConflict,
	JswConfigError_CouldntConnectToRegistrar,
	JswConfigError_MultiplePBCSessionsDetected,
	JswConfigError_RogueActivitySuspected,
	JswConfigError_DeviceBusy,
	JswConfigError_SetupLocked,
	JswConfigError_MessageTimeout,
	JswConfigError_RegistrationSessionTimeout,
	JswConfigError_DevicePasswordAuthFailure
}
