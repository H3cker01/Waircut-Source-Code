using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[ComImport]
[Guid("B685895E-EC5D-48EC-AC89-80CD20C81A49")]
[TypeIdentifier]
[CompilerGenerated]
public interface GInterface10
{
}
