using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate130(object object_0, DataGridViewTriState dataGridViewTriState_0);
