using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate38(object object_0, DataGridViewClipboardCopyMode dataGridViewClipboardCopyMode_0);
