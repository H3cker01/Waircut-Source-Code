using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate41(object object_0, DataGridViewSelectionMode dataGridViewSelectionMode_0);
