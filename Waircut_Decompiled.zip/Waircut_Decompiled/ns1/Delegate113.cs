namespace ns1;

internal delegate string[] Delegate113(object object_0);
