using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate31(object object_0, ToolStripItem[] toolStripItem_0);
