namespace ns1;

internal delegate int Delegate102(object object_0, object object_1);
