namespace ns1;

internal delegate char[] Delegate183(object object_0, int int_0);
