using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate216(object object_0, ImageLayout imageLayout_0);
