namespace ns1;

internal delegate object Delegate110(ref GClass8 gclass8_0, ref GClass9 gclass9_0, bool bool_0);
