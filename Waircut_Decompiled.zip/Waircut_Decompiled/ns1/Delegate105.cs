using System.Windows.Forms;

namespace ns1;

internal delegate string Delegate105(object object_0, ref GClass9 gclass9_0, ref GClass15<GClass9> gclass15_0, ref Control control_0);
