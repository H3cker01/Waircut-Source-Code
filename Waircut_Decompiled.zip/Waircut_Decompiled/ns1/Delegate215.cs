using System.Drawing;

namespace ns1;

internal delegate object Delegate215(Point point_0);
