namespace ns1;

internal delegate void Delegate33(object object_0, GClass14.GEnum7 genum7_0);
