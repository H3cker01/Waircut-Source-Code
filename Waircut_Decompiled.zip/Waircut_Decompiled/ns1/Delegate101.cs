using System.Drawing;

namespace ns1;

internal delegate void Delegate101(object object_0, string string_0, Color color_0, bool bool_0);
