using System;

namespace ns1;

internal delegate int Delegate98(DateTime dateTime_0, DateTime dateTime_1);
