namespace ns1;

internal delegate void Delegate109(object object_0, ref GClass9 gclass9_0, object object_1);
