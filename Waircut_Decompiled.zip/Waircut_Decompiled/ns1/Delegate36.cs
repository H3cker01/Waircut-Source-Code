namespace ns1;

internal delegate string Delegate36();
