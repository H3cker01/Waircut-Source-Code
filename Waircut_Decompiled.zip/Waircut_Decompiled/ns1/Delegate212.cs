using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate212(object object_0, DockStyle dockStyle_0);
