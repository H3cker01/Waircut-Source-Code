using System.IO;

namespace ns1;

internal delegate object Delegate182(string string_0, FileMode fileMode_0, FileAccess fileAccess_0);
