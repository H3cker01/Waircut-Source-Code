namespace ns1;

internal delegate int Delegate56(string string_0, string string_1, bool bool_0);
