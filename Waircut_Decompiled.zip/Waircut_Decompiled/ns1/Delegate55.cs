namespace ns1;

internal delegate object Delegate55(object object_0, int int_0);
