using System.Windows.Forms;

namespace ns1;

internal delegate DialogResult Delegate111(object object_0);
