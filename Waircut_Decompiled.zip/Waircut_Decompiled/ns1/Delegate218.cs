namespace ns1;

internal delegate int Delegate218(object object_0, object object_1, string string_0);
