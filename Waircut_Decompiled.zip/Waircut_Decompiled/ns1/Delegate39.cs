using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate39(object object_0, DataGridViewColumnHeadersHeightSizeMode dataGridViewColumnHeadersHeightSizeMode_0);
