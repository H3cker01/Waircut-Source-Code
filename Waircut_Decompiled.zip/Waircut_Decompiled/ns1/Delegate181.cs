using System.Collections.Generic;

namespace ns1;

internal delegate List<string> Delegate181(object object_0, int int_0, bool bool_0);
