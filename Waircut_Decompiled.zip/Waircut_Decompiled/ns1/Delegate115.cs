using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate115(RichTextBox richTextBox_0);
