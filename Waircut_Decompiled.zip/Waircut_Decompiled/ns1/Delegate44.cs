using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate44(object object_0, DataGridViewAutoSizeColumnMode dataGridViewAutoSizeColumnMode_0);
