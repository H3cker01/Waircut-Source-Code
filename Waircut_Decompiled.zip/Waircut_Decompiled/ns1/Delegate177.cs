namespace ns1;

internal delegate bool Delegate177(string string_0);
