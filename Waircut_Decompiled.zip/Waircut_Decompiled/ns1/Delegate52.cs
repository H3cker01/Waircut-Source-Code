using System.Windows.Forms;

namespace ns1;

internal delegate DialogResult Delegate52(string string_0, string string_1, MessageBoxButtons messageBoxButtons_0);
