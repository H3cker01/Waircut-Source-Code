namespace ns1;

internal delegate object Delegate59(object object_0, object object_1);
