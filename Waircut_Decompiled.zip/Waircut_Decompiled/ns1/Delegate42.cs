namespace ns1;

internal delegate void Delegate42(object object_0, float float_0);
