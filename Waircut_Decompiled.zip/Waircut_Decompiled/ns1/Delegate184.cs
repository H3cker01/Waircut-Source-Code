namespace ns1;

internal delegate object Delegate184(char[] char_0);
