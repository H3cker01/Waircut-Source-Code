namespace ns1;

internal delegate void Delegate107(object object_0, ref GClass9 gclass9_0);
