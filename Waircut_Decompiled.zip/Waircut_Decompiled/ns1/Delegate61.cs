using System.Drawing;

namespace ns1;

internal delegate Rectangle Delegate61(object object_0);
