namespace ns1;

internal delegate string Delegate57(string string_0, string string_1);
