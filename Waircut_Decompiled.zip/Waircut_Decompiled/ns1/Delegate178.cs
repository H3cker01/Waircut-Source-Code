using System;

namespace ns1;

internal delegate TimeSpan Delegate178(double double_0);
