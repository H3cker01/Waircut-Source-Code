namespace ns1;

internal delegate object Delegate121(string string_0, GClass3.GEnum0 genum0_0);
