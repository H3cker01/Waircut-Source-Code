namespace ns1;

internal delegate char Delegate127(object object_0);
