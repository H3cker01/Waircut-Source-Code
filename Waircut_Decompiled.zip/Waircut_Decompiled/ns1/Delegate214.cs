using System.Drawing;

namespace ns1;

internal delegate Point Delegate214(object object_0);
