namespace ns1;

internal delegate void Delegate100(string string_0);
