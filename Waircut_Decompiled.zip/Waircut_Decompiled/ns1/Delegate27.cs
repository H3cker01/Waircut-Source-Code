namespace ns1;

internal delegate void Delegate27(object object_0, object object_1, string string_0);
