namespace ns1;

internal delegate bool Delegate128(char char_0);
