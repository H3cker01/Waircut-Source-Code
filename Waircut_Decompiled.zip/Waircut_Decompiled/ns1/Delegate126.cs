namespace ns1;

internal delegate void Delegate126(object object_0, GClass9.GEnum3 genum3_0);
