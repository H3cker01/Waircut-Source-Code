namespace ns1;

internal delegate string Delegate37(string[] string_0);
