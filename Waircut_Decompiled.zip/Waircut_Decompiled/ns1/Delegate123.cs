namespace ns1;

internal delegate string[] Delegate123(string string_0);
