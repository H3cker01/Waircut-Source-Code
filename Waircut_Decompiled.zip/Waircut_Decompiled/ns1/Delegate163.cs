namespace ns1;

internal delegate string Delegate163(object object_0, string string_0);
