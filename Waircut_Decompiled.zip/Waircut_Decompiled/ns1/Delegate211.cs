using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate211(object object_0, BorderStyle borderStyle_0);
