namespace ns1;

internal delegate uint Delegate185(object object_0);
