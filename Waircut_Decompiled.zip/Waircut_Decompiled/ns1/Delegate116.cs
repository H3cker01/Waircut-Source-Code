namespace ns1;

internal delegate void Delegate116(object object_0, GClass8.GEnum1 genum1_0);
