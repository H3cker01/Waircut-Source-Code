using System;

namespace ns1;

internal delegate DateTime Delegate97(string string_0);
