using System.Drawing;

namespace ns1;

internal delegate Rectangle Delegate213(object object_0, Rectangle rectangle_0);
