namespace ns1;

internal delegate object Delegate49(object object_0, string string_0, object object_1, string string_1);
