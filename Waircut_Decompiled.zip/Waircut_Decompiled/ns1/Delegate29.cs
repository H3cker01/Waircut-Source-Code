using System.Drawing;

namespace ns1;

internal delegate void Delegate29(object object_0, Color color_0);
