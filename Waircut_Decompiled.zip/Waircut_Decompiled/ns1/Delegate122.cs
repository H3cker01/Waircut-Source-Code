using Microsoft.VisualBasic;

namespace ns1;

internal delegate bool Delegate122(string string_0, string string_1, CompareMethod compareMethod_0);
