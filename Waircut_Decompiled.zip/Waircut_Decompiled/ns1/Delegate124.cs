namespace ns1;

internal delegate bool Delegate124(string string_0, ref GClass12 gclass12_0);
