using System.Drawing;

namespace ns1;

internal delegate object Delegate43(string string_0, float float_0, FontStyle fontStyle_0, GraphicsUnit graphicsUnit_0, byte byte_0);
