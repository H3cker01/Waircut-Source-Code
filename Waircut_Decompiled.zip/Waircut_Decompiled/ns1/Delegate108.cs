namespace ns1;

internal delegate bool Delegate108(object object_0, object object_1, bool bool_0);
