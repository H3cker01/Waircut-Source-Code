using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate132(object object_0, DataGridViewColumnSortMode dataGridViewColumnSortMode_0);
