using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate131(object object_0, DataGridViewHeaderBorderStyle dataGridViewHeaderBorderStyle_0);
