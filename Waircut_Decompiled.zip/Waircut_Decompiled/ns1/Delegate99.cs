using System;

namespace ns1;

internal delegate void Delegate99(object object_0, DateTime dateTime_0);
