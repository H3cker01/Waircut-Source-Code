namespace ns1;

internal delegate void Delegate186(object object_0, uint uint_0);
