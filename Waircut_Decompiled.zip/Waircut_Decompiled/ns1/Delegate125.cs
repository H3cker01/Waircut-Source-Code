namespace ns1;

internal delegate GClass9.GEnum3 Delegate125(object object_0);
