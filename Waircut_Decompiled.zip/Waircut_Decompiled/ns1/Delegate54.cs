using System.Windows.Forms;

namespace ns1;

internal delegate DataGridViewEditMode Delegate54(object object_0);
