using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate46(object object_0, ToolStripItemDisplayStyle toolStripItemDisplayStyle_0);
