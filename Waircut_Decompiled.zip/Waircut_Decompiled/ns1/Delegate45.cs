using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate45(object object_0, ToolStripGripStyle toolStripGripStyle_0);
