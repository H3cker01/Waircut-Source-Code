using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate129(object object_0, DataGridViewContentAlignment dataGridViewContentAlignment_0);
