using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate34(object object_0, AutoScaleMode autoScaleMode_0);
