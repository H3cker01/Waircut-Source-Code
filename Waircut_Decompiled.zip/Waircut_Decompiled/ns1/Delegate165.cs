using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate165(object object_0, DateTimePickerFormat dateTimePickerFormat_0);
