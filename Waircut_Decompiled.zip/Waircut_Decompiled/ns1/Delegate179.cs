namespace ns1;

internal delegate char Delegate179(object object_0, int int_0);
