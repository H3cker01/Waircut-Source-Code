using System.Drawing;

namespace ns1;

internal delegate Color Delegate28();
