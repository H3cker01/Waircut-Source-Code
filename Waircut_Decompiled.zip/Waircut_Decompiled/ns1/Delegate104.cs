namespace ns1;

internal delegate GClass15<GClass9> Delegate104(object object_0, bool bool_0, int int_0);
