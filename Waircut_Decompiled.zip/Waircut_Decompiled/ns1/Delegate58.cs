using System;

namespace ns1;

internal delegate object Delegate58(object object_0, Type type_0, string string_0, object[] object_1, string[] string_1, Type[] type_1, bool[] bool_0);
