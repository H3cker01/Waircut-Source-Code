namespace ns1;

internal delegate int Delegate103(object object_0, int int_0);
