namespace ns1;

internal delegate void Delegate32(object object_0, int int_0);
