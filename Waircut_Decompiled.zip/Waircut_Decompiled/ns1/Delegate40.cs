using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate40(object object_0, DataGridViewColumn[] dataGridViewColumn_0);
