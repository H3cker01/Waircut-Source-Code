namespace ns1;

internal delegate object Delegate119(int int_0, int int_1);
