namespace ns1;

internal delegate string Delegate50(string string_0, object object_0);
