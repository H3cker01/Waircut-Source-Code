using System.Collections.Generic;

namespace ns1;

internal delegate List<string> Delegate180(object object_0, string string_0, string string_1);
