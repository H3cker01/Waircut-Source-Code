using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate217(object object_0, DataGridViewRowHeadersWidthSizeMode dataGridViewRowHeadersWidthSizeMode_0);
