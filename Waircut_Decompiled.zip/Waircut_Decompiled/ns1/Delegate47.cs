using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate47(object object_0, ToolStripItemAlignment toolStripItemAlignment_0);
