using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate35(object object_0, FormBorderStyle formBorderStyle_0);
