namespace ns1;

internal delegate bool Delegate96(object object_0, string string_0);
