using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate195(object object_0, DialogResult dialogResult_0);
