using System.Collections.Generic;

namespace ns1;

internal delegate List<string> Delegate176(object object_0, bool bool_0);
