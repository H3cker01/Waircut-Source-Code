namespace ns1;

internal delegate object Delegate112(object object_0, object object_1, object[] object_2);
