using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate48(object object_0, ToolTipIcon toolTipIcon_0);
