using System.Drawing;

namespace ns1;

internal delegate object Delegate120(Image image_0);
