namespace ns1;

internal delegate void Delegate164(object object_0, object[] object_1);
