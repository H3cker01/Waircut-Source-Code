namespace ns1;

internal delegate void Delegate30(object object_0, string string_0);
