namespace ns1;

internal delegate void Delegate196(object object_0, int int_0, int int_1);
