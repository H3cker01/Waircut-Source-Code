using System.Windows.Forms;

namespace ns1;

internal delegate void Delegate175(object object_0, CheckState checkState_0);
