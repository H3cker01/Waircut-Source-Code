namespace ns1;

internal delegate void Delegate106(object object_0, ref GClass9 gclass9_0, ref GClass12 gclass12_0);
