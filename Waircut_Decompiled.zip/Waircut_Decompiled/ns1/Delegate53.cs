using System.Windows.Forms;

namespace ns1;

internal delegate Keys Delegate53(object object_0);
