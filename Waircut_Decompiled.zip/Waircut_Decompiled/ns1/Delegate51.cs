namespace ns1;

internal delegate void Delegate51();
