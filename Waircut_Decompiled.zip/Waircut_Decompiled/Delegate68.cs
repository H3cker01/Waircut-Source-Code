internal delegate void Delegate68(object object_0, string string_0, string string_1);
