internal delegate string Delegate174(uint uint_0);
