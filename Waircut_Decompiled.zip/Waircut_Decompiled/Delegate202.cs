internal delegate byte[] Delegate202(object object_0, object object_1);
