using Microsoft.VisualBasic.ApplicationServices;

internal delegate void Delegate6(object object_0, ShutdownMode shutdownMode_0);
