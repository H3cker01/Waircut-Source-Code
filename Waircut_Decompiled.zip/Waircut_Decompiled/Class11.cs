using System.ComponentModel.Design;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Waircut.My;

[CompilerGenerated]
[HideModuleName]
[StandardModule]
[DebuggerNonUserCode]
internal sealed class Class11
{
	[HelpKeyword("My.Settings")]
	internal static MySettings MySettings_0 => (MySettings)Delegate3.delegate3_8();
}
