using System;

internal delegate object Delegate95(Delegate delegate_0, Delegate delegate_1);
