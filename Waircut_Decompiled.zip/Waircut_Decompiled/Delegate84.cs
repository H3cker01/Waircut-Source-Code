using System;

internal delegate TimeSpan Delegate84(DateTime dateTime_0, DateTime dateTime_1);
