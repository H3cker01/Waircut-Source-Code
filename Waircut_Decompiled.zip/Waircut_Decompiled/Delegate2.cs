internal delegate void Delegate2(bool bool_0);
