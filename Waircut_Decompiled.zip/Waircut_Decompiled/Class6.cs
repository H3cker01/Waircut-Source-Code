using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using Microsoft.VisualBasic.CompilerServices;
using Waircut;

[StandardModule]
[HideModuleName]
[GeneratedCode("MyTemplate", "11.0.0.0")]
internal sealed class Class6
{
	[EditorBrowsable(EditorBrowsableState.Never)]
	[MyGroupCollection("System.Windows.Forms.Form", "Create__Instance__", "Dispose__Instance__", "My.MyProject.Forms")]
	internal sealed class Class7
	{
		[ThreadStatic]
		private static Hashtable hashtable_0;

		[EditorBrowsable(EditorBrowsableState.Never)]
		public AboutForm aboutForm_0;

		[EditorBrowsable(EditorBrowsableState.Never)]
		public ApLogForm apLogForm_0;

		[EditorBrowsable(EditorBrowsableState.Never)]
		public MainForm mainForm_0;

		[EditorBrowsable(EditorBrowsableState.Never)]
		public StringListEditor stringListEditor_0;

		[EditorBrowsable(EditorBrowsableState.Never)]
		public UpdateForm updateForm_0;

		[EditorBrowsable(EditorBrowsableState.Never)]
		public WpsPinForm wpsPinForm_0;

		public AboutForm AboutForm_0
		{
			get
			{
				aboutForm_0 = smethod_0(aboutForm_0);
				return aboutForm_0;
			}
			set
			{
				if (value == aboutForm_0)
				{
					return;
				}
				while (true)
				{
					int num = 580258531;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x12E4A076u) % 5)
						{
						case 3u:
							method_0(ref aboutForm_0);
							num = 2004421822;
							continue;
						case 1u:
						{
							int num3;
							int num4;
							if (value != null)
							{
								num3 = 2107958009;
								num4 = 2107958009;
							}
							else
							{
								num3 = 750889110;
								num4 = 750889110;
							}
							num = num3 ^ (int)(num2 * 325324258);
							continue;
						}
						default:
							return;
						case 4u:
							break;
						case 2u:
							throw Delegate12.delegate12_1(global::_003CModule_003E.smethod_21<string>(930545973u, 1155137686u));
						case 0u:
							return;
						}
						break;
					}
				}
			}
		}

		public ApLogForm ApLogForm_0
		{
			get
			{
				apLogForm_0 = smethod_0(apLogForm_0);
				return apLogForm_0;
			}
			set
			{
				if (value == apLogForm_0)
				{
					return;
				}
				while (true)
				{
					int num = 691546706;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x24F81114u) % 5)
						{
						case 4u:
						{
							int num3;
							int num4;
							if (value == null)
							{
								num3 = 1800488867;
								num4 = 1800488867;
							}
							else
							{
								num3 = 188340552;
								num4 = 188340552;
							}
							num = num3 ^ (int)(num2 * 790471693);
							continue;
						}
						case 0u:
							method_0(ref apLogForm_0);
							num = 1008107388;
							continue;
						default:
							return;
						case 3u:
							break;
						case 2u:
							throw Delegate12.delegate12_1(global::_003CModule_003E.smethod_18<string>(3656014542u, 1450392687u));
						case 1u:
							return;
						}
						break;
					}
				}
			}
		}

		public MainForm MainForm_0
		{
			get
			{
				mainForm_0 = smethod_0(mainForm_0);
				return mainForm_0;
			}
			set
			{
				if (value == mainForm_0)
				{
					return;
				}
				while (true)
				{
					int num = 1851451919;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x599B91BFu) % 5)
						{
						case 2u:
						{
							int num3;
							int num4;
							if (value == null)
							{
								num3 = 334733687;
								num4 = 334733687;
							}
							else
							{
								num3 = 2060676249;
								num4 = 2060676249;
							}
							num = num3 ^ ((int)num2 * -1673110953);
							continue;
						}
						case 1u:
							method_0(ref mainForm_0);
							num = 2069342479;
							continue;
						default:
							return;
						case 4u:
							break;
						case 3u:
							throw Delegate12.delegate12_1(global::_003CModule_003E.smethod_21<string>(930545973u, 1058639301u));
						case 0u:
							return;
						}
						break;
					}
				}
			}
		}

		public StringListEditor StringListEditor_0
		{
			get
			{
				stringListEditor_0 = smethod_0(stringListEditor_0);
				return stringListEditor_0;
			}
			set
			{
				if (value == stringListEditor_0)
				{
					return;
				}
				while (true)
				{
					int num = -1611927381;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0xC58E8112u) % 5)
						{
						case 4u:
						{
							int num3;
							int num4;
							if (value != null)
							{
								num3 = -1968331550;
								num4 = -1968331550;
							}
							else
							{
								num3 = -1134039265;
								num4 = -1134039265;
							}
							num = num3 ^ (int)(num2 * 1951382151);
							continue;
						}
						case 3u:
							method_0(ref stringListEditor_0);
							num = -416856676;
							continue;
						default:
							return;
						case 0u:
							break;
						case 2u:
							throw Delegate12.delegate12_1(global::_003CModule_003E.smethod_20<string>(3828231587u, 2516757998u));
						case 1u:
							return;
						}
						break;
					}
				}
			}
		}

		public UpdateForm UpdateForm_0
		{
			get
			{
				updateForm_0 = smethod_0(updateForm_0);
				return updateForm_0;
			}
			set
			{
				if (value == updateForm_0)
				{
					return;
				}
				while (true)
				{
					int num = 925041381;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x56BE3ACBu) % 5)
						{
						case 4u:
							method_0(ref updateForm_0);
							num = 1038262483;
							continue;
						case 1u:
						{
							int num3;
							int num4;
							if (value != null)
							{
								num3 = -1561476331;
								num4 = -1561476331;
							}
							else
							{
								num3 = -759229737;
								num4 = -759229737;
							}
							num = num3 ^ ((int)num2 * -1885904272);
							continue;
						}
						default:
							return;
						case 3u:
							break;
						case 0u:
							throw Delegate12.delegate12_1(global::_003CModule_003E.smethod_22<string>(3101298591u, 3947821668u));
						case 2u:
							return;
						}
						break;
					}
				}
			}
		}

		public WpsPinForm WpsPinForm_0
		{
			get
			{
				wpsPinForm_0 = smethod_0(wpsPinForm_0);
				return wpsPinForm_0;
			}
			set
			{
				if (value == wpsPinForm_0)
				{
					return;
				}
				while (true)
				{
					int num = 200822039;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x2E8921CCu) % 5)
						{
						case 2u:
						{
							int num3;
							int num4;
							if (value != null)
							{
								num3 = 1744473326;
								num4 = 1744473326;
							}
							else
							{
								num3 = 356572952;
								num4 = 356572952;
							}
							num = num3 ^ ((int)num2 * -1157281770);
							continue;
						}
						case 1u:
							method_0(ref wpsPinForm_0);
							num = 701187865;
							continue;
						default:
							return;
						case 0u:
							break;
						case 4u:
							throw Delegate12.delegate12_1(global::_003CModule_003E.smethod_19<string>(2801824445u, 1002513320u));
						case 3u:
							return;
						}
						break;
					}
				}
			}
		}

		[DebuggerHidden]
		private static T smethod_0<T>(T gparam_0) where T : Form, new()
		{
			if (gparam_0 != null)
			{
				goto IL_007c;
			}
			goto IL_00ce;
			IL_007c:
			int num = -478750637;
			goto IL_0092;
			IL_0092:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xC2FB41F0u) % 7)
				{
				case 5u:
					break;
				case 4u:
				{
					int num3;
					int num4;
					if (Delegate10.delegate10_0(hashtable_0, Delegate9.delegate9_0(typeof(T).TypeHandle)))
					{
						num3 = 1729462975;
						num4 = 1729462975;
					}
					else
					{
						num3 = 1381375244;
						num4 = 1381375244;
					}
					num = num3 ^ ((int)num2 * -440780960);
					continue;
				}
				case 3u:
					goto end_IL_0092;
				case 1u:
					hashtable_0 = (Hashtable)Delegate3.smethod_0();
					num = -1752705044;
					continue;
				case 0u:
					goto IL_00ce;
				default:
					Delegate13.delegate13_0(hashtable_0, Delegate9.delegate9_0(typeof(T).TypeHandle), null);
					try
					{
						return new T();
					}
					catch (TargetInvocationException ex) when (((Func<bool>)delegate
					{
						// Could not convert BlockContainer to single expression
						Delegate14.smethod_0((Exception)ex);
						return Delegate7.delegate7_1(ex) != null;
					}).Invoke())
					{
						throw Delegate16.smethod_0(Delegate11.smethod_0(global::_003CModule_003E.smethod_21<string>(1336858013u, 2498795310u), new string[1] { Delegate15.delegate15_0(Delegate7.delegate7_1(ex)) }), Delegate7.delegate7_1(ex));
					}
					finally
					{
						Delegate8.delegate8_1(hashtable_0, Delegate9.delegate9_0(typeof(T).TypeHandle));
					}
				case 6u:
					throw Delegate12.delegate12_0(Delegate11.delegate11_0(global::_003CModule_003E.smethod_19<string>(2974521517u, 3771249587u), new string[0]));
				}
				if (gparam_0.IsDisposed)
				{
					num = ((int)num2 * -1550970213) ^ -894511067;
					continue;
				}
				return gparam_0;
				continue;
				end_IL_0092:
				break;
			}
			goto IL_007c;
			IL_00ce:
			int num5;
			if (hashtable_0 == null)
			{
				num = -779045483;
				num5 = -779045483;
			}
			else
			{
				num = -521064475;
				num5 = -521064475;
			}
			goto IL_0092;
		}

		[DebuggerHidden]
		private void method_0<T>(ref T gparam_0) where T : Form
		{
			gparam_0.Dispose();
			gparam_0 = null;
		}

		[DebuggerHidden]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public Class7()
		{
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		bool object.Equals(object obj)
		{
			return Delegate10.delegate10_1(this, Delegate7.delegate7_2(obj));
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		int object.GetHashCode()
		{
			return Delegate17.delegate17_0(this);
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		internal Type method_1()
		{
			return (Type)Delegate9.delegate9_0(typeof(Class7).TypeHandle);
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		string object.ToString()
		{
			return Delegate15.delegate15_1(this);
		}
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	[MyGroupCollection("System.Web.Services.Protocols.SoapHttpClientProtocol", "Create__Instance__", "Dispose__Instance__", "")]
	internal sealed class Class8
	{
		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerHidden]
		bool object.Equals(object obj)
		{
			return Delegate10.delegate10_1(this, Delegate7.delegate7_2(obj));
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerHidden]
		int object.GetHashCode()
		{
			return Delegate17.delegate17_0(this);
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerHidden]
		internal Type method_0()
		{
			return (Type)Delegate9.delegate9_0(typeof(Class8).TypeHandle);
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerHidden]
		string object.ToString()
		{
			return Delegate15.delegate15_1(this);
		}

		[DebuggerHidden]
		private static T smethod_0<T>(T gparam_0) where T : new()
		{
			if (gparam_0 == null)
			{
				goto IL_0008;
			}
			goto IL_0056;
			IL_0008:
			int num = 1194235671;
			goto IL_0031;
			IL_0031:
			T result = default(T);
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x23989DF2u) % 5)
				{
				case 4u:
					break;
				case 1u:
					result = new T();
					num = (int)((num2 * 540535919) ^ 0x1FE5C5D6);
					continue;
				case 0u:
					num = (int)((num2 * 1796452115) ^ 0x421569A3);
					continue;
				case 2u:
					goto IL_0056;
				default:
					return result;
				}
				break;
			}
			goto IL_0008;
			IL_0056:
			result = gparam_0;
			num = 1139542430;
			goto IL_0031;
		}

		[DebuggerHidden]
		private void method_1<T>(ref T gparam_0)
		{
			gparam_0 = default(T);
		}

		[DebuggerHidden]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public Class8()
		{
		}
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	[ComVisible(false)]
	internal sealed class Class9<T> where T : new()
	{
		[CompilerGenerated]
		[ThreadStatic]
		private static T gparam_0;

		internal T Prop_0
		{
			[DebuggerHidden]
			get
			{
				if (gparam_0 == null)
				{
					while (true)
					{
						int num = -1955249658;
						while (true)
						{
							uint num2;
							switch ((num2 = (uint)num ^ 0xE5E8782Bu) % 3)
							{
							case 1u:
								gparam_0 = new T();
								num = (int)((num2 * 1386445924) ^ 0x6DCC2B16);
								continue;
							case 0u:
								break;
							default:
								goto end_IL_0042;
							}
							break;
						}
						continue;
						end_IL_0042:
						break;
					}
				}
				return gparam_0;
			}
		}

		[DebuggerHidden]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public Class9()
		{
		}
	}

	private static readonly Class9<Class5> class9_0 = new Class9<Class5>();

	private static readonly Class9<Form0> class9_1;

	private static readonly Class9<User> class9_2;

	private static Class9<Class7> class9_3;

	private static readonly Class9<Class8> class9_4;

	[HelpKeyword("My.Computer")]
	internal static Class5 Class5_0
	{
		[DebuggerHidden]
		get
		{
			return class9_0.Prop_0;
		}
	}

	[HelpKeyword("My.Application")]
	internal static Form0 Form0_0
	{
		[DebuggerHidden]
		get
		{
			return class9_1.Prop_0;
		}
	}

	[HelpKeyword("My.User")]
	internal static User User_0
	{
		[DebuggerHidden]
		get
		{
			return class9_2.Prop_0;
		}
	}

	[HelpKeyword("My.Forms")]
	internal static Class7 Class7_0
	{
		[DebuggerHidden]
		get
		{
			return class9_3.Prop_0;
		}
	}

	[HelpKeyword("My.WebServices")]
	internal static Class8 Class8_0
	{
		[DebuggerHidden]
		get
		{
			return class9_4.Prop_0;
		}
	}

	static Class6()
	{
		while (true)
		{
			int num = 692366196;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x3696ED6u) % 3)
				{
				case 2u:
					goto IL_000c;
				case 0u:
					break;
				default:
					class9_2 = new Class9<User>();
					class9_3 = new Class9<Class7>();
					class9_4 = new Class9<Class8>();
					return;
				}
				break;
				IL_000c:
				class9_1 = new Class9<Form0>();
				num = (int)(num2 * 1609706003) ^ -1467539994;
			}
		}
	}
}
