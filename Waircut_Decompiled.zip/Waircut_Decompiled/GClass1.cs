using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Net;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using ns1;

public class GClass1
{
	public class GClass2
	{
		public string string_0;

		public string string_1;

		public string string_2;

		public string string_3;

		public string string_4;

		public string string_5;

		public string string_6;

		public string string_7;

		public string string_8;

		public string string_9;

		public string string_10;

		public string string_11;

		public string string_12;

		public string string_13;

		public string string_14;

		public int int_0;

		public int int_1;

		public GClass2()
		{
			string_0 = "";
			string_1 = "";
			string_2 = "";
			string_3 = "";
			string_4 = "";
			string_5 = "";
			string_6 = "";
			string_7 = "";
			string_8 = "";
			string_9 = "";
			string_10 = "";
			string_11 = "";
			string_12 = "";
			string_13 = "";
			string_14 = "";
			int_0 = 0;
			int_1 = 0;
		}
	}

	public object method_0()
	{
		object result = default(object);
		try
		{
			List<GClass2> list_ = Delegate62.delegate62_0(this);
			Stream stream = default(Stream);
			GClass2 gclass2_ = default(GClass2);
			while (true)
			{
				IL_0068:
				int num = 606559640;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x2FE73C0Eu) % 4)
					{
					case 2u:
						if (list_.Count > 0)
						{
							num = ((int)num2 * -2082835239) ^ -215475775;
							continue;
						}
						goto IL_015c;
					case 1u:
						stream = (Stream)Delegate63.delegate63_0(this, ref list_);
						num = ((int)num2 * -1722325805) ^ -8604378;
						continue;
					case 0u:
						break;
					default:
						{
							method_4(string.Format(global::_003CModule_003E.smethod_18<string>(827428654u, 2672801574u), Class13.string_3, Delegate64.delegate64_0().ToString(global::_003CModule_003E.smethod_22<string>(3317625083u, 3049654471u))), (MemoryStream)stream);
							using (List<GClass2>.Enumerator enumerator = list_.GetEnumerator())
							{
								while (true)
								{
									IL_0145:
									int num3 = 1613202683;
									while (true)
									{
										switch ((num2 = (uint)num3 ^ 0x2FE73C0Eu) % 6)
										{
										case 5u:
										{
											int num4;
											if (!enumerator.MoveNext())
											{
												num3 = 58812030;
												num4 = 58812030;
											}
											else
											{
												num3 = 1797948718;
												num4 = 1797948718;
											}
											continue;
										}
										case 4u:
											gclass2_ = enumerator.Current;
											num3 = 1140363131;
											continue;
										case 3u:
											method_3(ref gclass2_);
											num3 = (int)(num2 * 1878474363) ^ -1588924940;
											continue;
										case 1u:
											num3 = ((int)num2 * -1938598797) ^ 0x28C18CC;
											continue;
										default:
											goto end_IL_011b;
										case 2u:
											break;
										case 0u:
											goto end_IL_011b;
										}
										goto IL_0145;
										continue;
										end_IL_011b:
										break;
									}
									break;
								}
							}
							goto IL_015c;
						}
						IL_015c:
						result = true;
						goto end_IL_0046;
					}
					goto IL_0068;
					continue;
					end_IL_0046:
					break;
				}
				break;
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			while (true)
			{
				IL_01a3:
				int num5 = 810191264;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num5 ^ 0x2FE73C0Eu) % 3)
					{
					case 1u:
						goto IL_018c;
					case 2u:
						break;
					default:
						ProjectData.ClearProjectError();
						goto end_IL_016e;
					}
					goto IL_01a3;
					IL_018c:
					result = false;
					num5 = (int)(num2 * 2014153454) ^ -1098694306;
					continue;
					end_IL_016e:
					break;
				}
				break;
			}
		}
		return result;
	}

	private Stream method_1(ref List<GClass2> list_0)
	{
		Stream result = default(Stream);
		try
		{
			Stream stream = (Stream)Delegate3.delegate3_42();
			BinaryWriter binaryWriter = (BinaryWriter)Delegate7.delegate7_82(stream);
			GClass2 current = default(GClass2);
			while (true)
			{
				IL_0134:
				int num = 1583174303;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x77435E0Bu) % 5)
					{
					case 4u:
						Delegate66.delegate66_0(binaryWriter, Delegate65.delegate65_1(Class13.string_3));
						Delegate32.delegate32_4(binaryWriter, Delegate17.delegate17_7(Class13.string_2));
						Delegate66.delegate66_0(binaryWriter, Delegate65.delegate65_1(Class13.string_2));
						binaryWriter.Write(Delegate64.delegate64_0().ToString(global::_003CModule_003E.smethod_18<string>(1034678688u, 1456417706u)).ToCharArray());
						num = ((int)num2 * -361316144) ^ -1765484618;
						continue;
					case 1u:
						Delegate66.delegate66_0(binaryWriter, Delegate65.delegate65_0(global::_003CModule_003E.smethod_19<string>(842819799u, 1966428403u)));
						num = (int)(num2 * 294186484) ^ -1849297600;
						continue;
					case 0u:
						Delegate32.delegate32_4(binaryWriter, 1);
						Delegate32.delegate32_4(binaryWriter, Delegate17.delegate17_7(Class13.string_3));
						num = (int)((num2 * 1991326854) ^ 0xAB3DC37);
						continue;
					case 2u:
						break;
					default:
					{
						binaryWriter.Write(list_0.Count);
						using (List<GClass2>.Enumerator enumerator = list_0.GetEnumerator())
						{
							while (true)
							{
								IL_05bc:
								int num3 = 497339940;
								while (true)
								{
									switch ((num2 = (uint)num3 ^ 0x77435E0Bu) % 25)
									{
									case 24u:
									{
										int num4;
										if (!enumerator.MoveNext())
										{
											num3 = 2104887368;
											num4 = 2104887368;
										}
										else
										{
											num3 = 16278019;
											num4 = 16278019;
										}
										continue;
									}
									case 23u:
										num3 = ((int)num2 * -1351373113) ^ 0x2E6D9BFF;
										continue;
									case 22u:
										binaryWriter.Write(current.string_12.Length);
										num3 = (int)(num2 * 171571851) ^ -443141347;
										continue;
									case 21u:
										binaryWriter.Write(current.string_10.Length);
										num3 = (int)(num2 * 592367207) ^ -1342088298;
										continue;
									case 20u:
										binaryWriter.Write(current.string_2.ToCharArray());
										num3 = (int)((num2 * 242645246) ^ 0x47E357F7);
										continue;
									case 19u:
										binaryWriter.Write(current.string_10.ToCharArray());
										binaryWriter.Write(current.string_11.Length);
										num3 = ((int)num2 * -1363997510) ^ 0x64BBC7B0;
										continue;
									case 18u:
										binaryWriter.Write(current.int_0);
										num3 = (int)(num2 * 792522801) ^ -1671376030;
										continue;
									case 17u:
										binaryWriter.Write(current.string_8.ToCharArray());
										binaryWriter.Write(current.string_9.Length);
										binaryWriter.Write(current.string_9.ToCharArray());
										num3 = (int)((num2 * 879298808) ^ 0x3811602E);
										continue;
									case 16u:
										binaryWriter.Write(current.string_14.ToCharArray());
										num3 = ((int)num2 * -1976271807) ^ -1811858805;
										continue;
									case 15u:
										binaryWriter.Write(current.string_3.ToCharArray());
										num3 = (int)(num2 * 2060908944) ^ -241010513;
										continue;
									case 14u:
										binaryWriter.Write(current.string_4.ToCharArray());
										num3 = (int)((num2 * 1841829718) ^ 0x83D8622);
										continue;
									case 13u:
										binaryWriter.Write(current.string_3.Length);
										num3 = (int)((num2 * 141217843) ^ 0x3379727);
										continue;
									case 12u:
										binaryWriter.Write(current.string_0.ToCharArray());
										binaryWriter.Write(current.string_1.Length);
										binaryWriter.Write(current.string_1.ToCharArray());
										num3 = ((int)num2 * -215608994) ^ -1265503412;
										continue;
									case 10u:
										binaryWriter.Write(current.string_2.Length);
										num3 = (int)(num2 * 966560125) ^ -719631004;
										continue;
									case 9u:
										binaryWriter.Write(current.string_5.Length);
										binaryWriter.Write(current.string_5.ToCharArray());
										num3 = ((int)num2 * -1496954966) ^ -1743476705;
										continue;
									case 8u:
										binaryWriter.Write(current.string_12.ToCharArray());
										binaryWriter.Write(current.string_13.Length);
										binaryWriter.Write(current.string_13.ToCharArray());
										binaryWriter.Write(current.string_14.Length);
										num3 = ((int)num2 * -1875740699) ^ 0x16204D88;
										continue;
									case 7u:
										binaryWriter.Write(current.int_1);
										num3 = ((int)num2 * -1837507073) ^ -680237057;
										continue;
									case 6u:
										binaryWriter.Write(current.string_6.ToCharArray());
										binaryWriter.Write(current.string_7.Length);
										num3 = ((int)num2 * -845351022) ^ -1197760868;
										continue;
									case 5u:
										binaryWriter.Write(current.string_6.Length);
										num3 = (int)(num2 * 2013434144) ^ -899008487;
										continue;
									case 4u:
										current = enumerator.Current;
										binaryWriter.Write(current.string_0.Length);
										num3 = 1404698622;
										continue;
									case 3u:
										binaryWriter.Write(current.string_11.ToCharArray());
										num3 = (int)((num2 * 505177996) ^ 0x247F4A32);
										continue;
									case 2u:
										binaryWriter.Write(current.string_4.Length);
										num3 = (int)((num2 * 1428225677) ^ 0x3E782C9A);
										continue;
									case 0u:
										binaryWriter.Write(current.string_7.ToCharArray());
										binaryWriter.Write(current.string_8.Length);
										num3 = (int)((num2 * 1550111079) ^ 0x24C396E1);
										continue;
									default:
										goto end_IL_0545;
									case 11u:
										break;
									case 1u:
										goto end_IL_0545;
									}
									goto IL_05bc;
									continue;
									end_IL_0545:
									break;
								}
								break;
							}
						}
						binaryWriter.Close();
						result = stream;
						goto end_IL_010e;
					}
					}
					goto IL_0134;
					continue;
					end_IL_010e:
					break;
				}
				break;
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			while (true)
			{
				IL_0616:
				int num5 = 2013871627;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num5 ^ 0x77435E0Bu) % 3)
					{
					case 2u:
						goto IL_0604;
					case 0u:
						break;
					default:
						ProjectData.ClearProjectError();
						goto end_IL_05e6;
					}
					goto IL_0616;
					IL_0604:
					result = null;
					num5 = (int)((num2 * 897000654) ^ 0x19F9E172);
					continue;
					end_IL_05e6:
					break;
				}
				break;
			}
		}
		return result;
	}

	private List<GClass2> method_2()
	{
		SQLiteConnection sQLiteConnection = new SQLiteConnection(global::_003CModule_003E.smethod_18<string>(340013998u, 1173328311u));
		SQLiteCommand sQLiteCommand = new SQLiteCommand(global::_003CModule_003E.smethod_21<string>(150092601u, 1020966153u), sQLiteConnection);
		List<GClass2> list = new List<GClass2>();
		try
		{
			sQLiteConnection.Open();
			SQLiteDataReader sQLiteDataReader = default(SQLiteDataReader);
			GClass2 gClass = default(GClass2);
			while (true)
			{
				IL_05e5:
				int num = -751568107;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xCCEE0A51u) % 25)
					{
					case 24u:
					{
						int num9;
						int num10;
						if (!Delegate21.delegate21_4(Delegate7.delegate7_2(sQLiteDataReader[global::_003CModule_003E.smethod_18<string>(3628430347u, 950783214u)])))
						{
							num9 = 371631269;
							num10 = 371631269;
						}
						else
						{
							num9 = 1272576129;
							num10 = 1272576129;
						}
						num = num9 ^ ((int)num2 * -186652234);
						continue;
					}
					case 23u:
						num = (int)((num2 * 892747979) ^ 0x1F2A5AAD);
						continue;
					case 22u:
						gClass.string_0 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_22<string>(3749611755u, 3834591208u)]);
						gClass.string_1 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_21<string>(2785321141u, 1398241791u)]);
						gClass.string_2 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_19<string>(2523808813u, 1287609345u)]);
						num = ((int)num2 * -148404048) ^ 0x720603E1;
						continue;
					case 21u:
						Delegate22.delegate22_14(sQLiteCommand);
						num = ((int)num2 * -1924297512) ^ 0x254FA03C;
						continue;
					case 20u:
						gClass.string_3 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_19<string>(1579589793u, 1593219037u)]);
						num = ((int)num2 * -1480199325) ^ 0x62AFDF12;
						continue;
					case 19u:
						gClass = (GClass2)Delegate3.smethod_1();
						num = -138913852;
						continue;
					case 18u:
						gClass.string_6 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_20<string>(788174627u, 3161833045u)]);
						num = ((int)num2 * -1583682731) ^ -139188397;
						continue;
					case 17u:
						sQLiteConnection.Close();
						num = ((int)num2 * -1179068692) ^ -1759621304;
						continue;
					case 16u:
						sQLiteDataReader = sQLiteCommand.ExecuteReader();
						num = ((int)num2 * -1562703186) ^ 0x19496AB8;
						continue;
					case 15u:
						gClass.string_13 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_21<string>(3044775900u, 3446157131u)]);
						num = ((int)num2 * -672930899) ^ 0x789E2D99;
						continue;
					case 14u:
						gClass.string_7 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_18<string>(2386493260u, 1117699682u)]);
						gClass.string_8 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_22<string>(1487323560u, 2607299085u)]);
						num = ((int)num2 * -19411959) ^ -1762146844;
						continue;
					case 13u:
						gClass.string_4 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_22<string>(394788843u, 840241821u)]);
						gClass.string_5 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_20<string>(48359547u, 2800509665u)]);
						num = ((int)num2 * -1988618236) ^ -1215462989;
						continue;
					case 12u:
					{
						int num8;
						if (!Delegate21.delegate21_4(Delegate7.delegate7_2(sQLiteDataReader[global::_003CModule_003E.smethod_21<string>(2966669018u, 625125449u)])))
						{
							num = -1603786678;
							num8 = -1603786678;
						}
						else
						{
							num = -1233310110;
							num8 = -1233310110;
						}
						continue;
					}
					case 11u:
						gClass.int_1 = Delegate17.delegate17_1(sQLiteDataReader[global::_003CModule_003E.smethod_22<string>(3874437416u, 565641058u)]);
						list.Add(gClass);
						num = -1595471082;
						continue;
					case 9u:
						gClass.string_11 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_21<string>(1747809829u, 3305524619u)]);
						num = ((int)num2 * -822744869) ^ -1872534177;
						continue;
					case 8u:
					{
						int num6;
						int num7;
						if (Delegate56.delegate56_0(Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_21<string>(2966669018u, 1135021756u)]), "", bool_0: false) != 0)
						{
							num6 = -1962795032;
							num7 = -1962795032;
						}
						else
						{
							num6 = -1077782740;
							num7 = -1077782740;
						}
						num = num6 ^ ((int)num2 * -2000506678);
						continue;
					}
					case 7u:
						sQLiteDataReader.Close();
						num = ((int)num2 * -1115026571) ^ -1819974052;
						continue;
					case 6u:
						gClass.string_12 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_21<string>(2966669018u, 1102144046u)]);
						num = ((int)num2 * -55368103) ^ 0x479FA5BD;
						continue;
					case 5u:
						gClass.string_10 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_19<string>(1406892721u, 5476192u)]);
						num = ((int)num2 * -1212067637) ^ 0x3CE8EAF9;
						continue;
					case 4u:
					{
						int num5;
						if (sQLiteDataReader.Read())
						{
							num = -293636123;
							num5 = -293636123;
						}
						else
						{
							num = -402805996;
							num5 = -402805996;
						}
						continue;
					}
					case 3u:
					{
						int num3;
						int num4;
						if (Delegate56.delegate56_0(Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_19<string>(4055091608u, 694137060u)]), "", bool_0: false) == 0)
						{
							num3 = -182637867;
							num4 = -182637867;
						}
						else
						{
							num3 = -174544931;
							num4 = -174544931;
						}
						num = num3 ^ ((int)num2 * -2096858263);
						continue;
					}
					case 2u:
						gClass.int_0 = Delegate17.delegate17_1(sQLiteDataReader[global::_003CModule_003E.smethod_18<string>(1116420067u, 2861251445u)]);
						num = (int)(num2 * 543118775) ^ -1898126617;
						continue;
					case 1u:
						gClass.string_9 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_21<string>(2610932928u, 988848330u)]);
						num = (int)(num2 * 1845642678) ^ -2077253241;
						continue;
					default:
						goto end_IL_056e;
					case 10u:
						break;
					case 0u:
						goto end_IL_056e;
					}
					goto IL_05e5;
					continue;
					end_IL_056e:
					break;
				}
				break;
			}
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			while (true)
			{
				IL_062f:
				int num11 = -819155659;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num11 ^ 0xCCEE0A51u) % 3)
					{
					default:
						goto end_IL_05f7;
					case 2u:
						goto IL_0615;
					case 0u:
						break;
					case 1u:
						goto end_IL_05f7;
					}
					goto IL_062f;
					IL_0615:
					Delegate51.delegate51_0();
					num11 = (int)((num2 * 1851471226) ^ 0x3E8A831F);
					continue;
					end_IL_05f7:
					break;
				}
				break;
			}
		}
		return list;
	}

	public void method_3(ref GClass2 gclass2_0)
	{
		SQLiteConnection sQLiteConnection = new SQLiteConnection(global::_003CModule_003E.smethod_18<string>(340013998u, 3776781755u));
		SQLiteCommand sQLiteCommand = new SQLiteCommand(global::_003CModule_003E.smethod_19<string>(2466066006u, 696905912u), sQLiteConnection);
		try
		{
			sQLiteConnection.Open();
			while (true)
			{
				int num = -1663216189;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xC2F04FDBu) % 7)
					{
					case 6u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_18<string>(1299212140u, 3578235839u), 1);
						num = (int)(num2 * 607946577) ^ -1461526324;
						continue;
					case 4u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_22<string>(1917263043u, 1703422785u), gclass2_0.string_0);
						num = ((int)num2 * -673502933) ^ 0x78C7ED5;
						continue;
					case 3u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_21<string>(1956688638u, 3429219290u), gclass2_0.string_1);
						num = ((int)num2 * -2005748202) ^ -457673751;
						continue;
					case 2u:
						sQLiteCommand.ExecuteNonQuery();
						Delegate22.delegate22_14(sQLiteCommand);
						num = ((int)num2 * -1518345657) ^ -1209430388;
						continue;
					case 1u:
						sQLiteConnection.Close();
						num = ((int)num2 * -1696023226) ^ -1020807862;
						continue;
					default:
						return;
					case 0u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			Delegate51.delegate51_0();
		}
	}

	private bool method_4(string string_0, MemoryStream memoryStream_0)
	{
		int num = Delegate67.delegate67_0(memoryStream_0).Length;
		HttpWebRequest httpWebRequest = (HttpWebRequest)Delegate12.delegate12_2(global::_003CModule_003E.smethod_20<string>(1111685658u, 772889775u));
		try
		{
			Delegate30.delegate30_11(httpWebRequest, global::_003CModule_003E.smethod_19<string>(1452874427u, 1234769206u));
			Delegate5.delegate5_25(httpWebRequest, bool_0: true);
			Delegate68.delegate68_0(Delegate7.delegate7_83(httpWebRequest), global::_003CModule_003E.smethod_20<string>(4199403659u, 2051567269u), global::_003CModule_003E.smethod_21<string>(1150947291u, 2762484907u));
			Delegate68.delegate68_0(Delegate7.delegate7_83(httpWebRequest), global::_003CModule_003E.smethod_19<string>(2869202957u, 2126586498u), global::_003CModule_003E.smethod_18<string>(2024587259u, 1587621782u));
			Stream stream = default(Stream);
			while (true)
			{
				IL_01ed:
				int num2 = -73678950;
				while (true)
				{
					uint num3;
					switch ((num3 = (uint)num2 ^ 0xAB82E6B6u) % 6)
					{
					case 5u:
						stream.Close();
						num2 = ((int)num3 * -984123126) ^ 0x2E2EC4CA;
						continue;
					case 4u:
						Delegate68.delegate68_0(Delegate7.delegate7_83(httpWebRequest), global::_003CModule_003E.smethod_19<string>(485664554u, 1234415980u), string_0);
						((WebHeaderCollection)Delegate7.delegate7_83(httpWebRequest)).Add(global::_003CModule_003E.smethod_20<string>(32894044u, 1925034963u), num.ToString());
						httpWebRequest.ContentType = global::_003CModule_003E.smethod_19<string>(2719496738u, 963874353u);
						httpWebRequest.ContentLength = num;
						httpWebRequest.KeepAlive = false;
						num2 = ((int)num3 * -1191062957) ^ 0x13929693;
						continue;
					case 3u:
						stream = httpWebRequest.GetRequestStream();
						stream.Write(memoryStream_0.ToArray(), 0, num);
						num2 = ((int)num3 * -212580450) ^ 0x5048AF4B;
						continue;
					case 2u:
					{
						HttpWebResponse obj = (HttpWebResponse)httpWebRequest.GetResponse();
						Console.WriteLine(obj.StatusDescription);
						stream = obj.GetResponseStream();
						StreamReader streamReader = new StreamReader(stream);
						streamReader.ReadToEnd();
						streamReader.Close();
						stream.Close();
						obj.Close();
						num2 = ((int)num3 * -210311466) ^ 0x74E9C9DF;
						continue;
					}
					default:
						goto end_IL_01c3;
					case 0u:
						break;
					case 1u:
						goto end_IL_01c3;
					}
					goto IL_01ed;
					continue;
					end_IL_01c3:
					break;
				}
				break;
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		return true;
	}
}
