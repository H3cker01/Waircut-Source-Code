internal delegate object Delegate12(string string_0);
