internal delegate void Delegate162(object object_0, object object_1, string string_0, object object_2);
