using System;

internal delegate object Delegate144(object object_0, Type type_0);
