internal delegate object Delegate204(object object_0, object[] object_1, string[] string_0);
