using System;

internal class Attribute6 : Attribute
{
	internal readonly int int_0;

	internal Attribute6(int int_1)
	{
		int_0 = int_1 - -1103980892 - -1142192007 - 1278113163;
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
