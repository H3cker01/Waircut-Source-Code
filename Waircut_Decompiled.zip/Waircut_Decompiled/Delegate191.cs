using System.Drawing;

internal delegate ContentAlignment Delegate191(object object_0);
