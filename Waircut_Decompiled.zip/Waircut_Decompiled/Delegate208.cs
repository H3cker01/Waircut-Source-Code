using System;

internal delegate IntPtr Delegate208(int int_0);
