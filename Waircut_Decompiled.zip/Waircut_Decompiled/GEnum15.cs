using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
[TypeIdentifier("c9178c19-99cf-4f6d-85c6-3ef5a176f9fb", "JSWSCAPILib.JswEngineMode")]
public enum GEnum15
{
	JswEngMode_None,
	JswEngMode_JoinNetworkPushbutton,
	JswEngMode_JoinNetworkPin,
	JswEngMode_JoinNetworkApPin,
	JswEngMode_DiscoverAp,
	JswEngMode_ConfigureAp,
	JswEngMode_RunExternalRegistrar
}
