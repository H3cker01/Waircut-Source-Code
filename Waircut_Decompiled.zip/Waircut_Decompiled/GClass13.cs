using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns1;

public class GClass13
{
	private const int int_0 = 10000;

	private const int int_1 = 1000;

	private Random random_0;

	private List<string> list_0;

	public GClass13()
	{
		random_0 = (Random)Delegate3.delegate3_98();
		list_0 = new List<string>();
	}

	public object method_0(bool bool_0)
	{
		if (bool_0)
		{
			goto IL_001f;
		}
		goto IL_0045;
		IL_001f:
		int num = -59440192;
		goto IL_0024;
		IL_0024:
		object result = default(object);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0xC3CDA3B3u) % 4)
			{
			case 3u:
				result = 11000;
				num = ((int)num2 * -1111162428) ^ 0xB780902;
				continue;
			case 0u:
				break;
			case 2u:
				goto IL_0045;
			default:
				return result;
			}
			break;
		}
		goto IL_001f;
		IL_0045:
		result = 20000;
		num = -368950770;
		goto IL_0024;
	}

	private void method_1(bool bool_0)
	{
		if (bool_0)
		{
			goto IL_00d7;
		}
		goto IL_0183;
		IL_00d7:
		int num = 1985502007;
		goto IL_0144;
		IL_0144:
		int num5 = default(int);
		int num4 = default(int);
		int num3 = default(int);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0xCE0AD25u) % 11)
			{
			case 9u:
				num5 = checked(num5 * 10 + Delegate75.delegate75_0(num5));
				num = ((int)num2 * -1234493732) ^ 0x5BC1B9E4;
				continue;
			case 8u:
				num4 = 0;
				num = ((int)num2 * -964566462) ^ -1799374281;
				continue;
			case 7u:
			{
				num3 = checked(num3 + 1);
				int num8;
				int num9;
				if (num3 > 9999)
				{
					num8 = -98794729;
					num9 = -98794729;
				}
				else
				{
					num8 = -793526556;
					num9 = -793526556;
				}
				num = num8 ^ ((int)num2 * -1569086065);
				continue;
			}
			case 6u:
			{
				int num6;
				int num7;
				if (num4 <= 9999)
				{
					num6 = 80755417;
					num7 = 80755417;
				}
				else
				{
					num6 = 720640223;
					num7 = 720640223;
				}
				num = num6 ^ ((int)num2 * -405475279);
				continue;
			}
			case 5u:
				list_0.Add(num5.ToString(global::_003CModule_003E.smethod_20<string>(1142616664u, 1924736910u)));
				num4 = checked(num4 + 1);
				num = ((int)num2 * -1813430843) ^ -1018882402;
				continue;
			case 4u:
				break;
			case 3u:
				num5 = checked(num4 * 1000 + Delegate170.delegate170_0(random_0, 0, 999));
				num = 945012740;
				continue;
			case 1u:
				list_0.Add(checked(num3 * 10000 + random_0.Next(0, 9999)).ToString(global::_003CModule_003E.smethod_20<string>(1142616664u, 1447725924u)));
				num = 695751798;
				continue;
			default:
				return;
			case 10u:
				goto IL_0183;
			case 0u:
				return;
			case 2u:
				return;
			}
			break;
		}
		goto IL_00d7;
		IL_0183:
		num3 = 0;
		num = 668170937;
		goto IL_0144;
	}

	private void method_2(string string_0, bool bool_0)
	{
		if (bool_0)
		{
			goto IL_0006;
		}
		goto IL_016e;
		IL_0006:
		int num = 1804067494;
		goto IL_0133;
		IL_0133:
		int num3 = default(int);
		int num7 = default(int);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0x857052Du) % 10)
			{
			case 9u:
				break;
			case 8u:
				num3 = checked(num3 + 1);
				num = ((int)num2 * -245921180) ^ 0x24D8391F;
				continue;
			case 7u:
				num3 = 0;
				num = ((int)num2 * -956778254) ^ 0x4422E5E8;
				continue;
			case 5u:
				checked
				{
					int num6 = (int)Delegate69.delegate69_0(Delegate171.delegate171_0(string_0) * 1000.0 + (double)num3);
					num6 = num6 * 10 + GClass3.smethod_0(Conversions.ToInteger(num6.ToString(global::_003CModule_003E.smethod_20<string>(3366795561u, 2365574441u))));
					list_0.Add(Conversions.ToString(num6));
					num = 434695175;
					continue;
				}
			case 3u:
			{
				int num8;
				int num9;
				if (num7 > 9999)
				{
					num8 = -1954208707;
					num9 = -1954208707;
				}
				else
				{
					num8 = -335659211;
					num9 = -335659211;
				}
				num = num8 ^ ((int)num2 * -1010186370);
				continue;
			}
			case 2u:
				list_0.Add((Conversions.ToDouble(string_0) * 10000.0 + (double)num7).ToString(global::_003CModule_003E.smethod_22<string>(1816240832u, 2783996704u)));
				num7 = checked(num7 + 1);
				num = 632306212;
				continue;
			case 0u:
			{
				int num4;
				int num5;
				if (num3 <= 999)
				{
					num4 = -1583231510;
					num5 = -1583231510;
				}
				else
				{
					num4 = -1203257934;
					num5 = -1203257934;
				}
				num = num4 ^ ((int)num2 * -609891142);
				continue;
			}
			default:
				return;
			case 6u:
				goto IL_016e;
			case 1u:
				return;
			case 4u:
				return;
			}
			break;
		}
		goto IL_0006;
		IL_016e:
		num7 = 0;
		num = 1495022171;
		goto IL_0133;
	}

	public List<string> method_3(bool bool_0)
	{
		List<string> list = new List<string>();
		int index = default(int);
		int num3 = default(int);
		int num4 = default(int);
		while (true)
		{
			int num = -322148374;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xD5884FB9u) % 9)
				{
				case 7u:
					index = Delegate170.delegate170_0(random_0, 0, checked(list_0.Count - 1));
					list.Add(list_0[index]);
					num = -946802178;
					continue;
				case 6u:
					num = ((int)num2 * -1234635765) ^ 0x6ED4DCE1;
					continue;
				case 4u:
				{
					int num5;
					if (num3 <= num4)
					{
						num = -942923567;
						num5 = -942923567;
					}
					else
					{
						num = -2054712635;
						num5 = -2054712635;
					}
					continue;
				}
				case 3u:
					num3 = 0;
					num = (int)(num2 * 1608600136) ^ -1875744246;
					continue;
				case 2u:
					Delegate5.delegate5_47(this, bool_0);
					index = 0;
					num4 = checked(list_0.Count - 1);
					num = (int)((num2 * 1331080481) ^ 0x723A1B33);
					continue;
				case 1u:
					num3 = checked(num3 + 1);
					num = (int)((num2 * 880015782) ^ 0x1AE38DEA);
					continue;
				case 0u:
					list_0.RemoveAt(index);
					num = (int)((num2 * 1095245347) ^ 0x6BF4957);
					continue;
				case 8u:
					break;
				default:
					return list;
				}
				break;
			}
		}
	}

	public List<string> method_4(string string_0, string string_1)
	{
		string text = Delegate57.delegate57_1(string_0, string_1);
		bool bool_ = default(bool);
		int index = default(int);
		List<string> list = default(List<string>);
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num = -1645946619;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xD9A705EFu) % 15)
				{
				case 14u:
					Delegate5.delegate5_47(this, bool_);
					num = ((int)num2 * -536486650) ^ 0x7CB8FFD8;
					continue;
				case 13u:
					text = Delegate76.delegate76_0(text, global::_003CModule_003E.smethod_21<string>(4112138032u, 3070513868u), global::_003CModule_003E.smethod_21<string>(1612244264u, 3477741858u));
					index = 0;
					num = -1463533560;
					continue;
				case 12u:
					list_0.RemoveAt(index);
					num = -466175144;
					continue;
				case 11u:
					list.Add(list_0[index]);
					num = (int)((num2 * 1896442648) ^ 0x2F2C6A32);
					continue;
				case 9u:
					num4 = checked(num4 + 1);
					num = ((int)num2 * -965137995) ^ 0x342510;
					continue;
				case 8u:
					num4 = 0;
					num = ((int)num2 * -113435841) ^ -528654110;
					continue;
				case 7u:
				{
					int num8;
					if (num4 <= num5)
					{
						num = -1277918455;
						num8 = -1277918455;
					}
					else
					{
						num = -1888508213;
						num8 = -1888508213;
					}
					continue;
				}
				case 6u:
				{
					list = new List<string>();
					int num6;
					int num7;
					if (!(Delegate96.delegate96_0(string_0, global::_003CModule_003E.smethod_20<string>(1148290382u, 1345580292u)) | Delegate96.delegate96_0(string_0, global::_003CModule_003E.smethod_20<string>(1242347932u, 3476472514u))))
					{
						num6 = -1873590817;
						num7 = -1873590817;
					}
					else
					{
						num6 = -2028230837;
						num7 = -2028230837;
					}
					num = num6 ^ (int)(num2 * 2089201356);
					continue;
				}
				case 4u:
					bool_ = Delegate56.delegate56_0(Delegate172.delegate172_0(text.Last()), global::_003CModule_003E.smethod_21<string>(4112138032u, 3823784805u), bool_0: false) == 0;
					num = (int)(num2 * 2062117765) ^ -1810751867;
					continue;
				case 3u:
					num = ((int)num2 * -2053565665) ^ 0x2C893A73;
					continue;
				case 2u:
					num5 = checked(list_0.Count - 1);
					num = (int)(num2 * 567467954) ^ -1054941758;
					continue;
				case 1u:
					Delegate117.delegate117_1(this, Delegate174.delegate174_0(Delegate173.delegate173_0(string_0)), bool_);
					num = -1058012736;
					continue;
				case 0u:
				{
					index = Delegate170.delegate170_0(random_0, 0, checked(list_0.Count - 1));
					int num3;
					if (!Delegate122.delegate122_0(list_0[index], text, CompareMethod.Binary))
					{
						num = -1454848598;
						num3 = -1454848598;
					}
					else
					{
						num = -1523161122;
						num3 = -1523161122;
					}
					continue;
				}
				case 10u:
					break;
				default:
					return list;
				}
				break;
			}
		}
	}

	public List<string> method_5(int int_2, bool bool_0)
	{
		List<string> list = new List<string>();
		int index = default(int);
		int num4 = default(int);
		int num3 = default(int);
		while (true)
		{
			int num = 1707289190;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x19AF6B79u) % 9)
				{
				case 8u:
					list_0.RemoveAt(index);
					num4 = checked(num4 + 1);
					num = (int)((num2 * 181412142) ^ 0x82542E6);
					continue;
				case 6u:
					list.Add(list_0[index]);
					num = ((int)num2 * -1769260317) ^ 0x2F5B4E9D;
					continue;
				case 5u:
					num4 = 0;
					num = ((int)num2 * -1329145915) ^ -146410617;
					continue;
				case 4u:
				{
					int num5;
					if (num4 <= num3)
					{
						num = 673078213;
						num5 = 673078213;
					}
					else
					{
						num = 350002821;
						num5 = 350002821;
					}
					continue;
				}
				case 3u:
					index = Delegate170.delegate170_0(random_0, 0, checked(list_0.Count - 1));
					num = 1246357949;
					continue;
				case 2u:
					index = 0;
					num3 = checked(list_0.Count - 1);
					num = ((int)num2 * -31203282) ^ -1177825488;
					continue;
				case 1u:
					Delegate117.delegate117_1(this, Delegate73.delegate73_0(int_2), bool_0);
					num = ((int)num2 * -1691790742) ^ 0xA242749;
					continue;
				case 0u:
					break;
				default:
					return list;
				}
				break;
			}
		}
	}
}
