using System;

internal delegate object Delegate158(Uri uri_0);
