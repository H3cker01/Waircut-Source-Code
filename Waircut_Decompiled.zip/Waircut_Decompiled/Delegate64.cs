using System;

internal delegate DateTime Delegate64();
