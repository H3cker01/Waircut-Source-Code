internal delegate void Delegate156(object object_0, string string_0, int int_0);
