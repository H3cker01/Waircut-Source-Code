using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using ns0;
using ns1;

internal class Class12 : ProgressBar
{
	private Color color_0;

	CreateParams ProgressBar.CreateParams
	{
		get
		{
			CreateParams createParams = (CreateParams)Delegate7.delegate7_208(this);
			while (true)
			{
				int num = -1216835803;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xE29FBA0Fu) % 5)
					{
					case 4u:
						Delegate32.delegate32_14(createParams, Delegate17.delegate17_22(createParams) | 0x2000000);
						num = (int)(num2 * 502209554) ^ -295265153;
						continue;
					case 2u:
					{
						int num5;
						int num6;
						if (Delegate17.delegate17_17(Delegate7.delegate7_209(Delegate3.delegate3_97())) >= 6)
						{
							num5 = 1584813060;
							num6 = 1584813060;
						}
						else
						{
							num5 = 34249073;
							num6 = 34249073;
						}
						num = num5 ^ ((int)num2 * -117725118);
						continue;
					}
					case 1u:
					{
						int num3;
						int num4;
						if (Delegate168.delegate168_0(Delegate3.delegate3_97()) == PlatformID.Win32NT)
						{
							num3 = 1600025933;
							num4 = 1600025933;
						}
						else
						{
							num3 = 1878362759;
							num4 = 1878362759;
						}
						num = num3 ^ ((int)num2 * -1492923397);
						continue;
					}
					case 0u:
						break;
					default:
						return createParams;
					}
					break;
				}
			}
		}
	}

	[EditorBrowsable(EditorBrowsableState.Always)]
	[Browsable(true)]
	string ProgressBar.Text
	{
		get
		{
			return Delegate15.delegate15_35(this);
		}
		set
		{
			Delegate30.delegate30_20(this, value);
			while (true)
			{
				int num = -1811417375;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xA1D928A6u) % 3)
					{
					case 1u:
						goto IL_000e;
					default:
						return;
					case 0u:
						break;
					case 2u:
						return;
					}
					break;
					IL_000e:
					Delegate22.delegate22_48(this);
					num = ((int)num2 * -1771387070) ^ 0x780BBB1F;
				}
			}
		}
	}

	[EditorBrowsable(EditorBrowsableState.Always)]
	[Browsable(true)]
	Font ProgressBar.Font
	{
		get
		{
			return (Font)Delegate7.delegate7_210(this);
		}
		set
		{
			Delegate8.delegate8_254(this, value);
			Delegate22.delegate22_48(this);
		}
	}

	[Category("Appearance")]
	[EditorBrowsable(EditorBrowsableState.Always)]
	[Browsable(true)]
	public Color Color_0
	{
		get
		{
			return color_0;
		}
		set
		{
			color_0 = value;
			Delegate22.delegate22_48(this);
		}
	}

	public Class12()
	{
		while (true)
		{
			int num = -1697547263;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xE54677B5u) % 3)
				{
				case 1u:
					goto IL_0008;
				case 0u:
					break;
				default:
					Delegate167.delegate167_0(this, ProgressBarStyle.Continuous);
					return;
				}
				break;
				IL_0008:
				Delegate166.delegate166_0(this, ControlStyles.UserPaint, bool_0: true);
				num = (int)(num2 * 2140840236) ^ -1891586710;
			}
		}
	}

	void Control.OnPaintBackground(PaintEventArgs pevent)
	{
	}

	void Control.OnPaint(PaintEventArgs e)
	{
		Image image = (Image)Delegate119.delegate119_0(Delegate17.delegate17_20(this), Delegate17.delegate17_21(this));
		try
		{
			Graphics graphics = (Graphics)Delegate120.delegate120_0(image);
			try
			{
				Rectangle rectangle = new Rectangle(0, 0, Delegate17.delegate17_20(this), Delegate17.delegate17_21(this));
				LinearGradientBrush brush = default(LinearGradientBrush);
				while (true)
				{
					int num = 1779723841;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x4C2E2C1u) % 9)
						{
						case 7u:
							brush = new LinearGradientBrush(rectangle, BackColor, color_0, LinearGradientMode.Vertical);
							num = 1414874455;
							continue;
						case 6u:
						{
							int num5;
							int num6;
							if (rectangle.Width == 0)
							{
								num5 = -1337623632;
								num6 = -1337623632;
							}
							else
							{
								num5 = -657733549;
								num6 = -657733549;
							}
							num = num5 ^ ((int)num2 * -1452881788);
							continue;
						}
						case 5u:
							ProgressBarRenderer.DrawHorizontalBar(graphics, rectangle);
							num = (int)(num2 * 162010688) ^ -599059666;
							continue;
						case 4u:
							rectangle.Width = checked((int)Math.Round((double)rectangle.Width * ((double)base.Value / (double)base.Maximum)));
							num = ((int)num2 * -1870039005) ^ -1374936570;
							continue;
						case 3u:
							rectangle.Width = 1;
							num = ((int)num2 * -382404663) ^ 0x506D6ADA;
							continue;
						case 1u:
						{
							int num3;
							int num4;
							if (ProgressBarRenderer.IsSupported)
							{
								num3 = -1878388017;
								num4 = -1878388017;
							}
							else
							{
								num3 = -738455122;
								num4 = -738455122;
							}
							num = num3 ^ (int)(num2 * 1697552762);
							continue;
						}
						case 0u:
							rectangle.Inflate(new Size(-2, -2));
							num = 334695782;
							continue;
						case 8u:
							break;
						default:
							graphics.FillRectangle(brush, 2, 2, rectangle.Width, rectangle.Height);
							e.Graphics.DrawImage(image, 0, 0);
							image.Dispose();
							return;
						}
						break;
					}
				}
			}
			finally
			{
				if (graphics != null)
				{
					while (true)
					{
						IL_01e3:
						int num7 = 1444709340;
						while (true)
						{
							uint num2;
							switch ((num2 = (uint)num7 ^ 0x4C2E2C1u) % 3)
							{
							case 1u:
								goto IL_01b1;
							default:
								goto end_IL_01c5;
							case 0u:
								break;
							case 2u:
								goto end_IL_01c5;
							}
							goto IL_01e3;
							IL_01b1:
							((IDisposable)graphics).Dispose();
							num7 = ((int)num2 * -418082880) ^ 0x52C15BB5;
							continue;
							end_IL_01c5:
							break;
						}
						break;
					}
				}
			}
		}
		finally
		{
			if (image != null)
			{
				while (true)
				{
					IL_0222:
					int num8 = 2097375617;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num8 ^ 0x4C2E2C1u) % 3)
						{
						case 1u:
							goto IL_01f0;
						default:
							goto end_IL_0204;
						case 2u:
							break;
						case 0u:
							goto end_IL_0204;
						}
						goto IL_0222;
						IL_01f0:
						((IDisposable)image).Dispose();
						num8 = ((int)num2 * -48304017) ^ -1998940561;
						continue;
						end_IL_0204:
						break;
					}
					break;
				}
			}
		}
	}

	void Control.WndProc(ref Message m)
	{
		Delegate169.delegate169_0(this, ref m);
		if (m.Msg != 15)
		{
			return;
		}
		string s = Strings.FormatNumber((double)checked(base.Value * 100) / (double)base.Maximum, 2) + global::_003CModule_003E.smethod_19<string>(3459454826u, 3102227699u);
		Graphics graphics = CreateGraphics();
		try
		{
			SolidBrush solidBrush = new SolidBrush(ForeColor);
			try
			{
				SizeF sizeF = graphics.MeasureString(s, System_002EWindows_002EForms_002EProgressBar_002EFont);
				while (true)
				{
					int num = 1885338485;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x194914E4u) % 3)
						{
						case 1u:
							goto IL_0074;
						default:
							return;
						case 0u:
							break;
						case 2u:
							return;
						}
						break;
						IL_0074:
						graphics.DrawString(s, System_002EWindows_002EForms_002EProgressBar_002EFont, solidBrush, ((float)base.Width - sizeF.Width) / 2f, ((float)base.Height - sizeF.Height) / 2f);
						num = (int)(num2 * 1703361489) ^ -1818335799;
					}
				}
			}
			finally
			{
				if (solidBrush != null)
				{
					while (true)
					{
						IL_0118:
						int num3 = 1368800658;
						while (true)
						{
							uint num2;
							switch ((num2 = (uint)num3 ^ 0x194914E4u) % 3)
							{
							case 1u:
								goto IL_00e6;
							default:
								goto end_IL_00fa;
							case 2u:
								break;
							case 0u:
								goto end_IL_00fa;
							}
							goto IL_0118;
							IL_00e6:
							((IDisposable)solidBrush).Dispose();
							num3 = ((int)num2 * -1329194477) ^ 0x32D853FA;
							continue;
							end_IL_00fa:
							break;
						}
						break;
					}
				}
			}
		}
		finally
		{
			if (graphics != null)
			{
				while (true)
				{
					IL_0157:
					int num4 = 1054260324;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num4 ^ 0x194914E4u) % 3)
						{
						case 2u:
							goto IL_0125;
						default:
							goto end_IL_0139;
						case 0u:
							break;
						case 1u:
							goto end_IL_0139;
						}
						goto IL_0157;
						IL_0125:
						((IDisposable)graphics).Dispose();
						num4 = (int)(num2 * 132622862) ^ -354744060;
						continue;
						end_IL_0139:
						break;
					}
					break;
				}
			}
		}
	}
}
