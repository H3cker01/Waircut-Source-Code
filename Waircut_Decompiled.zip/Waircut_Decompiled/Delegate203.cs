internal delegate string Delegate203(object object_0, int int_0, char char_0);
