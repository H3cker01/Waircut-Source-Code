using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[ComImport]
[CompilerGenerated]
[Guid("6C2216B4-6018-42B9-866B-2F795BD61B66")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface GInterface14 : GInterface3
{
}
