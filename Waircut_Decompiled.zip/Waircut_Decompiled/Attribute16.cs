using System;

internal class Attribute16 : Attribute
{
	internal readonly int int_0;

	internal Attribute16(int int_1)
	{
		while (true)
		{
			int num = -164273185;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xC13FB5CFu) % 3)
				{
				case 1u:
					goto IL_0008;
				default:
					return;
				case 2u:
					break;
				case 0u:
					return;
				}
				break;
				IL_0008:
				int_0 = ~(-int_1 - 377372557);
				num = (int)(num2 * 1361656126) ^ -275659812;
			}
		}
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
