using System.ComponentModel;

internal delegate object Delegate193(ListChangedType listChangedType_0, int int_0);
