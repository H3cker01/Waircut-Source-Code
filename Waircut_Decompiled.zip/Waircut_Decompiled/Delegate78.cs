internal delegate long Delegate78(string string_0, int int_0);
