using System;

internal delegate DateTime Delegate161(string string_0, string string_1, IFormatProvider iformatProvider_0);
