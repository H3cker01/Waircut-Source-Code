using System.Drawing;

internal delegate object Delegate188(Color color_0);
