internal delegate object Delegate83(string string_0, string string_1);
