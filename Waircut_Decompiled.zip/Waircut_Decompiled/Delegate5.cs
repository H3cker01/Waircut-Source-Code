internal delegate void Delegate5(object object_0, bool bool_0);
