internal delegate string Delegate153(GClass9 gclass9_0, GClass3.GEnum0 genum0_0);
