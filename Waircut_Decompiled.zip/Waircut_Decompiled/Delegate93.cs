internal delegate byte[] Delegate93(object object_0, ref byte[] byte_0);
