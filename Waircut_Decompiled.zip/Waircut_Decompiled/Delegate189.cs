using System.Drawing;

internal delegate SizeF Delegate189(object object_0, string string_0, object object_1);
