internal delegate object Delegate146(object object_0, GEnum9 genum9_0);
