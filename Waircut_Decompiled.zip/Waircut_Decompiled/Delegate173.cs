internal delegate uint Delegate173(string string_0);
