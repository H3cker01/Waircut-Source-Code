using ns1;

public class GClass12
{
	public enum GEnum5
	{
		Manual,
		Generic,
		Algorithm,
		PixieDust,
		BruteForce,
		PushButton
	}

	public GEnum5 Type;

	private string _description;

	private string string_0;

	public GClass3.GEnum0 genum0_0;

	public GClass11 gclass11_0;

	public string Description
	{
		get
		{
			_description = Type.ToString();
			while (true)
			{
				int num = -1501417354;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xFB68636Cu) % 13)
					{
					case 12u:
					{
						ref string description4 = ref _description;
						description4 = Delegate71.delegate71_0(description4, global::_003CModule_003E.smethod_19<string>(1905181178u, 423698467u), genum0_0.ToString());
						num = ((int)num2 * -1284418629) ^ 0x338A5102;
						continue;
					}
					case 11u:
					{
						int num12;
						int num13;
						if (Delegate56.delegate56_0(_description, "", bool_0: false) != 0)
						{
							num12 = -1422975130;
							num13 = -1422975130;
						}
						else
						{
							num12 = -1016704032;
							num13 = -1016704032;
						}
						num = num12 ^ (int)(num2 * 2009000481);
						continue;
					}
					case 10u:
					{
						int num9;
						if (Delegate56.delegate56_0(gclass11_0.string_2, "", bool_0: false) != 0)
						{
							num = -1787546123;
							num9 = -1787546123;
						}
						else
						{
							num = -1531808623;
							num9 = -1531808623;
						}
						continue;
					}
					case 9u:
					{
						ref string description2 = ref _description;
						description2 = Delegate71.delegate71_0(description2, global::_003CModule_003E.smethod_18<string>(1488256681u, 356496200u), gclass11_0.string_2);
						num = (int)((num2 * 1612707085) ^ 0xF715A55);
						continue;
					}
					case 8u:
					{
						int num4;
						int num5;
						if (Delegate56.delegate56_0(gclass11_0.string_1, "", bool_0: false) == 0)
						{
							num4 = -467354557;
							num5 = -467354557;
						}
						else
						{
							num4 = -1396073458;
							num5 = -1396073458;
						}
						num = num4 ^ ((int)num2 * -1638536547);
						continue;
					}
					case 7u:
					{
						ref string description3 = ref _description;
						description3 = Delegate71.delegate71_0(description3, global::_003CModule_003E.smethod_19<string>(1905181178u, 4029265256u), GEnum5.PixieDust.ToString());
						num = ((int)num2 * -129801339) ^ 0x1DA56227;
						continue;
					}
					case 5u:
					{
						int num6;
						if (Type != GEnum5.PixieDust)
						{
							num = -1062354294;
							num6 = -1062354294;
						}
						else
						{
							num = -484871882;
							num6 = -484871882;
						}
						continue;
					}
					case 4u:
					{
						int num10;
						int num11;
						if (Delegate56.delegate56_0(_description, "", bool_0: false) == 0)
						{
							num10 = 1698819980;
							num11 = 1698819980;
						}
						else
						{
							num10 = 1567400803;
							num11 = 1567400803;
						}
						num = num10 ^ ((int)num2 * -236549009);
						continue;
					}
					case 3u:
					{
						int num7;
						int num8;
						if (Delegate56.delegate56_0(_description, "", bool_0: false) != 0)
						{
							num7 = 292124934;
							num8 = 292124934;
						}
						else
						{
							num7 = 492711471;
							num8 = 492711471;
						}
						num = num7 ^ (int)(num2 * 199257454);
						continue;
					}
					case 1u:
					{
						ref string description = ref _description;
						description = Delegate71.delegate71_0(description, global::_003CModule_003E.smethod_22<string>(2305355784u, 2253595591u), gclass11_0.string_1);
						num = (int)(num2 * 1995485579) ^ -1517988991;
						continue;
					}
					case 0u:
					{
						int num3;
						if (genum0_0 != GClass3.GEnum0.Nothing)
						{
							num = -1637083558;
							num3 = -1637083558;
						}
						else
						{
							num = -206822378;
							num3 = -206822378;
						}
						continue;
					}
					case 6u:
						break;
					default:
						return _description;
					}
					break;
				}
			}
		}
		set
		{
			_description = value;
		}
	}

	public string Pin
	{
		get
		{
			return string_0;
		}
		set
		{
			string_0 = value;
		}
	}

	public GClass12()
	{
		Type = GEnum5.Manual;
		_description = "";
		string_0 = "";
		genum0_0 = GClass3.GEnum0.Nothing;
		gclass11_0 = (GClass11)Delegate3.delegate3_86();
	}

	public GClass12(string string_1, GEnum5 genum5_0)
	{
		Type = GEnum5.Manual;
		_description = "";
		string_0 = "";
		genum0_0 = GClass3.GEnum0.Nothing;
		gclass11_0 = (GClass11)Delegate3.delegate3_86();
		string_0 = string_1;
		Type = genum5_0;
	}

	public GClass12(GEnum5 genum5_0, GClass11 gclass11_1)
	{
		Type = GEnum5.Manual;
		_description = "";
		string_0 = "";
		genum0_0 = GClass3.GEnum0.Nothing;
		gclass11_0 = (GClass11)Delegate3.delegate3_86();
		Type = genum5_0;
		gclass11_0 = gclass11_1;
	}

	public GClass12(string string_1, GEnum5 genum5_0, GClass11 gclass11_1)
	{
		Type = GEnum5.Manual;
		_description = "";
		string_0 = "";
		genum0_0 = GClass3.GEnum0.Nothing;
		gclass11_0 = (GClass11)Delegate3.delegate3_86();
		string_0 = string_1;
		Type = genum5_0;
		gclass11_0 = gclass11_1;
	}

	public GClass12(string string_1, GClass3.GEnum0 genum0_1)
	{
		Type = GEnum5.Manual;
		_description = "";
		string_0 = "";
		genum0_0 = GClass3.GEnum0.Nothing;
		gclass11_0 = (GClass11)Delegate3.delegate3_86();
		string_0 = string_1;
		Type = GEnum5.Algorithm;
		genum0_0 = genum0_1;
	}

	public GClass12(string string_1, GClass3.GEnum0 genum0_1, GClass11 gclass11_1)
	{
		while (true)
		{
			int num = -1662327208;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x97CB464Au) % 8)
				{
				case 7u:
					genum0_0 = GClass3.GEnum0.Nothing;
					gclass11_0 = (GClass11)Delegate3.delegate3_86();
					num = ((int)num2 * -42896174) ^ -1022119015;
					continue;
				case 5u:
					string_0 = string_1;
					num = (int)((num2 * 966745060) ^ 0x3E38EE2A);
					continue;
				case 4u:
					Type = GEnum5.Algorithm;
					num = ((int)num2 * -262144449) ^ -979141546;
					continue;
				case 2u:
					Type = GEnum5.Manual;
					_description = "";
					num = ((int)num2 * -1820415470) ^ -863367257;
					continue;
				case 1u:
					string_0 = "";
					num = ((int)num2 * -769591510) ^ 0x263990F7;
					continue;
				case 0u:
					genum0_0 = genum0_1;
					num = (int)(num2 * 1824995315) ^ -1922490343;
					continue;
				case 6u:
					break;
				default:
					gclass11_0 = gclass11_1;
					return;
				}
				break;
			}
		}
	}

	bool object.Equals(object obj)
	{
		GClass12 gClass = obj as GClass12;
		if (gClass == null)
		{
			goto IL_001d;
		}
		goto IL_0043;
		IL_001d:
		int num = 2026182944;
		goto IL_0022;
		IL_0022:
		bool result = default(bool);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0x325E9E35u) % 4)
			{
			case 1u:
				result = false;
				num = ((int)num2 * -264658672) ^ 0x681659E;
				continue;
			case 0u:
				break;
			case 2u:
				goto IL_0043;
			default:
				return result;
			}
			break;
		}
		goto IL_001d;
		IL_0043:
		result = Delegate96.delegate96_1(Delegate15.delegate15_25(gClass), Delegate15.delegate15_34(this));
		num = 1004061646;
		goto IL_0022;
	}

	int object.GetHashCode()
	{
		return Delegate17.delegate17_16(Delegate15.delegate15_34(this));
	}
}
