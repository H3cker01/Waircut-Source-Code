internal delegate string Delegate141(string string_0, object object_0, object object_1, object object_2);
