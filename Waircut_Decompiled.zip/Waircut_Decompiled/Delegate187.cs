using System.Drawing;

internal delegate Color Delegate187(object object_0);
