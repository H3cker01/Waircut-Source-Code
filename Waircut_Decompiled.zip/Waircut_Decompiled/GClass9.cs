using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SQLite;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using ns0;
using ns1;

public class GClass9 : INotifyPropertyChanged
{
	public enum GEnum3
	{
		Unknow,
		Ok,
		Nok
	}

	public enum GEnum4
	{
		Nothing,
		Single,
		Several,
		Algorithm
	}

	[CompilerGenerated]
	private PropertyChangedEventHandler propertyChangedEventHandler_0;

	public GInterface5 ginterface5_0;

	public GInterface5[] ginterface5_1;

	public string string_0;

	public string string_1;

	public string string_2;

	public string string_3;

	private string string_4;

	public string string_5;

	private string string_6;

	private string string_7;

	private bool bool_0;

	private string string_8;

	public string string_9;

	public string string_10;

	private string string_11;

	private int int_0;

	private string string_12;

	public GClass15<GClass12> gclass15_0;

	public bool bool_1;

	private string string_13;

	private GClass12 gclass12_0;

	private string string_14;

	private string string_15;

	private string string_16;

	private string string_17;

	private string string_18;

	private string string_19;

	private string string_20;

	private GEnum3 genum3_0;

	private GEnum4 genum4_0;

	private bool bool_2;

	private SQLiteConnection sqliteConnection_0;

	private SQLiteConnection sqliteConnection_1;

	private SQLiteConnection sqliteConnection_2;

	public string SerialNumber
	{
		get
		{
			if (!Class13.bool_1)
			{
				goto IL_001f;
			}
			goto IL_0045;
			IL_001f:
			int num = -1980300344;
			goto IL_0024;
			IL_0024:
			string result = default(string);
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xF772A873u) % 4)
				{
				case 3u:
					result = string_4;
					num = (int)(num2 * 493594716) ^ -1347658554;
					continue;
				case 0u:
					break;
				case 2u:
					goto IL_0045;
				default:
					return result;
				}
				break;
			}
			goto IL_001f;
			IL_0045:
			result = Delegate57.delegate57_0(string_4, global::_003CModule_003E.smethod_22<string>(3063879383u, 1935993600u));
			num = -1991691278;
			goto IL_0024;
		}
		set
		{
			string_4 = value;
		}
	}

	public string UUID
	{
		get
		{
			if (!Class13.bool_1)
			{
				goto IL_0007;
			}
			goto IL_0056;
			IL_0007:
			int num = 1604460036;
			goto IL_0031;
			IL_0031:
			string result = default(string);
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x1D43E488u) % 5)
				{
				case 4u:
					break;
				case 1u:
					result = string_6;
					num = ((int)num2 * -1190727539) ^ -1842929297;
					continue;
				case 0u:
					num = ((int)num2 * -475627748) ^ -2087867360;
					continue;
				case 2u:
					goto IL_0056;
				default:
					return result;
				}
				break;
			}
			goto IL_0007;
			IL_0056:
			result = Delegate57.delegate57_0(string_6, global::_003CModule_003E.smethod_22<string>(3063879383u, 3007743553u));
			num = 864703572;
			goto IL_0031;
		}
		set
		{
			string_6 = value;
		}
	}

	public string Version => string_7;

	public string BSSID
	{
		get
		{
			if (!Class13.bool_1)
			{
				goto IL_0007;
			}
			goto IL_0056;
			IL_0007:
			int num = 269990466;
			goto IL_0031;
			IL_0031:
			string result = default(string);
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x50C33B0Au) % 5)
				{
				case 3u:
					break;
				case 2u:
					result = string_8;
					num = ((int)num2 * -1109700402) ^ 0x232A1071;
					continue;
				case 1u:
					num = (int)(num2 * 98610839) ^ -1581365954;
					continue;
				case 0u:
					goto IL_0056;
				default:
					return result;
				}
				break;
			}
			goto IL_0007;
			IL_0056:
			result = Delegate57.delegate57_1(Delegate77.delegate77_0(string_8, 0, 9), global::_003CModule_003E.smethod_19<string>(2305130035u, 1850140855u));
			num = 342063811;
			goto IL_0031;
		}
	}

	public string SSID
	{
		get
		{
			if (!Class13.bool_1)
			{
				goto IL_002e;
			}
			goto IL_0058;
			IL_002e:
			int num = -1591282629;
			goto IL_0033;
			IL_0033:
			string result = default(string);
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xBB910D1Fu) % 5)
				{
				case 4u:
					result = string_11;
					num = ((int)num2 * -770678952) ^ 0x7660088E;
					continue;
				case 1u:
					num = ((int)num2 * -580122439) ^ -1999892506;
					continue;
				case 0u:
					break;
				case 2u:
					goto IL_0058;
				default:
					return result;
				}
				break;
			}
			goto IL_002e;
			IL_0058:
			result = Delegate57.delegate57_0(string_11, global::_003CModule_003E.smethod_20<string>(1148290382u, 1868709966u));
			num = -1664688945;
			goto IL_0033;
		}
	}

	public string Channel => string_12;

	public string RSSI => int_0.ToString();

	public bool ApSetupLocked => bool_0;

	public GEnum3 Status
	{
		get
		{
			return genum3_0;
		}
		set
		{
			genum3_0 = value;
			while (true)
			{
				int num = 1898776404;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x1F510780u) % 6)
					{
					case 4u:
						Delegate22.delegate22_40(this);
						num = 929611352;
						continue;
					case 3u:
						Delegate22.delegate22_39(this);
						num = ((int)num2 * -896699823) ^ -1136897080;
						continue;
					case 2u:
					{
						int num3;
						int num4;
						if (!Delegate21.delegate21_16(this))
						{
							num3 = 1042627152;
							num4 = 1042627152;
						}
						else
						{
							num3 = 298406469;
							num4 = 298406469;
						}
						num = num3 ^ (int)(num2 * 748637301);
						continue;
					}
					default:
						return;
					case 5u:
						break;
					case 0u:
						return;
					case 1u:
						return;
					}
					break;
				}
			}
		}
	}

	public GEnum4 PinStatus => genum4_0;

	public string NetworkKey
	{
		get
		{
			if (!Class13.bool_1)
			{
				goto IL_0018;
			}
			goto IL_0058;
			IL_0018:
			int num = 168800050;
			goto IL_0033;
			IL_0033:
			string result = default(string);
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x11EC0F24u) % 5)
				{
				case 4u:
					num = ((int)num2 * -506603212) ^ 0x41B30017;
					continue;
				case 3u:
					break;
				case 1u:
					result = string_13;
					num = (int)((num2 * 1906030948) ^ 0x2098D1F);
					continue;
				case 0u:
					goto IL_0058;
				default:
					return result;
				}
				break;
			}
			goto IL_0018;
			IL_0058:
			result = Delegate57.delegate57_0(string_13, global::_003CModule_003E.smethod_18<string>(3260271878u, 4142150007u));
			num = 814889995;
			goto IL_0033;
		}
		set
		{
			string_13 = value;
		}
	}

	public string PKE
	{
		get
		{
			if (ginterface5_1[4] != null)
			{
				while (true)
				{
					int num = -458648685;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x8FFF2ECBu) % 3)
						{
						case 2u:
							string_14 = Delegate150.delegate150_0((Array)Delegate146.delegate146_0(ginterface5_1[4], GEnum9.JswAttr_PublicKey), global::_003CModule_003E.smethod_22<string>(3900288055u, 50347090u));
							num = ((int)num2 * -1353375288) ^ -1417739049;
							continue;
						case 0u:
							break;
						default:
							goto end_IL_0071;
						}
						break;
					}
					continue;
					end_IL_0071:
					break;
				}
			}
			return string_14;
		}
	}

	public string PKR
	{
		get
		{
			if (ginterface5_1[4] != null)
			{
				while (true)
				{
					int num = -996886935;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0xD07FE689u) % 3)
						{
						case 1u:
							string_15 = Delegate150.delegate150_0((Array)Delegate146.delegate146_0(ginterface5_1[5], GEnum9.JswAttr_PublicKey), global::_003CModule_003E.smethod_21<string>(3545203245u, 2291197379u));
							num = ((int)num2 * -1082844989) ^ -833279786;
							continue;
						case 2u:
							break;
						default:
							goto end_IL_0071;
						}
						break;
					}
					continue;
					end_IL_0071:
					break;
				}
			}
			return string_15;
		}
	}

	public string E_HAS1
	{
		get
		{
			if (ginterface5_1[4] != null)
			{
				while (true)
				{
					int num = 1567848775;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x131156BEu) % 3)
						{
						case 1u:
							string_16 = Delegate150.delegate150_0((Array)Delegate146.delegate146_0(ginterface5_1[7], GEnum9.JswAttr_E_Hash1), global::_003CModule_003E.smethod_21<string>(3545203245u, 2770085862u));
							num = (int)((num2 * 314336504) ^ 0x7A77B818);
							continue;
						case 2u:
							break;
						default:
							goto end_IL_0071;
						}
						break;
					}
					continue;
					end_IL_0071:
					break;
				}
			}
			return string_16;
		}
	}

	public string E_HAS2
	{
		get
		{
			if (ginterface5_1[4] != null)
			{
				while (true)
				{
					int num = 688122183;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x9B11F8Du) % 3)
						{
						case 1u:
							string_17 = Delegate150.delegate150_0((Array)Delegate146.delegate146_0(ginterface5_1[7], GEnum9.JswAttr_E_Hash2), global::_003CModule_003E.smethod_22<string>(3900288055u, 833804776u));
							num = (int)((num2 * 532729152) ^ 0x7060E8A0);
							continue;
						case 0u:
							break;
						default:
							goto end_IL_0071;
						}
						break;
					}
					continue;
					end_IL_0071:
					break;
				}
			}
			return string_17;
		}
	}

	public string E_NONCE
	{
		get
		{
			if (ginterface5_1[4] != null)
			{
				while (true)
				{
					int num = -1240964470;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0xBA8A524Eu) % 3)
						{
						case 2u:
							string_18 = Delegate150.delegate150_0((Array)Delegate146.delegate146_0(ginterface5_1[4], GEnum9.JswAttr_EnrolleeNonce), global::_003CModule_003E.smethod_20<string>(2863696683u, 3775398579u));
							num = ((int)num2 * -1985005682) ^ -1583921967;
							continue;
						case 0u:
							break;
						default:
							goto end_IL_0071;
						}
						break;
					}
					continue;
					end_IL_0071:
					break;
				}
			}
			return string_18;
		}
	}

	public string R_NONCE
	{
		get
		{
			if (ginterface5_1[4] != null)
			{
				while (true)
				{
					int num = -908935634;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0xF8B1DFFBu) % 3)
						{
						case 2u:
							string_19 = Delegate150.delegate150_0((Array)Delegate146.delegate146_0(ginterface5_1[5], GEnum9.JswAttr_RegistrarNonce), global::_003CModule_003E.smethod_22<string>(3900288055u, 836288247u));
							num = ((int)num2 * -475051061) ^ -605117845;
							continue;
						case 0u:
							break;
						default:
							goto end_IL_0071;
						}
						break;
					}
					continue;
					end_IL_0071:
					break;
				}
			}
			return string_19;
		}
	}

	public string AuthKey
	{
		get
		{
			if (ginterface5_1[5] != null)
			{
				goto IL_00a9;
			}
			goto IL_00d3;
			IL_00a9:
			int num = 1893671666;
			goto IL_00ae;
			IL_00ae:
			string result = default(string);
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x1FD3AFFEu) % 5)
				{
				case 4u:
					num = (int)((num2 * 746388938) ^ 0x673E8237);
					continue;
				case 1u:
				{
					Delegate151 delegate151_ = Delegate151.delegate151_0;
					Delegate7 delegate7_ = Delegate7.delegate7_2;
					Delegate148 delegate148_ = Delegate148.delegate148_0;
					GInterface5 gInterface = (GInterface5)Delegate146.delegate146_0(ginterface5_1[5], GEnum9.JswAttr_VendorExtension);
					object obj = delegate7_(delegate148_(this, ref gInterface, GEnum9.JswAttr_Data));
					result = delegate151_(array_1: (Array)Delegate7.delegate7_2(Delegate148.delegate148_0(this, ref ginterface5_1[5], GEnum9.JswAttr_PublicKey)), array_0: (Array)obj);
					num = ((int)num2 * -170364576) ^ -2142309188;
					continue;
				}
				case 0u:
					break;
				case 3u:
					goto IL_00d3;
				default:
					return result;
				}
				break;
			}
			goto IL_00a9;
			IL_00d3:
			result = "";
			num = 1351697187;
			goto IL_00ae;
		}
	}

	public GClass12 Pin
	{
		get
		{
			return gclass12_0;
		}
		set
		{
			gclass12_0 = value;
			Delegate22.delegate22_41(this);
			if (Delegate21.delegate21_16(this))
			{
				goto IL_003b;
			}
			goto IL_0065;
			IL_003b:
			int num = -1609085052;
			goto IL_0040;
			IL_0040:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xECFB9D13u) % 5)
				{
				case 3u:
					Delegate22.delegate22_39(this);
					num = ((int)num2 * -1104377998) ^ -249126147;
					continue;
				case 0u:
					break;
				default:
					return;
				case 4u:
					goto IL_0065;
				case 1u:
					return;
				case 2u:
					return;
				}
				break;
			}
			goto IL_003b;
			IL_0065:
			Delegate22.delegate22_40(this);
			num = -1090632502;
			goto IL_0040;
		}
	}

	event PropertyChangedEventHandler INotifyPropertyChanged.PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			PropertyChangedEventHandler propertyChangedEventHandler = propertyChangedEventHandler_0;
			PropertyChangedEventHandler propertyChangedEventHandler2 = default(PropertyChangedEventHandler);
			while (true)
			{
				int num = -1832179606;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xE9F336E7u) % 4)
					{
					case 1u:
					{
						propertyChangedEventHandler2 = propertyChangedEventHandler;
						PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate95.delegate95_0(propertyChangedEventHandler2, value);
						propertyChangedEventHandler = Interlocked.CompareExchange(ref propertyChangedEventHandler_0, value2, propertyChangedEventHandler2);
						num = -1719974625;
						continue;
					}
					case 0u:
					{
						int num3;
						int num4;
						if ((object)propertyChangedEventHandler == propertyChangedEventHandler2)
						{
							num3 = -1879148444;
							num4 = -1879148444;
						}
						else
						{
							num3 = -862059614;
							num4 = -862059614;
						}
						num = num3 ^ (int)(num2 * 260882439);
						continue;
					}
					default:
						return;
					case 2u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
		[CompilerGenerated]
		remove
		{
			PropertyChangedEventHandler propertyChangedEventHandler = propertyChangedEventHandler_0;
			PropertyChangedEventHandler propertyChangedEventHandler2 = default(PropertyChangedEventHandler);
			while (true)
			{
				int num = 1677260896;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x1C4DC1DBu) % 5)
					{
					case 3u:
					{
						PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate95.delegate95_1(propertyChangedEventHandler2, value);
						propertyChangedEventHandler = Interlocked.CompareExchange(ref propertyChangedEventHandler_0, value2, propertyChangedEventHandler2);
						num = (int)((num2 * 1840222017) ^ 0x1152FC9A);
						continue;
					}
					case 2u:
						propertyChangedEventHandler2 = propertyChangedEventHandler;
						num = 1078370487;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if ((object)propertyChangedEventHandler != propertyChangedEventHandler2)
						{
							num3 = 695298558;
							num4 = 695298558;
						}
						else
						{
							num3 = 1341558043;
							num4 = 1341558043;
						}
						num = num3 ^ ((int)num2 * -2091399466);
						continue;
					}
					default:
						return;
					case 4u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
	}

	public GClass9(ref GInterface5 ginterface5_2)
	{
		while (true)
		{
			int num = -1607977132;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xB28FBADFu) % 24)
				{
				case 23u:
					string_10 = "";
					num = (int)(num2 * 1202320691) ^ -169686821;
					continue;
				case 22u:
					string_20 = "";
					num = (int)(num2 * 1924421524) ^ -1408088885;
					continue;
				case 21u:
					string_4 = "";
					string_5 = "";
					num = ((int)num2 * -1636349321) ^ 0x4948361B;
					continue;
				case 20u:
					bool_1 = false;
					string_13 = "";
					num = (int)((num2 * 1713098837) ^ 0x249BA867);
					continue;
				case 19u:
					int_0 = 0;
					string_12 = "";
					gclass15_0 = new GClass15<GClass12>();
					num = ((int)num2 * -1191097047) ^ -2140075464;
					continue;
				case 18u:
					string_1 = "";
					num = (int)((num2 * 1087421661) ^ 0x2DEDC3FE);
					continue;
				case 17u:
					bool_2 = false;
					sqliteConnection_0 = new SQLiteConnection(global::_003CModule_003E.smethod_19<string>(2574572660u, 4090559847u));
					num = (int)(num2 * 574472254) ^ -261051456;
					continue;
				case 15u:
					string_14 = "";
					num = (int)((num2 * 2141330529) ^ 0x7BE394C2);
					continue;
				case 14u:
					Delegate147.delegate147_0(this, ref ginterface5_2);
					num = (int)((num2 * 825539312) ^ 0x4ACC3B81);
					continue;
				case 12u:
					gclass12_0 = (GClass12)Delegate3.delegate3_48();
					num = ((int)num2 * -338493731) ^ -2103103284;
					continue;
				case 11u:
					string_2 = "";
					num = (int)(num2 * 1543886030) ^ -742671385;
					continue;
				case 10u:
					string_15 = "";
					num = (int)(num2 * 2121868213) ^ -1870108229;
					continue;
				case 9u:
					string_11 = "";
					num = ((int)num2 * -1134940539) ^ -1804836071;
					continue;
				case 8u:
					string_9 = "";
					num = ((int)num2 * -939993293) ^ -2062976448;
					continue;
				case 7u:
					string_6 = "";
					string_7 = "";
					bool_0 = false;
					num = (int)(num2 * 859910021) ^ -2141711028;
					continue;
				case 6u:
					Delegate22.delegate22_36(this);
					num = (int)((num2 * 1459096572) ^ 0x13CDFDA2);
					continue;
				case 5u:
					Delegate22.delegate22_37(this);
					num = (int)((num2 * 2083299850) ^ 0x7FDA8DF0);
					continue;
				case 4u:
					genum3_0 = GEnum3.Unknow;
					genum4_0 = GEnum4.Nothing;
					num = ((int)num2 * -115374682) ^ 0x5D12D9EE;
					continue;
				case 3u:
					ginterface5_1 = new GInterface5[17];
					string_0 = "";
					num = ((int)num2 * -301815892) ^ -706781919;
					continue;
				case 2u:
					string_3 = "";
					num = (int)(num2 * 1300082338) ^ -95184482;
					continue;
				case 1u:
					sqliteConnection_1 = new SQLiteConnection(global::_003CModule_003E.smethod_18<string>(3019185181u, 3291773025u));
					sqliteConnection_2 = new SQLiteConnection(global::_003CModule_003E.smethod_18<string>(340013998u, 1750196944u));
					num = ((int)num2 * -2073085646) ^ -1610751533;
					continue;
				case 0u:
					string_8 = "";
					num = (int)(num2 * 855566462) ^ -474016017;
					continue;
				default:
					return;
				case 16u:
					break;
				case 13u:
					return;
				}
				break;
			}
		}
	}

	private void method_0()
	{
		Delegate22.delegate22_38(this);
		IEnumerator<GClass12> enumerator = default(IEnumerator<GClass12>);
		try
		{
			enumerator = gclass15_0.GetEnumerator();
			int count = default(int);
			GClass12 current = default(GClass12);
			while (true)
			{
				IL_01e3:
				int num;
				int num2;
				if (Delegate21.delegate21_3(enumerator))
				{
					num = 645292901;
					num2 = 645292901;
				}
				else
				{
					num = 870772369;
					num2 = 870772369;
				}
				while (true)
				{
					uint num3;
					switch ((num3 = (uint)num ^ 0x13A10856u) % 15)
					{
					case 14u:
						genum4_0 = GEnum4.Nothing;
						num = (int)(num3 * 16917497) ^ -427599708;
						continue;
					case 13u:
					{
						count = gclass15_0.Count;
						int num9;
						if (count != 0)
						{
							num = 166035646;
							num9 = 166035646;
						}
						else
						{
							num = 405195531;
							num9 = 405195531;
						}
						continue;
					}
					case 12u:
					{
						int num7;
						if (count == 1)
						{
							num = 920819566;
							num7 = 920819566;
						}
						else
						{
							num = 1024579598;
							num7 = 1024579598;
						}
						continue;
					}
					case 11u:
						genum4_0 = GEnum4.Several;
						num = (int)(num3 * 413332306) ^ -1378653503;
						continue;
					case 10u:
						genum4_0 = GEnum4.Algorithm;
						num = ((int)num3 * -1590075855) ^ -759150998;
						continue;
					case 9u:
						num = ((int)num3 * -1523775921) ^ 0x4E23EBD4;
						continue;
					case 8u:
					{
						int num8;
						if (count > 1)
						{
							num = 1610173342;
							num8 = 1610173342;
						}
						else
						{
							num = 1291838673;
							num8 = 1291838673;
						}
						continue;
					}
					case 6u:
						current = enumerator.Current;
						num = 1187320242;
						continue;
					case 5u:
					{
						int num6;
						if (current.gclass11_0.bool_0)
						{
							num = 2096304598;
							num6 = 2096304598;
						}
						else
						{
							num = 1013352788;
							num6 = 1013352788;
						}
						continue;
					}
					case 4u:
						genum4_0 = GEnum4.Single;
						num = (int)((num3 * 923981706) ^ 0x7765000D);
						continue;
					case 3u:
					{
						int num4;
						int num5;
						if (current.genum0_0 != GClass3.GEnum0.Nothing)
						{
							num4 = -799985843;
							num5 = -799985843;
						}
						else
						{
							num4 = -1201501743;
							num5 = -1201501743;
						}
						num = num4 ^ ((int)num3 * -1060193204);
						continue;
					}
					case 1u:
						bool_1 = true;
						num = (int)(num3 * 557641793) ^ -1985548076;
						continue;
					case 0u:
						num = 645292901;
						continue;
					default:
						goto end_IL_0186;
					case 2u:
						break;
					case 7u:
						goto end_IL_0186;
					}
					goto IL_01e3;
					continue;
					end_IL_0186:
					break;
				}
				break;
			}
		}
		finally
		{
			if (enumerator != null)
			{
				while (true)
				{
					IL_0231:
					int num10 = 1139963159;
					while (true)
					{
						uint num3;
						switch ((num3 = (uint)num10 ^ 0x13A10856u) % 3)
						{
						case 2u:
							goto IL_01fc;
						default:
							goto end_IL_0214;
						case 0u:
							break;
						case 1u:
							goto end_IL_0214;
						}
						goto IL_0231;
						IL_01fc:
						Delegate22.delegate22_4(enumerator);
						num10 = ((int)num3 * -1060769922) ^ -1785092767;
						continue;
						end_IL_0214:
						break;
					}
					break;
				}
			}
		}
		if (Delegate56.delegate56_0(Delegate15.delegate15_25(gclass12_0), "", bool_0: false) == 0)
		{
			return;
		}
		while (true)
		{
			int num11 = 1683809323;
			while (true)
			{
				uint num3;
				switch ((num3 = (uint)num11 ^ 0x13A10856u) % 4)
				{
				case 1u:
				{
					int num12;
					int num13;
					if (!gclass15_0.Contains(gclass12_0))
					{
						num12 = 1955317522;
						num13 = 1955317522;
					}
					else
					{
						num12 = 1771213308;
						num13 = 1771213308;
					}
					num11 = num12 ^ ((int)num3 * -613890900);
					continue;
				}
				case 0u:
					gclass15_0.Add(gclass12_0);
					num11 = ((int)num3 * -1587000410) ^ 0x52E76950;
					continue;
				default:
					return;
				case 3u:
					break;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	public void method_1(GInterface5 ginterface5_2)
	{
		bool_0 = Delegate108.delegate108_1(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_ConfigurationError), GEnum10.JswConfigError_SetupLocked, bool_0: false);
	}

	public void method_2(ref GInterface5 ginterface5_2, GEnum16 genum16_0)
	{
		try
		{
			bool flag = bool_2;
			PropertyChangedEventHandler propertyChangedEventHandler = default(PropertyChangedEventHandler);
			while (true)
			{
				int num = 1990713864;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x52570B38u) % 13)
					{
					case 12u:
					{
						int num7;
						if (!flag & bool_2)
						{
							num = 725439745;
							num7 = 725439745;
						}
						else
						{
							num = 1438746399;
							num7 = 1438746399;
						}
						continue;
					}
					case 11u:
					{
						int num5;
						int num6;
						if (genum16_0 == GEnum16.JswMsgType_M1)
						{
							num5 = 1946718003;
							num6 = 1946718003;
						}
						else
						{
							num5 = 1323918343;
							num6 = 1323918343;
						}
						num = num5 ^ (int)(num2 * 209404198);
						continue;
					}
					case 10u:
					{
						int num8;
						int num9;
						if (propertyChangedEventHandler != null)
						{
							num8 = 332890901;
							num9 = 332890901;
						}
						else
						{
							num8 = 306577271;
							num9 = 306577271;
						}
						num = num8 ^ (int)(num2 * 241747549);
						continue;
					}
					case 9u:
						Delegate147.delegate147_1(this, ref ginterface5_2);
						num = 1120922781;
						continue;
					case 7u:
						Delegate147.delegate147_0(this, ref ginterface5_2);
						num = 444478368;
						continue;
					case 6u:
						num = ((int)num2 * -829081909) ^ 0x69D81C15;
						continue;
					case 5u:
						propertyChangedEventHandler(this, (PropertyChangedEventArgs)Delegate12.delegate12_5(Delegate15.delegate15_28(this)));
						num = ((int)num2 * -1796236387) ^ -11556286;
						continue;
					case 3u:
						gclass15_0.Clear();
						Delegate22.delegate22_37(this);
						num = ((int)num2 * -2039495255) ^ -407857218;
						continue;
					case 2u:
					{
						int num3;
						int num4;
						if (genum16_0 == GEnum16.JswMsgType_Beacon)
						{
							num3 = -641079207;
							num4 = -641079207;
						}
						else
						{
							num3 = -758859657;
							num4 = -758859657;
						}
						num = num3 ^ ((int)num2 * -1974532217);
						continue;
					}
					case 1u:
						propertyChangedEventHandler = propertyChangedEventHandler_0;
						num = 2069870579;
						continue;
					case 0u:
						num = ((int)num2 * -362685155) ^ -2036659924;
						continue;
					default:
						return;
					case 8u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			Delegate51.delegate51_0();
		}
	}

	private void method_3(ref GInterface5 ginterface5_2)
	{
		ginterface5_0 = ginterface5_2;
		try
		{
			string_8 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_MACAddress));
			GInterface5 gInterface = default(GInterface5);
			while (true)
			{
				int num = -1170936454;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x85AB72D6u) % 28)
					{
					case 27u:
						string_6 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref gInterface, GEnum9.JswAttr_UUID_E));
						num = ((int)num2 * -1377416728) ^ 0x61F604C;
						continue;
					case 25u:
						string_4 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref gInterface, GEnum9.JswAttr_SerialNumber));
						num = (int)(num2 * 2129164781) ^ -1403819670;
						continue;
					case 23u:
						int_0 = Delegate17.delegate17_1(Delegate59.delegate59_3(Delegate59.delegate59_2(int_0, Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_Rssi)), 2));
						num = -2120631416;
						continue;
					case 22u:
						string_12 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_APChannel));
						num = -478280713;
						continue;
					case 21u:
						string_0 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref gInterface, GEnum9.JswAttr_DeviceName));
						num = ((int)num2 * -1277135962) ^ 0x5B56C95C;
						continue;
					case 20u:
						string_11 = Delegate15.delegate15_8(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_SSID));
						num = ((int)num2 * -1359605953) ^ -911067486;
						continue;
					case 19u:
						bool_2 = (Delegate56.delegate56_0(string_0, "", bool_0: false) != 0) & (Delegate56.delegate56_0(string_1, "", bool_0: false) != 0) & (Delegate56.delegate56_0(string_2, "", bool_0: false) != 0) & (Delegate56.delegate56_0(Delegate15.delegate15_29(this), "", bool_0: false) != 0);
						num = -1270950938;
						continue;
					case 18u:
					{
						int num14;
						if (Delegate56.delegate56_0(string_2, "", bool_0: false) == 0)
						{
							num = -1686627765;
							num14 = -1686627765;
						}
						else
						{
							num = -627781337;
							num14 = -627781337;
						}
						continue;
					}
					case 17u:
						string_2 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref gInterface, GEnum9.JswAttr_ModelName));
						num = (int)((num2 * 413033813) ^ 0x37C97C06);
						continue;
					case 16u:
						string_7 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref gInterface, GEnum9.JswAttr_Version));
						num = (int)(num2 * 1779915324) ^ -2075768239;
						continue;
					case 15u:
					{
						Delegate147 delegate147_ = Delegate147.delegate147_2;
						GInterface5 gInterface2 = (GInterface5)Delegate148.delegate148_0(this, ref gInterface, GEnum9.JswAttr_VendorExtension);
						delegate147_(this, ref gInterface2);
						bool_0 = Delegate21.delegate21_1(Delegate148.delegate148_0(this, ref gInterface, GEnum9.JswAttr_APSetupLocked));
						int num10;
						if (Delegate56.delegate56_0(string_10, "", bool_0: false) == 0)
						{
							num = -1018872342;
							num10 = -1018872342;
						}
						else
						{
							num = -1581241419;
							num10 = -1581241419;
						}
						continue;
					}
					case 14u:
					{
						int num8;
						if (Delegate56.delegate56_0(string_6, "", bool_0: false) == 0)
						{
							num = -2138378915;
							num8 = -2138378915;
						}
						else
						{
							num = -2067375948;
							num8 = -2067375948;
						}
						continue;
					}
					case 13u:
						string_9 = Delegate15.delegate15_2(Delegate59.delegate59_0(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_AuthenticationTypeFlags), Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_EncryptionTypeFlags)));
						num = ((int)num2 * -187989562) ^ -816812458;
						continue;
					case 12u:
						string_10 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref gInterface, GEnum9.JswAttr_ConfigMethods));
						num = ((int)num2 * -499757840) ^ 0x4C5833F5;
						continue;
					case 11u:
						string_3 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref gInterface, GEnum9.JswAttr_ModelNumber));
						num = (int)(num2 * 1887010995) ^ -574709948;
						continue;
					case 10u:
						string_1 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref gInterface, GEnum9.JswAttr_Manufacturer));
						num = (int)(num2 * 928363644) ^ -1398323308;
						continue;
					case 9u:
					{
						int num15;
						if (Delegate56.delegate56_0(string_5, "", bool_0: false) == 0)
						{
							num = -193843026;
							num15 = -193843026;
						}
						else
						{
							num = -415579292;
							num15 = -415579292;
						}
						continue;
					}
					case 8u:
					{
						int num12;
						int num13;
						if (int_0 != 0)
						{
							num12 = 1508263729;
							num13 = 1508263729;
						}
						else
						{
							num12 = 966152705;
							num13 = 966152705;
						}
						num = num12 ^ (int)(num2 * 2027304912);
						continue;
					}
					case 7u:
					{
						int num11;
						if (Delegate56.delegate56_0(Delegate15.delegate15_29(this), "", bool_0: false) != 0)
						{
							num = -1377666877;
							num11 = -1377666877;
						}
						else
						{
							num = -1472545285;
							num11 = -1472545285;
						}
						continue;
					}
					case 6u:
					{
						gInterface = (GInterface5)Delegate146.delegate146_0(ginterface5_2, GEnum9.JswAttr_SimpleConfigIEs);
						int num9;
						if (Delegate56.delegate56_0(string_0, "", bool_0: false) != 0)
						{
							num = -1231990046;
							num9 = -1231990046;
						}
						else
						{
							num = -1736140141;
							num9 = -1736140141;
						}
						continue;
					}
					case 5u:
					{
						int num6;
						int num7;
						if (Delegate56.delegate56_0(string_9, "", bool_0: false) != 0)
						{
							num6 = -1865540610;
							num7 = -1865540610;
						}
						else
						{
							num6 = -690039535;
							num7 = -690039535;
						}
						num = num6 ^ ((int)num2 * -1724009346);
						continue;
					}
					case 4u:
					{
						int num5;
						if (Delegate56.delegate56_0(string_1, "", bool_0: false) != 0)
						{
							num = -1865034548;
							num5 = -1865034548;
						}
						else
						{
							num = -1906919236;
							num5 = -1906919236;
						}
						continue;
					}
					case 3u:
						int_0 = Delegate17.delegate17_1(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_Rssi));
						num = ((int)num2 * -293167386) ^ 0x433154A2;
						continue;
					case 2u:
					{
						int num4;
						if (Delegate56.delegate56_0(string_7, "", bool_0: false) == 0)
						{
							num = -1714807330;
							num4 = -1714807330;
						}
						else
						{
							num = -1244618831;
							num4 = -1244618831;
						}
						continue;
					}
					case 1u:
					{
						int num3;
						if (Delegate56.delegate56_0(string_3, "", bool_0: false) == 0)
						{
							num = -1833746207;
							num3 = -1833746207;
						}
						else
						{
							num = -692387023;
							num3 = -692387023;
						}
						continue;
					}
					case 0u:
						string_5 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref gInterface, GEnum9.JswAttr_RFBand));
						num = ((int)num2 * -1213248187) ^ -1481653956;
						continue;
					default:
						return;
					case 26u:
						break;
					case 24u:
						return;
					}
					break;
				}
			}
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			Delegate51.delegate51_0();
		}
	}

	private void method_4(ref GInterface5 ginterface5_2)
	{
		string_1 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_Manufacturer));
		while (true)
		{
			int num = -718311761;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xD00D0AC3u) % 8)
				{
				case 7u:
					string_4 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_SerialNumber));
					num = (int)(num2 * 394064843) ^ -1732171292;
					continue;
				case 6u:
					string_5 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_RFBand));
					string_6 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_UUID_E));
					num = ((int)num2 * -864478838) ^ -664549242;
					continue;
				case 4u:
					string_2 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_ModelName));
					num = (int)(num2 * 1490370409) ^ -1752817276;
					continue;
				case 3u:
					string_3 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_ModelNumber));
					num = ((int)num2 * -5486235) ^ -1188212173;
					continue;
				case 2u:
					string_0 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_DeviceName));
					num = ((int)num2 * -1602929380) ^ 0x7A62C23D;
					continue;
				case 1u:
					string_10 = Delegate15.delegate15_2(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_ConfigMethods));
					bool_0 = Delegate108.delegate108_1(Delegate148.delegate148_0(this, ref ginterface5_2, GEnum9.JswAttr_ConfigurationError), GEnum10.JswConfigError_SetupLocked, bool_0: false);
					bool_2 = true;
					num = ((int)num2 * -318379447) ^ -765153281;
					continue;
				default:
					return;
				case 0u:
					break;
				case 5u:
					return;
				}
				break;
			}
		}
	}

	private void method_5(ref GInterface5 ginterface5_2)
	{
		if (Delegate17.delegate17_15(ginterface5_2) == 0)
		{
			return;
		}
		byte[] array = default(byte[]);
		int num5 = default(int);
		while (true)
		{
			int num = -527620228;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xA7A95C25u) % 8)
				{
				case 7u:
				{
					int num6;
					int num7;
					if (array[0] != 0)
					{
						num6 = 1174423774;
						num7 = 1174423774;
					}
					else
					{
						num6 = 244541042;
						num7 = 244541042;
					}
					num = num6 ^ ((int)num2 * -588837577);
					continue;
				}
				case 6u:
					num5 = Delegate74.delegate74_1(Delegate149.delegate149_0(array[2]));
					num = (int)((num2 * 12629567) ^ 0x4F638513);
					continue;
				case 5u:
					array = (byte[])Delegate146.delegate146_0(ginterface5_2, GEnum9.JswAttr_Data);
					num = (int)(num2 * 772468764) ^ -1556219674;
					continue;
				case 4u:
					string_7 = Delegate137.delegate137_0(global::_003CModule_003E.smethod_19<string>(75548643u, 3365802358u), (double)num5 / 10.0, (double)num5 - (double)num5 / 10.0 * 10.0);
					num = ((int)num2 * -1803456846) ^ -1985966641;
					continue;
				case 3u:
					array = new byte[1025];
					num = (int)(num2 * 492336214) ^ -2128239110;
					continue;
				case 1u:
				{
					int num3;
					int num4;
					if (Delegate108.delegate108_1(Delegate146.delegate146_0(ginterface5_2, GEnum9.JswAttr_VendorExtID), 14122, bool_0: false))
					{
						num3 = -304631103;
						num4 = -304631103;
					}
					else
					{
						num3 = -1499223072;
						num4 = -1499223072;
					}
					num = num3 ^ (int)(num2 * 1129014975);
					continue;
				}
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	private void method_6()
	{
		try
		{
			if (gclass15_0.Contains(gclass12_0))
			{
				return;
			}
			while (true)
			{
				int num = -1726399035;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xF8831767u) % 3)
					{
					case 2u:
						goto IL_0015;
					default:
						return;
					case 0u:
						break;
					case 1u:
						return;
					}
					break;
					IL_0015:
					gclass15_0.Add(gclass12_0);
					num = ((int)num2 * -1275028541) ^ 0x31D4FECB;
				}
			}
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			Delegate51.delegate51_0();
		}
	}

	private object method_7(ref GInterface5 ginterface5_2, GEnum9 genum9_0)
	{
		string text = "";
		object result = default(object);
		try
		{
			object object_2 = default(object);
			object object_ = default(object);
			while (true)
			{
				IL_0d80:
				int num = 1037515840;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x21A4DD1Bu) % 59)
					{
					case 58u:
					{
						int num24;
						int num25;
						if (genum9_0 == GEnum9.JswAttr_Rssi)
						{
							num24 = -1141261946;
							num25 = -1141261946;
						}
						else
						{
							num24 = -495355509;
							num25 = -495355509;
						}
						num = num24 ^ (int)(num2 * 177459888);
						continue;
					}
					case 57u:
						switch (genum9_0)
						{
						case GEnum9.JswAttr_UUID_E:
						case GEnum9.JswAttr_UUID_R:
							goto IL_0069;
						case GEnum9.JswAttr_Version:
							goto IL_0095;
						case GEnum9.JswAttr_VendorExtension:
							goto IL_10a3;
						}
						num = ((int)num2 * -352927035) ^ -276380090;
						continue;
					case 9u:
						goto IL_0069;
					case 0u:
						goto IL_0095;
					case 56u:
					{
						int num21;
						if (genum9_0 == GEnum9.JswAttr_APSetupLocked)
						{
							num = 1630364715;
							num21 = 1630364715;
						}
						else
						{
							num = 686759402;
							num21 = 686759402;
						}
						continue;
					}
					case 55u:
						text = Delegate77.delegate77_0(text, 0, checked(Delegate17.delegate17_7(text) - 2));
						num = ((int)num2 * -1901462033) ^ -891108694;
						continue;
					case 54u:
						num = (int)((num2 * 1824142560) ^ 0x4404286F);
						continue;
					case 53u:
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 128)), global::_003CModule_003E.smethod_19<string>(3057911922u, 1463338638u), "")));
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 256)), global::_003CModule_003E.smethod_21<string>(349691858u, 1545068743u), "")));
						num = ((int)num2 * -1612400573) ^ -1931708425;
						continue;
					case 52u:
					{
						int num10;
						if (genum9_0 > GEnum9.JswAttr_Version)
						{
							num = 1125049817;
							num10 = 1125049817;
						}
						else
						{
							num = 2098347773;
							num10 = 2098347773;
						}
						continue;
					}
					case 51u:
						text = global::_003CModule_003E.smethod_20<string>(1646655603u, 2867447142u);
						num = (int)((num2 * 1618094467) ^ 0x70EAABBA);
						continue;
					case 50u:
					{
						int num26;
						int num27;
						if (genum9_0 > GEnum9.JswAttr_ConfigMethods)
						{
							num26 = -1358829369;
							num27 = -1358829369;
						}
						else
						{
							num26 = -111324919;
							num27 = -111324919;
						}
						num = num26 ^ (int)(num2 * 2033200767);
						continue;
					}
					case 49u:
					{
						int num17;
						int num18;
						if (genum9_0 != GEnum9.JswAttr_ConfigMethods)
						{
							num17 = -930920590;
							num18 = -930920590;
						}
						else
						{
							num17 = -395981356;
							num18 = -395981356;
						}
						num = num17 ^ (int)(num2 * 2077318020);
						continue;
					}
					case 48u:
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 1)), global::_003CModule_003E.smethod_19<string>(674373519u, 2019788656u), "")));
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 2)), global::_003CModule_003E.smethod_22<string>(3992122042u, 3264149535u), "")));
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 4)), global::_003CModule_003E.smethod_22<string>(2187671158u, 2905537186u), "")));
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 8)), global::_003CModule_003E.smethod_22<string>(1908074819u, 4222488128u), "")));
						num = ((int)num2 * -1966081185) ^ 0x17C0D866;
						continue;
					case 45u:
						object_2 = Delegate146.delegate146_0(ginterface5_2, genum9_0);
						num = 1611150930;
						continue;
					case 43u:
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 2)), global::_003CModule_003E.smethod_22<string>(585264696u, 692533243u), "")));
						num = (int)(num2 * 966341743) ^ -733088816;
						continue;
					case 41u:
					{
						int num12;
						if (Delegate108.delegate108_1(object_2, 2, bool_0: false))
						{
							num = 290347484;
							num12 = 290347484;
						}
						else
						{
							num = 1860226216;
							num12 = 1860226216;
						}
						continue;
					}
					case 40u:
					{
						int num9;
						if (Delegate108.delegate108_1(object_2, 3, bool_0: false))
						{
							num = 1277255733;
							num9 = 1277255733;
						}
						else
						{
							num = 1157791881;
							num9 = 1157791881;
						}
						continue;
					}
					case 39u:
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 16392)), global::_003CModule_003E.smethod_20<string>(696321670u, 26895451u), "")));
						num = ((int)num2 * -1772599420) ^ -285772663;
						continue;
					case 36u:
					{
						int num6;
						if (Delegate108.delegate108_1(object_, 17, bool_0: false))
						{
							num = 670353180;
							num6 = 670353180;
						}
						else
						{
							num = 917297967;
							num6 = 917297967;
						}
						continue;
					}
					case 35u:
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 32)), global::_003CModule_003E.smethod_19<string>(3530021432u, 3607737526u), "")));
						num = ((int)num2 * -805718993) ^ -1526373001;
						continue;
					case 34u:
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 64)), global::_003CModule_003E.smethod_22<string>(2034947669u, 3536766688u), "")));
						num = (int)((num2 * 1738322590) ^ 0x63C5105D);
						continue;
					case 33u:
					{
						int num22;
						int num23;
						if (!Delegate108.delegate108_1(object_2, 1, bool_0: false))
						{
							num22 = -1861535411;
							num23 = -1861535411;
						}
						else
						{
							num22 = -1041374924;
							num23 = -1041374924;
						}
						num = num22 ^ (int)(num2 * 2040048455);
						continue;
					}
					case 32u:
						text = "";
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 1)), global::_003CModule_003E.smethod_18<string>(2612500698u, 662660664u), "")));
						num = 480634552;
						continue;
					case 31u:
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 4096)), global::_003CModule_003E.smethod_20<string>(2530393867u, 1315855238u), "")));
						num = (int)((num2 * 671107541) ^ 0x2CF3F4AE);
						continue;
					case 30u:
						object_ = Delegate146.delegate146_0(ginterface5_2, genum9_0);
						num = ((int)num2 * -1177250729) ^ 0x5EE3399B;
						continue;
					case 29u:
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 16)), global::_003CModule_003E.smethod_21<string>(3825152341u, 2752062486u), "")));
						num = ((int)num2 * -235503278) ^ 0x3726FB8C;
						continue;
					case 28u:
					{
						int num19;
						int num20;
						if (Delegate108.delegate108_1(object_, 16, bool_0: false))
						{
							num19 = -1612337382;
							num20 = -1612337382;
						}
						else
						{
							num19 = -580851187;
							num20 = -580851187;
						}
						num = num19 ^ ((int)num2 * -1720942188);
						continue;
					}
					case 26u:
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 4)), global::_003CModule_003E.smethod_18<string>(1474188628u, 1345533419u), "")));
						num = (int)(num2 * 14665402) ^ -1622934856;
						continue;
					case 24u:
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 640)), global::_003CModule_003E.smethod_21<string>(3287991443u, 138908741u), "")));
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 1152)), global::_003CModule_003E.smethod_21<string>(1118699652u, 2246035442u), "")));
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 2176)), global::_003CModule_003E.smethod_18<string>(3020748298u, 1253155171u), "")));
						num = ((int)num2 * -703216358) ^ 0x3AD4680;
						continue;
					case 21u:
					{
						int num15;
						int num16;
						if (genum9_0 == GEnum9.JswAttr_AuthenticationTypeFlags)
						{
							num15 = -27255475;
							num16 = -27255475;
						}
						else
						{
							num15 = -346256724;
							num16 = -346256724;
						}
						num = num15 ^ ((int)num2 * -654070063);
						continue;
					}
					case 20u:
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 8)), global::_003CModule_003E.smethod_20<string>(1086428370u, 3786357836u), "")));
						num = (int)((num2 * 747523100) ^ 0x2B3803E4);
						continue;
					case 19u:
					{
						int num13;
						int num14;
						if (genum9_0 == GEnum9.JswAttr_RFBand)
						{
							num13 = 35193782;
							num14 = 35193782;
						}
						else
						{
							num13 = 145931725;
							num14 = 145931725;
						}
						num = num13 ^ ((int)num2 * -736335528);
						continue;
					}
					case 17u:
						text = global::_003CModule_003E.smethod_19<string>(4197818867u, 2015377674u);
						num = (int)(num2 * 1901964079) ^ -1912563710;
						continue;
					case 15u:
						text = Delegate77.delegate77_0(text, 0, checked(Delegate17.delegate17_7(text) - 2));
						num = ((int)num2 * -1586743737) ^ 0x4C2B874;
						continue;
					case 14u:
						result = Delegate152.delegate152_0(Delegate108.delegate108_1(Delegate146.delegate146_0(ginterface5_2, genum9_0), 0, bool_0: false), "", Delegate7.delegate7_2(Delegate146.delegate146_0(ginterface5_2, genum9_0)));
						num = 1354138863;
						continue;
					case 13u:
					{
						int num11;
						if (genum9_0 != GEnum9.JswAttr_EncryptionTypeFlags)
						{
							num = 296182913;
							num11 = 296182913;
						}
						else
						{
							num = 579760576;
							num11 = 579760576;
						}
						continue;
					}
					case 12u:
						result = global::_003CModule_003E.smethod_19<string>(697364372u, 2067827445u);
						num = ((int)num2 * -225848371) ^ -19546144;
						continue;
					case 11u:
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 8200)), global::_003CModule_003E.smethod_19<string>(4278552527u, 3380178554u), "")));
						num = (int)(num2 * 743043271) ^ -151360199;
						continue;
					case 8u:
					{
						int num7;
						int num8;
						if (genum9_0 != GEnum9.JswAttr_MACAddress)
						{
							num7 = -135136976;
							num8 = -135136976;
						}
						else
						{
							num7 = -2087524012;
							num8 = -2087524012;
						}
						num = num7 ^ ((int)num2 * -544374242);
						continue;
					}
					case 5u:
					{
						int num4;
						int num5;
						if (genum9_0 > GEnum9.JswAttr_MACAddress)
						{
							num4 = 1276933694;
							num5 = 1276933694;
						}
						else
						{
							num4 = 391378723;
							num5 = 391378723;
						}
						num = num4 ^ (int)(num2 * 1458066348);
						continue;
					}
					case 3u:
						text = "";
						num = 363127001;
						continue;
					case 2u:
						result = global::_003CModule_003E.smethod_22<string>(1095136441u, 366796828u);
						num = (int)(num2 * 1792118173) ^ -798310996;
						continue;
					case 4u:
						break;
					case 10u:
						text = "";
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 1)), global::_003CModule_003E.smethod_19<string>(2516829853u, 1683929656u), "")));
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 2)), global::_003CModule_003E.smethod_21<string>(1162315938u, 1845433708u), "")));
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 4)), global::_003CModule_003E.smethod_18<string>(3175404265u, 1738431599u), "")));
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 8)), global::_003CModule_003E.smethod_22<string>(841390741u, 2031217380u), "")));
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 16)), global::_003CModule_003E.smethod_21<string>(1931323732u, 3846774560u), "")));
						text = Delegate15.delegate15_2(Delegate59.delegate59_0(text, Delegate152.delegate152_0(Delegate21.delegate21_1(Delegate59.delegate59_4(Delegate146.delegate146_0(ginterface5_2, genum9_0), 32)), global::_003CModule_003E.smethod_20<string>(4030223187u, 3450734983u), "")));
						text = Delegate77.delegate77_0(text, 0, checked(Delegate17.delegate17_7(text) - 2));
						result = text;
						goto end_IL_0c7e;
					case 16u:
						result = text;
						goto end_IL_0c7e;
					default:
						try
						{
							result = Delegate152.delegate152_0(Delegate146.delegate146_0(ginterface5_2, genum9_0) == null, false, true);
						}
						catch (Exception exception_)
						{
							Delegate14.smethod_0(exception_);
							result = false;
							while (true)
							{
								IL_1051:
								int num3 = 1825918041;
								while (true)
								{
									switch ((num2 = (uint)num3 ^ 0x21A4DD1Bu) % 3)
									{
									default:
										goto end_IL_1019;
									case 2u:
										goto IL_1037;
									case 0u:
										break;
									case 1u:
										goto end_IL_1019;
									}
									goto IL_1051;
									IL_1037:
									Delegate51.delegate51_0();
									num3 = ((int)num2 * -1963712900) ^ -1247894329;
									continue;
									end_IL_1019:
									break;
								}
								break;
							}
						}
						goto end_IL_0c7e;
					case 22u:
						goto end_IL_0c7e;
					case 25u:
						result = Delegate134.delegate134_0((byte[])Delegate146.delegate146_0(ginterface5_2, genum9_0));
						goto end_IL_0c7e;
					case 27u:
						goto end_IL_0c7e;
					case 37u:
						result = text;
						goto end_IL_0c7e;
					case 38u:
						goto end_IL_0c7e;
					case 42u:
						result = global::_003CModule_003E.smethod_22<string>(1374732780u, 2830937095u);
						goto end_IL_0c7e;
					case 44u:
						result = "";
						goto end_IL_0c7e;
					case 46u:
						goto end_IL_0c7e;
					case 47u:
						result = text;
						goto end_IL_0c7e;
					case 1u:
					case 6u:
					case 7u:
					case 23u:
						goto IL_10a3;
						IL_0069:
						result = Delegate150.delegate150_0((Array)Delegate146.delegate146_0(ginterface5_2, genum9_0), "");
						num = 1040427723;
						continue;
						IL_10a3:
						result = Delegate146.delegate146_0(ginterface5_2, genum9_0);
						goto end_IL_0c7e;
						IL_0095:
						text = "";
						num = 1347966803;
						continue;
					}
					goto IL_0d80;
					continue;
					end_IL_0c7e:
					break;
				}
				break;
			}
		}
		catch (Exception exception_2)
		{
			Delegate14.smethod_0(exception_2);
			result = "";
			Delegate51.delegate51_0();
		}
		return result;
	}

	bool object.Equals(object obj)
	{
		GClass9 gClass = obj as GClass9;
		if (gClass == null)
		{
			goto IL_000a;
		}
		goto IL_0054;
		IL_000a:
		int num = -17950196;
		goto IL_002f;
		IL_002f:
		bool result = default(bool);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0xF3D3F8C2u) % 5)
			{
			case 4u:
				break;
			case 2u:
				num = ((int)num2 * -64279313) ^ 0x75B5DB55;
				continue;
			case 1u:
				result = false;
				num = ((int)num2 * -514871662) ^ 0x71130BF;
				continue;
			case 0u:
				goto IL_0054;
			default:
				return result;
			}
			break;
		}
		goto IL_000a;
		IL_0054:
		result = Delegate96.delegate96_1(Delegate15.delegate15_9(gClass), Delegate15.delegate15_28(this));
		num = -1414619974;
		goto IL_002f;
	}

	int object.GetHashCode()
	{
		return Delegate17.delegate17_16(Delegate15.delegate15_28(this));
	}

	private void method_8()
	{
		SQLiteCommand sQLiteCommand = new SQLiteCommand(global::_003CModule_003E.smethod_22<string>(4041442975u, 2326610180u), sqliteConnection_0);
		string value = Delegate77.delegate77_0(string_8, 0, 8);
		GClass15<GClass12> gClass = new GClass15<GClass12>();
		GClass15<GClass12> gClass2 = new GClass15<GClass12>();
		GClass15<GClass12> gClass3 = new GClass15<GClass12>();
		GClass15<GClass12> gClass4 = new GClass15<GClass12>();
		try
		{
			sqliteConnection_0.Open();
			GClass11 gClass6 = default(GClass11);
			GClass15<GClass12> gClass5 = default(GClass15<GClass12>);
			SQLiteDataReader sQLiteDataReader = default(SQLiteDataReader);
			string text = default(string);
			int num4 = default(int);
			string[] array = default(string[]);
			while (true)
			{
				int num = 1994356304;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x312B6CEEu) % 37)
					{
					case 36u:
						bool_1 = gClass6.bool_0;
						num = ((int)num2 * -1011696877) ^ -781568063;
						continue;
					case 34u:
						gClass4.method_0(gClass5);
						num = ((int)num2 * -110717976) ^ -903487622;
						continue;
					case 33u:
					{
						int num18;
						int num19;
						if (gClass4.Count > 0)
						{
							num18 = -1863827361;
							num19 = -1863827361;
						}
						else
						{
							num18 = -2110559273;
							num19 = -2110559273;
						}
						num = num18 ^ ((int)num2 * -1316783458);
						continue;
					}
					case 32u:
					{
						int num12;
						int num13;
						if (gClass6.genum0_0 != GClass3.GEnum0.Nothing)
						{
							num12 = -1875344570;
							num13 = -1875344570;
						}
						else
						{
							num12 = -641854119;
							num13 = -641854119;
						}
						num = num12 ^ ((int)num2 * -413961035);
						continue;
					}
					case 31u:
						sQLiteDataReader.Close();
						num = 509017194;
						continue;
					case 30u:
						gClass6.genum0_0 = (GClass3.GEnum0)Delegate17.delegate17_1(sQLiteDataReader[global::_003CModule_003E.smethod_21<string>(1545659891u, 3764463205u)]);
						num = ((int)num2 * -1025863965) ^ 0x7B1B39FC;
						continue;
					case 29u:
					{
						int num16;
						if (gClass3.Count <= 0)
						{
							num = 2002426791;
							num16 = 2002426791;
						}
						else
						{
							num = 1455484946;
							num16 = 1455484946;
						}
						continue;
					}
					case 28u:
						gClass5.Add((GClass12)Delegate155.delegate155_0(text, GClass12.GEnum5.Generic, gClass6));
						num4 = checked(num4 + 1);
						num = ((int)num2 * -693650311) ^ -609585220;
						continue;
					case 27u:
					{
						int num11;
						if (!(Delegate122.delegate122_0(Delegate15.delegate15_30(string_2), Delegate71.delegate71_0(global::_003CModule_003E.smethod_22<string>(3049930469u, 3371368703u), Delegate15.delegate15_30(gClass6.string_2), global::_003CModule_003E.smethod_22<string>(3049930469u, 263016778u)), CompareMethod.Binary) | Delegate122.delegate122_0(Delegate15.delegate15_30(string_0), Delegate71.delegate71_0(global::_003CModule_003E.smethod_18<string>(386907508u, 1724783891u), Delegate15.delegate15_30(gClass6.string_2), global::_003CModule_003E.smethod_21<string>(3083675479u, 1411412832u)), CompareMethod.Binary) | Delegate122.delegate122_0(Delegate15.delegate15_30(string_3), Delegate71.delegate71_0(global::_003CModule_003E.smethod_20<string>(1101893873u, 4117141344u), Delegate15.delegate15_30(gClass6.string_2), global::_003CModule_003E.smethod_18<string>(386907508u, 3026520065u)), CompareMethod.Binary)))
						{
							num = 888072535;
							num11 = 888072535;
						}
						else
						{
							num = 1751245884;
							num11 = 1751245884;
						}
						continue;
					}
					case 26u:
						gClass3.method_0(gClass5);
						num = ((int)num2 * -1266104032) ^ 0x32A31517;
						continue;
					case 25u:
					{
						int num7;
						if (num4 >= array.Length)
						{
							num = 1520922586;
							num7 = 1520922586;
						}
						else
						{
							num = 1462003593;
							num7 = 1462003593;
						}
						continue;
					}
					case 24u:
						gClass5 = new GClass15<GClass12>();
						num = 2012027138;
						continue;
					case 23u:
						gClass6.string_0 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_18<string>(1475199834u, 3244228609u)]);
						num = (int)((num2 * 1211407539) ^ 0x48F6D1F9);
						continue;
					case 22u:
						gclass15_0.method_0(gClass);
						num = (int)(num2 * 1881946855) ^ -1756530814;
						continue;
					case 21u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_22<string>(2923057619u, 1877087078u), value);
						sQLiteDataReader = sQLiteCommand.ExecuteReader();
						num = (int)((num2 * 1718578314) ^ 0x25AE7B3B);
						continue;
					case 20u:
						gClass5.Add((GClass12)Delegate154.delegate154_0(Delegate153.delegate153_0(this, (GClass3.GEnum0)Delegate17.delegate17_1(sQLiteDataReader[global::_003CModule_003E.smethod_18<string>(4009093752u, 69808756u)])), (GClass3.GEnum0)Delegate17.delegate17_1(sQLiteDataReader[global::_003CModule_003E.smethod_20<string>(4287138549u, 893688768u)]), gClass6));
						num = ((int)num2 * -394938486) ^ -1160663988;
						continue;
					case 19u:
						gClass6.string_1 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_22<string>(2631226399u, 1933280393u)]);
						gClass6.string_2 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_19<string>(489915346u, 103205382u)]);
						num = ((int)num2 * -1841623570) ^ -1388421121;
						continue;
					case 18u:
					{
						int num17;
						if (sQLiteDataReader.Read())
						{
							num = 1002280645;
							num17 = 1002280645;
						}
						else
						{
							num = 456902144;
							num17 = 456902144;
						}
						continue;
					}
					case 17u:
						gClass2.method_0(gClass5);
						num = 1819847373;
						continue;
					case 16u:
						num = (int)((num2 * 922473604) ^ 0x76578587);
						continue;
					case 15u:
						gClass6.bool_0 = Delegate21.delegate21_1(sQLiteDataReader[global::_003CModule_003E.smethod_22<string>(2363864941u, 2582596820u)]);
						num = (int)((num2 * 2008236585) ^ 0x5EAAEE2F);
						continue;
					case 14u:
					{
						int num14;
						int num15;
						if (!Delegate21.delegate21_4(Delegate7.delegate7_2(sQLiteDataReader[global::_003CModule_003E.smethod_21<string>(1545659891u, 722841619u)])))
						{
							num14 = 1635775685;
							num15 = 1635775685;
						}
						else
						{
							num14 = 1973846197;
							num15 = 1973846197;
						}
						num = num14 ^ (int)(num2 * 1477816462);
						continue;
					}
					case 13u:
					{
						int num10;
						if (gClass.Count > 0)
						{
							num = 1745876486;
							num10 = 1745876486;
						}
						else
						{
							num = 1280123098;
							num10 = 1280123098;
						}
						continue;
					}
					case 12u:
						num = (int)((num2 * 816530301) ^ 0x6FBA1C5B);
						continue;
					case 11u:
					{
						int num8;
						int num9;
						if (!(Delegate122.delegate122_0(Delegate15.delegate15_30(string_2), Delegate71.delegate71_0(global::_003CModule_003E.smethod_19<string>(4289782279u, 667077688u), Delegate15.delegate15_30(gClass6.string_2), global::_003CModule_003E.smethod_18<string>(386907508u, 2175617089u)), CompareMethod.Binary) | Delegate122.delegate122_0(Delegate15.delegate15_30(string_0), Delegate71.delegate71_0(global::_003CModule_003E.smethod_21<string>(3083675479u, 3126219591u), Delegate15.delegate15_30(gClass6.string_2), global::_003CModule_003E.smethod_20<string>(1101893873u, 2714843117u)), CompareMethod.Binary) | Delegate122.delegate122_0(Delegate15.delegate15_30(string_3), Delegate71.delegate71_0(global::_003CModule_003E.smethod_20<string>(1101893873u, 820841491u), Delegate15.delegate15_30(gClass6.string_2), global::_003CModule_003E.smethod_20<string>(1101893873u, 2697266353u)), CompareMethod.Binary)))
						{
							num8 = 649826764;
							num9 = 649826764;
						}
						else
						{
							num8 = 342487729;
							num9 = 342487729;
						}
						num = num8 ^ (int)(num2 * 673943723);
						continue;
					}
					case 10u:
						array = Delegate70.smethod_0((object)Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_20<string>(78026021u, 2241449284u)]), new char[1] { ';' });
						num4 = 0;
						num = ((int)num2 * -320878368) ^ 0x5FF6CF51;
						continue;
					case 9u:
						gclass15_0.method_0(gClass2);
						num = ((int)num2 * -787841621) ^ -877553520;
						continue;
					case 8u:
						num = ((int)num2 * -344912826) ^ 0x3C4A38C5;
						continue;
					case 7u:
					{
						int num6;
						if (gClass2.Count > 0)
						{
							num = 1344068463;
							num6 = 1344068463;
						}
						else
						{
							num = 1053907685;
							num6 = 1053907685;
						}
						continue;
					}
					case 6u:
						gclass15_0.method_0(gClass3);
						num = (int)((num2 * 1705287022) ^ 0x6FB92092);
						continue;
					case 5u:
					{
						int num5;
						if (!Delegate122.delegate122_0(Delegate15.delegate15_30(string_11), Delegate15.delegate15_30(gClass6.string_1), CompareMethod.Binary))
						{
							num = 1361088180;
							num5 = 1361088180;
						}
						else
						{
							num = 493856943;
							num5 = 493856943;
						}
						continue;
					}
					case 4u:
						text = array[num4];
						num = 1686574395;
						continue;
					case 3u:
						gClass6 = (GClass11)Delegate3.smethod_4();
						num = 1847681276;
						continue;
					case 2u:
					{
						int num3;
						if (!Delegate21.delegate21_4(Delegate7.delegate7_2(sQLiteDataReader[global::_003CModule_003E.smethod_21<string>(2016313347u, 1873863091u)])))
						{
							num = 1159027208;
							num3 = 1159027208;
						}
						else
						{
							num = 1520922586;
							num3 = 1520922586;
						}
						continue;
					}
					case 1u:
						gclass15_0.method_0(gClass4);
						num = ((int)num2 * -479391452) ^ -666261458;
						continue;
					case 35u:
						break;
					default:
						Delegate22.delegate22_14(sQLiteCommand);
						sqliteConnection_0.Close();
						return;
					}
					break;
				}
			}
		}
		catch (Exception ex)
		{
			Delegate14.smethod_0(ex);
			Exception object_ = ex;
			while (true)
			{
				int num20 = 1474140063;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num20 ^ 0x312B6CEEu) % 3)
					{
					case 1u:
						goto IL_08fd;
					case 0u:
						break;
					default:
						Delegate51.delegate51_0();
						return;
					}
					break;
					IL_08fd:
					Delegate52.delegate52_0(Delegate15.delegate15_0(object_), global::_003CModule_003E.smethod_18<string>(2870781682u, 2061264562u), MessageBoxButtons.OK);
					sqliteConnection_0.Close();
					num20 = ((int)num2 * -1012983376) ^ 0x41B6640F;
				}
			}
		}
	}

	private void method_9()
	{
		SQLiteCommand sQLiteCommand = new SQLiteCommand(global::_003CModule_003E.smethod_19<string>(294227421u, 2629475841u), sqliteConnection_1);
		Delegate77.delegate77_0(string_8, 0, 8);
		new GClass15<GClass12>();
		new GClass15<GClass12>();
		string[] array = default(string[]);
		SQLiteDataReader sQLiteDataReader = default(SQLiteDataReader);
		int num6 = default(int);
		GClass11 gClass = default(GClass11);
		GClass15<GClass12> gClass2 = default(GClass15<GClass12>);
		string text = default(string);
		while (true)
		{
			int num = -618700067;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x8B1F895Eu) % 3)
				{
				case 2u:
					goto IL_003c;
				case 0u:
					break;
				default:
					new GClass15<GClass12>();
					try
					{
						sqliteConnection_1.Open();
						while (true)
						{
							int num3 = -844037536;
							while (true)
							{
								switch ((num2 = (uint)num3 ^ 0x8B1F895Eu) % 28)
								{
								case 27u:
									array = Delegate70.smethod_0((object)Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_20<string>(78026021u, 2288741668u)]), new char[1] { ';' });
									num6 = 0;
									num3 = ((int)num2 * -1552514176) ^ -530790609;
									continue;
								case 26u:
									gClass = (GClass11)Delegate3.smethod_4();
									gClass.string_0 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_20<string>(930833279u, 1577878322u)]);
									num3 = -952223107;
									continue;
								case 25u:
								{
									bool_1 = gClass.bool_0;
									int num9;
									int num10;
									if (gClass.genum0_0 == GClass3.GEnum0.Nothing)
									{
										num9 = 2115382652;
										num10 = 2115382652;
									}
									else
									{
										num9 = 1309579330;
										num10 = 1309579330;
									}
									num3 = num9 ^ (int)(num2 * 489653394);
									continue;
								}
								case 24u:
								{
									int num14;
									if (!Delegate21.delegate21_4(Delegate7.delegate7_2(sQLiteDataReader[global::_003CModule_003E.smethod_19<string>(2293900283u, 2930033577u)])))
									{
										num3 = -2089734499;
										num14 = -2089734499;
									}
									else
									{
										num3 = -1726688151;
										num14 = -1726688151;
									}
									continue;
								}
								case 22u:
									sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_19<string>(743346078u, 2379343044u), string_0);
									num3 = -860690030;
									continue;
								case 21u:
									gClass2 = new GClass15<GClass12>();
									num3 = -903720405;
									continue;
								case 20u:
									num3 = (int)((num2 * 1740623608) ^ 0x349075CF);
									continue;
								case 19u:
									gclass15_0.method_0(gClass2);
									num3 = -1137121137;
									continue;
								case 18u:
								{
									text = array[num6];
									int num7;
									if (Delegate56.delegate56_0(text, "", bool_0: false) == 0)
									{
										num3 = -118604650;
										num7 = -118604650;
									}
									else
									{
										num3 = -213516902;
										num7 = -213516902;
									}
									continue;
								}
								case 17u:
									gClass.genum0_0 = (GClass3.GEnum0)Delegate17.delegate17_1(sQLiteDataReader[global::_003CModule_003E.smethod_22<string>(559414057u, 1669182704u)]);
									num3 = ((int)num2 * -167248020) ^ 0x653F3B77;
									continue;
								case 16u:
									num6 = checked(num6 + 1);
									num3 = -1269666385;
									continue;
								case 15u:
									sQLiteDataReader = sQLiteCommand.ExecuteReader();
									num3 = (int)((num2 * 45102591) ^ 0x4E49DB3);
									continue;
								case 14u:
								{
									int num12;
									int num13;
									if (Delegate122.delegate122_0(string_11, global::_003CModule_003E.smethod_18<string>(3079594833u, 1034955467u), CompareMethod.Binary))
									{
										num12 = 85938380;
										num13 = 85938380;
									}
									else
									{
										num12 = 1663134306;
										num13 = 1663134306;
									}
									num3 = num12 ^ (int)(num2 * 823835027);
									continue;
								}
								case 13u:
									num3 = (int)((num2 * 1933550552) ^ 0x7AD9091);
									continue;
								case 12u:
									string_11 = string_11;
									num3 = (int)((num2 * 363846511) ^ 0x33AA3880);
									continue;
								case 11u:
									gClass.string_2 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_18<string>(2016771674u, 1053900930u)]);
									num3 = ((int)num2 * -1156564594) ^ -1152561014;
									continue;
								case 10u:
									gClass2.Add((GClass12)Delegate154.delegate154_0(Delegate153.delegate153_0(this, (GClass3.GEnum0)Delegate17.delegate17_1(sQLiteDataReader[global::_003CModule_003E.smethod_20<string>(4287138549u, 3455743719u)])), (GClass3.GEnum0)Delegate17.delegate17_1(sQLiteDataReader[global::_003CModule_003E.smethod_18<string>(4009093752u, 1197636027u)]), gClass));
									num3 = ((int)num2 * -1934069836) ^ 0x172246CB;
									continue;
								case 9u:
								{
									int num11;
									if (sQLiteDataReader.Read())
									{
										num3 = -1118873444;
										num11 = -1118873444;
									}
									else
									{
										num3 = -1781737645;
										num11 = -1781737645;
									}
									continue;
								}
								case 8u:
									gClass2.Add((GClass12)Delegate155.delegate155_0(text, GClass12.GEnum5.Generic, gClass));
									num3 = ((int)num2 * -1305254310) ^ 0x1DB1187E;
									continue;
								case 6u:
									gClass.string_3 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_18<string>(2689552726u, 2467312213u)]);
									num3 = (int)((num2 * 162637824) ^ 0x317CE27A);
									continue;
								case 5u:
								{
									int num8;
									if (num6 >= array.Length)
									{
										num3 = -1726688151;
										num8 = -1726688151;
									}
									else
									{
										num3 = -44717672;
										num8 = -44717672;
									}
									continue;
								}
								case 4u:
									sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_20<string>(1117359376u, 2239236287u), string_2);
									num3 = (int)(num2 * 2118916634) ^ -1434862792;
									continue;
								case 3u:
								{
									int num4;
									int num5;
									if (Delegate21.delegate21_4(Delegate7.delegate7_2(sQLiteDataReader[global::_003CModule_003E.smethod_22<string>(559414057u, 60280694u)])))
									{
										num4 = -854363900;
										num5 = -854363900;
									}
									else
									{
										num4 = -1395174748;
										num5 = -1395174748;
									}
									num3 = num4 ^ (int)(num2 * 833815785);
									continue;
								}
								case 2u:
									sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_20<string>(2227081996u, 1984246459u), string_3);
									num3 = (int)(num2 * 430910893) ^ -537811181;
									continue;
								case 1u:
									sQLiteDataReader.Close();
									Delegate22.delegate22_14(sQLiteCommand);
									sqliteConnection_1.Close();
									num3 = ((int)num2 * -1887816097) ^ -1011175074;
									continue;
								case 0u:
									gClass.string_4 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_18<string>(1343990622u, 3815808727u)]);
									gClass.bool_0 = Delegate21.delegate21_1(sQLiteDataReader[global::_003CModule_003E.smethod_19<string>(2055950095u, 1544045773u)]);
									num3 = (int)(num2 * 566327740) ^ -1096373511;
									continue;
								default:
									return;
								case 7u:
									break;
								case 23u:
									return;
								}
								break;
							}
						}
					}
					catch (Exception ex)
					{
						Delegate14.smethod_0(ex);
						Exception object_ = ex;
						Delegate52.delegate52_0(Delegate15.delegate15_0(object_), global::_003CModule_003E.smethod_18<string>(1475751745u, 3963310341u), MessageBoxButtons.OK);
						sqliteConnection_1.Close();
						while (true)
						{
							int num15 = -2097403197;
							while (true)
							{
								switch ((num2 = (uint)num15 ^ 0x8B1F895Eu) % 3)
								{
								default:
									return;
								case 1u:
									goto IL_066f;
								case 2u:
									break;
								case 0u:
									return;
								}
								break;
								IL_066f:
								Delegate51.delegate51_0();
								num15 = (int)(num2 * 1523549505) ^ -1229753878;
							}
						}
					}
				}
				break;
				IL_003c:
				new GClass15<GClass12>();
				num = ((int)num2 * -546366872) ^ 0x248EB37;
			}
		}
	}

	public void method_10()
	{
		SQLiteCommand sQLiteCommand = new SQLiteCommand(global::_003CModule_003E.smethod_19<string>(893052297u, 1607555524u), sqliteConnection_2);
		try
		{
			sqliteConnection_2.Open();
			SQLiteDataReader sQLiteDataReader = default(SQLiteDataReader);
			while (true)
			{
				int num = 1952847210;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x21BD3789u) % 21)
					{
					case 20u:
						gclass12_0 = (GClass12)Delegate133.delegate133_0(Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_21<string>(3044775900u, 2836421026u)]), (GClass12.GEnum5)Delegate17.delegate17_1(sQLiteDataReader[global::_003CModule_003E.smethod_20<string>(114955216u, 2911253718u)]));
						num = ((int)num2 * -1772841464) ^ -491300839;
						continue;
					case 18u:
						string_9 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_21<string>(1254265217u, 1725404260u)]);
						num = (int)((num2 * 1274009416) ^ 0x1DC5E576);
						continue;
					case 17u:
						sqliteConnection_2.Close();
						num = ((int)num2 * -1851578893) ^ 0x2D5B5694;
						continue;
					case 16u:
						string_10 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_19<string>(2178414669u, 4118802441u)]);
						num = (int)(num2 * 748593768) ^ -1114738134;
						continue;
					case 15u:
						string_1 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_18<string>(3362333778u, 2381559351u)]);
						num = (int)(num2 * 587935066) ^ -381558847;
						continue;
					case 14u:
						genum3_0 = (GEnum3)Delegate17.delegate17_1(sQLiteDataReader[global::_003CModule_003E.smethod_18<string>(1116420067u, 1722863245u)]);
						num = (int)((num2 * 815565849) ^ 0x10F56B5A);
						continue;
					case 13u:
						string_2 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_19<string>(3640724905u, 536663258u)]);
						num = (int)(num2 * 1001649063) ^ -166312211;
						continue;
					case 12u:
						sQLiteDataReader.Close();
						Delegate22.delegate22_14(sQLiteCommand);
						num = 1203803680;
						continue;
					case 11u:
						string_3 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_21<string>(4011216925u, 2208200876u)]);
						num = ((int)num2 * -241892726) ^ 0x28362D04;
						continue;
					case 10u:
						string_13 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_19<string>(2616303574u, 2869342605u)]);
						num = (int)((num2 * 1580875023) ^ 0x72F95410);
						continue;
					case 9u:
						string_6 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_20<string>(3362061904u, 1090722552u)]);
						string_7 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_21<string>(2610932928u, 3353713042u)]);
						num = (int)(num2 * 754123765) ^ -775512347;
						continue;
					case 8u:
					{
						int num10;
						int num11;
						if (Delegate56.delegate56_0(Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_22<string>(3037695588u, 693870904u)]), "", bool_0: false) != 0)
						{
							num10 = -848710445;
							num11 = -848710445;
						}
						else
						{
							num10 = -1393777898;
							num11 = -1393777898;
						}
						num = num10 ^ ((int)num2 * -163177398);
						continue;
					}
					case 6u:
					{
						int num8;
						int num9;
						if (!Delegate21.delegate21_4(Delegate7.delegate7_2(sQLiteDataReader[global::_003CModule_003E.smethod_19<string>(4055091608u, 367879321u)])))
						{
							num8 = -1981218730;
							num9 = -1981218730;
						}
						else
						{
							num8 = -341936463;
							num9 = -341936463;
						}
						num = num8 ^ ((int)num2 * -1703230861);
						continue;
					}
					case 5u:
					{
						int num6;
						int num7;
						if (Delegate56.delegate56_0(Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_20<string>(2447392634u, 3885452739u)]), "", bool_0: false) != 0)
						{
							num6 = 1226585787;
							num7 = 1226585787;
						}
						else
						{
							num6 = 2032961144;
							num7 = 2032961144;
						}
						num = num6 ^ (int)(num2 * 762344727);
						continue;
					}
					case 4u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_22<string>(2923057619u, 4289939178u), string_8);
						sQLiteDataReader = sQLiteCommand.ExecuteReader();
						num = (int)((num2 * 1767885131) ^ 0x5C6312A);
						continue;
					case 3u:
						string_0 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_19<string>(2523808813u, 4161261816u)]);
						num = ((int)num2 * -1545819394) ^ 0x10D018B9;
						continue;
					case 2u:
					{
						int num4;
						int num5;
						if (sQLiteDataReader.Read())
						{
							num4 = 1399331756;
							num5 = 1399331756;
						}
						else
						{
							num4 = 78202508;
							num5 = 78202508;
						}
						num = num4 ^ (int)(num2 * 2089523365);
						continue;
					}
					case 1u:
					{
						int num3;
						if (Delegate21.delegate21_4(Delegate7.delegate7_2(sQLiteDataReader[global::_003CModule_003E.smethod_20<string>(2169013580u, 3682854869u)])))
						{
							num = 1790044262;
							num3 = 1790044262;
						}
						else
						{
							num = 979690193;
							num3 = 979690193;
						}
						continue;
					}
					case 0u:
						string_4 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_20<string>(788174627u, 832359291u)]);
						string_5 = Delegate15.delegate15_8(sQLiteDataReader[global::_003CModule_003E.smethod_18<string>(2386493260u, 3797954456u)]);
						num = ((int)num2 * -1730287555) ^ -2007219743;
						continue;
					default:
						return;
					case 19u:
						break;
					case 7u:
						return;
					}
					break;
				}
			}
		}
		catch (Exception ex)
		{
			Delegate14.smethod_0(ex);
			Exception object_ = ex;
			while (true)
			{
				int num12 = 427434502;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num12 ^ 0x21BD3789u) % 4)
					{
					default:
						return;
					case 3u:
						Delegate52.delegate52_0(Delegate15.delegate15_0(object_), global::_003CModule_003E.smethod_18<string>(1423157678u, 1239276063u), MessageBoxButtons.OK);
						sqliteConnection_0.Close();
						num12 = (int)(num2 * 656972698) ^ -1541752506;
						continue;
					case 1u:
						Delegate51.delegate51_0();
						num12 = (int)(num2 * 1209122635) ^ -1993981508;
						continue;
					case 0u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	public void method_11()
	{
		SQLiteCommand sQLiteCommand = new SQLiteCommand(global::_003CModule_003E.smethod_20<string>(1132824879u, 1900414622u), sqliteConnection_2);
		try
		{
			sqliteConnection_2.Open();
			sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_18<string>(2437524210u, 1239415091u), string_8);
			while (true)
			{
				int num = 446278045;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x49E292DBu) % 12)
					{
					case 10u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_19<string>(3794150567u, 142391841u), string_4);
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_20<string>(3728175848u, 835532655u), string_5);
						num = ((int)num2 * -1910465158) ^ 0x54F6BA8E;
						continue;
					case 9u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_19<string>(1387621311u, 4100361737u), string_6);
						num = ((int)num2 * -882562379) ^ -276415889;
						continue;
					case 8u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_21<string>(1290844908u, 3315069826u), string_1);
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_20<string>(1117359376u, 2464678068u), string_2);
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_18<string>(802970693u, 4199507778u), string_3);
						num = ((int)num2 * -260363123) ^ 0x358F8FA5;
						continue;
					case 7u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_18<string>(2751525495u, 783450219u), genum3_0);
						num = (int)((num2 * 197402905) ^ 0x606F1D);
						continue;
					case 6u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_21<string>(565453400u, 651560884u), Delegate15.delegate15_25(gclass12_0));
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_22<string>(2511827740u, 1295762041u), string_13);
						num = ((int)num2 * -528945295) ^ -804369303;
						continue;
					case 5u:
						sQLiteCommand.ExecuteNonQuery();
						Delegate22.delegate22_14(sQLiteCommand);
						sqliteConnection_2.Close();
						num = ((int)num2 * -1174191642) ^ 0x22080F39;
						continue;
					case 4u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_21<string>(2916093068u, 2940849425u), gclass12_0.Type);
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_19<string>(681352479u, 3412453422u), 0);
						num = (int)((num2 * 1211683155) ^ 0x42D7414);
						continue;
					case 3u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_18<string>(3752375885u, 1819982193u), string_0);
						num = ((int)num2 * -403085545) ^ 0x53D834DE;
						continue;
					case 2u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_20<string>(2334400456u, 2804464509u), string_11);
						num = (int)(num2 * 1832495738) ^ -1699563136;
						continue;
					case 1u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_22<string>(2384954890u, 1683149918u), string_7);
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_21<string>(2603896333u, 2700586653u), string_9);
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_18<string>(4149681666u, 980568021u), string_10);
						num = (int)((num2 * 1175401569) ^ 0x1EE95FB4);
						continue;
					default:
						return;
					case 11u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
		catch (Exception ex)
		{
			Delegate14.smethod_0(ex);
			Exception object_ = ex;
			while (true)
			{
				int num3 = 1611915654;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num3 ^ 0x49E292DBu) % 3)
					{
					default:
						return;
					case 1u:
						goto IL_03af;
					case 0u:
						break;
					case 2u:
						return;
					}
					break;
					IL_03af:
					Delegate52.delegate52_0(Delegate15.delegate15_0(object_), global::_003CModule_003E.smethod_21<string>(3097440945u, 2096900992u), MessageBoxButtons.OK);
					Delegate51.delegate51_0();
					num3 = (int)((num2 * 1497465118) ^ 0x312BC758);
				}
			}
		}
	}

	public void method_12()
	{
		SQLiteCommand sQLiteCommand = new SQLiteCommand(global::_003CModule_003E.smethod_18<string>(1044057390u, 3254975169u), sqliteConnection_2);
		try
		{
			sqliteConnection_2.Open();
			while (true)
			{
				int num = 838666114;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x363792A3u) % 11)
					{
					case 10u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_19<string>(3410285026u, 2974756503u), string_11);
						num = ((int)num2 * -516852260) ^ -1941767185;
						continue;
					case 9u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_20<string>(2633918731u, 1086831430u), string_9);
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_20<string>(2264011191u, 1844885988u), string_10);
						num = (int)((num2 * 1536091418) ^ 0x6808C755);
						continue;
					case 8u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_19<string>(3126353132u, 939366611u), Delegate15.delegate15_25(gclass12_0));
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_20<string>(2022561332u, 710758564u), string_13);
						num = (int)(num2 * 1211095105) ^ -767824756;
						continue;
					case 6u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_19<string>(3794150567u, 200396877u), string_4);
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_19<string>(4116553858u, 4214477843u), string_5);
						num = ((int)num2 * -672460025) ^ -744078414;
						continue;
					case 5u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_20<string>(1487266916u, 1976052214u), string_0);
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_20<string>(1025830890u, 1501853454u), string_1);
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_21<string>(3859566006u, 2836275354u), string_2);
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_21<string>(1102614298u, 3889169895u), string_3);
						num = ((int)num2 * -583198646) ^ -11173999;
						continue;
					case 4u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_19<string>(4243269224u, 1213006633u), gclass12_0.Type);
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_19<string>(681352479u, 207776481u), 0);
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_18<string>(2751525495u, 208573608u), genum3_0);
						num = ((int)num2 * -1784213657) ^ 0x6222E42B;
						continue;
					case 2u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_20<string>(3856633529u, 997529191u), string_6);
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_22<string>(2384954890u, 634881660u), string_7);
						num = ((int)num2 * -114640310) ^ 0x40C0F024;
						continue;
					case 1u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_21<string>(1369028721u, 2011111357u), string_8);
						num = (int)(num2 * 1282018003) ^ -1296406961;
						continue;
					case 0u:
						sQLiteCommand.ExecuteNonQuery();
						Delegate22.delegate22_14(sQLiteCommand);
						sqliteConnection_2.Close();
						num = (int)((num2 * 845368479) ^ 0xB2F7FEC);
						continue;
					default:
						return;
					case 3u:
						break;
					case 7u:
						return;
					}
					break;
				}
			}
		}
		catch (Exception ex)
		{
			Delegate14.smethod_0(ex);
			Exception object_ = ex;
			Delegate52.delegate52_0(Delegate15.delegate15_0(object_), global::_003CModule_003E.smethod_21<string>(1986385596u, 2322292434u), MessageBoxButtons.OK);
			Delegate51.delegate51_0();
		}
	}

	public bool method_13()
	{
		SQLiteCommand sQLiteCommand = new SQLiteCommand(global::_003CModule_003E.smethod_19<string>(893052297u, 2269314687u), sqliteConnection_2);
		bool result = false;
		try
		{
			sqliteConnection_2.Open();
			while (true)
			{
				IL_00d9:
				int num = -549859800;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xB72C4863u) % 6)
					{
					case 4u:
						sqliteConnection_2.Close();
						num = (int)((num2 * 536452489) ^ 0x44B58F7A);
						continue;
					case 3u:
					{
						SQLiteDataReader sQLiteDataReader = sQLiteCommand.ExecuteReader();
						result = sQLiteDataReader.Read();
						sQLiteDataReader.Close();
						num = ((int)num2 * -1041003171) ^ -454544902;
						continue;
					}
					case 2u:
						Delegate22.delegate22_14(sQLiteCommand);
						num = ((int)num2 * -2018475300) ^ 0x798E77E5;
						continue;
					case 1u:
						sQLiteCommand.Parameters.AddWithValue(global::_003CModule_003E.smethod_22<string>(2923057619u, 2585649325u), string_8);
						num = ((int)num2 * -1554465555) ^ -2074319911;
						continue;
					default:
						goto end_IL_00b0;
					case 0u:
						break;
					case 5u:
						goto end_IL_00b0;
					}
					goto IL_00d9;
					continue;
					end_IL_00b0:
					break;
				}
				break;
			}
		}
		catch (Exception ex)
		{
			Delegate14.smethod_0(ex);
			Exception object_ = ex;
			while (true)
			{
				IL_0181:
				int num3 = -978983883;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num3 ^ 0xB72C4863u) % 5)
					{
					default:
						goto end_IL_00f1;
					case 4u:
						Delegate52.delegate52_0(Delegate15.delegate15_0(object_), global::_003CModule_003E.smethod_19<string>(3655674100u, 838480874u), MessageBoxButtons.OK);
						num3 = (int)(num2 * 1404047244) ^ -2132472374;
						continue;
					case 1u:
						Delegate51.delegate51_0();
						num3 = (int)(num2 * 1063216012) ^ -67096443;
						continue;
					case 0u:
						sqliteConnection_0.Close();
						num3 = (int)((num2 * 1414606908) ^ 0x7A4E7202);
						continue;
					case 2u:
						break;
					case 3u:
						goto end_IL_00f1;
					}
					goto IL_0181;
					continue;
					end_IL_00f1:
					break;
				}
				break;
			}
		}
		return result;
	}
}
