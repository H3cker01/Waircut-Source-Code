using System;

internal delegate IntPtr Delegate207(object object_0);
