using System;

internal class Attribute14 : Attribute
{
	internal readonly int int_0;

	internal Attribute14(int int_1)
	{
		int_0 = -950550549 - (int_1 * 549147973 - -2010222065);
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
