internal delegate int Delegate17(object object_0);
