using System;

internal class Attribute2 : Attribute
{
	internal readonly int int_0;

	internal Attribute2(int int_1)
	{
		int_0 = ~(207195246 - ~int_1);
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
