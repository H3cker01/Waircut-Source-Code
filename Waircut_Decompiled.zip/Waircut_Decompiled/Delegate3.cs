internal delegate object Delegate3();
