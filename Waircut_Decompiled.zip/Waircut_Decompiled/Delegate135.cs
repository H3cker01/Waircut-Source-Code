internal delegate object Delegate135(object object_0, GEnum15 genum15_0, object object_1, object object_2);
