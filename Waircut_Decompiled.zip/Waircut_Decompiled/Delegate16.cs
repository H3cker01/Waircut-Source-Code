internal delegate object Delegate16(string string_0, object object_0);
