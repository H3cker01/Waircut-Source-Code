internal delegate object Delegate152(bool bool_0, object object_0, object object_1);
