internal delegate string[] Delegate70(object object_0, char[] char_0);
