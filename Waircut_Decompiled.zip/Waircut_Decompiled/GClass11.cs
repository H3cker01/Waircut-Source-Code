public class GClass11
{
	public string string_0;

	public string string_1;

	public string string_2;

	public string string_3;

	public string string_4;

	public string string_5;

	public bool bool_0;

	public GClass3.GEnum0 genum0_0;

	public GClass11()
	{
		while (true)
		{
			int num = -1320955064;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xEC6AE81Eu) % 8)
				{
				case 7u:
					string_4 = "";
					num = (int)((num2 * 1110850135) ^ 0x48AFEEE4);
					continue;
				case 6u:
					string_0 = "";
					num = (int)((num2 * 560910022) ^ 0x2B7AD9F);
					continue;
				case 5u:
					string_1 = "";
					num = (int)((num2 * 1652142326) ^ 0x217FAE8);
					continue;
				case 3u:
					string_5 = "";
					num = (int)((num2 * 2033754707) ^ 0x32BF5416);
					continue;
				case 1u:
					bool_0 = false;
					num = (int)((num2 * 1167600022) ^ 0x1C31E0C2);
					continue;
				case 0u:
					string_2 = "";
					string_3 = "";
					num = ((int)num2 * -598274783) ^ -880513463;
					continue;
				case 4u:
					break;
				default:
					genum0_0 = GClass3.GEnum0.Nothing;
					return;
				}
				break;
			}
		}
	}
}
