using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[ComImport]
[CompilerGenerated]
[Guid("85B53D39-0F61-4DCA-AA47-8B8792A04749")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface GInterface16 : GInterface6
{
}
