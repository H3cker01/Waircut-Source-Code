using System;

internal class Attribute10 : Attribute
{
	internal readonly int int_0;

	internal Attribute10(int int_1)
	{
		int_0 = ~(-553052975 - (907762019 - int_1));
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
