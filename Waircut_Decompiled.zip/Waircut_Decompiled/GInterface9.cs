using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[ComImport]
[CompilerGenerated]
[Guid("D95318F7-B1D4-46F6-8932-038A886A7722")]
[InterfaceType(1)]
[TypeIdentifier]
public interface GInterface9
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void OnJswSupplicantEvent([In] GEnum17 @event, [In] int evtData, [In][MarshalAs(UnmanagedType.BStr)] string evtString);
}
