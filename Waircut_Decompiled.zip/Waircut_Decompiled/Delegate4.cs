internal delegate void Delegate4(object object_0, string[] string_0);
