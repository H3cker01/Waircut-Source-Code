internal delegate void Delegate190(object object_0, string string_0, object object_1, object object_2, float float_0, float float_1);
