internal delegate string Delegate77(object object_0, int int_0, int int_1);
