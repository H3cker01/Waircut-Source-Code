using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
[TypeIdentifier("c9178c19-99cf-4f6d-85c6-3ef5a176f9fb", "JSWSCAPILib.JswMessageType")]
public enum GEnum16
{
	JswMsgType_None,
	JswMsgType_Beacon,
	JswMsgType_ProbeRequest,
	JswMsgType_ProbeResponse,
	JswMsgType_M1,
	JswMsgType_M2,
	JswMsgType_M2D,
	JswMsgType_M3,
	JswMsgType_M4,
	JswMsgType_M5,
	JswMsgType_M6,
	JswMsgType_M7,
	JswMsgType_M8,
	JswMsgType_WSC_ACK,
	JswMsgType_WSC_NACK,
	JswMsgType_WSC_DONE
}
