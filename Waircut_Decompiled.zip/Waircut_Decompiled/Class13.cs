using System;
using System.Collections;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.ServiceProcess;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.Win32;
using ns0;
using ns1;

[StandardModule]
internal sealed class Class13
{
	public static string[] string_0 = new string[10]
	{
		global::_003CModule_003E.smethod_18<string>(925353114u, 2070632708u),
		global::_003CModule_003E.smethod_19<string>(1144888982u, 1768304137u),
		global::_003CModule_003E.smethod_20<string>(3672312025u, 2251095767u),
		global::_003CModule_003E.smethod_22<string>(2300595094u, 4075453005u),
		global::_003CModule_003E.smethod_20<string>(3949426547u, 396870991u),
		global::_003CModule_003E.smethod_22<string>(876762760u, 397480671u),
		global::_003CModule_003E.smethod_21<string>(3232929579u, 443361334u),
		Delegate71.delegate71_0(global::_003CModule_003E.smethod_21<string>(3501510028u, 14462658u), Delegate15.delegate15_3(Delegate7.delegate7_15(Delegate3.delegate3_0())), global::_003CModule_003E.smethod_20<string>(3610450013u, 4172083395u)),
		global::_003CModule_003E.smethod_19<string>(1386558613u, 1696777312u),
		global::_003CModule_003E.smethod_20<string>(651189693u, 701010770u)
	};

	public static string string_1 = "";

	public static bool bool_0;

	public static string string_2;

	public static string string_3;

	public static string string_4;

	public static bool bool_1;

	public static string string_5;

	public static string string_6;

	public static int int_0;

	public static bool bool_2;

	public static string string_7;

	public static string string_8;

	private const int int_1 = 277;

	private const int int_2 = 7;

	public static string Version
	{
		get
		{
			string result = Delegate137.delegate137_0(global::_003CModule_003E.smethod_20<string>(1019832701u, 1091262167u), Delegate17.delegate17_17(Delegate7.delegate7_187(Delegate7.delegate7_15(Delegate3.delegate3_0()))), Delegate17.delegate17_18(Delegate7.delegate7_187(Delegate7.delegate7_15(Delegate3.delegate3_0()))));
			if (bool_0)
			{
				while (true)
				{
					int num = 1505526485;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x795F1756u) % 3)
						{
						case 2u:
							result = Delegate57.delegate57_1(result, global::_003CModule_003E.smethod_19<string>(1397788365u, 3186723022u));
							num = (int)((num2 * 1351015964) ^ 0x43BAE37C);
							continue;
						case 0u:
							break;
						default:
							goto end_IL_00c2;
						}
						break;
					}
					continue;
					end_IL_00c2:
					break;
				}
			}
			return result;
		}
	}

	static Class13()
	{
		while (true)
		{
			int num = -551700448;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xF890850Du) % 4)
				{
				case 1u:
					bool_0 = false;
					string_2 = Delegate36.delegate36_63();
					string_3 = Delegate36.delegate36_64();
					string_4 = Delegate57.delegate57_1(global::_003CModule_003E.smethod_18<string>(2151107120u, 2433283415u), Delegate137.delegate137_0(global::_003CModule_003E.smethod_18<string>(1013346961u, 3940247712u), string_3, string_2));
					bool_1 = false;
					string_5 = "";
					num = ((int)num2 * -1605552369) ^ -935401658;
					continue;
				case 0u:
					string_6 = "";
					num = (int)((num2 * 380153554) ^ 0x2BB8D3BA);
					continue;
				case 2u:
					break;
				default:
					int_0 = 0;
					bool_2 = false;
					string_7 = global::_003CModule_003E.smethod_19<string>(2364998238u, 2501497076u);
					string_8 = global::_003CModule_003E.smethod_21<string>(3166345206u, 2309751292u);
					return;
				}
				break;
			}
		}
	}

	public static string smethod_0(GClass15<GClass9> gclass15_0)
	{
		string result = "";
		string text = global::_003CModule_003E.smethod_21<string>(3253577778u, 2738529953u);
		int num3 = default(int);
		int num4 = default(int);
		while (true)
		{
			int num = 1907670741;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x5B0935DFu) % 7)
				{
				case 6u:
					result = Delegate57.delegate57_1(result, global::_003CModule_003E.smethod_18<string>(2409940015u, 3100301319u));
					num = ((int)num2 * -1907982174) ^ 0x79AADCD2;
					continue;
				case 4u:
					num = (int)(num2 * 1186948812) ^ -1057046222;
					continue;
				case 3u:
					result = Delegate57.smethod_0(result, Delegate142.smethod_0(text, new object[5]
					{
						Delegate15.delegate15_9(gclass15_0[num3]),
						Delegate15.delegate15_39(gclass15_0[num3]),
						Delegate15.delegate15_40(gclass15_0[num3]),
						Delegate21.delegate21_11(gclass15_0[num3]),
						Delegate15.delegate15_10(gclass15_0[num3])
					}));
					num3 = checked(num3 + 1);
					num = 1043926362;
					continue;
				case 2u:
					result = Delegate57.delegate57_1(result, global::_003CModule_003E.smethod_19<string>(257881420u, 1132627333u));
					num4 = checked(gclass15_0.Count - 1);
					num3 = 0;
					num = ((int)num2 * -1077187151) ^ -1187517144;
					continue;
				case 1u:
				{
					int num5;
					if (num3 <= num4)
					{
						num = 6418175;
						num5 = 6418175;
					}
					else
					{
						num = 70574262;
						num5 = 70574262;
					}
					continue;
				}
				case 0u:
					break;
				default:
					return result;
				}
				break;
			}
		}
	}

	public static string smethod_1(byte[] byte_0)
	{
		string text = "";
		int num = checked(byte_0.Length - 1);
		int num2 = 0;
		while (true)
		{
			int num3;
			int num4;
			if (num2 <= num)
			{
				num3 = -2116059769;
				num4 = -2116059769;
			}
			else
			{
				num3 = -451845359;
				num4 = -451845359;
			}
			while (true)
			{
				uint num5;
				switch ((num5 = (uint)num3 ^ 0xBCFC19D1u) % 7)
				{
				case 6u:
					num3 = -2116059769;
					continue;
				case 5u:
					text = Delegate57.delegate57_1(text, global::_003CModule_003E.smethod_22<string>(3900288055u, 2563573876u));
					num3 = ((int)num5 * -1294333694) ^ 0x309C87B8;
					continue;
				case 3u:
					text += byte_0[num2].ToString(global::_003CModule_003E.smethod_19<string>(3113529333u, 1615333942u));
					num3 = -935999933;
					continue;
				case 2u:
					num2 = checked(num2 + 1);
					num3 = (int)(num5 * 1652852959) ^ -311550985;
					continue;
				case 1u:
				{
					int num6;
					if (!((num2 > 0) & (num2 < byte_0.Length)))
					{
						num3 = -643015774;
						num6 = -643015774;
					}
					else
					{
						num3 = -1476695460;
						num6 = -1476695460;
					}
					continue;
				}
				case 0u:
					break;
				default:
					return text;
				}
				break;
			}
		}
	}

	public static void smethod_2(string string_9)
	{
		ServiceController object_ = (ServiceController)Delegate12.delegate12_9(string_9);
		ServiceControllerStatus serviceControllerStatus = default(ServiceControllerStatus);
		while (true)
		{
			int num = -849009393;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x9ADA9FABu) % 3)
				{
				case 1u:
					goto IL_000e;
				case 0u:
					break;
				default:
					if (!serviceControllerStatus.Equals(ServiceControllerStatus.Running))
					{
						return;
					}
					try
					{
						Delegate22.delegate22_63(object_);
						while (true)
						{
							int num3 = -1235465482;
							while (true)
							{
								switch ((num2 = (uint)num3 ^ 0x9ADA9FABu) % 3)
								{
								case 1u:
									goto IL_0070;
								default:
									return;
								case 2u:
									break;
								case 0u:
									return;
								}
								break;
								IL_0070:
								Delegate198.delegate198_0(object_, ServiceControllerStatus.Stopped);
								num3 = ((int)num2 * -1406076981) ^ 0x17289513;
							}
						}
					}
					catch (Exception exception_)
					{
						Delegate14.smethod_0(exception_);
						while (true)
						{
							int num4 = -225255339;
							while (true)
							{
								switch ((num2 = (uint)num4 ^ 0x9ADA9FABu) % 3)
								{
								default:
									return;
								case 2u:
									goto IL_00d5;
								case 0u:
									break;
								case 1u:
									return;
								}
								break;
								IL_00d5:
								Delegate51.delegate51_0();
								num4 = ((int)num2 * -1617799265) ^ -1509433330;
							}
						}
					}
				}
				break;
				IL_000e:
				serviceControllerStatus = Delegate197.delegate197_0(object_);
				num = (int)(num2 * 1701461515) ^ -77240865;
			}
		}
	}

	public static void smethod_3(string string_9)
	{
		ServiceController object_ = (ServiceController)Delegate12.delegate12_9(string_9);
		try
		{
			Delegate22.delegate22_63(object_);
			while (true)
			{
				int num = 1353590188;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x1A3F83BCu) % 5)
					{
					case 4u:
						Delegate198.delegate198_0(object_, ServiceControllerStatus.Running);
						num = (int)(num2 * 1401407676) ^ -171759191;
						continue;
					case 2u:
						Delegate22.delegate22_64(object_);
						num = (int)((num2 * 300387360) ^ 0x37BEEE29);
						continue;
					case 1u:
						Delegate198.delegate198_0(object_, ServiceControllerStatus.Stopped);
						num = (int)(num2 * 218229977) ^ -1368634553;
						continue;
					default:
						return;
					case 3u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			while (true)
			{
				int num3 = 1595245930;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num3 ^ 0x1A3F83BCu) % 3)
					{
					default:
						return;
					case 1u:
						goto IL_00bb;
					case 2u:
						break;
					case 0u:
						return;
					}
					break;
					IL_00bb:
					Delegate51.delegate51_0();
					num3 = (int)(num2 * 937914072) ^ -1619282665;
				}
			}
		}
	}

	public static bool smethod_4()
	{
		return Delegate17.delegate17_17(Delegate7.delegate7_209(Delegate3.delegate3_97())) >= 6;
	}

	public static bool smethod_5()
	{
		string text = Delegate36.delegate36_9();
		string text3 = default(string);
		byte[] byte_2 = default(byte[]);
		bool result = default(bool);
		ServiceController object_2 = default(ServiceController);
		RegistryKey registryKey = default(RegistryKey);
		DateTime dateTime_ = default(DateTime);
		DateTime dateTime_2 = default(DateTime);
		while (true)
		{
			int num = -1605392703;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xA5DE9132u) % 3)
				{
				case 1u:
					goto IL_000d;
				case 0u:
					break;
				default:
					{
						bool flag = false;
						string text2 = "";
						try
						{
							text2 = Delegate81.delegate81_20(Delegate57.delegate57_1(Delegate15.delegate15_41(Delegate3.delegate3_109()), global::_003CModule_003E.smethod_20<string>(3755637729u, 3365513436u)));
							while (true)
							{
								IL_087e:
								int num3 = -274779197;
								while (true)
								{
									switch ((num2 = (uint)num3 ^ 0xA5DE9132u) % 36)
									{
									case 35u:
										Delegate68.delegate68_1(Delegate7.delegate7_251(Delegate3.smethod_6()), Delegate57.delegate57_1(text3, global::_003CModule_003E.smethod_22<string>(3033601210u, 747439944u)), global::_003CModule_003E.smethod_18<string>(3597719918u, 386446543u));
										num3 = -829083863;
										continue;
									case 34u:
									{
										text2 = Delegate134.delegate134_1(byte_2);
										int num17;
										int num18;
										if (Delegate56.delegate56_0(text2, global::_003CModule_003E.smethod_19<string>(3481914330u, 1015680604u), bool_0: false) != 0)
										{
											num17 = -1684374568;
											num18 = -1684374568;
										}
										else
										{
											num17 = -931258319;
											num18 = -931258319;
										}
										num3 = num17 ^ ((int)num2 * -1431270435);
										continue;
									}
									case 33u:
									{
										text2 = Delegate81.delegate81_20(Delegate57.delegate57_1(Delegate15.delegate15_41(Delegate3.smethod_5()), global::_003CModule_003E.smethod_21<string>(365777212u, 2457564880u)));
										int num14;
										if (Delegate56.delegate56_0(text2, global::_003CModule_003E.smethod_18<string>(2307878115u, 420547447u), bool_0: false) == 0)
										{
											num3 = -1160160153;
											num14 = -1160160153;
										}
										else
										{
											num3 = -1935516755;
											num14 = -1935516755;
										}
										continue;
									}
									case 32u:
										flag = Delegate1.smethod_0();
										num3 = -500696075;
										continue;
									case 31u:
										Delegate60.delegate60_0(global::_003CModule_003E.smethod_18<string>(1427847029u, 2714424514u), global::_003CModule_003E.smethod_19<string>(2123328607u, 2834489347u), MessageBoxButtons.OK, MessageBoxIcon.Hand);
										result = false;
										num3 = ((int)num2 * -1015790918) ^ -1444708485;
										continue;
									case 30u:
										result = false;
										num3 = (int)(num2 * 1492557599) ^ -1372507341;
										continue;
									case 29u:
										flag = true;
										num3 = (int)((num2 * 1816217854) ^ 0x8819E6A);
										continue;
									case 26u:
										Delegate100.delegate100_1(text);
										num3 = ((int)num2 * -2133376753) ^ -1785391928;
										continue;
									case 25u:
									{
										int num19;
										if (Delegate15.delegate15_42(object_2) == null)
										{
											num3 = -636009576;
											num19 = -636009576;
										}
										else
										{
											num3 = -473039612;
											num19 = -473039612;
										}
										continue;
									}
									case 24u:
										Delegate24.delegate24_6(Delegate24.delegate24_5(registryKey, text), global::_003CModule_003E.smethod_19<string>(1984852140u, 3159849679u));
										text3 = Delegate81.delegate81_21(Delegate15.delegate15_8(Delegate24.delegate24_6(Delegate24.delegate24_5(registryKey, text), global::_003CModule_003E.smethod_18<string>(3959625919u, 3504406979u))));
										num3 = ((int)num2 * -300293777) ^ -12580635;
										continue;
									case 23u:
									{
										text2 = Delegate81.delegate81_20(Delegate57.delegate57_1(text3, global::_003CModule_003E.smethod_18<string>(337439675u, 1591744268u)));
										int num10;
										int num11;
										if (Delegate56.delegate56_0(text2, global::_003CModule_003E.smethod_20<string>(2003626704u, 2523282246u), bool_0: false) == 0)
										{
											num10 = -978572144;
											num11 = -978572144;
										}
										else
										{
											num10 = -308064889;
											num11 = -308064889;
										}
										num3 = num10 ^ (int)(num2 * 1236967041);
										continue;
									}
									case 22u:
										num3 = ((int)num2 * -781141896) ^ -1657263800;
										continue;
									case 21u:
									{
										Delegate201.delegate201_1(Delegate57.delegate57_1(text3, global::_003CModule_003E.smethod_19<string>(3101768232u, 250551442u)), dateTime_);
										int num6;
										int num7;
										if (Delegate96.delegate96_3(Delegate7.delegate7_251(Delegate3.delegate3_110()), Delegate57.delegate57_1(text3, global::_003CModule_003E.smethod_19<string>(2307255431u, 1656509316u))))
										{
											num6 = 1406132305;
											num7 = 1406132305;
										}
										else
										{
											num6 = 378386050;
											num7 = 378386050;
										}
										num3 = num6 ^ (int)(num2 * 1651395112);
										continue;
									}
									case 18u:
									{
										int num15;
										int num16;
										if (registryKey == null)
										{
											num15 = -1686217961;
											num16 = -1686217961;
										}
										else
										{
											num15 = -662108266;
											num16 = -662108266;
										}
										num3 = num15 ^ (int)(num2 * 1392859317);
										continue;
									}
									case 17u:
									{
										int num12;
										int num13;
										if (Delegate96.delegate96_3(Delegate7.delegate7_251(Delegate3.delegate3_110()), Delegate57.delegate57_1(text3, global::_003CModule_003E.smethod_19<string>(2307255431u, 780972723u))))
										{
											num12 = -1956958723;
											num13 = -1956958723;
										}
										else
										{
											num12 = -1334276017;
											num13 = -1334276017;
										}
										num3 = num12 ^ (int)(num2 * 1620701634);
										continue;
									}
									case 16u:
										Delegate60.delegate60_0(global::_003CModule_003E.smethod_20<string>(1921565532u, 1414377225u), global::_003CModule_003E.smethod_22<string>(1104657821u, 1487053150u), MessageBoxButtons.OK, MessageBoxIcon.Hand);
										num3 = (int)((num2 * 1423448225) ^ 0x695A469A);
										continue;
									case 15u:
										Delegate200.delegate200_0(Delegate57.delegate57_1(text3, global::_003CModule_003E.smethod_19<string>(3101768232u, 1643335202u)), byte_2);
										num3 = (int)(num2 * 1620125989) ^ -844982025;
										continue;
									case 14u:
										registryKey = (RegistryKey)Delegate24.delegate24_5(Registry.LocalMachine, global::_003CModule_003E.smethod_21<string>(1077403254u, 400093813u));
										num3 = ((int)num2 * -62095948) ^ -889656488;
										continue;
									case 13u:
									{
										text2 = Delegate81.delegate81_20(Delegate57.delegate57_1(Delegate15.delegate15_41(Delegate3.smethod_5()), global::_003CModule_003E.smethod_18<string>(855564760u, 1522706489u)));
										int num9;
										if (Delegate56.delegate56_0(text2, global::_003CModule_003E.smethod_18<string>(2201126864u, 1457631637u), bool_0: false) == 0)
										{
											num3 = -1016609013;
											num9 = -1016609013;
										}
										else
										{
											num3 = -413719786;
											num9 = -413719786;
										}
										continue;
									}
									case 12u:
										Delegate60.delegate60_0(Delegate36.smethod_3(), global::_003CModule_003E.smethod_21<string>(1527331580u, 1279431963u), MessageBoxButtons.OK, MessageBoxIcon.Hand);
										num3 = -302279060;
										continue;
									case 11u:
									{
										int num8;
										if (Delegate56.delegate56_0(text3, "", bool_0: false) != 0)
										{
											num3 = -2049433023;
											num8 = -2049433023;
										}
										else
										{
											num3 = -636009576;
											num8 = -636009576;
										}
										continue;
									}
									case 10u:
										Delegate201.delegate201_0(Delegate57.delegate57_1(text3, global::_003CModule_003E.smethod_19<string>(3101768232u, 96938942u)), dateTime_2);
										num3 = ((int)num2 * -1205283320) ^ -643543677;
										continue;
									case 9u:
										dateTime_2 = Delegate97.delegate97_1(Delegate57.delegate57_1(text3, global::_003CModule_003E.smethod_19<string>(3101768232u, 612804279u)));
										num3 = (int)((num2 * 907410355) ^ 0x18412095);
										continue;
									case 7u:
										num3 = (int)((num2 * 251033299) ^ 0x1D13FF9D);
										continue;
									case 5u:
									{
										int num4;
										int num5;
										if (Delegate56.delegate56_0(text2, global::_003CModule_003E.smethod_18<string>(1324222012u, 1076027502u), bool_0: false) == 0)
										{
											num4 = 59885615;
											num5 = 59885615;
										}
										else
										{
											num4 = 764663558;
											num5 = 764663558;
										}
										num3 = num4 ^ ((int)num2 * -269257200);
										continue;
									}
									case 4u:
										dateTime_ = Delegate97.delegate97_0(Delegate57.delegate57_1(text3, global::_003CModule_003E.smethod_18<string>(337439675u, 474547051u)));
										num3 = ((int)num2 * -146632425) ^ -323164113;
										continue;
									case 3u:
										Delegate30.delegate30_26(Delegate7.delegate7_251(Delegate3.delegate3_110()), Delegate57.delegate57_1(text3, global::_003CModule_003E.smethod_18<string>(441064692u, 3593996572u)));
										num3 = ((int)num2 * -1803699114) ^ -733571944;
										continue;
									case 2u:
									{
										Delegate93 delegate93_ = Delegate93.delegate93_1;
										object object_ = Delegate12.delegate12_10(text2);
										byte[] byte_ = Delegate199.delegate199_0();
										byte_2 = delegate93_(object_, ref byte_);
										num3 = -216764700;
										continue;
									}
									case 1u:
										Delegate30.delegate30_26(Delegate7.delegate7_251(Delegate3.delegate3_110()), Delegate57.delegate57_1(text3, global::_003CModule_003E.smethod_19<string>(2307255431u, 3126595031u)));
										num3 = (int)((num2 * 584794874) ^ 0x50355877);
										continue;
									case 0u:
										Delegate60.delegate60_0(global::_003CModule_003E.smethod_21<string>(3891736714u, 3515082521u), global::_003CModule_003E.smethod_19<string>(2123328607u, 71999238u), MessageBoxButtons.OK, MessageBoxIcon.Hand);
										result = false;
										num3 = ((int)num2 * -2038926351) ^ 0xED5C25A;
										continue;
									default:
										goto end_IL_07db;
									case 28u:
										break;
									case 6u:
										goto end_IL_07db;
									case 8u:
										result = false;
										goto IL_092b;
									case 19u:
									case 20u:
									case 27u:
										goto IL_092b;
									}
									goto IL_087e;
									continue;
									end_IL_07db:
									break;
								}
								break;
							}
						}
						catch (Exception exception_)
						{
							Delegate14.smethod_0(exception_);
							while (true)
							{
								IL_091f:
								int num20 = -108060935;
								while (true)
								{
									switch ((num2 = (uint)num20 ^ 0xA5DE9132u) % 4)
									{
									default:
										goto end_IL_08ac;
									case 3u:
										Delegate60.delegate60_0(Delegate36.delegate36_66(), global::_003CModule_003E.smethod_22<string>(110764970u, 2531345155u), MessageBoxButtons.OK, MessageBoxIcon.Hand);
										num20 = ((int)num2 * -2086872937) ^ 0x3C135DD7;
										continue;
									case 0u:
										Delegate51.delegate51_0();
										num20 = (int)(num2 * 525700666) ^ -369152349;
										continue;
									case 2u:
										break;
									case 1u:
										goto end_IL_08ac;
									}
									goto IL_091f;
									continue;
									end_IL_08ac:
									break;
								}
								break;
							}
						}
						result = flag;
						goto IL_092b;
					}
					IL_092b:
					return result;
				}
				break;
				IL_000d:
				object_2 = (ServiceController)Delegate12.delegate12_9(text);
				text3 = "";
				num = ((int)num2 * -357206629) ^ -542835475;
			}
		}
	}

	public static string smethod_6(string string_9)
	{
		return Delegate134.delegate134_1(Delegate92.delegate92_0(string_9));
	}

	public static string smethod_7(byte[] byte_0)
	{
		Stream stream = (Stream)Delegate94.delegate94_0(byte_0);
		int num3 = default(int);
		int num4 = default(int);
		MD5CryptoServiceProvider object_ = default(MD5CryptoServiceProvider);
		StringBuilder stringBuilder = default(StringBuilder);
		while (true)
		{
			int num = 1986554004;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x5BC2428Cu) % 5)
				{
				case 4u:
				{
					int num5;
					if (num3 <= num4)
					{
						num = 1945835125;
						num5 = 1945835125;
					}
					else
					{
						num = 176151952;
						num5 = 176151952;
					}
					continue;
				}
				case 1u:
					object_ = (MD5CryptoServiceProvider)Delegate3.delegate3_111();
					Delegate202.delegate202_0(object_, stream);
					Delegate22.delegate22_58(stream);
					stringBuilder = (StringBuilder)Delegate3.delegate3_112();
					num4 = checked(Delegate67.delegate67_1(object_).Length - 1);
					num3 = 0;
					num = ((int)num2 * -137217368) ^ 0x77424B2B;
					continue;
				case 0u:
					stringBuilder.Append(Delegate67.delegate67_1(object_)[num3].ToString(global::_003CModule_003E.smethod_20<string>(1793107851u, 3351601u)));
					num3 = checked(num3 + 1);
					num = 1135035627;
					continue;
				case 3u:
					break;
				default:
					return stringBuilder.ToString();
				}
				break;
			}
		}
	}

	public static string smethod_8(Array array_0, string string_9)
	{
		string text = "";
		IEnumerator enumerator = default(IEnumerator);
		try
		{
			enumerator = (IEnumerator)Delegate7.delegate7_252(array_0);
			object object_ = default(object);
			while (true)
			{
				IL_00ce:
				int num = -1105624733;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xEB7B5EB5u) % 6)
					{
					case 5u:
						text = Delegate71.delegate71_0(text, Delegate203.delegate203_0(Delegate15.delegate15_43(Delegate7.delegate7_2(object_)), 2, '0'), string_9);
						num = (int)(num2 * 53471378) ^ -248673424;
						continue;
					case 3u:
					{
						int num3;
						if (Delegate21.delegate21_3(enumerator))
						{
							num = -1873553004;
							num3 = -1873553004;
						}
						else
						{
							num = -1726959139;
							num3 = -1726959139;
						}
						continue;
					}
					case 2u:
						num = (int)(num2 * 721546558) ^ -1930060770;
						continue;
					case 1u:
						object_ = Delegate7.delegate7_2(Delegate7.delegate7_76(enumerator));
						num = -1978971200;
						continue;
					default:
						goto end_IL_00a5;
					case 4u:
						break;
					case 0u:
						goto end_IL_00a5;
					}
					goto IL_00ce;
					continue;
					end_IL_00a5:
					break;
				}
				break;
			}
		}
		finally
		{
			if (enumerator is IDisposable)
			{
				while (true)
				{
					IL_011b:
					int num4 = -1139452166;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num4 ^ 0xEB7B5EB5u) % 3)
						{
						case 2u:
							goto IL_00e1;
						default:
							goto end_IL_00fe;
						case 0u:
							break;
						case 1u:
							goto end_IL_00fe;
						}
						goto IL_011b;
						IL_00e1:
						Delegate22.delegate22_4(enumerator as IDisposable);
						num4 = ((int)num2 * -1352874121) ^ -1675507675;
						continue;
						end_IL_00fe:
						break;
					}
					break;
				}
			}
		}
		if (Delegate56.delegate56_0(string_9, string.Empty, bool_0: false) != 0)
		{
			while (true)
			{
				int num5 = -1571077010;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num5 ^ 0xEB7B5EB5u) % 3)
					{
					case 2u:
						text = Delegate77.delegate77_0(text, 0, checked(Delegate17.delegate17_7(text) - 1));
						num5 = ((int)num2 * -2112359694) ^ -1048727602;
						continue;
					case 0u:
						break;
					default:
						goto end_IL_017c;
					}
					break;
				}
				continue;
				end_IL_017c:
				break;
			}
		}
		return text;
	}

	public static string smethod_9(Array array_0, Array array_1)
	{
		byte[] array = new byte[32];
		int num3 = default(int);
		while (true)
		{
			int num = 1751970516;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x3B261471u) % 6)
				{
				case 5u:
				{
					int num4;
					int num5;
					if (num3 <= 31)
					{
						num4 = 64173056;
						num5 = 64173056;
					}
					else
					{
						num4 = 267590298;
						num5 = 267590298;
					}
					num = num4 ^ (int)(num2 * 1238044851);
					continue;
				}
				case 3u:
					num3 = 0;
					num = (int)(num2 * 1868141183) ^ -1765319966;
					continue;
				case 1u:
					num3 = checked(num3 + 1);
					num = ((int)num2 * -433807068) ^ -284435002;
					continue;
				case 0u:
					array[num3] = Delegate205.smethod_0(checked(Delegate59.smethod_1(Delegate59.smethod_1(Delegate204.smethod_0((object)array_0, new object[1] { num3 + 3 }, (string[])null), Delegate204.smethod_0((object)array_1, new object[1] { num3 }, (string[])null)), Delegate204.smethod_0((object)array_1, new object[1] { 32 + num3 }, (string[])null))));
					num = 590228796;
					continue;
				case 4u:
					break;
				default:
					return Delegate150.delegate150_0(array, global::_003CModule_003E.smethod_20<string>(2863696683u, 879203820u));
				}
				break;
			}
		}
	}

	public static string smethod_10(GEnum16 genum16_0)
	{
		string result = default(string);
		while (true)
		{
			int num = 1632513815;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xC88333Fu) % 29)
				{
				case 28u:
					num = ((int)num2 * -1774187699) ^ -683557205;
					continue;
				case 27u:
					result = global::_003CModule_003E.smethod_22<string>(3797218655u, 3834992746u);
					num = 572433455;
					continue;
				case 26u:
					num = (int)((num2 * 1135699123) ^ 0x35662910);
					continue;
				case 25u:
					goto IL_0045;
				case 24u:
					num = ((int)num2 * -1205649227) ^ -1941631448;
					continue;
				case 23u:
					goto IL_0071;
				case 22u:
					goto IL_008b;
				case 21u:
					goto IL_00a5;
				case 20u:
					goto IL_00bf;
				case 19u:
					num = (int)(num2 * 352598505) ^ -1092596245;
					continue;
				case 18u:
					goto IL_00eb;
				case 16u:
					num = (int)((num2 * 2044022090) ^ 0x42193CE6);
					continue;
				case 15u:
					goto IL_0117;
				case 14u:
					goto IL_0131;
				case 12u:
					switch (genum16_0)
					{
					case GEnum16.JswMsgType_None:
						break;
					case GEnum16.JswMsgType_M8:
						goto IL_0045;
					case GEnum16.JswMsgType_WSC_NACK:
						goto IL_0071;
					case GEnum16.JswMsgType_M6:
						goto IL_008b;
					case GEnum16.JswMsgType_M5:
						goto IL_00a5;
					case GEnum16.JswMsgType_M4:
						goto IL_00bf;
					case GEnum16.JswMsgType_M7:
						goto IL_00eb;
					case GEnum16.JswMsgType_ProbeResponse:
						goto IL_0117;
					case GEnum16.JswMsgType_M1:
						goto IL_0131;
					default:
						goto IL_0191;
					case GEnum16.JswMsgType_Beacon:
						goto IL_01a3;
					case GEnum16.JswMsgType_ProbeRequest:
						goto IL_01bd;
					case GEnum16.JswMsgType_M2:
						goto IL_01d7;
					case GEnum16.JswMsgType_M2D:
						goto IL_01f1;
					case GEnum16.JswMsgType_M3:
						goto IL_020b;
					case GEnum16.JswMsgType_WSC_ACK:
						goto IL_0222;
					case GEnum16.JswMsgType_WSC_DONE:
						goto IL_0239;
					}
					goto case 27u;
				case 5u:
					goto IL_01a3;
				case 3u:
					goto IL_01bd;
				case 10u:
					goto IL_01d7;
				case 8u:
					goto IL_01f1;
				case 0u:
					goto IL_020b;
				case 6u:
					goto IL_0222;
				case 9u:
					goto IL_0239;
				case 11u:
					result = global::_003CModule_003E.smethod_22<string>(1840044282u, 782463972u);
					num = 1096697414;
					continue;
				case 7u:
					num = ((int)num2 * -861572224) ^ 0x19DA15C6;
					continue;
				case 4u:
					num = (int)((num2 * 974678591) ^ 0x28C6E742);
					continue;
				case 2u:
					num = (int)(num2 * 1218573191) ^ -877395823;
					continue;
				case 1u:
					num = (int)((num2 * 1609506948) ^ 0x65C8630A);
					continue;
				case 13u:
					break;
				default:
					{
						return result;
					}
					IL_0239:
					result = global::_003CModule_003E.smethod_19<string>(2111567506u, 496005968u);
					num = 1660335374;
					continue;
					IL_0222:
					result = global::_003CModule_003E.smethod_19<string>(1317054705u, 2251252518u);
					num = 78391661;
					continue;
					IL_020b:
					result = global::_003CModule_003E.smethod_21<string>(2346838393u, 2884093468u);
					num = 1096697414;
					continue;
					IL_01f1:
					result = global::_003CModule_003E.smethod_18<string>(2357345948u, 3320950216u);
					num = 1096697414;
					continue;
					IL_01d7:
					result = global::_003CModule_003E.smethod_21<string>(4291166021u, 741914538u);
					num = 1096697414;
					continue;
					IL_01bd:
					result = global::_003CModule_003E.smethod_22<string>(747509565u, 349830639u);
					num = 1096697414;
					continue;
					IL_01a3:
					result = global::_003CModule_003E.smethod_18<string>(3132188900u, 2986003151u);
					num = 52864798;
					continue;
					IL_0191:
					num = (int)(num2 * 141476661) ^ -1345257908;
					continue;
					IL_0131:
					result = global::_003CModule_003E.smethod_21<string>(2883999291u, 683061809u);
					num = 1096697414;
					continue;
					IL_0117:
					result = global::_003CModule_003E.smethod_20<string>(380073360u, 376792596u);
					num = 843257370;
					continue;
					IL_00eb:
					result = global::_003CModule_003E.smethod_21<string>(1940526353u, 3411512840u);
					num = 1096697414;
					continue;
					IL_00bf:
					result = global::_003CModule_003E.smethod_21<string>(3522158227u, 3235942391u);
					num = 1096697414;
					continue;
					IL_00a5:
					result = global::_003CModule_003E.smethod_18<string>(1219033878u, 3557509324u);
					num = 111046526;
					continue;
					IL_008b:
					result = global::_003CModule_003E.smethod_18<string>(3702908052u, 1400833904u);
					num = 1096697414;
					continue;
					IL_0071:
					result = global::_003CModule_003E.smethod_22<string>(2119640621u, 3608273653u);
					num = 1090806220;
					continue;
					IL_0045:
					result = global::_003CModule_003E.smethod_20<string>(2953960637u, 1207065866u);
					num = 2066739785;
					continue;
				}
				break;
			}
		}
	}

	public static bool smethod_11(string string_9, ref GClass12 gclass12_0)
	{
		Match object_ = (Match)Delegate24.delegate24_3(Delegate160.delegate160_0(global::_003CModule_003E.smethod_18<string>(3184782967u, 2079457427u), RegexOptions.IgnoreCase | RegexOptions.Singleline), string_9);
		if (Delegate21.delegate21_18(object_))
		{
			goto IL_011f;
		}
		goto IL_0195;
		IL_011f:
		int num = -70619739;
		goto IL_015b;
		IL_015b:
		bool result = default(bool);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0x9D7D93D5u) % 10)
			{
			case 8u:
				Delegate30.delegate30_14(gclass12_0, gclass12_0.Type.ToString());
				result = true;
				num = (int)((num2 * 1474127554) ^ 0x2ABB2DD8);
				continue;
			case 7u:
				Delegate30.delegate30_13(gclass12_0, Delegate15.delegate15_33(Delegate55.delegate55_5(Delegate7.delegate7_185(object_), 1)));
				num = -1356316387;
				continue;
			case 6u:
			{
				int num3;
				int num4;
				if (Delegate56.delegate56_0(Delegate15.delegate15_33(Delegate55.delegate55_5(Delegate7.delegate7_185(object_), 1)), global::_003CModule_003E.smethod_22<string>(1001255265u, 1615611361u), bool_0: false) == 0)
				{
					num3 = 1072662667;
					num4 = 1072662667;
				}
				else
				{
					num3 = 2106138056;
					num4 = 2106138056;
				}
				num = num3 ^ (int)(num2 * 1542123928);
				continue;
			}
			case 5u:
				num = ((int)num2 * -2134481262) ^ -859489768;
				continue;
			case 4u:
				num = (int)((num2 * 473658379) ^ 0x6754D873);
				continue;
			case 3u:
				break;
			case 2u:
				Delegate30.delegate30_13(gclass12_0, "");
				num = (int)((num2 * 1842734743) ^ 0x37A8752D);
				continue;
			case 0u:
				gclass12_0.Type = GClass12.GEnum5.PixieDust;
				gclass12_0.genum0_0 = GClass3.GEnum0.Nothing;
				num = -1448775481;
				continue;
			case 9u:
				goto IL_0195;
			default:
				return result;
			}
			break;
		}
		goto IL_011f;
		IL_0195:
		result = false;
		num = -1389464966;
		goto IL_015b;
	}

	public static string smethod_12(string string_9)
	{
		return Delegate76.delegate76_1(Delegate160.delegate160_0(global::_003CModule_003E.smethod_20<string>(1746711342u, 2208427021u), RegexOptions.IgnoreCase | RegexOptions.Singleline), string_9, "");
	}

	public static string smethod_13(string string_9, string string_10)
	{
		return Delegate57.delegate57_1(Delegate77.delegate77_0(string_9, 0, Delegate17.delegate17_7(string_9) / 2), Delegate206.delegate206_0(checked(Delegate17.delegate17_7(string_9) - unchecked(Delegate17.delegate17_7(string_9) / 2)), string_10));
	}

	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	private static extern int SendMessage(IntPtr intptr_0, int int_3, IntPtr intptr_1, IntPtr intptr_2);

	public static void smethod_14(RichTextBox richTextBox_0)
	{
		Delegate209.delegate209_0(Delegate207.delegate207_0(richTextBox_0), 277, Delegate208.delegate208_0(7), IntPtr.Zero);
	}

	public static void smethod_15(string string_9, string string_10)
	{
		object object_ = Delegate182.delegate182_0(Delegate71.delegate71_0(Delegate15.delegate15_41(Delegate3.delegate3_109()), global::_003CModule_003E.smethod_19<string>(3827308474u, 1680538017u), string_9), FileMode.Append, FileAccess.Write);
		byte[] array = Delegate85.delegate85_0(Delegate210.delegate210_0(bool_0: true), string_10);
		Delegate91.smethod_1(object_, array, 0, array.Length);
		Delegate22.smethod_2(object_);
	}

	public static bool smethod_16()
	{
		return Delegate21.delegate21_21(Delegate7.delegate7_253(Delegate3.delegate3_110()));
	}
}
