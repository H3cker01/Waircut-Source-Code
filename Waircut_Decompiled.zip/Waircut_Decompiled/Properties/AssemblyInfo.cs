using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("waircut")]
[assembly: AssemblyDescription("Wireless Air Cut")]
[assembly: AssemblyCompany("Patcher")]
[assembly: AssemblyProduct("waircut")]
[assembly: AssemblyTrademark("Wireless Air Cut")]
[assembly: ComVisible(false)]
[assembly: Guid("bab8f370-0329-4b61-a21a-34f329104444")]
[assembly: AssemblyCopyright("Copyright © Patcher 2018")]
[assembly: AssemblyFileVersion("2.0")]
[assembly: NeutralResourcesLanguage("")]
[assembly: AssemblyVersion("2.0.0.0")]
[module: Attribute0("MS Windows 2.1.12.3")]
