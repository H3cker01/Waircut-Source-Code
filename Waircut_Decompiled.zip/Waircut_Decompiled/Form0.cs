using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic.ApplicationServices;

[GeneratedCode("MyTemplate", "11.0.0.0")]
[EditorBrowsable(EditorBrowsableState.Never)]
internal class Form0 : WindowsFormsApplicationBase
{
	[MethodImpl(MethodImplOptions.NoOptimization)]
	[STAThread]
	[DebuggerHidden]
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static void Main(string[] args)
	{
		Delegate2.delegate2_0(Delegate1.delegate1_0());
		Delegate4.delegate4_0(Delegate3.delegate3_0(), args);
	}

	[DebuggerStepThrough]
	public Form0()
		: base(AuthenticationMode.Windows)
	{
		while (true)
		{
			int num = -503614541;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x9861AF11u) % 4)
				{
				case 2u:
					Delegate5.delegate5_0(this, bool_0: true);
					Delegate5.delegate5_1(this, bool_0: true);
					Delegate5.delegate5_2(this, bool_0: true);
					num = ((int)num2 * -1766221187) ^ 0x1770C08E;
					continue;
				case 1u:
					Delegate6.delegate6_0(this, ShutdownMode.AfterMainFormCloses);
					num = ((int)num2 * -1033350051) ^ 0x5F0E63E4;
					continue;
				default:
					return;
				case 3u:
					break;
				case 0u:
					return;
				}
				break;
			}
		}
	}

	[DebuggerStepThrough]
	void WindowsFormsApplicationBase.OnCreateMainForm()
	{
		Delegate8.delegate8_0(this, Delegate7.delegate7_0(Delegate3.delegate3_1()));
	}
}
