internal delegate object Delegate155(string string_0, GClass12.GEnum5 genum5_0, object object_0);
