using System.Windows.Forms;

internal delegate Padding Delegate192(object object_0);
