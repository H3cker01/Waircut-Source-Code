internal delegate int Delegate194(object object_0, string string_0);
