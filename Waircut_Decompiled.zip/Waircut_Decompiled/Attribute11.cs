using System;

internal class Attribute11 : Attribute
{
	internal readonly int int_0;

	internal Attribute11(int int_1)
	{
		int_0 = ((int_1 - 1866002054) ^ -1034394345) * -1820861495;
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
