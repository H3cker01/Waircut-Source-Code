internal delegate byte Delegate205(object object_0);
