internal delegate byte[] Delegate88(object object_0, string string_0, int int_0);
