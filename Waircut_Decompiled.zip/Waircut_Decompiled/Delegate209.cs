using System;

internal delegate int Delegate209(IntPtr intptr_0, int int_0, IntPtr intptr_1, IntPtr intptr_2);
