using System;

internal class Attribute5 : Attribute
{
	internal readonly int int_0;

	internal Attribute5(int int_1)
	{
		while (true)
		{
			int num = -2076982631;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xE92A0E5Au) % 3)
				{
				case 2u:
					goto IL_0008;
				default:
					return;
				case 0u:
					break;
				case 1u:
					return;
				}
				break;
				IL_0008:
				int_0 = ((int_1 ^ -1213840806) - 753634800) ^ 0x1FFD0378;
				num = ((int)num2 * -1538350150) ^ -78908300;
			}
		}
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
