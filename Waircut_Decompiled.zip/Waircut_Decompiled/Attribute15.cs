using System;

internal class Attribute15 : Attribute
{
	internal readonly int int_0;

	internal Attribute15(int int_1)
	{
		while (true)
		{
			int num = -1575739265;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x9CD5DC4Bu) % 3)
				{
				case 1u:
					goto IL_0008;
				default:
					return;
				case 2u:
					break;
				case 0u:
					return;
				}
				break;
				IL_0008:
				int_0 = -(int_1 ^ 0x3003DD4) - 1073251597;
				num = (int)((num2 * 1706230804) ^ 0xB0655D5);
			}
		}
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
