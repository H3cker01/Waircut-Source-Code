using System;

internal delegate PlatformID Delegate168(object object_0);
