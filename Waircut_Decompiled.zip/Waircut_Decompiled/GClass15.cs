using System;
using System.Collections.Generic;
using System.ComponentModel;
using ns0;
using ns1;

public class GClass15<T> : BindingList<T>
{
	private bool bool_0;

	private ListSortDirection listSortDirection_0;

	private PropertyDescriptor propertyDescriptor_0;

	bool BindingList<T>.SupportsSortingCore => true;

	bool BindingList<T>.IsSortedCore => bool_0;

	PropertyDescriptor BindingList<T>.SortPropertyCore => propertyDescriptor_0;

	ListSortDirection BindingList<T>.SortDirectionCore => listSortDirection_0;

	public GClass15()
	{
		while (true)
		{
			int num = -756441818;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x871FE449u) % 3)
				{
				case 2u:
					goto IL_0008;
				default:
					return;
				case 0u:
					break;
				case 1u:
					return;
				}
				break;
				IL_0008:
				bool_0 = false;
				num = (int)(num2 * 496406570) ^ -73197371;
			}
		}
	}

	void BindingList<T>.RemoveSortCore()
	{
		bool_0 = false;
	}

	public void method_0(IEnumerable<T> ienumerable_0)
	{
		IEnumerator<T> enumerator = default(IEnumerator<T>);
		try
		{
			enumerator = ienumerable_0.GetEnumerator();
			T current = default(T);
			while (true)
			{
				int num;
				int num2;
				if (!Delegate21.delegate21_3(enumerator))
				{
					num = 1402060655;
					num2 = 1402060655;
				}
				else
				{
					num = 1987898608;
					num2 = 1987898608;
				}
				while (true)
				{
					uint num3;
					switch ((num3 = (uint)num ^ 0x222D0D98u) % 5)
					{
					case 4u:
						current = enumerator.Current;
						num = 780286836;
						continue;
					case 3u:
						num = 1987898608;
						continue;
					case 2u:
						base.Items.Add(current);
						num = ((int)num3 * -1799247199) ^ 0x5FC7D0A2;
						continue;
					default:
						return;
					case 0u:
						break;
					case 1u:
						return;
					}
					break;
				}
			}
		}
		finally
		{
			if (enumerator != null)
			{
				while (true)
				{
					IL_00c0:
					int num4 = 1041548382;
					while (true)
					{
						uint num3;
						switch ((num3 = (uint)num4 ^ 0x222D0D98u) % 3)
						{
						case 1u:
							goto IL_008b;
						default:
							goto end_IL_00a3;
						case 2u:
							break;
						case 0u:
							goto end_IL_00a3;
						}
						goto IL_00c0;
						IL_008b:
						Delegate22.delegate22_4(enumerator);
						num4 = (int)(num3 * 487860521) ^ -1641824458;
						continue;
						end_IL_00a3:
						break;
					}
					break;
				}
			}
		}
	}

	void BindingList<T>.ApplySortCore(PropertyDescriptor prop, ListSortDirection direction)
	{
		List<T> list = base.Items as List<T>;
		try
		{
			if (list != null)
			{
				goto IL_0012;
			}
			goto IL_00d8;
			IL_0012:
			int num = -831351900;
			goto IL_00a2;
			IL_00a2:
			GClass16<T> comparer = default(GClass16<T>);
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xC3D75C65u) % 9)
				{
				case 8u:
					break;
				case 6u:
					bool_0 = true;
					num = ((int)num2 * -504801743) ^ -2088810401;
					continue;
				case 5u:
					list.Sort(comparer);
					num = (int)(num2 * 2015550595) ^ -1005909861;
					continue;
				case 4u:
					OnListChanged((ListChangedEventArgs)Delegate193.delegate193_0(ListChangedType.Reset, -1));
					num = -1448040174;
					continue;
				case 3u:
					comparer = new GClass16<T>(prop, direction);
					num = (int)((num2 * 1260441365) ^ 0x7FBAF4F8);
					continue;
				case 2u:
					listSortDirection_0 = direction;
					propertyDescriptor_0 = prop;
					num = ((int)num2 * -923815918) ^ 0x114E543E;
					continue;
				case 1u:
					num = (int)(num2 * 1492064954) ^ -950669356;
					continue;
				default:
					return;
				case 7u:
					goto IL_00d8;
				case 0u:
					return;
				}
				break;
			}
			goto IL_0012;
			IL_00d8:
			bool_0 = false;
			num = -1331040324;
			goto IL_00a2;
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			while (true)
			{
				int num3 = -2115389769;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num3 ^ 0xC3D75C65u) % 3)
					{
					default:
						return;
					case 2u:
						goto IL_010e;
					case 0u:
						break;
					case 1u:
						return;
					}
					break;
					IL_010e:
					Delegate51.delegate51_0();
					num3 = (int)((num2 * 644067906) ^ 0x59A065D6);
				}
			}
		}
	}
}
