using System;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using ns0;
using ns1;

public class GClass10
{
	public delegate void GDelegate9(string version);

	[CompilerGenerated]
	[AccessedThroughProperty("backWorker")]
	private BackgroundWorker backgroundWorker_0;

	private Version version_0;

	private DateTime dateTime_0;

	private DateTime dateTime_1;

	private DateTime dateTime_2;

	private bool bool_0;

	private int int_0;

	private GClass1 gclass1_0;

	[CompilerGenerated]
	private GDelegate9 gdelegate9_0;

	private virtual BackgroundWorker BackgroundWorker_0
	{
		[CompilerGenerated]
		get
		{
			return backgroundWorker_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DoWorkEventHandler object_ = method_1;
			RunWorkerCompletedEventHandler object_2 = method_2;
			BackgroundWorker backgroundWorker = default(BackgroundWorker);
			ProgressChangedEventHandler object_3 = default(ProgressChangedEventHandler);
			while (true)
			{
				int num = -1462934001;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x8113E170u) % 9)
					{
					case 8u:
						backgroundWorker = backgroundWorker_0;
						num = (int)((num2 * 1433220661) ^ 0x6CCFC552);
						continue;
					case 5u:
					{
						int num5;
						int num6;
						if (backgroundWorker != null)
						{
							num5 = 2088734380;
							num6 = 2088734380;
						}
						else
						{
							num5 = 963949890;
							num6 = 963949890;
						}
						num = num5 ^ (int)(num2 * 1032472789);
						continue;
					}
					case 4u:
						backgroundWorker_0 = value;
						num = -1450066685;
						continue;
					case 3u:
						object_3 = method_3;
						num = (int)((num2 * 1519572945) ^ 0x79B94804);
						continue;
					case 2u:
					{
						backgroundWorker = backgroundWorker_0;
						int num3;
						int num4;
						if (backgroundWorker == null)
						{
							num3 = 1609806223;
							num4 = 1609806223;
						}
						else
						{
							num3 = 321403673;
							num4 = 321403673;
						}
						num = num3 ^ ((int)num2 * -208043463);
						continue;
					}
					case 1u:
						Delegate8.delegate8_223(backgroundWorker, object_);
						Delegate8.delegate8_224(backgroundWorker, object_2);
						Delegate8.delegate8_225(backgroundWorker, object_3);
						num = (int)(num2 * 1019312111) ^ -586455760;
						continue;
					case 0u:
						Delegate8.delegate8_226(backgroundWorker, object_);
						Delegate8.delegate8_227(backgroundWorker, object_2);
						Delegate8.delegate8_228(backgroundWorker, object_3);
						num = (int)((num2 * 1080775683) ^ 0xBA187C2);
						continue;
					default:
						return;
					case 6u:
						break;
					case 7u:
						return;
					}
					break;
				}
			}
		}
	}

	public event GDelegate9 Event_0
	{
		[CompilerGenerated]
		add
		{
			GDelegate9 gDelegate = gdelegate9_0;
			while (true)
			{
				int num = -1550728619;
				while (true)
				{
					switch ((uint)(num ^ -797608302) % 3u)
					{
					case 2u:
					{
						GDelegate9 gDelegate2 = gDelegate;
						GDelegate9 value2 = (GDelegate9)Delegate95.delegate95_0(gDelegate2, value);
						gDelegate = Interlocked.CompareExchange(ref gdelegate9_0, value2, gDelegate2);
						int num2;
						if ((object)gDelegate != gDelegate2)
						{
							num = -1550728619;
							num2 = -1550728619;
						}
						else
						{
							num = -591334349;
							num2 = -591334349;
						}
						continue;
					}
					default:
						return;
					case 0u:
						break;
					case 1u:
						return;
					}
					break;
				}
			}
		}
		[CompilerGenerated]
		remove
		{
			GDelegate9 gDelegate = gdelegate9_0;
			GDelegate9 gDelegate2 = default(GDelegate9);
			GDelegate9 value2 = default(GDelegate9);
			while (true)
			{
				int num = -884632220;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x87FDE7C8u) % 5)
					{
					case 4u:
					{
						int num3;
						int num4;
						if ((object)gDelegate == gDelegate2)
						{
							num3 = -13008894;
							num4 = -13008894;
						}
						else
						{
							num3 = -1496424388;
							num4 = -1496424388;
						}
						num = num3 ^ ((int)num2 * -1967631558);
						continue;
					}
					case 3u:
						gDelegate = Interlocked.CompareExchange(ref gdelegate9_0, value2, gDelegate2);
						num = ((int)num2 * -1459799438) ^ -925379352;
						continue;
					case 1u:
						gDelegate2 = gDelegate;
						value2 = (GDelegate9)Delegate95.delegate95_1(gDelegate2, value);
						num = -49706362;
						continue;
					default:
						return;
					case 0u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	public GClass10()
	{
		while (true)
		{
			int num = -1632131844;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xDB9A607Eu) % 6)
				{
				case 4u:
					Delegate22.delegate22_42(Delegate7.delegate7_181(this));
					num = ((int)num2 * -1416769261) ^ -682435541;
					continue;
				case 2u:
					Delegate8.delegate8_229(this, Delegate3.delegate3_87());
					num = ((int)num2 * -2077671912) ^ -379354939;
					continue;
				case 1u:
					bool_0 = false;
					num = ((int)num2 * -1014151857) ^ 0x77AC1F8F;
					continue;
				case 0u:
					int_0 = 0;
					gclass1_0 = (GClass1)Delegate3.delegate3_41();
					Delegate5.delegate5_42(Delegate7.delegate7_181(this), bool_0: true);
					Delegate5.delegate5_43(Delegate7.delegate7_181(this), bool_0: true);
					num = ((int)num2 * -1455452535) ^ -1689367402;
					continue;
				default:
					return;
				case 5u:
					break;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public void method_0()
	{
		Delegate22.delegate22_43(Delegate7.delegate7_181(this));
	}

	private void method_1(object sender, DoWorkEventArgs e)
	{
		if (Delegate1.delegate1_1())
		{
			goto IL_0052;
		}
		goto IL_00a9;
		IL_0052:
		int num = 813053692;
		goto IL_0082;
		IL_0082:
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0x4FAB0CE9u) % 6)
			{
			case 4u:
				Delegate32.delegate32_11(Delegate7.delegate7_181(this), 1);
				num = (int)(num2 * 1139046571) ^ -944336254;
				continue;
			case 3u:
				checked
				{
					int_0++;
				}
				num = ((int)num2 * -1123680946) ^ 0x199A840B;
				continue;
			case 2u:
				break;
			case 1u:
				Delegate156.delegate156_0(this, global::_003CModule_003E.smethod_19<string>(477622896u, 3141575290u), 15);
				num = (int)((num2 * 211631546) ^ 0x500676B5);
				continue;
			default:
				goto IL_00a9;
			}
			break;
		}
		goto IL_0052;
		IL_00a9:
		Delegate32.delegate32_11(Delegate7.delegate7_181(this), 1);
		Delegate157.delegate157_0(60000);
		num = 1445305884;
		goto IL_0082;
	}

	private void method_2(object sender, RunWorkerCompletedEventArgs e)
	{
	}

	private void method_3(object sender, ProgressChangedEventArgs e)
	{
		if (Class13.bool_0)
		{
			return;
		}
		GDelegate9 gDelegate = default(GDelegate9);
		while (true)
		{
			int num = 530155907;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x2C1A6EDDu) % 7)
				{
				case 5u:
					bool_0 = true;
					num = ((int)num2 * -162520073) ^ 0x1B5A8887;
					continue;
				case 4u:
					gDelegate(Delegate15.delegate15_31(version_0));
					num = (int)((num2 * 508451219) ^ 0x558EC13A);
					continue;
				case 3u:
					gDelegate = gdelegate9_0;
					num = (int)((num2 * 1270106880) ^ 0x7BE028F2);
					continue;
				case 1u:
				{
					int num5;
					int num6;
					if (!(Delegate21.delegate21_17(this) & !bool_0))
					{
						num5 = -250663158;
						num6 = -250663158;
					}
					else
					{
						num5 = -213384591;
						num6 = -213384591;
					}
					num = num5 ^ ((int)num2 * -124878681);
					continue;
				}
				case 0u:
				{
					int num3;
					int num4;
					if (gDelegate == null)
					{
						num3 = -1191211629;
						num4 = -1191211629;
					}
					else
					{
						num3 = -328650432;
						num4 = -328650432;
					}
					num = num3 ^ ((int)num2 * -285061083);
					continue;
				}
				default:
					return;
				case 2u:
					break;
				case 6u:
					return;
				}
				break;
			}
		}
	}

	private void method_4(string string_0, int int_1)
	{
		HttpWebRequest object_ = (HttpWebRequest)Delegate158.delegate158_0((Uri)Delegate12.delegate12_6(string_0));
		Delegate32.delegate32_12(object_, checked(1000 * int_1));
		Delegate159.delegate159_0(SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
		try
		{
			Stream stream = (Stream)Delegate7.delegate7_183(Delegate7.delegate7_182(object_));
			try
			{
				StreamReader streamReader = (StreamReader)Delegate7.delegate7_184(stream);
				try
				{
					string string_ = Delegate15.delegate15_32(streamReader);
					Match object_2 = (Match)Delegate24.delegate24_3(Delegate160.delegate160_0(global::_003CModule_003E.smethod_21<string>(2043844279u, 140037729u), RegexOptions.IgnoreCase | RegexOptions.Singleline), string_);
					while (true)
					{
						IL_0128:
						int num = -1208057344;
						while (true)
						{
							uint num2;
							switch ((num2 = (uint)num ^ 0xC0EDA815u) % 4)
							{
							case 3u:
								version_0 = (Version)Delegate12.delegate12_7(Delegate15.delegate15_33(Delegate55.delegate55_5(Delegate7.delegate7_185(object_2), 1)));
								num = ((int)num2 * -855019171) ^ -855734918;
								continue;
							case 1u:
							{
								int num3;
								int num4;
								if (Delegate21.delegate21_18(object_2))
								{
									num3 = -97962396;
									num4 = -97962396;
								}
								else
								{
									num3 = -1526045097;
									num4 = -1526045097;
								}
								num = num3 ^ ((int)num2 * -1278955690);
								continue;
							}
							default:
								goto end_IL_0106;
							case 2u:
								break;
							case 0u:
								goto end_IL_0106;
							}
							goto IL_0128;
							continue;
							end_IL_0106:
							break;
						}
						break;
					}
				}
				finally
				{
					if (streamReader != null)
					{
						while (true)
						{
							IL_016d:
							int num5 = -65741194;
							while (true)
							{
								uint num2;
								switch ((num2 = (uint)num5 ^ 0xC0EDA815u) % 3)
								{
								case 1u:
									goto IL_0136;
								default:
									goto end_IL_014f;
								case 2u:
									break;
								case 0u:
									goto end_IL_014f;
								}
								goto IL_016d;
								IL_0136:
								Delegate22.delegate22_4(streamReader);
								num5 = ((int)num2 * -1689889076) ^ 0x3F2041E7;
								continue;
								end_IL_014f:
								break;
							}
							break;
						}
					}
				}
			}
			finally
			{
				if (stream != null)
				{
					while (true)
					{
						IL_01b3:
						int num6 = -2122469047;
						while (true)
						{
							uint num2;
							switch ((num2 = (uint)num6 ^ 0xC0EDA815u) % 3)
							{
							case 2u:
								goto IL_017c;
							default:
								goto end_IL_0195;
							case 0u:
								break;
							case 1u:
								goto end_IL_0195;
							}
							goto IL_01b3;
							IL_017c:
							Delegate22.delegate22_4(stream);
							num6 = ((int)num2 * -352735728) ^ 0x1F05D4D2;
							continue;
							end_IL_0195:
							break;
						}
						break;
					}
				}
			}
			Delegate22.delegate22_44(Delegate7.delegate7_182(object_));
		}
		catch (WebException exception_)
		{
			Delegate14.smethod_0((Exception)exception_);
			while (true)
			{
				int num7 = -37851689;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num7 ^ 0xC0EDA815u) % 3)
					{
					default:
						return;
					case 1u:
						goto IL_01f9;
					case 0u:
						break;
					case 2u:
						return;
					}
					break;
					IL_01f9:
					Delegate51.delegate51_0();
					num7 = ((int)num2 * -1332431603) ^ -1209816010;
				}
			}
		}
	}

	private void method_5(string string_0, int int_1)
	{
		WebRequest object_ = (WebRequest)Delegate158.delegate158_0((Uri)Delegate12.delegate12_6(string_0));
		Delegate32.delegate32_13(object_, checked(1000 * int_1));
		Delegate159.delegate159_0(SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
		try
		{
			Stream stream = (Stream)Delegate7.delegate7_183(Delegate7.delegate7_186(object_));
			try
			{
				StreamReader streamReader = (StreamReader)Delegate7.delegate7_184(stream);
				try
				{
					string string_ = Delegate15.delegate15_32(streamReader);
					Match object_2 = (Match)Delegate24.delegate24_3(Delegate160.delegate160_0(global::_003CModule_003E.smethod_20<string>(307479502u, 272150095u), RegexOptions.IgnoreCase | RegexOptions.Singleline), string_);
					while (true)
					{
						IL_013c:
						int num = -1873049282;
						while (true)
						{
							uint num2;
							switch ((num2 = (uint)num ^ 0xB70B8D4Cu) % 4)
							{
							case 2u:
							{
								int num3;
								int num4;
								if (!Delegate21.delegate21_18(object_2))
								{
									num3 = 1392372362;
									num4 = 1392372362;
								}
								else
								{
									num3 = 408081603;
									num4 = 408081603;
								}
								num = num3 ^ ((int)num2 * -246178619);
								continue;
							}
							case 1u:
								dateTime_2 = Delegate161.delegate161_0(Delegate15.delegate15_33(Delegate55.delegate55_5(Delegate7.delegate7_185(object_2), 1)), global::_003CModule_003E.smethod_20<string>(3266739822u, 3544110309u), (IFormatProvider)Delegate3.delegate3_88());
								num = (int)(num2 * 114342287) ^ -883795541;
								continue;
							default:
								goto end_IL_011a;
							case 3u:
								break;
							case 0u:
								goto end_IL_011a;
							}
							goto IL_013c;
							continue;
							end_IL_011a:
							break;
						}
						break;
					}
				}
				finally
				{
					if (streamReader != null)
					{
						while (true)
						{
							IL_0181:
							int num5 = -858076363;
							while (true)
							{
								uint num2;
								switch ((num2 = (uint)num5 ^ 0xB70B8D4Cu) % 3)
								{
								case 1u:
									goto IL_014a;
								default:
									goto end_IL_0163;
								case 2u:
									break;
								case 0u:
									goto end_IL_0163;
								}
								goto IL_0181;
								IL_014a:
								Delegate22.delegate22_4(streamReader);
								num5 = (int)((num2 * 1876608769) ^ 0x771052E2);
								continue;
								end_IL_0163:
								break;
							}
							break;
						}
					}
				}
			}
			finally
			{
				if (stream != null)
				{
					while (true)
					{
						IL_01c7:
						int num6 = -1453699852;
						while (true)
						{
							uint num2;
							switch ((num2 = (uint)num6 ^ 0xB70B8D4Cu) % 3)
							{
							case 2u:
								goto IL_0190;
							default:
								goto end_IL_01a9;
							case 0u:
								break;
							case 1u:
								goto end_IL_01a9;
							}
							goto IL_01c7;
							IL_0190:
							Delegate22.delegate22_4(stream);
							num6 = ((int)num2 * -695763547) ^ -1673768594;
							continue;
							end_IL_01a9:
							break;
						}
						break;
					}
				}
			}
			Delegate22.delegate22_44(Delegate7.delegate7_186(object_));
		}
		catch (WebException exception_)
		{
			Delegate14.smethod_0((Exception)exception_);
			Delegate51.delegate51_0();
		}
	}

	private bool method_6()
	{
		if ((object)version_0 != null)
		{
			goto IL_000b;
		}
		goto IL_00f4;
		IL_000b:
		int num = 908806267;
		goto IL_00d3;
		IL_00d3:
		bool result = default(bool);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0x3F674EE9u) % 4)
			{
			case 3u:
				break;
			case 2u:
				result = (Delegate17.delegate17_17(version_0) > Delegate17.delegate17_17(Delegate7.delegate7_187(Delegate7.delegate7_15(Delegate3.delegate3_0())))) | ((Delegate17.delegate17_17(version_0) == Delegate17.delegate17_17(Delegate7.delegate7_187(Delegate7.delegate7_15(Delegate3.delegate3_0())))) & (Delegate17.delegate17_18(version_0) > Delegate17.delegate17_18(Delegate7.delegate7_187(Delegate7.delegate7_15(Delegate3.delegate3_0())))));
				num = (int)((num2 * 1889994608) ^ 0x4C6C2509);
				continue;
			case 1u:
				goto IL_00f4;
			default:
				return result;
			}
			break;
		}
		goto IL_000b;
		IL_00f4:
		result = false;
		num = 46332137;
		goto IL_00d3;
	}

	private void method_7(string string_0, string string_1)
	{
		try
		{
			Uri object_ = (Uri)Delegate12.delegate12_6(string_0);
			while (true)
			{
				int num = 722231323;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x155F65A5u) % 3)
					{
					case 1u:
						goto IL_000e;
					default:
						return;
					case 2u:
						break;
					case 0u:
						return;
					}
					break;
					IL_000e:
					object object_2 = Delegate3.delegate3_89();
					Delegate159.delegate159_0(SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
					Delegate8.smethod_1(object_2, (object)new AsyncCompletedEventHandler(method_8));
					Delegate162.smethod_0(object_2, (object)object_, string_1, (object)string_1);
					num = (int)(num2 * 45779276) ^ -848570972;
				}
			}
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			Delegate51.delegate51_0();
		}
	}

	private void method_8(object sender, AsyncCompletedEventArgs e)
	{
	}
}
