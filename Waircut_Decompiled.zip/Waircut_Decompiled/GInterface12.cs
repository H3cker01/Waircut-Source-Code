using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[ComImport]
[Guid("D5B00EF7-40B1-434A-8199-BAF41DA46731")]
[CompilerGenerated]
[TypeIdentifier]
[CoClass(typeof(object))]
public interface GInterface12 : GInterface1
{
}
