internal delegate object Delegate138(string string_0, int int_0, object object_0);
