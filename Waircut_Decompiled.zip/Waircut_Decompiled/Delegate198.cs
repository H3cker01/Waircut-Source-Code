using System.ServiceProcess;

internal delegate void Delegate198(object object_0, ServiceControllerStatus serviceControllerStatus_0);
