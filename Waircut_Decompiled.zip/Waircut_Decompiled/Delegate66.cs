internal delegate void Delegate66(object object_0, char[] char_0);
