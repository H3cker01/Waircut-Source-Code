internal delegate string Delegate76(object object_0, string string_0, string string_1);
