internal delegate object Delegate210(bool bool_0);
