using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Waircut;
using ns0;
using ns1;

public class GClass8
{
	public delegate void GDelegate6(string message, Color color, bool autoCrLf);

	public delegate void GDelegate7(GEnum16 MessageType);

	public delegate void GDelegate8(GEnum1 Status);

	private delegate void Delegate0();

	public enum GEnum1
	{
		Stop = 0,
		Start = 1,
		Testing = 2,
		Success = 4,
		NACK = 5,
		Updated = 6,
		Locked = 7,
		PixieSucced = 8,
		ApNotFound = 9,
		AssociationFailed = 10
	}

	public enum GEnum2
	{
		None,
		Nok,
		Ok,
		fHalfOk,
		Fault
	}

	private GInterface3 ginterface3_0;

	private GInterface2 ginterface2_0;

	private int int_0;

	public List<GInterface1> list_0;

	private GInterface0 ginterface0_0;

	private GInterface7 ginterface7_0;

	[CompilerGenerated]
	[AccessedThroughProperty("engineListener")]
	private GClass7 gclass7_0;

	private bool bool_0;

	private GClass9 gclass9_0;

	private GClass12 gclass12_0;

	public string string_0;

	private bool bool_1;

	private GEnum1 genum1_0;

	public GEnum2 genum2_0;

	public GEnum16 genum16_0;

	public bool bool_2;

	[CompilerGenerated]
	private GDelegate6 gdelegate6_0;

	[CompilerGenerated]
	private GDelegate7 gdelegate7_0;

	[CompilerGenerated]
	private GDelegate8 gdelegate8_0;

	[CompilerGenerated]
	private Delegate0 delegate0_0;

	private bool bool_3;

	private virtual GClass7 GClass7_0
	{
		[CompilerGenerated]
		get
		{
			return gclass7_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			GClass7.GDelegate3 object_ = method_13;
			GClass7 gClass = default(GClass7);
			while (true)
			{
				int num = 860861586;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x21FA20C5u) % 8)
					{
					case 7u:
					{
						gClass = gclass7_0;
						int num5;
						int num6;
						if (gClass != null)
						{
							num5 = -1141393920;
							num6 = -1141393920;
						}
						else
						{
							num5 = -2066503159;
							num6 = -2066503159;
						}
						num = num5 ^ (int)(num2 * 1748618903);
						continue;
					}
					case 6u:
						Delegate8.delegate8_219(gClass, object_);
						num = (int)((num2 * 1059622173) ^ 0x2DA799C9);
						continue;
					case 5u:
						gclass7_0 = value;
						num = 1780481356;
						continue;
					case 4u:
						Delegate8.delegate8_218(gClass, object_);
						num = (int)((num2 * 745745888) ^ 0x3D718ED8);
						continue;
					case 3u:
					{
						int num3;
						int num4;
						if (gClass == null)
						{
							num3 = -563810338;
							num4 = -563810338;
						}
						else
						{
							num3 = -155605766;
							num4 = -155605766;
						}
						num = num3 ^ ((int)num2 * -275051317);
						continue;
					}
					case 1u:
						gClass = gclass7_0;
						num = ((int)num2 * -2090966308) ^ -1195655678;
						continue;
					default:
						return;
					case 0u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	public event GDelegate6 Event_0
	{
		[CompilerGenerated]
		add
		{
			GDelegate6 gDelegate = gdelegate6_0;
			GDelegate6 value2 = default(GDelegate6);
			GDelegate6 gDelegate2 = default(GDelegate6);
			while (true)
			{
				int num = 446831183;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x712C4EABu) % 5)
					{
					case 4u:
					{
						gDelegate = Interlocked.CompareExchange(ref gdelegate6_0, value2, gDelegate2);
						int num3;
						int num4;
						if ((object)gDelegate != gDelegate2)
						{
							num3 = 130387909;
							num4 = 130387909;
						}
						else
						{
							num3 = 1232343991;
							num4 = 1232343991;
						}
						num = num3 ^ ((int)num2 * -284476055);
						continue;
					}
					case 3u:
						value2 = (GDelegate6)Delegate95.delegate95_0(gDelegate2, value);
						num = (int)(num2 * 1946591428) ^ -1811267171;
						continue;
					case 1u:
						gDelegate2 = gDelegate;
						num = 111232648;
						continue;
					default:
						return;
					case 2u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
		[CompilerGenerated]
		remove
		{
			GDelegate6 gDelegate = gdelegate6_0;
			GDelegate6 gDelegate2 = default(GDelegate6);
			GDelegate6 value2 = default(GDelegate6);
			while (true)
			{
				int num = 176444634;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x17B95BD3u) % 5)
					{
					case 4u:
						gDelegate2 = gDelegate;
						num = 606599235;
						continue;
					case 1u:
						value2 = (GDelegate6)Delegate95.delegate95_1(gDelegate2, value);
						num = (int)(num2 * 1012286384) ^ -795114275;
						continue;
					case 0u:
					{
						gDelegate = Interlocked.CompareExchange(ref gdelegate6_0, value2, gDelegate2);
						int num3;
						int num4;
						if ((object)gDelegate != gDelegate2)
						{
							num3 = 1501759958;
							num4 = 1501759958;
						}
						else
						{
							num3 = 1857112265;
							num4 = 1857112265;
						}
						num = num3 ^ ((int)num2 * -707290166);
						continue;
					}
					default:
						return;
					case 3u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	public event GDelegate7 Event_1
	{
		[CompilerGenerated]
		add
		{
			GDelegate7 gDelegate = gdelegate7_0;
			GDelegate7 gDelegate2 = default(GDelegate7);
			GDelegate7 value2 = default(GDelegate7);
			while (true)
			{
				int num = -790353960;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x9ACD998Du) % 4)
					{
					case 1u:
						gDelegate2 = gDelegate;
						value2 = (GDelegate7)Delegate95.delegate95_0(gDelegate2, value);
						num = -1894663879;
						continue;
					case 0u:
					{
						gDelegate = Interlocked.CompareExchange(ref gdelegate7_0, value2, gDelegate2);
						int num3;
						int num4;
						if ((object)gDelegate == gDelegate2)
						{
							num3 = 641633535;
							num4 = 641633535;
						}
						else
						{
							num3 = 2034989868;
							num4 = 2034989868;
						}
						num = num3 ^ ((int)num2 * -797252271);
						continue;
					}
					default:
						return;
					case 3u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
		[CompilerGenerated]
		remove
		{
			GDelegate7 gDelegate = gdelegate7_0;
			GDelegate7 gDelegate2 = default(GDelegate7);
			while (true)
			{
				int num = 146770846;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x21C864F8u) % 5)
					{
					case 2u:
					{
						GDelegate7 value2 = (GDelegate7)Delegate95.delegate95_1(gDelegate2, value);
						gDelegate = Interlocked.CompareExchange(ref gdelegate7_0, value2, gDelegate2);
						num = ((int)num2 * -911044619) ^ -1795374314;
						continue;
					}
					case 1u:
						gDelegate2 = gDelegate;
						num = 600276243;
						continue;
					case 0u:
					{
						int num3;
						int num4;
						if ((object)gDelegate == gDelegate2)
						{
							num3 = 522706393;
							num4 = 522706393;
						}
						else
						{
							num3 = 1182316409;
							num4 = 1182316409;
						}
						num = num3 ^ ((int)num2 * -1993322897);
						continue;
					}
					default:
						return;
					case 4u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
	}

	public event GDelegate8 Event_2
	{
		[CompilerGenerated]
		add
		{
			GDelegate8 gDelegate = gdelegate8_0;
			GDelegate8 value2 = default(GDelegate8);
			GDelegate8 gDelegate2 = default(GDelegate8);
			while (true)
			{
				int num = -1006418519;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xCE3C6A00u) % 4)
					{
					case 2u:
					{
						gDelegate = Interlocked.CompareExchange(ref gdelegate8_0, value2, gDelegate2);
						int num3;
						int num4;
						if ((object)gDelegate == gDelegate2)
						{
							num3 = 690601385;
							num4 = 690601385;
						}
						else
						{
							num3 = 1881322435;
							num4 = 1881322435;
						}
						num = num3 ^ (int)(num2 * 1471787889);
						continue;
					}
					case 1u:
						gDelegate2 = gDelegate;
						value2 = (GDelegate8)Delegate95.delegate95_0(gDelegate2, value);
						num = -864920054;
						continue;
					default:
						return;
					case 0u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
		[CompilerGenerated]
		remove
		{
			GDelegate8 gDelegate = gdelegate8_0;
			while (true)
			{
				int num = -1520124763;
				while (true)
				{
					switch ((uint)(num ^ -518780997) % 3u)
					{
					case 1u:
					{
						GDelegate8 gDelegate2 = gDelegate;
						GDelegate8 value2 = (GDelegate8)Delegate95.delegate95_1(gDelegate2, value);
						gDelegate = Interlocked.CompareExchange(ref gdelegate8_0, value2, gDelegate2);
						int num2;
						if ((object)gDelegate != gDelegate2)
						{
							num = -1520124763;
							num2 = -1520124763;
						}
						else
						{
							num = -1532333955;
							num2 = -1532333955;
						}
						continue;
					}
					default:
						return;
					case 2u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
	}

	private event Delegate0 Event_3
	{
		[CompilerGenerated]
		add
		{
			Delegate0 @delegate = delegate0_0;
			Delegate0 delegate2 = default(Delegate0);
			Delegate0 value2 = default(Delegate0);
			while (true)
			{
				int num = -939240727;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xFBF50ADCu) % 6)
					{
					case 4u:
					{
						int num3;
						int num4;
						if ((object)@delegate == delegate2)
						{
							num3 = 1281335165;
							num4 = 1281335165;
						}
						else
						{
							num3 = 767394281;
							num4 = 767394281;
						}
						num = num3 ^ ((int)num2 * -657125840);
						continue;
					}
					case 3u:
						value2 = (Delegate0)Delegate95.delegate95_0(delegate2, value);
						num = (int)((num2 * 1601596080) ^ 0x7B80F0AC);
						continue;
					case 1u:
						delegate2 = @delegate;
						num = -1554421415;
						continue;
					case 0u:
						@delegate = Interlocked.CompareExchange(ref delegate0_0, value2, delegate2);
						num = ((int)num2 * -1678233585) ^ -1047558452;
						continue;
					default:
						return;
					case 2u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
		[CompilerGenerated]
		remove
		{
			Delegate0 @delegate = delegate0_0;
			Delegate0 delegate2 = default(Delegate0);
			while (true)
			{
				int num = -1836619334;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x837619DDu) % 5)
					{
					case 3u:
						delegate2 = @delegate;
						num = -944440992;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if ((object)@delegate == delegate2)
						{
							num3 = -1196887217;
							num4 = -1196887217;
						}
						else
						{
							num3 = -1153861878;
							num4 = -1153861878;
						}
						num = num3 ^ (int)(num2 * 774119748);
						continue;
					}
					case 0u:
					{
						Delegate0 value2 = (Delegate0)Delegate95.delegate95_1(delegate2, value);
						@delegate = Interlocked.CompareExchange(ref delegate0_0, value2, delegate2);
						num = (int)((num2 * 1041397421) ^ 0x66672988);
						continue;
					}
					default:
						return;
					case 4u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	public GClass8()
	{
		int_0 = 0;
		list_0 = new List<GInterface1>();
		Delegate8.delegate8_220(this, Delegate3.delegate3_85());
		bool_0 = false;
		gclass12_0 = (GClass12)Delegate133.delegate133_0(global::_003CModule_003E.smethod_22<string>(1757731675u, 2671395442u), GClass12.GEnum5.Manual);
		string_0 = "";
		bool_1 = true;
		genum1_0 = GEnum1.Stop;
		genum2_0 = GEnum2.None;
		genum16_0 = GEnum16.JswMsgType_None;
		bool_2 = false;
		bool_3 = false;
		Delegate100.delegate100_0(Delegate36.delegate36_9());
		Delegate22.delegate22_28(this);
		Delegate22.delegate22_29(this);
	}

	private void method_0()
	{
		ginterface3_0 = (GInterface14)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid(global::_003CModule_003E.smethod_19<string>(4082864602u, 1560744000u))));
		ginterface3_0.imethod_0();
	}

	private void method_1(int int_1)
	{
		ginterface0_0 = (GInterface0)Delegate59.delegate59_1(ginterface3_0, (GInterface12)list_0[int_1]);
		GDelegate6 gDelegate = default(GDelegate6);
		string object_ = default(string);
		while (true)
		{
			int num = -694500108;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xA8587758u) % 8)
				{
				case 7u:
					gDelegate(Delegate50.delegate50_0(global::_003CModule_003E.smethod_21<string>(1844091160u, 1978794740u), object_), Delegate28.delegate28_1(), autoCrLf: true);
					num = ((int)num2 * -614909156) ^ 0x74D9D5D7;
					continue;
				case 6u:
				{
					int num4;
					int num5;
					if (Class13.bool_1)
					{
						num4 = -547589381;
						num5 = -547589381;
					}
					else
					{
						num4 = -1289718897;
						num5 = -1289718897;
					}
					num = num4 ^ (int)(num2 * 463465285);
					continue;
				}
				case 5u:
					object_ = Delegate57.delegate57_0(object_, global::_003CModule_003E.smethod_20<string>(3151543051u, 2458757047u));
					num = (int)((num2 * 184453911) ^ 0x695BB68A);
					continue;
				case 4u:
					object_ = Delegate134.delegate134_0((byte[])Delegate7.delegate7_177(Delegate7.delegate7_176(ginterface0_0)));
					num = ((int)num2 * -1284089159) ^ -2057054238;
					continue;
				case 3u:
					Delegate22.delegate22_30(this);
					num = -798810134;
					continue;
				case 1u:
				{
					gDelegate = gdelegate6_0;
					int num3;
					if (gDelegate != null)
					{
						num = -1869366505;
						num3 = -1869366505;
					}
					else
					{
						num = -1106356109;
						num3 = -1106356109;
					}
					continue;
				}
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	private void method_2()
	{
		ginterface7_0 = (GInterface7)Delegate135.delegate135_0(ginterface3_0, GEnum15.JswEngMode_JoinNetworkApPin, (GInterface11)ginterface0_0, null);
		GDelegate6 gDelegate = default(GDelegate6);
		while (true)
		{
			int num = 1266077273;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x22D32416u) % 6)
				{
				case 5u:
				{
					int num3;
					int num4;
					if (gDelegate == null)
					{
						num3 = 1225956676;
						num4 = 1225956676;
					}
					else
					{
						num3 = 882194988;
						num4 = 882194988;
					}
					num = num3 ^ (int)(num2 * 1735942650);
					continue;
				}
				case 2u:
					gDelegate(Class13.string_4, Delegate28.delegate28_9(), autoCrLf: false);
					num = ((int)num2 * -1131271760) ^ 0x17ED943E;
					continue;
				case 1u:
					gDelegate = gdelegate6_0;
					num = (int)((num2 * 661007044) ^ 0x458282AB);
					continue;
				case 0u:
					bool_3 = true;
					num = 336362469;
					continue;
				case 4u:
					break;
				default:
					Delegate8.delegate8_221(ginterface7_0, Delegate7.delegate7_178(this));
					return;
				}
				break;
			}
		}
	}

	public void method_3()
	{
		list_0.Clear();
		GDelegate6 gDelegate3 = default(GDelegate6);
		GDelegate6 gDelegate4 = default(GDelegate6);
		GDelegate6 gDelegate = default(GDelegate6);
		GInterface12 gInterface = default(GInterface12);
		string object_ = default(string);
		GDelegate6 gDelegate2 = default(GDelegate6);
		while (true)
		{
			int num = -1348380496;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xCC9710C4u) % 8)
				{
				case 7u:
				{
					int num14;
					int num15;
					if (bool_3)
					{
						num14 = -560482237;
						num15 = -560482237;
					}
					else
					{
						num14 = -257825784;
						num15 = -257825784;
					}
					num = num14 ^ (int)(num2 * 171896783);
					continue;
				}
				case 6u:
				{
					gDelegate3 = gdelegate6_0;
					int num13;
					if (gDelegate3 != null)
					{
						num = -1043497659;
						num13 = -1043497659;
					}
					else
					{
						num = -653157460;
						num13 = -653157460;
					}
					continue;
				}
				case 5u:
				{
					gDelegate4 = gdelegate6_0;
					int num16;
					int num17;
					if (gDelegate4 == null)
					{
						num16 = -947225485;
						num17 = -947225485;
					}
					else
					{
						num16 = -2044451138;
						num17 = -2044451138;
					}
					num = num16 ^ (int)(num2 * 1890836229);
					continue;
				}
				case 4u:
					ginterface2_0 = (GInterface2)Delegate7.delegate7_179(ginterface3_0);
					num = (int)(num2 * 1778325113) ^ -1289814009;
					continue;
				case 3u:
					gDelegate4(Class13.string_4, Delegate28.delegate28_9(), autoCrLf: false);
					num = (int)((num2 * 1674314619) ^ 0x91236BB);
					continue;
				case 1u:
					gDelegate3(global::_003CModule_003E.smethod_21<string>(1075083366u, 3650527141u), Delegate28.delegate28_1(), autoCrLf: true);
					num = (int)((num2 * 105429008) ^ 0x7FB20BBC);
					continue;
				case 2u:
					break;
				default:
					try
					{
						while (true)
						{
							IL_0334:
							int num3;
							int num4;
							if (ginterface2_0 != null)
							{
								num3 = -1594896856;
								num4 = -1594896856;
							}
							else
							{
								num3 = -2051619578;
								num4 = -2051619578;
							}
							while (true)
							{
								switch ((num2 = (uint)num3 ^ 0xCC9710C4u) % 11)
								{
								case 9u:
									num3 = -1594896856;
									continue;
								case 8u:
								{
									gDelegate = gdelegate6_0;
									int num7;
									if (gDelegate == null)
									{
										num3 = -2073248843;
										num7 = -2073248843;
									}
									else
									{
										num3 = -27239975;
										num7 = -27239975;
									}
									continue;
								}
								case 7u:
								{
									int num8;
									int num9;
									if ((Delegate136.delegate136_0(gInterface) == GEnum13.JswDeviceType_WiFi) & !Delegate96.delegate96_0(Delegate15.delegate15_22(gInterface), global::_003CModule_003E.smethod_21<string>(1619126997u, 3160391638u)))
									{
										num8 = -1922326077;
										num9 = -1922326077;
									}
									else
									{
										num8 = -262418798;
										num9 = -262418798;
									}
									num3 = num8 ^ (int)(num2 * 1864898787);
									continue;
								}
								case 6u:
									list_0.Add(gInterface);
									num3 = ((int)num2 * -465438664) ^ -671127294;
									continue;
								case 5u:
								{
									int num5;
									int num6;
									if (Class13.bool_1)
									{
										num5 = -340257803;
										num6 = -340257803;
									}
									else
									{
										num5 = -1902665336;
										num6 = -1902665336;
									}
									num3 = num5 ^ (int)(num2 * 1907967123);
									continue;
								}
								case 4u:
									gDelegate(Delegate137.delegate137_0(global::_003CModule_003E.smethod_21<string>(2206786914u, 1372062127u), object_, Delegate15.delegate15_22(gInterface)), Delegate28.delegate28_1(), autoCrLf: true);
									num3 = (int)(num2 * 450763297) ^ -1944066808;
									continue;
								case 3u:
									gInterface = (GInterface12)Delegate7.delegate7_180(ginterface2_0);
									num3 = -1449670359;
									continue;
								case 2u:
									object_ = Delegate134.delegate134_0((byte[])Delegate7.delegate7_177(gInterface));
									num3 = (int)(num2 * 328740914) ^ -1893770376;
									continue;
								case 1u:
									object_ = Delegate57.delegate57_0(object_, global::_003CModule_003E.smethod_18<string>(3260271878u, 1635162191u));
									num3 = (int)(num2 * 2062129904) ^ -234610872;
									continue;
								default:
									goto end_IL_02e6;
								case 0u:
									break;
								case 10u:
									goto end_IL_02e6;
								}
								goto IL_0334;
								continue;
								end_IL_02e6:
								break;
							}
							break;
						}
					}
					catch (Exception exception_)
					{
						Delegate14.smethod_0(exception_);
						Delegate51.delegate51_0();
					}
					if (bool_3)
					{
						return;
					}
					while (true)
					{
						int num10 = -201912155;
						while (true)
						{
							switch ((num2 = (uint)num10 ^ 0xCC9710C4u) % 5)
							{
							case 3u:
								gDelegate2(Class13.string_4, Delegate28.delegate28_9(), autoCrLf: false);
								num10 = (int)((num2 * 767036686) ^ 0x51F3AA82);
								continue;
							case 2u:
							{
								int num11;
								int num12;
								if (gDelegate2 != null)
								{
									num11 = -238555849;
									num12 = -238555849;
								}
								else
								{
									num11 = -873470160;
									num12 = -873470160;
								}
								num10 = num11 ^ ((int)num2 * -1210965445);
								continue;
							}
							case 1u:
								gDelegate2 = gdelegate6_0;
								num10 = ((int)num2 * -172020220) ^ -1446027816;
								continue;
							default:
								return;
							case 4u:
								break;
							case 0u:
								return;
							}
							break;
						}
					}
				}
				break;
			}
		}
	}

	public void method_4(int int_1)
	{
		try
		{
			int_0 = int_1;
			Delegate32.delegate32_10(this, int_0);
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			while (true)
			{
				int num = -1985994535;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xF396B2ACu) % 3)
					{
					default:
						return;
					case 1u:
						goto IL_0040;
					case 2u:
						break;
					case 0u:
						return;
					}
					break;
					IL_0040:
					Delegate51.delegate51_0();
					num = (int)(num2 * 1503949822) ^ -1950971387;
				}
			}
		}
	}

	private void method_5()
	{
		Delegate100.delegate100_0(Delegate36.delegate36_9());
		Delegate22.delegate22_28(this);
		while (true)
		{
			int num = -1512257027;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xD181EFA0u) % 3)
				{
				case 1u:
					goto IL_0021;
				case 2u:
					break;
				default:
					Delegate104.delegate104_1(this, bool_1, 1);
					return;
				}
				break;
				IL_0021:
				Delegate22.delegate22_29(this);
				Delegate32.delegate32_10(this, int_0);
				num = ((int)num2 * -762493998) ^ -618499002;
			}
		}
	}

	public GClass15<GClass9> method_6(bool bool_4, int int_1)
	{
		GClass15<GClass9> gClass = new GClass15<GClass9>();
		int num = 0;
		GDelegate6 gDelegate7 = default(GDelegate6);
		GInterface16 gInterface = default(GInterface16);
		GDelegate6 gDelegate4 = default(GDelegate6);
		GDelegate6 gDelegate3 = default(GDelegate6);
		GDelegate6 gDelegate = default(GDelegate6);
		int num10 = default(int);
		DateTime now = default(DateTime);
		GDelegate6 gDelegate2 = default(GDelegate6);
		WaitSplashForm waitSplashForm = default(WaitSplashForm);
		int num7 = default(int);
		int num9 = default(int);
		DateTime value = default(DateTime);
		TimeSpan timeSpan = default(TimeSpan);
		GInterface15 gInterface2 = default(GInterface15);
		GClass9 item = default(GClass9);
		GDelegate6 gDelegate5 = default(GDelegate6);
		while (true)
		{
			int num2 = -1460418461;
			while (true)
			{
				uint num3;
				switch ((num3 = (uint)num2 ^ 0xD06A5096u) % 4)
				{
				case 2u:
					gDelegate7(Delegate50.delegate50_0(global::_003CModule_003E.smethod_21<string>(262459286u, 1291875421u), bool_4), Delegate28.delegate28_1(), autoCrLf: true);
					num2 = (int)((num3 * 1799413044) ^ 0x56C77DD2);
					continue;
				case 1u:
				{
					bool_1 = bool_4;
					gDelegate7 = gdelegate6_0;
					int num29;
					int num30;
					if (gDelegate7 != null)
					{
						num29 = 2078482194;
						num30 = 2078482194;
					}
					else
					{
						num29 = 1420591852;
						num30 = 1420591852;
					}
					num2 = num29 ^ ((int)num3 * -502686082);
					continue;
				}
				case 3u:
					break;
				default:
				{
					try
					{
						if (genum1_0 == GEnum1.Stop)
						{
							while (true)
							{
								IL_0622:
								int num4 = -594339584;
								while (true)
								{
									switch ((num3 = (uint)num4 ^ 0xD06A5096u) % 36)
									{
									case 35u:
										gInterface = (GInterface16)Delegate139.delegate139_0(ginterface0_0, bool_4);
										Delegate22.delegate22_32(ginterface0_0);
										gDelegate4 = gdelegate6_0;
										num4 = -2049004953;
										continue;
									case 33u:
									{
										gDelegate3 = gdelegate6_0;
										int num16;
										if (gDelegate3 != null)
										{
											num4 = -694266329;
											num16 = -694266329;
										}
										else
										{
											num4 = -1665875824;
											num16 = -1665875824;
										}
										continue;
									}
									case 32u:
									{
										gDelegate = gdelegate6_0;
										int num21;
										int num22;
										if (gDelegate != null)
										{
											num21 = 1915139797;
											num22 = 1915139797;
										}
										else
										{
											num21 = 1094447003;
											num22 = 1094447003;
										}
										num4 = num21 ^ (int)(num3 * 862286000);
										continue;
									}
									case 31u:
										num10 = 0;
										num4 = (int)(num3 * 1132493140) ^ -1170603440;
										continue;
									case 30u:
										num4 = ((int)num3 * -1696728286) ^ 0x336EEA5E;
										continue;
									case 29u:
										now = DateAndTime.Now;
										num4 = ((int)num3 * -403133372) ^ -1886228684;
										continue;
									case 28u:
										Application.DoEvents();
										num4 = -1569784866;
										continue;
									case 27u:
									{
										int num17;
										int num18;
										if (gDelegate2 == null)
										{
											num17 = -1776500539;
											num18 = -1776500539;
										}
										else
										{
											num17 = -1077220606;
											num18 = -1077220606;
										}
										num4 = num17 ^ ((int)num3 * -961234162);
										continue;
									}
									case 26u:
										gInterface = ginterface0_0.imethod_1(bool_4);
										num = (waitSplashForm.Int32_0 = checked(num + 1));
										num4 = (int)(num3 * 39837334) ^ -1588377563;
										continue;
									case 25u:
										gDelegate3(Class13.smethod_0(gClass), Color.White, autoCrLf: true);
										num4 = (int)((num3 * 331608491) ^ 0x794D9AB);
										continue;
									case 24u:
									{
										int num8;
										if (num < int_1)
										{
											num4 = -1606033243;
											num8 = -1606033243;
										}
										else
										{
											num4 = -565583454;
											num8 = -565583454;
										}
										continue;
									}
									case 23u:
										num7 = checked(gInterface.imethod_1() - 1);
										num4 = (int)((num3 * 869887145) ^ 0xD73BCA);
										continue;
									case 22u:
										gDelegate2(global::_003CModule_003E.smethod_21<string>(1850973893u, 1784891015u), Color.Yellow, autoCrLf: true);
										num4 = ((int)num3 * -801252007) ^ -1863312831;
										continue;
									case 21u:
									{
										int num19;
										int num20;
										if (gDelegate4 != null)
										{
											num19 = 508757081;
											num20 = 508757081;
										}
										else
										{
											num19 = 17919364;
											num20 = 17919364;
										}
										num4 = num19 ^ ((int)num3 * -272577804);
										continue;
									}
									case 20u:
										waitSplashForm.Dispose();
										num4 = ((int)num3 * -1176992233) ^ -2078902096;
										continue;
									case 19u:
										gDelegate4(global::_003CModule_003E.smethod_22<string>(996494575u, 835467827u), Delegate28.delegate28_20(), autoCrLf: false);
										num4 = ((int)num3 * -1308480080) ^ -1958397536;
										continue;
									case 18u:
										gDelegate2 = gdelegate6_0;
										num4 = (int)((num3 * 239400140) ^ 0x4D2EE411);
										continue;
									case 17u:
										num10 = checked(num10 + 1);
										num4 = -1673763879;
										continue;
									case 16u:
										num9 = checked(num9 - 1);
										num4 = ((int)num3 * -1240295811) ^ 0x6B35F727;
										continue;
									case 15u:
										timeSpan = Delegate64.delegate64_0().Subtract(Delegate64.delegate64_0());
										value = DateAndTime.Now;
										now = DateAndTime.Now;
										timeSpan = now.Subtract(value);
										num4 = (int)(num3 * 1660032090) ^ -1537767268;
										continue;
									case 14u:
										timeSpan = now.Subtract(value);
										num4 = ((int)num3 * -1266887517) ^ -831279160;
										continue;
									case 13u:
									{
										GInterface5 ginterface5_ = gInterface2;
										GClass9 gClass3 = new GClass9(ref ginterface5_);
										gInterface2 = (GInterface15)ginterface5_;
										item = gClass3;
										int num14;
										int num15;
										if (!gClass.Contains(item))
										{
											num14 = -1200858254;
											num15 = -1200858254;
										}
										else
										{
											num14 = -1082540393;
											num15 = -1082540393;
										}
										num4 = num14 ^ (int)(num3 * 1387962141);
										continue;
									}
									case 12u:
									{
										int num12;
										if (!(timeSpan.TotalMilliseconds >= 1000.0))
										{
											num4 = -206354486;
											num12 = -206354486;
										}
										else
										{
											num4 = -240459548;
											num12 = -240459548;
										}
										continue;
									}
									case 10u:
										waitSplashForm = (WaitSplashForm)Delegate138.delegate138_0(global::_003CModule_003E.smethod_19<string>(87309744u, 933061963u), int_1, Delegate7.delegate7_0(Delegate3.delegate3_1()));
										num4 = ((int)num3 * -859739384) ^ 0x353DE30A;
										continue;
									case 9u:
										value = Delegate64.delegate64_0();
										num4 = (int)((num3 * 1457888672) ^ 0x618E2619);
										continue;
									case 8u:
									{
										int index = gClass.IndexOf(item);
										GClass9 gClass2 = gClass[index];
										GInterface5 ginterface5_ = gInterface2;
										gClass2.method_2(ref ginterface5_, GEnum16.JswMsgType_Beacon);
										gInterface2 = (GInterface15)ginterface5_;
										num4 = ((int)num3 * -781822308) ^ -1226580549;
										continue;
									}
									case 7u:
									{
										int num11;
										if (num10 <= num7)
										{
											num4 = -1165789090;
											num11 = -1165789090;
										}
										else
										{
											num4 = -753428854;
											num11 = -753428854;
										}
										continue;
									}
									case 6u:
										num9 = 500000;
										num4 = -336991877;
										continue;
									case 5u:
									{
										int num5;
										int num6;
										if (bool_2)
										{
											num5 = -541014617;
											num6 = -541014617;
										}
										else
										{
											num5 = -1817781218;
											num6 = -1817781218;
										}
										num4 = num5 ^ (int)(num3 * 1075702997);
										continue;
									}
									case 4u:
										Delegate22.delegate22_31(waitSplashForm);
										num4 = (int)((num3 * 1043446638) ^ 0x4DFB16B4);
										continue;
									case 3u:
										gDelegate(Class13.smethod_12(gInterface2.imethod_2()), Color.Gray, autoCrLf: true);
										num4 = ((int)num3 * -1948609904) ^ -1328619541;
										continue;
									case 2u:
										num4 = (int)((num3 * 334956224) ^ 0x2AB7BC59);
										continue;
									case 1u:
										gClass.Add(item);
										num4 = -409482969;
										continue;
									case 0u:
										gInterface2 = gInterface.imethod_0();
										num4 = -514920181;
										continue;
									default:
										goto end_IL_057f;
									case 11u:
										break;
									case 34u:
										goto end_IL_057f;
									}
									goto IL_0622;
									continue;
									end_IL_057f:
									break;
								}
								break;
							}
						}
					}
					catch (Exception ex)
					{
						ProjectData.SetProjectError(ex);
						Exception ex2 = ex;
						while (true)
						{
							IL_06c9:
							int num23 = -2073330720;
							while (true)
							{
								switch ((num3 = (uint)num23 ^ 0xD06A5096u) % 5)
								{
								case 2u:
								{
									int num24;
									int num25;
									if (gDelegate5 != null)
									{
										num24 = 1813977870;
										num25 = 1813977870;
									}
									else
									{
										num24 = 366818630;
										num25 = 366818630;
									}
									num23 = num24 ^ (int)(num3 * 107334949);
									continue;
								}
								case 1u:
									gDelegate5 = gdelegate6_0;
									num23 = ((int)num3 * -1233914831) ^ 0x5FEE39FC;
									continue;
								case 0u:
									gDelegate5(ex2.Message, Color.IndianRed, autoCrLf: true);
									num23 = ((int)num3 * -462636627) ^ 0xD1752CE;
									continue;
								case 4u:
									break;
								default:
									ProjectData.ClearProjectError();
									goto end_IL_063e;
								}
								goto IL_06c9;
								continue;
								end_IL_063e:
								break;
							}
							break;
						}
					}
					GDelegate6 gDelegate6 = gdelegate6_0;
					while (true)
					{
						int num26 = -1093439791;
						while (true)
						{
							switch ((num3 = (uint)num26 ^ 0xD06A5096u) % 4)
							{
							case 3u:
							{
								int num27;
								int num28;
								if (gDelegate6 != null)
								{
									num27 = -326567210;
									num28 = -326567210;
								}
								else
								{
									num27 = -360184005;
									num28 = -360184005;
								}
								num26 = num27 ^ (int)(num3 * 537720744);
								continue;
							}
							case 0u:
								gDelegate6(Class13.string_4, Color.LightGreen, autoCrLf: false);
								num26 = (int)(num3 * 1014097609) ^ -1276555717;
								continue;
							case 2u:
								break;
							default:
								return gClass;
							}
							break;
						}
					}
				}
				}
				break;
			}
		}
	}

	public void method_7(ref GClass9 gclass9_1, GClass12 gclass12_1)
	{
		try
		{
			gclass9_0 = gclass9_1;
			GDelegate8 gDelegate = default(GDelegate8);
			while (true)
			{
				int num = 52369651;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x2DFC7C03u) % 15)
					{
					case 14u:
						gDelegate = gdelegate8_0;
						num = (int)(num2 * 642750706) ^ -82335283;
						continue;
					case 13u:
						gclass12_0 = gclass12_1;
						num = ((int)num2 * -1380919526) ^ 0x7E76FA65;
						continue;
					case 12u:
						Delegate140.smethod_0((object)ginterface0_0, (Type)null, global::_003CModule_003E.smethod_22<string>(2241752781u, 4209594208u), new object[2]
						{
							true,
							GEnum11.JswConnResetMethod_Default
						}, (string[])null, (Type[])null, (bool[])null, bool_1: true);
						num = (int)(num2 * 2104426919) ^ -1282576773;
						continue;
					case 11u:
					{
						int num9;
						int num10;
						if (gDelegate == null)
						{
							num9 = 1621712195;
							num10 = 1621712195;
						}
						else
						{
							num9 = 1609005225;
							num10 = 1609005225;
						}
						num = num9 ^ (int)(num2 * 924623451);
						continue;
					}
					case 9u:
						genum1_0 = GEnum1.Start;
						num = 325578419;
						continue;
					case 8u:
					{
						int num5;
						int num6;
						if (!Delegate21.delegate21_15(ginterface0_0))
						{
							num5 = -1426641632;
							num6 = -1426641632;
						}
						else
						{
							num5 = -605327852;
							num6 = -605327852;
						}
						num = num5 ^ ((int)num2 * -694275659);
						continue;
					}
					case 7u:
						Delegate22.delegate22_33(ginterface7_0);
						num = ((int)num2 * -1343056796) ^ -742897911;
						continue;
					case 6u:
					{
						int num7;
						int num8;
						if (ginterface7_0 != null)
						{
							num7 = -2119782576;
							num8 = -2119782576;
						}
						else
						{
							num7 = -1702048278;
							num8 = -1702048278;
						}
						num = num7 ^ ((int)num2 * -1182112703);
						continue;
					}
					case 5u:
						genum16_0 = GEnum16.JswMsgType_None;
						ginterface7_0 = (GInterface7)Delegate135.delegate135_0(ginterface3_0, GEnum15.JswEngMode_JoinNetworkApPin, (GInterface11)ginterface0_0, null);
						num = 631860219;
						continue;
					case 4u:
						Delegate8.delegate8_221(ginterface7_0, Delegate7.delegate7_178(this));
						num = ((int)num2 * -1394379335) ^ -1753823196;
						continue;
					case 2u:
						gDelegate(genum1_0);
						num = (int)((num2 * 1583917128) ^ 0x39EA4C19);
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (Delegate21.delegate21_14(this))
						{
							num3 = 370033440;
							num4 = 370033440;
						}
						else
						{
							num3 = 766346963;
							num4 = 766346963;
						}
						num = num3 ^ (int)(num2 * 1564329783);
						continue;
					}
					case 0u:
						Delegate8.delegate8_222(ginterface7_0, (GInterface15)gclass9_0.ginterface5_0);
						Delegate30.delegate30_17(ginterface7_0, Delegate15.delegate15_25(gclass12_0));
						num = (int)(num2 * 202248020) ^ -1184155180;
						continue;
					default:
						return;
					case 3u:
						break;
					case 10u:
						return;
					}
					break;
				}
			}
		}
		catch (Exception ex)
		{
			Delegate14.smethod_0(ex);
			Exception object_ = ex;
			GDelegate6 gDelegate2 = gdelegate6_0;
			while (true)
			{
				int num11 = 480967008;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num11 ^ 0x2DFC7C03u) % 5)
					{
					default:
						return;
					case 2u:
					{
						int num12;
						int num13;
						if (gDelegate2 == null)
						{
							num12 = -339119938;
							num13 = -339119938;
						}
						else
						{
							num12 = -1429294251;
							num13 = -1429294251;
						}
						num11 = num12 ^ ((int)num2 * -453785562);
						continue;
					}
					case 1u:
						gDelegate2(Delegate15.delegate15_0(object_), Delegate28.delegate28_21(), autoCrLf: true);
						num11 = ((int)num2 * -2099638192) ^ -1465867444;
						continue;
					case 0u:
						Delegate22.delegate22_34(this);
						Delegate51.delegate51_0();
						num11 = 256310671;
						continue;
					case 3u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	public void method_8(ref GClass9 gclass9_1, ref GClass12 gclass12_1)
	{
		try
		{
			gclass9_0 = gclass9_1;
			GDelegate8 gDelegate = default(GDelegate8);
			while (true)
			{
				int num = 604120123;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x5837AC85u) % 14)
					{
					case 13u:
						Delegate22.delegate22_33(ginterface7_0);
						num = ((int)num2 * -812490499) ^ 0x717CA977;
						continue;
					case 12u:
						gclass12_0 = gclass12_1;
						num = (int)((num2 * 1714072566) ^ 0x20BAC903);
						continue;
					case 10u:
					{
						int num7;
						int num8;
						if (!Delegate21.delegate21_15(ginterface0_0))
						{
							num7 = 1772796600;
							num8 = 1772796600;
						}
						else
						{
							num7 = 1396183824;
							num8 = 1396183824;
						}
						num = num7 ^ (int)(num2 * 1770087383);
						continue;
					}
					case 8u:
						ginterface7_0 = (GInterface7)Delegate135.delegate135_0(ginterface3_0, GEnum15.JswEngMode_JoinNetworkPushbutton, (GInterface11)ginterface0_0, null);
						Delegate8.delegate8_221(ginterface7_0, Delegate7.delegate7_178(this));
						num = (int)((num2 * 949157717) ^ 0x787931C4);
						continue;
					case 7u:
						genum16_0 = GEnum16.JswMsgType_None;
						num = 2008112011;
						continue;
					case 6u:
						gDelegate(genum1_0);
						num = ((int)num2 * -1243873911) ^ 0x781C63AA;
						continue;
					case 5u:
						Delegate140.smethod_0((object)ginterface0_0, (Type)null, global::_003CModule_003E.smethod_20<string>(1225617897u, 180565317u), new object[2]
						{
							true,
							GEnum11.JswConnResetMethod_Default
						}, (string[])null, (Type[])null, (bool[])null, bool_1: true);
						num = (int)((num2 * 840916407) ^ 0x639701FB);
						continue;
					case 4u:
					{
						int num5;
						int num6;
						if (gDelegate == null)
						{
							num5 = 1105679214;
							num6 = 1105679214;
						}
						else
						{
							num5 = 1193157729;
							num6 = 1193157729;
						}
						num = num5 ^ (int)(num2 * 1651659165);
						continue;
					}
					case 3u:
						genum1_0 = GEnum1.Start;
						num = 2027557573;
						continue;
					case 2u:
						Delegate8.delegate8_222(ginterface7_0, (GInterface15)gclass9_0.ginterface5_0);
						num = (int)((num2 * 1493601513) ^ 0x8CB9E2);
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (ginterface7_0 == null)
						{
							num3 = -1895436220;
							num4 = -1895436220;
						}
						else
						{
							num3 = -1535371907;
							num4 = -1535371907;
						}
						num = num3 ^ ((int)num2 * -752223150);
						continue;
					}
					case 0u:
						gDelegate = gdelegate8_0;
						num = (int)(num2 * 1723808724) ^ -2061669187;
						continue;
					default:
						return;
					case 11u:
						break;
					case 9u:
						return;
					}
					break;
				}
			}
		}
		catch (Exception ex)
		{
			Delegate14.smethod_0(ex);
			Exception object_ = ex;
			GDelegate6 gDelegate2 = gdelegate6_0;
			while (true)
			{
				int num9 = 1194010138;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num9 ^ 0x5837AC85u) % 5)
					{
					default:
						return;
					case 3u:
						gDelegate2(Delegate15.delegate15_0(object_), Delegate28.delegate28_21(), autoCrLf: true);
						num9 = ((int)num2 * -1697522532) ^ 0x552A9CBE;
						continue;
					case 2u:
						Delegate22.delegate22_34(this);
						Delegate51.delegate51_0();
						num9 = 376811359;
						continue;
					case 1u:
					{
						int num10;
						int num11;
						if (gDelegate2 != null)
						{
							num10 = -251313311;
							num11 = -251313311;
						}
						else
						{
							num10 = -856347363;
							num11 = -856347363;
						}
						num9 = num10 ^ (int)(num2 * 971841129);
						continue;
					}
					case 4u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
	}

	public void method_9(ref GClass9 gclass9_1)
	{
		bool_0 = true;
		while (true)
		{
			int num = 1519852823;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xB58F3BFu) % 3)
				{
				case 1u:
					goto IL_0009;
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
				IL_0009:
				Delegate109.delegate109_1(this, ref gclass9_1, Delegate133.delegate133_0(global::_003CModule_003E.smethod_21<string>(2344518505u, 4148389462u), GClass12.GEnum5.Manual));
				num = (int)(num2 * 1962127532) ^ -1834585710;
			}
		}
	}

	public void method_10(bool bool_4)
	{
		try
		{
			if (ginterface7_0 == null)
			{
				return;
			}
			GDelegate8 gDelegate = default(GDelegate8);
			while (true)
			{
				int num = 179463461;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x22DD2FF2u) % 11)
					{
					case 10u:
					{
						int num8;
						if (bool_4)
						{
							num = 1889641602;
							num8 = 1889641602;
						}
						else
						{
							num = 440365792;
							num8 = 440365792;
						}
						continue;
					}
					case 9u:
						ginterface7_0 = null;
						num = (int)((num2 * 727660921) ^ 0x5C46A510);
						continue;
					case 8u:
						Delegate22.delegate22_35(ginterface7_0);
						num = (int)(num2 * 148565320) ^ -241205832;
						continue;
					case 6u:
					{
						int num4;
						int num5;
						if (gDelegate != null)
						{
							num4 = -604695211;
							num5 = -604695211;
						}
						else
						{
							num4 = -1360566099;
							num5 = -1360566099;
						}
						num = num4 ^ (int)(num2 * 310626758);
						continue;
					}
					case 5u:
						gDelegate(genum1_0);
						num = (int)((num2 * 1418171536) ^ 0x758B7A05);
						continue;
					case 3u:
						genum1_0 = GEnum1.Stop;
						gDelegate = gdelegate8_0;
						num = (int)((num2 * 1233465782) ^ 0x4BE658FC);
						continue;
					case 2u:
					{
						int num6;
						int num7;
						if (!Delegate21.delegate21_15(ginterface0_0))
						{
							num6 = -1311913365;
							num7 = -1311913365;
						}
						else
						{
							num6 = -1189867757;
							num7 = -1189867757;
						}
						num = num6 ^ ((int)num2 * -594927286);
						continue;
					}
					case 1u:
					{
						bool_0 = false;
						int num3;
						if (genum1_0 != 0)
						{
							num = 1258114109;
							num3 = 1258114109;
						}
						else
						{
							num = 440365792;
							num3 = 440365792;
						}
						continue;
					}
					case 0u:
						Delegate140.smethod_0((object)ginterface0_0, (Type)null, global::_003CModule_003E.smethod_21<string>(3026293727u, 4161459609u), new object[2]
						{
							true,
							GEnum11.JswConnResetMethod_Default
						}, (string[])null, (Type[])null, (bool[])null, bool_1: true);
						num = ((int)num2 * -1246561094) ^ -1498540963;
						continue;
					default:
						return;
					case 7u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
		catch (Exception ex)
		{
			Delegate14.smethod_0(ex);
			Exception object_ = ex;
			GDelegate6 gDelegate2 = default(GDelegate6);
			while (true)
			{
				int num9 = 556195725;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num9 ^ 0x22DD2FF2u) % 5)
					{
					default:
						return;
					case 2u:
						Delegate22.delegate22_34(this);
						Delegate51.delegate51_0();
						num9 = 69886844;
						continue;
					case 1u:
					{
						gDelegate2 = gdelegate6_0;
						int num10;
						int num11;
						if (gDelegate2 != null)
						{
							num10 = -1369928239;
							num11 = -1369928239;
						}
						else
						{
							num10 = -848106509;
							num11 = -848106509;
						}
						num9 = num10 ^ (int)(num2 * 1016633888);
						continue;
					}
					case 0u:
						gDelegate2(Delegate15.delegate15_0(object_), Delegate28.delegate28_21(), autoCrLf: true);
						num9 = (int)(num2 * 403993944) ^ -1175792613;
						continue;
					case 4u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
	}

	private bool method_11()
	{
		int num = 10;
		GDelegate6 gDelegate7 = default(GDelegate6);
		bool flag = default(bool);
		int num6 = default(int);
		GInterface15 gInterface2 = default(GInterface15);
		DateTime dateTime = default(DateTime);
		TimeSpan timeSpan = default(TimeSpan);
		GDelegate6 gDelegate5 = default(GDelegate6);
		GDelegate6 gDelegate3 = default(GDelegate6);
		GInterface5 ginterface5_ = default(GInterface5);
		GDelegate6 gDelegate4 = default(GDelegate6);
		GDelegate8 gDelegate = default(GDelegate8);
		GDelegate6 gDelegate2 = default(GDelegate6);
		DateTime value = default(DateTime);
		int num5 = default(int);
		GInterface16 gInterface = default(GInterface16);
		GDelegate6 gDelegate6 = default(GDelegate6);
		while (true)
		{
			int num2 = 2006522259;
			while (true)
			{
				uint num3;
				switch ((num3 = (uint)num2 ^ 0x53B161C8u) % 42)
				{
				case 41u:
				{
					gDelegate7 = gdelegate6_0;
					int num21;
					if (gDelegate7 != null)
					{
						num2 = 1305954724;
						num21 = 1305954724;
					}
					else
					{
						num2 = 1265050741;
						num21 = 1265050741;
					}
					continue;
				}
				case 40u:
					gDelegate7(Class13.string_4, Color.LightGreen, autoCrLf: false);
					num2 = ((int)num3 * -1878249054) ^ 0x2415642D;
					continue;
				case 39u:
				{
					int num12;
					int num13;
					if (flag)
					{
						num12 = -192587884;
						num13 = -192587884;
					}
					else
					{
						num12 = -881864701;
						num13 = -881864701;
					}
					num2 = num12 ^ ((int)num3 * -191897872);
					continue;
				}
				case 38u:
					Application.DoEvents();
					num6 = checked(num6 - 1);
					num2 = 900167724;
					continue;
				case 37u:
				{
					int num22;
					int num23;
					if (Operators.CompareString(Class13.smethod_1((byte[])gInterface2.imethod_0(GEnum9.JswAttr_MACAddress)), Class13.smethod_1((byte[])gclass9_0.ginterface5_0.imethod_0(GEnum9.JswAttr_MACAddress)), TextCompare: false) == 0)
					{
						num22 = -474174713;
						num23 = -474174713;
					}
					else
					{
						num22 = -1683553909;
						num23 = -1683553909;
					}
					num2 = num22 ^ (int)(num3 * 1357855469);
					continue;
				}
				case 36u:
				{
					int num25;
					if (!(num > 0 && !flag))
					{
						num2 = 1808662987;
						num25 = 1808662987;
					}
					else
					{
						num2 = 2114723301;
						num25 = 2114723301;
					}
					continue;
				}
				case 35u:
					dateTime = Delegate64.delegate64_0();
					timeSpan = dateTime.Subtract(Delegate64.delegate64_0());
					gDelegate5 = gdelegate6_0;
					num2 = (int)((num3 * 1680108836) ^ 0x465478B4);
					continue;
				case 34u:
				{
					int num17;
					int num18;
					if (gDelegate3 == null)
					{
						num17 = -1203320046;
						num18 = -1203320046;
					}
					else
					{
						num17 = -339020474;
						num18 = -339020474;
					}
					num2 = num17 ^ ((int)num3 * -1558211679);
					continue;
				}
				case 33u:
					gInterface2 = (GInterface15)ginterface5_;
					flag = true;
					num2 = (int)((num3 * 955462404) ^ 0x58BD75C8);
					continue;
				case 32u:
					num2 = ((int)num3 * -2128485150) ^ 0x46E903FB;
					continue;
				case 31u:
					gDelegate4(global::_003CModule_003E.smethod_18<string>(4005967518u, 2977995771u), Color.Yellow, autoCrLf: false);
					num2 = (int)(num3 * 2067694019) ^ -610765287;
					continue;
				case 30u:
				{
					gDelegate = gdelegate8_0;
					int num11;
					if (gDelegate != null)
					{
						num2 = 1445726302;
						num11 = 1445726302;
					}
					else
					{
						num2 = 1835092583;
						num11 = 1835092583;
					}
					continue;
				}
				case 29u:
					flag = false;
					num2 = (int)((num3 * 1125281944) ^ 0x7FC676C9);
					continue;
				case 27u:
					gDelegate2(Class10.String_47, Color.Yellow, autoCrLf: false);
					num2 = ((int)num3 * -1710323434) ^ -1199130570;
					continue;
				case 26u:
					dateTime = DateAndTime.Now;
					num2 = ((int)num3 * -1540379187) ^ -1377256673;
					continue;
				case 25u:
					timeSpan = dateTime.Subtract(value);
					num2 = (int)((num3 * 845386179) ^ 0xD55F5A2);
					continue;
				case 24u:
					timeSpan = dateTime.Subtract(value);
					num2 = ((int)num3 * -1071267510) ^ 0xAB9EA07;
					continue;
				case 23u:
					num5 = checked(gInterface.imethod_1() - 1);
					num6 = 0;
					num2 = 653872999;
					continue;
				case 22u:
					num = checked(num - 1);
					num2 = ((int)num3 * -1756284935) ^ -173549747;
					continue;
				case 21u:
					ginterface0_0.imethod_0();
					num2 = (int)((num3 * 1804099941) ^ 0x6443BB51);
					continue;
				case 20u:
					gInterface2 = gInterface.imethod_0();
					num2 = 1606209075;
					continue;
				case 19u:
					gDelegate4 = gdelegate6_0;
					num2 = 1153426115;
					continue;
				case 18u:
					gDelegate3(global::_003CModule_003E.smethod_19<string>(2282670531u, 2387105383u) + Class10.String_41, Color.Red, autoCrLf: true);
					num2 = (int)(num3 * 1354151234) ^ -212073340;
					continue;
				case 17u:
				{
					int num24;
					if (!(timeSpan.TotalMilliseconds >= 1600.0))
					{
						num2 = 420106536;
						num24 = 420106536;
					}
					else
					{
						num2 = 1867363203;
						num24 = 1867363203;
					}
					continue;
				}
				case 16u:
				{
					gDelegate6 = gdelegate6_0;
					int num19;
					int num20;
					if (gDelegate6 != null)
					{
						num19 = 140010975;
						num20 = 140010975;
					}
					else
					{
						num19 = 1137881443;
						num20 = 1137881443;
					}
					num2 = num19 ^ (int)(num3 * 321735499);
					continue;
				}
				case 15u:
					value = Delegate64.delegate64_0();
					num2 = ((int)num3 * -809224302) ^ -541068313;
					continue;
				case 14u:
					gDelegate5(string.Format(global::_003CModule_003E.smethod_19<string>(3564773386u, 2636254640u), gclass9_0.BSSID), Color.White, autoCrLf: true);
					num2 = ((int)num3 * -2077241367) ^ -575121931;
					continue;
				case 13u:
					gDelegate6("", Color.LightGreen, autoCrLf: true);
					num2 = ((int)num3 * -461908610) ^ -561830084;
					continue;
				case 12u:
				{
					int num15;
					int num16;
					if (gDelegate5 != null)
					{
						num15 = -1579290522;
						num16 = -1579290522;
					}
					else
					{
						num15 = -1471217077;
						num16 = -1471217077;
					}
					num2 = num15 ^ ((int)num3 * -441374213);
					continue;
				}
				case 11u:
				{
					int num14;
					if (num6 <= num5)
					{
						num2 = 1524947030;
						num14 = 1524947030;
					}
					else
					{
						num2 = 58346736;
						num14 = 58346736;
					}
					continue;
				}
				case 10u:
					gInterface = ginterface0_0.imethod_1(bool_1);
					num2 = 310374259;
					continue;
				case 9u:
				{
					gInterface = ginterface0_0.imethod_1(bool_1);
					int num9;
					int num10;
					if (gInterface.imethod_1() > 0)
					{
						num9 = -503430479;
						num10 = -503430479;
					}
					else
					{
						num9 = -1795035276;
						num10 = -1795035276;
					}
					num2 = num9 ^ ((int)num3 * -679615085);
					continue;
				}
				case 8u:
					dateTime = DateAndTime.Now;
					num2 = (int)((num3 * 1522363954) ^ 0x6A548DC2);
					continue;
				case 6u:
					num6 = 500000;
					value = DateAndTime.Now;
					num2 = ((int)num3 * -603233659) ^ -1025122428;
					continue;
				case 5u:
				{
					int num7;
					int num8;
					if (gDelegate4 == null)
					{
						num7 = -1721340696;
						num8 = -1721340696;
					}
					else
					{
						num7 = -165920685;
						num8 = -165920685;
					}
					num2 = num7 ^ ((int)num3 * -150889296);
					continue;
				}
				case 4u:
					num6 = checked(num6 + 1);
					num2 = 653872999;
					continue;
				case 3u:
					gDelegate3 = gdelegate6_0;
					num2 = 346882062;
					continue;
				case 2u:
				{
					GClass9 gClass = gclass9_0;
					ginterface5_ = gInterface2;
					gClass.method_2(ref ginterface5_, GEnum16.JswMsgType_Beacon);
					num2 = ((int)num3 * -1857709291) ^ 0x87C4D1F;
					continue;
				}
				case 1u:
				{
					gDelegate2 = gdelegate6_0;
					int num4;
					if (gDelegate2 == null)
					{
						num2 = 58346736;
						num4 = 58346736;
					}
					else
					{
						num2 = 1622967617;
						num4 = 1622967617;
					}
					continue;
				}
				case 0u:
					gDelegate(GEnum1.ApNotFound);
					num2 = (int)(num3 * 2131427957) ^ -766040087;
					continue;
				case 28u:
					break;
				default:
					return flag;
				}
				break;
			}
		}
	}

	public string method_12(ref GClass9 gclass9_1, ref GClass15<GClass9> gclass15_0, ref Control control_0)
	{
		bool flag = false;
		string text = "";
		DateTime value = Delegate64.delegate64_0();
		TimeSpan timeSpan = default(TimeSpan);
		GDelegate6 gDelegate2 = default(GDelegate6);
		WaitSplashProcess waitSplashProcess = default(WaitSplashProcess);
		DateTime dateTime = default(DateTime);
		int num5 = default(int);
		GInterface5 ginterface5_ = default(GInterface5);
		GClass9 item = default(GClass9);
		GDelegate6 gDelegate = default(GDelegate6);
		GDelegate8 gDelegate5 = default(GDelegate8);
		GDelegate6 gDelegate4 = default(GDelegate6);
		GDelegate6 gDelegate3 = default(GDelegate6);
		while (true)
		{
			int num = -1927317807;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xCB9ACA26u) % 25)
				{
				case 6u:
					break;
				case 24u:
				{
					int num18;
					if (!(timeSpan.TotalMilliseconds < 1600.0))
					{
						num = -1888033124;
						num18 = -1888033124;
					}
					else
					{
						num = -487939059;
						num18 = -487939059;
					}
					continue;
				}
				case 23u:
				{
					int num19;
					int num20;
					if (gclass9_1 != null)
					{
						num19 = 1904857394;
						num20 = 1904857394;
					}
					else
					{
						num19 = 1843532991;
						num20 = 1843532991;
					}
					num = num19 ^ ((int)num2 * -1074505003);
					continue;
				}
				case 22u:
				{
					GInterface16 gInterface = ginterface0_0.imethod_1(bool_1);
					ginterface0_0.imethod_0();
					num = -1410184418;
					continue;
				}
				case 21u:
					if (gDelegate2 != null)
					{
						num = (int)((num2 * 1153052001) ^ 0x1D272287);
						continue;
					}
					goto case 13u;
				case 20u:
					waitSplashProcess = new WaitSplashProcess(control_0, Class10.String_77);
					num = (int)((num2 * 737443284) ^ 0x7CC759AD);
					continue;
				case 19u:
					flag = true;
					num = -442024466;
					continue;
				case 18u:
					waitSplashProcess.Refresh();
					num = -1556054886;
					continue;
				case 17u:
					num = (int)(num2 * 776563055) ^ -356291990;
					continue;
				case 16u:
					Application.DoEvents();
					num = -279824728;
					continue;
				case 15u:
					timeSpan = dateTime.Subtract(value);
					num = ((int)num2 * -875767788) ^ 0xD94104;
					continue;
				default:
					try
					{
						GInterface16 gInterface = ginterface0_0.imethod_1(bool_1);
						int num21 = checked(gInterface.imethod_1() - 1);
						num5 = 0;
						while (true)
						{
							if (num5 <= num21)
							{
								while (true)
								{
									GInterface15 gInterface2 = gInterface.imethod_0();
									int num22 = -775881977;
									while (true)
									{
										switch ((num2 = (uint)num22 ^ 0xCB9ACA26u) % 6)
										{
										case 5u:
											num22 = -570386748;
											continue;
										case 3u:
											break;
										case 2u:
											goto IL_01f3;
										case 1u:
										{
											GClass9 obj = gclass9_1;
											ginterface5_ = gInterface2;
											obj.method_2(ref ginterface5_, GEnum16.JswMsgType_Beacon);
											num22 = ((int)num2 * -1469642842) ^ -2134580480;
											continue;
										}
										case 4u:
											goto end_IL_025b;
										default:
											goto IL_0294;
										}
										if (gclass9_1 != null)
										{
											num22 = ((int)num2 * -1202555584) ^ -1309525366;
											continue;
										}
										ginterface5_ = gInterface2;
										while (true)
										{
											int num23 = -981132652;
											while (true)
											{
												switch ((num2 = (uint)num23 ^ 0xCB9ACA26u) % 6)
												{
												case 4u:
													gInterface2 = (GInterface15)ginterface5_;
													num23 = ((int)num2 * -1406622644) ^ -1564476347;
													continue;
												case 3u:
													gclass15_0.Add(item);
													num23 = -2051338099;
													continue;
												case 2u:
												{
													GClass9 gClass2 = new GClass9(ref ginterface5_);
													gInterface2 = (GInterface15)ginterface5_;
													item = gClass2;
													int num24;
													int num25;
													if (!gclass15_0.Contains(item))
													{
														num24 = 452657375;
														num25 = 452657375;
													}
													else
													{
														num24 = 1927058195;
														num25 = 1927058195;
													}
													num23 = num24 ^ (int)(num2 * 59857411);
													continue;
												}
												case 1u:
												{
													int index = gclass15_0.IndexOf(item);
													GClass9 gClass = gclass15_0[index];
													ginterface5_ = gInterface2;
													gClass.method_2(ref ginterface5_, GEnum16.JswMsgType_Beacon);
													num23 = ((int)num2 * -1137060525) ^ 0x77B73D39;
													continue;
												}
												case 0u:
													break;
												default:
													goto end_IL_0428;
												}
												break;
											}
											continue;
											end_IL_0428:
											break;
										}
										try
										{
											if (Operators.ConditionalCompareObjectEqual(((GInterface15)gInterface2.imethod_0(GEnum9.JswAttr_SimpleConfigIEs)).imethod_0(GEnum9.JswAttr_DevicePasswordID), GEnum12.JswDevicePasswordID_PushButton, TextCompare: false))
											{
												while (true)
												{
													IL_049e:
													int num26 = -117806301;
													while (true)
													{
														switch ((num2 = (uint)num26 ^ 0xCB9ACA26u) % 3)
														{
														case 1u:
															goto IL_045b;
														default:
															goto end_IL_0480;
														case 2u:
															break;
														case 0u:
															goto end_IL_0480;
														}
														goto IL_049e;
														IL_045b:
														text = Class13.smethod_1((byte[])gInterface2.imethod_0(GEnum9.JswAttr_MACAddress));
														num26 = ((int)num2 * -207670911) ^ -1710904382;
														continue;
														end_IL_0480:
														break;
													}
													break;
												}
											}
										}
										catch (Exception projectError)
										{
											ProjectData.SetProjectError(projectError);
											while (true)
											{
												IL_04e3:
												int num27 = -8913835;
												while (true)
												{
													switch ((num2 = (uint)num27 ^ 0xCB9ACA26u) % 3)
													{
													default:
														goto end_IL_04b0;
													case 2u:
														goto IL_04ce;
													case 0u:
														break;
													case 1u:
														goto end_IL_04b0;
													}
													goto IL_04e3;
													IL_04ce:
													ProjectData.ClearProjectError();
													num27 = (int)((num2 * 1251118301) ^ 0x76987CB7);
													continue;
													end_IL_04b0:
													break;
												}
												break;
											}
										}
										goto IL_0516;
										IL_0294:
										gInterface2 = (GInterface15)ginterface5_;
										try
										{
											if (Operators.ConditionalCompareObjectEqual(((GInterface15)gInterface2.imethod_0(GEnum9.JswAttr_SimpleConfigIEs)).imethod_0(GEnum9.JswAttr_DevicePasswordID), GEnum12.JswDevicePasswordID_PushButton, TextCompare: false))
											{
												while (true)
												{
													IL_030b:
													int num28 = -706271732;
													while (true)
													{
														switch ((num2 = (uint)num28 ^ 0xCB9ACA26u) % 3)
														{
														case 1u:
															goto IL_02c8;
														default:
															goto end_IL_02ed;
														case 2u:
															break;
														case 0u:
															goto end_IL_02ed;
														}
														goto IL_030b;
														IL_02c8:
														text = Class13.smethod_1((byte[])gInterface2.imethod_0(GEnum9.JswAttr_MACAddress));
														num28 = ((int)num2 * -1449843792) ^ -1900928139;
														continue;
														end_IL_02ed:
														break;
													}
													break;
												}
											}
										}
										catch (Exception projectError2)
										{
											ProjectData.SetProjectError(projectError2);
											while (true)
											{
												IL_0353:
												int num29 = -724581510;
												while (true)
												{
													switch ((num2 = (uint)num29 ^ 0xCB9ACA26u) % 3)
													{
													default:
														goto end_IL_0320;
													case 1u:
														goto IL_033e;
													case 2u:
														break;
													case 0u:
														goto end_IL_0320;
													}
													goto IL_0353;
													IL_033e:
													ProjectData.ClearProjectError();
													num29 = ((int)num2 * -1912011339) ^ -1117556877;
													continue;
													end_IL_0320:
													break;
												}
												break;
											}
										}
										goto IL_0516;
										IL_01f3:
										if (Operators.CompareString(Class13.smethod_1((byte[])gInterface2.imethod_0(GEnum9.JswAttr_MACAddress)), Class13.smethod_1((byte[])gclass9_1.ginterface5_0.imethod_0(GEnum9.JswAttr_MACAddress)), TextCompare: false) == 0)
										{
											num22 = (int)(num2 * 607280151) ^ -1102741277;
											continue;
										}
										goto IL_0516;
										IL_0516:
										num5 = checked(num5 + 1);
										goto end_IL_0285;
										continue;
										end_IL_025b:
										break;
									}
									continue;
									end_IL_0285:
									break;
								}
								goto IL_04ec;
							}
							int num30 = -1243031696;
							goto IL_04f1;
							IL_04ec:
							num30 = -669865605;
							goto IL_04f1;
							IL_04f1:
							switch ((num2 = (uint)num30 ^ 0xCB9ACA26u) % 3)
							{
							case 2u:
								break;
							case 0u:
								goto IL_04ec;
							default:
								goto end_IL_01c7;
							case 1u:
								goto end_IL_01c7;
							}
							continue;
							end_IL_01c7:
							break;
						}
					}
					catch (Exception projectError3)
					{
						ProjectData.SetProjectError(projectError3);
						while (true)
						{
							IL_055f:
							int num31 = -1095521571;
							while (true)
							{
								switch ((num2 = (uint)num31 ^ 0xCB9ACA26u) % 3)
								{
								default:
									goto end_IL_052c;
								case 1u:
									goto IL_054a;
								case 2u:
									break;
								case 0u:
									goto end_IL_052c;
								}
								goto IL_055f;
								IL_054a:
								ProjectData.ClearProjectError();
								num31 = ((int)num2 * -372737794) ^ 0x4A708011;
								continue;
								end_IL_052c:
								break;
							}
							break;
						}
					}
					goto case 13u;
				case 12u:
					value = DateAndTime.Now;
					dateTime = DateAndTime.Now;
					num = (int)((num2 * 546890717) ^ 0x6EE1F63B);
					continue;
				case 11u:
					gDelegate = gdelegate6_0;
					if (gDelegate != null)
					{
						num = -1312420308;
						continue;
					}
					goto case 13u;
				case 10u:
					num5 = 500000;
					num = (int)(num2 * 709660887) ^ -816347930;
					continue;
				case 9u:
				{
					int num6;
					int num7;
					if (!waitSplashProcess.IsDisposed)
					{
						num6 = -1141437927;
						num7 = -1141437927;
					}
					else
					{
						num6 = -1109220155;
						num7 = -1109220155;
					}
					num = num6 ^ ((int)num2 * -1573417089);
					continue;
				}
				case 8u:
					dateTime = Delegate64.delegate64_0();
					num = ((int)num2 * -530205417) ^ 0x515C20D2;
					continue;
				case 7u:
					waitSplashProcess.Show();
					num = (int)(num2 * 560954945) ^ -347661887;
					continue;
				case 5u:
					num5 = checked(num5 - 1);
					dateTime = DateAndTime.Now;
					timeSpan = dateTime.Subtract(value);
					num = ((int)num2 * -1207032277) ^ 0x6D9438FA;
					continue;
				case 4u:
					timeSpan = dateTime.Subtract(Delegate64.delegate64_0());
					num = (int)((num2 * 1773470722) ^ 0x63668944);
					continue;
				case 3u:
				{
					int num3;
					int num4;
					if (!waitSplashProcess.Visible)
					{
						num3 = -1109118469;
						num4 = -1109118469;
					}
					else
					{
						num3 = -1296493220;
						num4 = -1296493220;
					}
					num = num3 ^ (int)(num2 * 340115520);
					continue;
				}
				case 2u:
					gDelegate2 = gdelegate6_0;
					num = ((int)num2 * -1056033514) ^ 0x34DC370F;
					continue;
				case 1u:
					gDelegate2(string.Format(global::_003CModule_003E.smethod_20<string>(3927962855u, 1296950261u), gclass9_1.BSSID), Color.White, autoCrLf: true);
					goto case 13u;
				case 0u:
					gDelegate(global::_003CModule_003E.smethod_18<string>(3644061517u, 2149799305u), Color.White, autoCrLf: true);
					num = ((int)num2 * -1776229707) ^ 0x13D236E;
					continue;
				case 13u:
					if (!(Operators.CompareString(text, "", TextCompare: false) == 0 && !flag))
					{
						while (true)
						{
							int num8 = -17438631;
							while (true)
							{
								switch ((num2 = (uint)num8 ^ 0xCB9ACA26u) % 14)
								{
								case 13u:
								{
									int num16;
									int num17;
									if (waitSplashProcess.IsDisposed)
									{
										num16 = -1198744332;
										num17 = -1198744332;
									}
									else
									{
										num16 = -1820893635;
										num17 = -1820893635;
									}
									num8 = num16 ^ ((int)num2 * -628008009);
									continue;
								}
								case 12u:
									gDelegate5 = gdelegate8_0;
									num8 = -1126741175;
									continue;
								case 11u:
								{
									int num13;
									int num14;
									if (gDelegate5 == null)
									{
										num13 = -633373236;
										num14 = -633373236;
									}
									else
									{
										num13 = -860580870;
										num14 = -860580870;
									}
									num8 = num13 ^ (int)(num2 * 1633278175);
									continue;
								}
								case 10u:
									gDelegate4 = gdelegate6_0;
									num8 = (int)(num2 * 1890800261) ^ -1874098635;
									continue;
								case 8u:
									gDelegate3(Class13.string_4, Color.LightGreen, autoCrLf: false);
									num8 = ((int)num2 * -2004663875) ^ 0x58ECC5E1;
									continue;
								case 7u:
									gDelegate3 = gdelegate6_0;
									num8 = -485148382;
									continue;
								case 6u:
									gDelegate4("", Color.LightGreen, autoCrLf: true);
									num8 = (int)((num2 * 2135356453) ^ 0x16E602DF);
									continue;
								case 5u:
									gDelegate5(GEnum1.ApNotFound);
									num8 = ((int)num2 * -1506821771) ^ 0x11BD56AC;
									continue;
								case 4u:
									waitSplashProcess.Dispose();
									num8 = ((int)num2 * -524302613) ^ 0x153D8EFB;
									continue;
								case 3u:
								{
									int num15;
									if (Operators.CompareString(text, "", TextCompare: false) == 0)
									{
										num8 = -894926472;
										num15 = -894926472;
									}
									else
									{
										num8 = -429131432;
										num15 = -429131432;
									}
									continue;
								}
								case 1u:
								{
									int num11;
									int num12;
									if (gDelegate4 != null)
									{
										num11 = 886692030;
										num12 = 886692030;
									}
									else
									{
										num11 = 457055135;
										num12 = 457055135;
									}
									num8 = num11 ^ ((int)num2 * -1434095814);
									continue;
								}
								case 0u:
								{
									int num9;
									int num10;
									if (gDelegate3 == null)
									{
										num9 = 1869202189;
										num10 = 1869202189;
									}
									else
									{
										num9 = 1081889658;
										num10 = 1081889658;
									}
									num8 = num9 ^ (int)(num2 * 517514816);
									continue;
								}
								case 2u:
									break;
								default:
									return text;
								}
								break;
							}
						}
					}
					goto case 22u;
				}
				break;
			}
		}
	}

	private void method_13(GEnum14 genum14_0, int int_1, string string_1)
	{
		Delegate30.delegate30_18(Delegate3.delegate3_0(), Delegate15.delegate15_19(Delegate3.delegate3_7()));
		GDelegate8 gDelegate8 = default(GDelegate8);
		GDelegate6 gDelegate38 = default(GDelegate6);
		GDelegate6 gDelegate24 = default(GDelegate6);
		GDelegate6 gDelegate36 = default(GDelegate6);
		GDelegate6 gDelegate34 = default(GDelegate6);
		int num3 = default(int);
		GDelegate6 gDelegate23 = default(GDelegate6);
		GDelegate6 gDelegate10 = default(GDelegate6);
		int num82 = default(int);
		GDelegate6 gDelegate14 = default(GDelegate6);
		GDelegate8 gDelegate22 = default(GDelegate8);
		GDelegate6 gDelegate3 = default(GDelegate6);
		GDelegate6 gDelegate25 = default(GDelegate6);
		GDelegate8 gDelegate4 = default(GDelegate8);
		GDelegate6 gDelegate33 = default(GDelegate6);
		GDelegate6 gDelegate32 = default(GDelegate6);
		GDelegate6 gDelegate11 = default(GDelegate6);
		GEnum16 gEnum = default(GEnum16);
		GDelegate6 gDelegate7 = default(GDelegate6);
		GDelegate6 gDelegate17 = default(GDelegate6);
		GDelegate8 gDelegate37 = default(GDelegate8);
		GDelegate7 gDelegate29 = default(GDelegate7);
		GDelegate6 gDelegate13 = default(GDelegate6);
		GDelegate8 gDelegate9 = default(GDelegate8);
		GDelegate6 gDelegate31 = default(GDelegate6);
		GInterface5 object_2 = default(GInterface5);
		GDelegate8 gDelegate5 = default(GDelegate8);
		GDelegate6 gDelegate12 = default(GDelegate6);
		GDelegate8 gDelegate26 = default(GDelegate8);
		GDelegate6 gDelegate21 = default(GDelegate6);
		GDelegate6 gDelegate18 = default(GDelegate6);
		GDelegate6 gDelegate16 = default(GDelegate6);
		GDelegate6 gDelegate6 = default(GDelegate6);
		GDelegate6 gDelegate19 = default(GDelegate6);
		GDelegate6 gDelegate20 = default(GDelegate6);
		GDelegate6 gDelegate27 = default(GDelegate6);
		GDelegate6 gDelegate28 = default(GDelegate6);
		GDelegate6 gDelegate = default(GDelegate6);
		GDelegate6 gDelegate30 = default(GDelegate6);
		GDelegate6 gDelegate15 = default(GDelegate6);
		GDelegate6 gDelegate2 = default(GDelegate6);
		while (true)
		{
			int num = 1991932991;
			while (true)
			{
				uint num2;
				int num30;
				int num78;
				int num81;
				GInterface5[] ginterface5_2;
				int num85;
				GInterface7 object_6;
				string text3;
				object[] obj6;
				object[] array;
				bool[] obj7;
				bool[] array2;
				object obj8;
				int num88;
				int num91;
				int num96;
				int num97;
				int num98;
				int num100;
				int num101;
				switch ((num2 = (uint)num ^ 0x2A5679B3u) % 172)
				{
				case 171u:
					gDelegate8(GEnum1.Locked);
					num = ((int)num2 * -853287920) ^ -58794775;
					continue;
				case 170u:
					gDelegate38(Delegate36.delegate36_41(), Delegate28.delegate28_9(), autoCrLf: true);
					num = (int)(num2 * 1626924474) ^ -420249948;
					continue;
				case 169u:
					gDelegate24(Delegate57.delegate57_1(Delegate36.delegate36_47(), Delegate143.delegate143_0((GEnum16)int_1)), Delegate28.delegate28_24(), autoCrLf: true);
					num = (int)((num2 * 1878023893) ^ 0x7F4A705A);
					continue;
				case 168u:
					gDelegate36(Delegate36.delegate36_31(), Delegate28.delegate28_22(), autoCrLf: true);
					num = ((int)num2 * -1424132660) ^ -1396626077;
					continue;
				case 166u:
					gDelegate34(Delegate36.delegate36_30(), Delegate28.delegate28_22(), autoCrLf: true);
					num = ((int)num2 * -332793109) ^ -187214593;
					continue;
				case 164u:
				{
					int num89;
					int num90;
					if (num3 == 15)
					{
						num89 = 2005866362;
						num90 = 2005866362;
					}
					else
					{
						num89 = 1334546160;
						num90 = 1334546160;
					}
					num = num89 ^ (int)(num2 * 912750653);
					continue;
				}
				case 163u:
					genum2_0 = GEnum2.Nok;
					Delegate5.delegate5_41(this, bool_0: true);
					num = 823067166;
					continue;
				case 162u:
				{
					gDelegate23 = gdelegate6_0;
					int num37;
					if (gDelegate23 != null)
					{
						num = 677662633;
						num37 = 677662633;
					}
					else
					{
						num = 37469980;
						num37 = 37469980;
					}
					continue;
				}
				case 161u:
				{
					GInterface5 object_ = (GInterface5)Delegate146.delegate146_0(gclass9_0.ginterface5_1[11], GEnum9.JswAttr_EncryptedSettings);
					Delegate30.delegate30_19(gclass9_0, Delegate15.delegate15_2(Delegate146.delegate146_0(object_, GEnum9.JswAttr_NetworkKey)));
					num = ((int)num2 * -888370149) ^ -1128720226;
					continue;
				}
				case 160u:
					gDelegate10(Delegate36.delegate36_38(), Delegate28.delegate28_23(), autoCrLf: true);
					num = (int)(num2 * 1573240765) ^ -1965598068;
					continue;
				case 159u:
					goto IL_0219;
				case 158u:
					genum2_0 = GEnum2.Nok;
					num = 61730565;
					continue;
				case 157u:
				{
					int num86;
					int num87;
					if (num82 == 4)
					{
						num86 = 1557720537;
						num87 = 1557720537;
					}
					else
					{
						num86 = 302751135;
						num87 = 302751135;
					}
					num = num86 ^ (int)(num2 * 1879503381);
					continue;
				}
				case 156u:
					gDelegate14(Delegate137.delegate137_0(Delegate36.delegate36_49(), Delegate77.delegate77_0(Delegate15.delegate15_25(gclass12_0), 0, 4), Delegate77.delegate77_0(Delegate15.delegate15_25(gclass12_0), 4, 4)), Delegate28.delegate28_23(), autoCrLf: true);
					num = ((int)num2 * -1962344192) ^ -1019189820;
					continue;
				case 155u:
				{
					int num66;
					if (Delegate125.delegate125_0(gclass9_0) == GClass9.GEnum3.Unknow)
					{
						num = 196842089;
						num66 = 196842089;
					}
					else
					{
						num = 840244006;
						num66 = 840244006;
					}
					continue;
				}
				case 154u:
					goto IL_0317;
				case 153u:
					num = ((int)num2 * -890513189) ^ -309429277;
					continue;
				case 152u:
					gDelegate22(genum1_0);
					num = ((int)num2 * -1736788216) ^ 0x1A83345A;
					continue;
				case 151u:
					gDelegate3(Delegate137.delegate137_0(global::_003CModule_003E.smethod_18<string>(4160623485u, 817865908u), Delegate15.delegate15_10(gclass9_0), Delegate15.delegate15_9(gclass9_0)), Delegate28.delegate28_1(), autoCrLf: true);
					num = ((int)num2 * -1691436986) ^ 0xD1A6564;
					continue;
				case 150u:
					gDelegate25(Delegate141.delegate141_0(global::_003CModule_003E.smethod_21<string>(632037773u, 4291120027u), Delegate15.delegate15_25(gclass12_0), Delegate15.delegate15_10(gclass9_0), Delegate15.delegate15_9(gclass9_0)), Delegate28.delegate28_1(), autoCrLf: true);
					num = (int)((num2 * 1548800458) ^ 0x572E7FEA);
					continue;
				case 149u:
				{
					int num14;
					if (!(bool_0 & (genum1_0 == GEnum1.Testing)))
					{
						num = 37469980;
						num14 = 37469980;
					}
					else
					{
						num = 260852509;
						num14 = 260852509;
					}
					continue;
				}
				case 148u:
				{
					int num5;
					int num6;
					if (gDelegate4 == null)
					{
						num5 = -186595004;
						num6 = -186595004;
					}
					else
					{
						num5 = -1096478010;
						num6 = -1096478010;
					}
					num = num5 ^ (int)(num2 * 462941717);
					continue;
				}
				case 147u:
					num = ((int)num2 * -2096994419) ^ -1971966317;
					continue;
				case 146u:
				{
					int num94;
					int num95;
					if (gDelegate10 == null)
					{
						num94 = 1526269650;
						num95 = 1526269650;
					}
					else
					{
						num94 = 1601014889;
						num95 = 1601014889;
					}
					num = num94 ^ (int)(num2 * 1625158919);
					continue;
				}
				case 145u:
					gDelegate33(Delegate36.delegate36_35(), Delegate28.delegate28_1(), autoCrLf: true);
					num = ((int)num2 * -641290089) ^ -791534829;
					continue;
				case 144u:
				{
					int num76;
					int num77;
					if (gDelegate32 != null)
					{
						num76 = 1981738317;
						num77 = 1981738317;
					}
					else
					{
						num76 = 1815895351;
						num77 = 1815895351;
					}
					num = num76 ^ (int)(num2 * 1016425235);
					continue;
				}
				case 143u:
					gDelegate11(Delegate57.delegate57_1(Delegate36.delegate36_52(), Delegate15.delegate15_26(gclass9_0)), Delegate28.delegate28_25(), autoCrLf: true);
					num = (int)((num2 * 2068654752) ^ 0x1F49C221);
					continue;
				case 142u:
				{
					int num72;
					if (gEnum != GEnum16.JswMsgType_M7)
					{
						num = 1579800539;
						num72 = 1579800539;
					}
					else
					{
						num = 663674523;
						num72 = 663674523;
					}
					continue;
				}
				case 141u:
				{
					int num65;
					if (genum1_0 == GEnum1.Testing)
					{
						num = 823308311;
						num65 = 823308311;
					}
					else
					{
						num = 1330277520;
						num65 = 1330277520;
					}
					continue;
				}
				case 140u:
					num = (int)(num2 * 2112934301) ^ -1767347188;
					continue;
				case 139u:
					num = ((int)num2 * -627742119) ^ -721616693;
					continue;
				case 138u:
					num = (int)(num2 * 2142910776) ^ -988725044;
					continue;
				case 137u:
				{
					int num51;
					if (!(int_1 >= 4 && int_1 <= 12))
					{
						num = 1012389191;
						num51 = 1012389191;
					}
					else
					{
						num = 824452595;
						num51 = 824452595;
					}
					continue;
				}
				case 136u:
					num = ((int)num2 * -1177987528) ^ 0x5AB66DC;
					continue;
				case 135u:
					Delegate22.delegate22_32(ginterface0_0);
					num = 37469980;
					continue;
				case 134u:
				{
					int num38;
					int num39;
					if (Delegate125.delegate125_0(gclass9_0) != 0)
					{
						num38 = 461144096;
						num39 = 461144096;
					}
					else
					{
						num38 = 673253118;
						num39 = 673253118;
					}
					num = num38 ^ ((int)num2 * -1039839583);
					continue;
				}
				case 133u:
					goto IL_066e;
				case 132u:
					genum2_0 = GEnum2.Fault;
					num = ((int)num2 * -691256068) ^ -1922726228;
					continue;
				case 131u:
					Delegate145.delegate145_0(gclass9_0, ref gclass9_0.ginterface5_1[int_1], GEnum16.JswMsgType_M1);
					gDelegate4 = gdelegate8_0;
					num = 828796471;
					continue;
				case 130u:
					gDelegate14 = gdelegate6_0;
					num = ((int)num2 * -1792967042) ^ -249548307;
					continue;
				case 129u:
					gDelegate8 = gdelegate8_0;
					num = 77780099;
					continue;
				case 128u:
				{
					int num9;
					int num10;
					if (gDelegate7 != null)
					{
						num9 = -1123713331;
						num10 = -1123713331;
					}
					else
					{
						num9 = -581504312;
						num10 = -581504312;
					}
					num = num9 ^ (int)(num2 * 1732942155);
					continue;
				}
				case 127u:
				{
					int num102;
					int num103;
					if (gDelegate17 == null)
					{
						num102 = -216240503;
						num103 = -216240503;
					}
					else
					{
						num102 = -2082694286;
						num103 = -2082694286;
					}
					num = num102 ^ ((int)num2 * -835885587);
					continue;
				}
				case 126u:
				{
					gDelegate37 = gdelegate8_0;
					int num99;
					if (gDelegate37 != null)
					{
						num = 175064969;
						num99 = 175064969;
					}
					else
					{
						num = 37469980;
						num99 = 37469980;
					}
					continue;
				}
				case 125u:
					Delegate126.delegate126_0(gclass9_0, GClass9.GEnum3.Ok);
					num = ((int)num2 * -26529060) ^ -500197336;
					continue;
				case 124u:
					num82 = int_1;
					num = 1113548070;
					continue;
				case 123u:
				{
					int num92;
					int num93;
					if (gDelegate29 != null)
					{
						num92 = 1067541665;
						num93 = 1067541665;
					}
					else
					{
						num92 = 1065531390;
						num93 = 1065531390;
					}
					num = num92 ^ (int)(num2 * 1278293870);
					continue;
				}
				case 122u:
					gDelegate13(Class13.string_4, Delegate28.delegate28_9(), autoCrLf: false);
					num = (int)((num2 * 1850446462) ^ 0x58142F92);
					continue;
				case 121u:
				{
					int num83;
					int num84;
					if (num82 == 14)
					{
						num83 = -1698469065;
						num84 = -1698469065;
					}
					else
					{
						num83 = -2009259315;
						num84 = -2009259315;
					}
					num = num83 ^ (int)(num2 * 1619862589);
					continue;
				}
				case 120u:
					genum16_0 = (GEnum16)int_1;
					num = (int)((num2 * 932601134) ^ 0x7BD806C7);
					continue;
				case 119u:
					gDelegate9 = gdelegate8_0;
					num = ((int)num2 * -1370392696) ^ 0x720B0C82;
					continue;
				case 118u:
					Delegate126.delegate126_0(gclass9_0, GClass9.GEnum3.Ok);
					num = (int)(num2 * 42592828) ^ -1874856021;
					continue;
				case 117u:
					genum1_0 = GEnum1.PixieSucced;
					num = 1783597361;
					continue;
				case 116u:
					goto IL_08a2;
				case 115u:
					gDelegate31(Delegate57.delegate57_1(Delegate36.delegate36_46(), Delegate143.delegate143_0((GEnum16)int_1)), Delegate28.delegate28_24(), autoCrLf: true);
					num = (int)(num2 * 2101876203) ^ -1630967281;
					continue;
				case 114u:
					num = ((int)num2 * -794425909) ^ -1119018874;
					continue;
				case 113u:
					Delegate8.delegate8_116(gclass9_0, gclass12_0);
					object_2 = (GInterface5)Delegate58.smethod_0(Delegate146.delegate146_0(gclass9_0.ginterface5_1[12], GEnum9.JswAttr_EncryptedSettings), (Type)null, global::_003CModule_003E.smethod_20<string>(388276142u, 623873364u), new object[1] { GEnum9.JswAttr_Credential }, (string[])null, (Type[])null, (bool[])null);
					num = ((int)num2 * -1921840352) ^ -790325667;
					continue;
				case 112u:
				{
					int num68;
					int num69;
					if (genum1_0 != GEnum1.NACK)
					{
						num68 = -1901188848;
						num69 = -1901188848;
					}
					else
					{
						num68 = -676797589;
						num69 = -676797589;
					}
					num = num68 ^ (int)(num2 * 1948321917);
					continue;
				}
				case 111u:
					num = ((int)num2 * -451510114) ^ -717907214;
					continue;
				case 110u:
					gDelegate17(Delegate137.delegate137_0(Delegate36.delegate36_45(), Delegate15.delegate15_9(gclass9_0), Delegate15.delegate15_10(gclass9_0)), Delegate28.delegate28_22(), autoCrLf: true);
					num = (int)((num2 * 1379903438) ^ 0x55835C6A);
					continue;
				case 109u:
				{
					int num61;
					int num62;
					if (gDelegate5 == null)
					{
						num61 = 158641255;
						num62 = 158641255;
					}
					else
					{
						num61 = 595970842;
						num62 = 595970842;
					}
					num = num61 ^ ((int)num2 * -446152549);
					continue;
				}
				case 108u:
					goto IL_0a5c;
				case 107u:
				{
					int num59;
					if (gEnum != GEnum16.JswMsgType_M5)
					{
						num = 2011223109;
						num59 = 2011223109;
					}
					else
					{
						num = 1659547689;
						num59 = 1659547689;
					}
					continue;
				}
				case 106u:
					Delegate30.delegate30_19(gclass9_0, Delegate15.delegate15_2(Delegate146.delegate146_0(object_2, GEnum9.JswAttr_NetworkKey)));
					num = ((int)num2 * -2063026378) ^ 0x146FE7A;
					continue;
				case 105u:
				{
					int num54;
					int num55;
					if (!(bool_0 && int_1 == 8))
					{
						num54 = -17340822;
						num55 = -17340822;
					}
					else
					{
						num54 = -483113658;
						num55 = -483113658;
					}
					num = num54 ^ ((int)num2 * -1088886063);
					continue;
				}
				case 104u:
					gDelegate29((GEnum16)int_1);
					num = (int)((num2 * 1019629069) ^ 0x1EF8D4B1);
					continue;
				case 103u:
				{
					gDelegate12 = gdelegate6_0;
					int num48;
					if (gDelegate12 != null)
					{
						num = 1694511538;
						num48 = 1694511538;
					}
					else
					{
						num = 322320796;
						num48 = 322320796;
					}
					continue;
				}
				case 102u:
					gDelegate23(Delegate36.delegate36_34(), Delegate28.delegate28_22(), autoCrLf: true);
					num = (int)(num2 * 1740053647) ^ -659116134;
					continue;
				case 101u:
					num = (int)(num2 * 1553500333) ^ -450722547;
					continue;
				case 100u:
				{
					int num42;
					int num43;
					if (gDelegate25 == null)
					{
						num42 = 2013742050;
						num43 = 2013742050;
					}
					else
					{
						num42 = 2116061053;
						num43 = 2116061053;
					}
					num = num42 ^ ((int)num2 * -1498024423);
					continue;
				}
				case 99u:
					num = (int)(num2 * 1324078519) ^ -718658267;
					continue;
				case 98u:
					gDelegate26 = gdelegate8_0;
					num = ((int)num2 * -211126273) ^ -434749747;
					continue;
				case 97u:
				{
					int num33;
					int num34;
					if (num3 != 14)
					{
						num33 = 804196618;
						num34 = 804196618;
					}
					else
					{
						num33 = 295625331;
						num34 = 295625331;
					}
					num = num33 ^ ((int)num2 * -183266823);
					continue;
				}
				case 96u:
					gDelegate21(Delegate36.delegate36_29(), Delegate28.delegate28_9(), autoCrLf: true);
					num = (int)((num2 * 1988374064) ^ 0x22B9B21C);
					continue;
				case 95u:
					genum1_0 = GEnum1.Success;
					gDelegate22 = gdelegate8_0;
					num = (int)((num2 * 1056088147) ^ 0x7286ECA1);
					continue;
				case 94u:
				{
					int num26;
					int num27;
					if (gDelegate14 != null)
					{
						num26 = -547055133;
						num27 = -547055133;
					}
					else
					{
						num26 = -2064149492;
						num27 = -2064149492;
					}
					num = num26 ^ ((int)num2 * -117093996);
					continue;
				}
				case 93u:
					gDelegate18(Delegate36.delegate36_37(), Delegate28.delegate28_22(), autoCrLf: true);
					num = (int)(num2 * 1532754752) ^ -833741302;
					continue;
				case 92u:
					num = (int)(num2 * 562568993) ^ -1747954004;
					continue;
				case 91u:
					num = ((int)num2 * -1532656663) ^ -858681705;
					continue;
				case 90u:
					goto IL_0cd5;
				case 89u:
					gDelegate16 = gdelegate6_0;
					num = (int)((num2 * 816191913) ^ 0x59F35E39);
					continue;
				case 88u:
					goto IL_0d02;
				case 87u:
				{
					genum2_0 = GEnum2.Ok;
					gDelegate11 = gdelegate6_0;
					int num18;
					int num19;
					if (gDelegate11 == null)
					{
						num18 = -902667737;
						num19 = -902667737;
					}
					else
					{
						num18 = -514606294;
						num19 = -514606294;
					}
					num = num18 ^ (int)(num2 * 1009005642);
					continue;
				}
				case 86u:
					Delegate5.delegate5_41(this, bool_0: true);
					num = 37469980;
					continue;
				case 85u:
					gDelegate12(Delegate57.delegate57_1(Delegate36.delegate36_52(), Delegate15.delegate15_26(gclass9_0)), Delegate28.delegate28_25(), autoCrLf: true);
					num = (int)(num2 * 1394033622) ^ -1590080950;
					continue;
				case 84u:
				{
					int num15;
					if (Delegate125.delegate125_0(gclass9_0) != 0)
					{
						num = 413859604;
						num15 = 413859604;
					}
					else
					{
						num = 1693849640;
						num15 = 1693849640;
					}
					continue;
				}
				case 83u:
				{
					int num11;
					if (gEnum == GEnum16.JswMsgType_M3)
					{
						num = 1588620879;
						num11 = 1588620879;
					}
					else
					{
						num = 1309060904;
						num11 = 1309060904;
					}
					continue;
				}
				case 82u:
				{
					int num104;
					int num105;
					if (gDelegate33 == null)
					{
						num104 = 286222088;
						num105 = 286222088;
					}
					else
					{
						num104 = 1243432686;
						num105 = 1243432686;
					}
					num = num104 ^ (int)(num2 * 676931926);
					continue;
				}
				case 81u:
					goto IL_0e23;
				case 80u:
					switch (genum14_0)
					{
					case GEnum14.JswEngEvt_NoCandidateApsFound:
						break;
					case GEnum14.JswEngEvt_Initializing:
						goto IL_0219;
					case GEnum14.JswEngEvt_ProtocolFailed:
						goto IL_0317;
					case GEnum14.JswEngEvt_StartProtocol:
						goto IL_066e;
					case GEnum14.JswEngEvt_FailedDeviceInitialize:
						goto IL_08a2;
					case GEnum14.JswEngEvt_None:
						goto IL_0a5c;
					case GEnum14.JswEngEvt_ApInSetupLockedState:
						goto IL_0cd5;
					case GEnum14.JswEngEvt_PushButtonTimeout:
						goto IL_0d02;
					case GEnum14.JswEngEvt_ProtocolFailedResetPin:
						goto IL_0e23;
					default:
						goto IL_0e95;
					case GEnum14.JswEngEvt_FailedInitialize:
						goto IL_0ea8;
					case GEnum14.JswEngEvt_Starting:
						goto IL_0ed0;
					case GEnum14.JswEngEvt_ScanningForAps:
						goto IL_0efb;
					case GEnum14.JswEngEvt_SelectedAp:
						goto IL_0f23;
					case GEnum14.JswEngEvt_Associating:
						goto IL_0f4b;
					case GEnum14.JswEngEvt_AssociationFailed:
						goto IL_0f5c;
					case GEnum14.JswEngEvt_MultipleApsInPbMode:
						goto IL_0f82;
					case GEnum14.JswEngEvt_ReceivedCredentials:
						goto IL_0f94;
					case GEnum14.JswEngEvt_SupplicantReceivedMsg:
						goto IL_0fb9;
					case GEnum14.JswEngEvt_SupplicantSentMsg:
						goto IL_0fcb;
					case GEnum14.JswEngEvt_ProtocolSuccess:
					case GEnum14.JswEngEvt_ProtocolAttemptFailed:
						goto IL_1057;
					case GEnum14.JswEngEvt_ProtocolTimeout:
						goto IL_1080;
					}
					goto case 162u;
				case 21u:
					goto IL_0ea8;
				case 64u:
					goto IL_0ed0;
				case 74u:
					goto IL_0efb;
				case 9u:
					goto IL_0f23;
				case 5u:
					goto IL_0f4b;
				case 77u:
					goto IL_0f5c;
				case 23u:
					goto IL_0f82;
				case 7u:
					goto IL_0f94;
				case 51u:
					goto IL_0fb9;
				case 17u:
					goto IL_0fcb;
				case 67u:
					goto IL_1057;
				case 8u:
					goto IL_1080;
				case 79u:
				{
					int num79;
					int num80;
					if (gDelegate21 != null)
					{
						num79 = -1837726691;
						num80 = -1837726691;
					}
					else
					{
						num79 = -445809134;
						num80 = -445809134;
					}
					num = num79 ^ (int)(num2 * 1152339426);
					continue;
				}
				case 78u:
					gDelegate37(GEnum1.AssociationFailed);
					num = ((int)num2 * -597258751) ^ -1700069247;
					continue;
				case 76u:
					genum1_0 = GEnum1.NACK;
					gDelegate5 = gdelegate8_0;
					num = (int)((num2 * 732802622) ^ 0xCF34DE);
					continue;
				case 75u:
				{
					int num74;
					int num75;
					if (gDelegate22 == null)
					{
						num74 = -1957255487;
						num75 = -1957255487;
					}
					else
					{
						num74 = -1612517286;
						num75 = -1612517286;
					}
					num = num74 ^ (int)(num2 * 329211559);
					continue;
				}
				case 73u:
					gDelegate4(GEnum1.Updated);
					num = (int)(num2 * 1139633110) ^ -1019778810;
					continue;
				case 72u:
				{
					int num73;
					if (genum1_0 != GEnum1.Testing)
					{
						num = 323474147;
						num73 = 323474147;
					}
					else
					{
						num = 318441677;
						num73 = 318441677;
					}
					continue;
				}
				case 71u:
					gDelegate29 = gdelegate7_0;
					num = 415090852;
					continue;
				case 70u:
					gDelegate6(Delegate50.delegate50_0(Delegate36.delegate36_48(), Delegate15.delegate15_25(gclass12_0)), Delegate28.delegate28_22(), autoCrLf: true);
					num = ((int)num2 * -190855061) ^ -2054663776;
					continue;
				case 69u:
					gDelegate32 = gdelegate6_0;
					num = 261830603;
					continue;
				case 68u:
					gDelegate19(Delegate36.delegate36_42(), Delegate28.delegate28_9(), autoCrLf: true);
					num = ((int)num2 * -27672830) ^ -522126017;
					continue;
				case 66u:
					Delegate5.delegate5_41(this, bool_0: true);
					num = 124773539;
					continue;
				case 65u:
					bool_3 = true;
					num = 2114765112;
					continue;
				case 63u:
					Delegate126.delegate126_0(gclass9_0, GClass9.GEnum3.Nok);
					num = ((int)num2 * -201692520) ^ -1834427108;
					continue;
				case 62u:
					Delegate126.delegate126_0(gclass9_0, GClass9.GEnum3.Nok);
					num = ((int)num2 * -2038875500) ^ -1031704919;
					continue;
				case 61u:
					num = ((int)num2 * -746970681) ^ 0x49229E93;
					continue;
				case 60u:
					gDelegate20(Delegate141.delegate141_0(Delegate36.delegate36_44(), Delegate15.delegate15_10(gclass9_0), Delegate15.delegate15_9(gclass9_0), Delegate64.delegate64_0()), Delegate28.delegate28_20(), autoCrLf: true);
					num = ((int)num2 * -339102302) ^ 0x51CC1C57;
					continue;
				case 59u:
				{
					gDelegate27 = gdelegate6_0;
					int num70;
					int num71;
					if (gDelegate27 != null)
					{
						num70 = -824595642;
						num71 = -824595642;
					}
					else
					{
						num70 = -1972054288;
						num71 = -1972054288;
					}
					num = num70 ^ (int)(num2 * 262987468);
					continue;
				}
				case 58u:
				{
					GInterface5[] ginterface5_ = gclass9_0.ginterface5_1;
					int num67 = int_1;
					GInterface7 object_5 = ginterface7_0;
					string text2 = global::_003CModule_003E.smethod_20<string>(2592255879u, 992241419u);
					object[] obj3 = new object[1] { int_1 };
					array = obj3;
					bool[] obj4 = new bool[1] { true };
					array2 = obj4;
					object obj5 = Delegate58.smethod_0((object)object_5, (Type)null, text2, obj3, (string[])null, (Type[])null, obj4);
					if (array2[0])
					{
						int_1 = (int)Delegate144.delegate144_0(Delegate7.delegate7_2(array[0]), (Type)Delegate9.delegate9_0(typeof(int).TypeHandle));
					}
					ginterface5_[num67] = (GInterface5)obj5;
					num = 323474147;
					continue;
				}
				case 57u:
				{
					GDelegate6 gDelegate35 = gDelegate16;
					GInterface7 object_3 = ginterface7_0;
					string text = global::_003CModule_003E.smethod_21<string>(1125582385u, 4020824501u);
					object[] obj = new object[1] { int_1 };
					array = obj;
					bool[] obj2 = new bool[1] { true };
					array2 = obj2;
					object object_4 = Delegate58.smethod_0((object)object_3, (Type)null, text, obj, (string[])null, (Type[])null, obj2);
					if (array2[0])
					{
						int_1 = (int)Delegate144.delegate144_0(Delegate7.delegate7_2(array[0]), (Type)Delegate9.delegate9_0(typeof(int).TypeHandle));
					}
					gDelegate35(Delegate81.smethod_0(Delegate15.smethod_0(Delegate58.smethod_0(object_4, (Type)null, global::_003CModule_003E.smethod_20<string>(3332070959u, 1755946168u), new object[0], (string[])null, (Type[])null, (bool[])null))), Delegate28.delegate28_26(), autoCrLf: true);
					num = 326690136;
					continue;
				}
				case 56u:
					gDelegate6 = gdelegate6_0;
					num = (int)(num2 * 936283468) ^ -1051336260;
					continue;
				case 55u:
				{
					int num63;
					int num64;
					if (gDelegate28 != null)
					{
						num63 = 1271945016;
						num64 = 1271945016;
					}
					else
					{
						num63 = 1850781784;
						num64 = 1850781784;
					}
					num = num63 ^ ((int)num2 * -1925469348);
					continue;
				}
				case 54u:
					num = (int)((num2 * 1298711711) ^ 0x411C6812);
					continue;
				case 53u:
				{
					gEnum = genum16_0;
					int num60;
					if (gEnum < GEnum16.JswMsgType_M3)
					{
						num = 1706561391;
						num60 = 1706561391;
					}
					else
					{
						num = 476760232;
						num60 = 476760232;
					}
					continue;
				}
				case 52u:
				{
					int num57;
					int num58;
					if (gDelegate8 != null)
					{
						num57 = 199897216;
						num58 = 199897216;
					}
					else
					{
						num57 = 2093347577;
						num58 = 2093347577;
					}
					num = num57 ^ (int)(num2 * 53829702);
					continue;
				}
				case 50u:
					gDelegate32(Delegate142.smethod_0(Delegate36.delegate36_43(), new object[4]
					{
						Delegate15.delegate15_25(gclass12_0),
						Delegate15.delegate15_10(gclass9_0),
						Delegate15.delegate15_9(gclass9_0),
						Delegate64.delegate64_0()
					}), Delegate28.delegate28_20(), autoCrLf: true);
					num = ((int)num2 * -1203554974) ^ 0xCDA15B3;
					continue;
				case 49u:
				{
					gDelegate = gdelegate6_0;
					int num56;
					if (gDelegate == null)
					{
						num = 756239963;
						num56 = 756239963;
					}
					else
					{
						num = 811551186;
						num56 = 811551186;
					}
					continue;
				}
				case 48u:
				{
					int num52;
					int num53;
					if (gDelegate31 != null)
					{
						num52 = -1979566196;
						num53 = -1979566196;
					}
					else
					{
						num52 = -1346778950;
						num53 = -1346778950;
					}
					num = num52 ^ (int)(num2 * 1924781071);
					continue;
				}
				case 47u:
					gDelegate25 = gdelegate6_0;
					num = (int)(num2 * 1945803846) ^ -1428384403;
					continue;
				case 46u:
					gDelegate30(Delegate36.delegate36_40(), Delegate28.delegate28_9(), autoCrLf: true);
					num = ((int)num2 * -2064208884) ^ 0x42FD28FB;
					continue;
				case 45u:
				{
					int num49;
					int num50;
					if (gDelegate18 != null)
					{
						num49 = -1308346098;
						num50 = -1308346098;
					}
					else
					{
						num49 = -1533755524;
						num50 = -1533755524;
					}
					num = num49 ^ (int)(num2 * 1696076640);
					continue;
				}
				case 44u:
				{
					int num46;
					int num47;
					if (gDelegate26 != null)
					{
						num46 = 1426305644;
						num47 = 1426305644;
					}
					else
					{
						num46 = 406007580;
						num47 = 406007580;
					}
					num = num46 ^ ((int)num2 * -2109534402);
					continue;
				}
				case 43u:
					Delegate126.delegate126_0(gclass9_0, GClass9.GEnum3.Nok);
					num = ((int)num2 * -1570780084) ^ -1438163670;
					continue;
				case 42u:
					Delegate5.delegate5_41(this, bool_0: true);
					num = ((int)num2 * -745614535) ^ 0x530B2F9A;
					continue;
				case 41u:
					num = (int)(num2 * 1800834143) ^ -37840885;
					continue;
				case 40u:
				{
					int num44;
					int num45;
					if (gDelegate15 == null)
					{
						num44 = -225867092;
						num45 = -225867092;
					}
					else
					{
						num44 = -755368635;
						num45 = -755368635;
					}
					num = num44 ^ (int)(num2 * 777403148);
					continue;
				}
				case 39u:
					gDelegate28(Delegate36.delegate36_36(), Delegate28.delegate28_22(), autoCrLf: true);
					num = (int)((num2 * 1152075277) ^ 0x7F41CD63);
					continue;
				case 38u:
					gDelegate7(Delegate36.delegate36_33(), Delegate28.delegate28_23(), autoCrLf: true);
					num = (int)(num2 * 1987208754) ^ -1952059864;
					continue;
				case 37u:
					gDelegate27(Delegate57.delegate57_1(Delegate36.delegate36_51(), Delegate15.delegate15_25(Delegate7.delegate7_101(gclass9_0))), Delegate28.delegate28_25(), autoCrLf: true);
					num = (int)(num2 * 1676665299) ^ -1258250729;
					continue;
				case 36u:
					Delegate8.delegate8_116(gclass9_0, gclass12_0);
					num = (int)((num2 * 452090406) ^ 0xC9AD356);
					continue;
				case 35u:
					gDelegate26(genum1_0);
					num = ((int)num2 * -1274981783) ^ -1599298709;
					continue;
				case 34u:
					num = ((int)num2 * -1956198780) ^ 0x46277534;
					continue;
				case 33u:
					gDelegate20 = gdelegate6_0;
					num = 903551305;
					continue;
				case 32u:
				{
					gDelegate24 = gdelegate6_0;
					int num40;
					int num41;
					if (gDelegate24 != null)
					{
						num40 = 1622516418;
						num41 = 1622516418;
					}
					else
					{
						num40 = 1168898583;
						num41 = 1168898583;
					}
					num = num40 ^ ((int)num2 * -538404589);
					continue;
				}
				case 31u:
				{
					int num35;
					int num36;
					if (num3 == 8)
					{
						num35 = -1943006106;
						num36 = -1943006106;
					}
					else
					{
						num35 = -772295982;
						num36 = -772295982;
					}
					num = num35 ^ (int)(num2 * 913706276);
					continue;
				}
				case 30u:
				{
					int num31;
					int num32;
					if (gDelegate20 == null)
					{
						num31 = 1516878335;
						num32 = 1516878335;
					}
					else
					{
						num31 = 1916669207;
						num32 = 1916669207;
					}
					num = num31 ^ (int)(num2 * 215320656);
					continue;
				}
				case 29u:
					genum2_0 = GEnum2.fHalfOk;
					Delegate5.delegate5_41(this, bool_0: true);
					num = 37469980;
					continue;
				case 28u:
				{
					int num28;
					int num29;
					if (!((int_1 != 0) & bool_2))
					{
						num28 = 509316720;
						num29 = 509316720;
					}
					else
					{
						num28 = 1953060242;
						num29 = 1953060242;
					}
					num = num28 ^ (int)(num2 * 232814882);
					continue;
				}
				case 27u:
				{
					int num24;
					int num25;
					if (gDelegate16 == null)
					{
						num24 = 1400016476;
						num25 = 1400016476;
					}
					else
					{
						num24 = 156160390;
						num25 = 156160390;
					}
					num = num24 ^ ((int)num2 * -1265663028);
					continue;
				}
				case 26u:
					gDelegate15(Delegate36.delegate36_39(), Delegate28.delegate28_23(), autoCrLf: true);
					num = ((int)num2 * -1820662628) ^ 0x75DFBD51;
					continue;
				case 25u:
				{
					int num23;
					if (Delegate125.delegate125_0(gclass9_0) != 0)
					{
						num = 1358067841;
						num23 = 1358067841;
					}
					else
					{
						num = 987704049;
						num23 = 987704049;
					}
					continue;
				}
				case 24u:
				{
					int num22;
					if (gEnum != GEnum16.JswMsgType_M8)
					{
						num = 37469980;
						num22 = 37469980;
					}
					else
					{
						num = 1592924506;
						num22 = 1592924506;
					}
					continue;
				}
				case 22u:
				{
					gDelegate13 = gdelegate6_0;
					int num20;
					int num21;
					if (gDelegate13 == null)
					{
						num20 = -384606712;
						num21 = -384606712;
					}
					else
					{
						num20 = -898727689;
						num21 = -898727689;
					}
					num = num20 ^ ((int)num2 * -2137125855);
					continue;
				}
				case 20u:
					num = ((int)num2 * -1576705688) ^ 0x43E3943C;
					continue;
				case 19u:
					Delegate5.delegate5_41(this, bool_0: true);
					num = 2076140093;
					continue;
				case 18u:
					gDelegate9(genum1_0);
					num = ((int)num2 * -860540066) ^ 0x45B7E7FA;
					continue;
				case 16u:
					genum2_0 = GEnum2.Ok;
					num = ((int)num2 * -1058729329) ^ -885179152;
					continue;
				case 15u:
					num = (int)(num2 * 1770870188) ^ -791665480;
					continue;
				case 14u:
				{
					int num16;
					int num17;
					if (genum1_0 == GEnum1.NACK)
					{
						num16 = 1082528641;
						num17 = 1082528641;
					}
					else
					{
						num16 = 17132674;
						num17 = 17132674;
					}
					num = num16 ^ ((int)num2 * -1060389158);
					continue;
				}
				case 13u:
				{
					int num12;
					int num13;
					if (gDelegate9 != null)
					{
						num12 = 1717875906;
						num13 = 1717875906;
					}
					else
					{
						num12 = 377801903;
						num13 = 377801903;
					}
					num = num12 ^ (int)(num2 * 1954671707);
					continue;
				}
				case 12u:
					genum1_0 = GEnum1.Testing;
					genum2_0 = GEnum2.None;
					num = 1495953972;
					continue;
				case 11u:
				{
					int num7;
					int num8;
					if (gDelegate6 == null)
					{
						num7 = 1881978596;
						num8 = 1881978596;
					}
					else
					{
						num7 = 1839371379;
						num8 = 1839371379;
					}
					num = num7 ^ (int)(num2 * 879187898);
					continue;
				}
				case 10u:
					gDelegate5(genum1_0);
					num = ((int)num2 * -591077844) ^ -1296088904;
					continue;
				case 6u:
				{
					gDelegate3 = gdelegate6_0;
					int num4;
					if (gDelegate3 != null)
					{
						num = 1104267420;
						num4 = 1104267420;
					}
					else
					{
						num = 888954814;
						num4 = 888954814;
					}
					continue;
				}
				case 4u:
					num3 = int_1;
					num = 1798034816;
					continue;
				case 3u:
					gDelegate2(Delegate36.delegate36_32(), Delegate28.delegate28_22(), autoCrLf: true);
					num = ((int)num2 * -1262295861) ^ 0x2BACA2E1;
					continue;
				case 2u:
					Delegate126.delegate126_0(gclass9_0, GClass9.GEnum3.Nok);
					num = (int)((num2 * 1519692080) ^ 0x594239C6);
					continue;
				case 1u:
					gDelegate(Delegate50.delegate50_0(Delegate36.delegate36_50(), Delegate15.delegate15_25(gclass12_0)), Delegate28.delegate28_22(), autoCrLf: true);
					num = ((int)num2 * -305539479) ^ 0x84DA392;
					continue;
				case 0u:
					num = (int)(num2 * 1471463411) ^ -886785748;
					continue;
				default:
					return;
				case 165u:
					break;
				case 167u:
					return;
					IL_0d02:
					gDelegate15 = gdelegate6_0;
					num = 180586391;
					continue;
					IL_0cd5:
					gDelegate17 = gdelegate6_0;
					num = 1155023712;
					continue;
					IL_066e:
					gDelegate19 = gdelegate6_0;
					if (gDelegate19 == null)
					{
						num = 37469980;
						num30 = 37469980;
					}
					else
					{
						num = 423786319;
						num30 = 423786319;
					}
					continue;
					IL_0317:
					gDelegate28 = gdelegate6_0;
					num = 1709482020;
					continue;
					IL_0a5c:
					gDelegate33 = gdelegate6_0;
					num = 561346989;
					continue;
					IL_08a2:
					gDelegate36 = gdelegate6_0;
					if (gDelegate36 != null)
					{
						num = 584355195;
						num78 = 584355195;
					}
					else
					{
						num = 37469980;
						num78 = 37469980;
					}
					continue;
					IL_1080:
					gDelegate10 = gdelegate6_0;
					num = 1767046129;
					continue;
					IL_1057:
					if (!(bool_0 && int_1 == 8))
					{
						num = 1450512359;
						num81 = 1450512359;
					}
					else
					{
						num = 326690136;
						num81 = 326690136;
					}
					continue;
					IL_0fcb:
					ginterface5_2 = gclass9_0.ginterface5_1;
					num85 = int_1;
					object_6 = ginterface7_0;
					text3 = global::_003CModule_003E.smethod_18<string>(642062258u, 88484293u);
					obj6 = new object[1] { int_1 };
					array = obj6;
					obj7 = new bool[1] { true };
					array2 = obj7;
					obj8 = Delegate58.smethod_0((object)object_6, (Type)null, text3, obj6, (string[])null, (Type[])null, obj7);
					if (array2[0])
					{
						int_1 = (int)Delegate144.delegate144_0(Delegate7.delegate7_2(array[0]), (Type)Delegate9.delegate9_0(typeof(int).TypeHandle));
					}
					ginterface5_2[num85] = (GInterface5)obj8;
					num = 937987422;
					continue;
					IL_0fb9:
					gDelegate31 = gdelegate6_0;
					num = 151920939;
					continue;
					IL_0f94:
					if (genum1_0 != GEnum1.Testing)
					{
						num = 37469980;
						num88 = 37469980;
					}
					else
					{
						num = 230950208;
						num88 = 230950208;
					}
					continue;
					IL_0f82:
					gDelegate7 = gdelegate6_0;
					num = 401883471;
					continue;
					IL_0f5c:
					gDelegate34 = gdelegate6_0;
					if (gDelegate34 != null)
					{
						num = 1415401709;
						num91 = 1415401709;
					}
					else
					{
						num = 375755189;
						num91 = 375755189;
					}
					continue;
					IL_0f4b:
					gDelegate21 = gdelegate6_0;
					num = 216815428;
					continue;
					IL_0f23:
					gDelegate38 = gdelegate6_0;
					if (gDelegate38 != null)
					{
						num = 646394037;
						num96 = 646394037;
					}
					else
					{
						num = 1656886008;
						num96 = 1656886008;
					}
					continue;
					IL_0efb:
					gDelegate30 = gdelegate6_0;
					if (gDelegate30 != null)
					{
						num = 621880817;
						num97 = 621880817;
					}
					else
					{
						num = 37469980;
						num97 = 37469980;
					}
					continue;
					IL_0ed0:
					bool_3 = false;
					if (bool_0)
					{
						num = 17157837;
						num98 = 17157837;
					}
					else
					{
						num = 1426197176;
						num98 = 1426197176;
					}
					continue;
					IL_0219:
					if (!bool_3)
					{
						num = 1307742805;
						num100 = 1307742805;
					}
					else
					{
						num = 37469980;
						num100 = 37469980;
					}
					continue;
					IL_0ea8:
					gDelegate2 = gdelegate6_0;
					if (gDelegate2 != null)
					{
						num = 1135939300;
						num101 = 1135939300;
					}
					else
					{
						num = 37469980;
						num101 = 37469980;
					}
					continue;
					IL_0e95:
					num = (int)(num2 * 2001550365) ^ -909228775;
					continue;
					IL_0e23:
					gDelegate18 = gdelegate6_0;
					num = 1570840842;
					continue;
				}
				break;
			}
		}
	}
}
