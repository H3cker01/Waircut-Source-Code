internal delegate string Delegate11(string string_0, string[] string_1);
