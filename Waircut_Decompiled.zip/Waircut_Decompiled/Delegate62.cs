using System.Collections.Generic;

internal delegate List<GClass1.GClass2> Delegate62(object object_0);
