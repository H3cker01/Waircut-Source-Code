internal delegate char[] Delegate65(object object_0);
