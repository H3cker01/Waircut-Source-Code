internal delegate string Delegate206(int int_0, string string_0);
