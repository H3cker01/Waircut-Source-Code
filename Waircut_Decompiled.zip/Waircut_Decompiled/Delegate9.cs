using System;

internal delegate object Delegate9(RuntimeTypeHandle runtimeTypeHandle_0);
