using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
[TypeIdentifier("c9178c19-99cf-4f6d-85c6-3ef5a176f9fb", "JSWSCAPILib.JswConnResetMethod")]
public enum GEnum11
{
	JswConnResetMethod_None,
	JswConnResetMethod_Default,
	JswConnResetMethod_ConnectionMgr,
	JswConnResetMethod_ResetInterface
}
