internal delegate object Delegate133(string string_0, GClass12.GEnum5 genum5_0);
