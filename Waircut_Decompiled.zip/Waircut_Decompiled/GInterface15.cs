using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[ComImport]
[CompilerGenerated]
[Guid("D3CBDBF0-067B-4EA8-8E3A-E42D2831EB14")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface GInterface15 : GInterface5
{
}
