using System;

internal class Attribute3 : Attribute
{
	internal readonly int int_0;

	internal Attribute3(int int_1)
	{
		int_0 = int_1 * -699083231 * 833624603;
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
