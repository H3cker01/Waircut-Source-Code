using System.Runtime.CompilerServices;
using System.Threading;

public class GClass7 : GInterface8
{
	public delegate void GDelegate3(GEnum14 @event, int evtData, string evtString);

	[CompilerGenerated]
	private GDelegate3 gdelegate3_0;

	public event GDelegate3 Event_0
	{
		[CompilerGenerated]
		add
		{
			GDelegate3 gDelegate = gdelegate3_0;
			GDelegate3 gDelegate2 = default(GDelegate3);
			GDelegate3 value2 = default(GDelegate3);
			while (true)
			{
				int num = -1158068079;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x927D4A5Cu) % 5)
					{
					case 4u:
						gDelegate2 = gDelegate;
						num = -1024699927;
						continue;
					case 3u:
						value2 = (GDelegate3)Delegate95.delegate95_0(gDelegate2, value);
						num = (int)(num2 * 2025486111) ^ -1228466049;
						continue;
					case 1u:
					{
						gDelegate = Interlocked.CompareExchange(ref gdelegate3_0, value2, gDelegate2);
						int num3;
						int num4;
						if ((object)gDelegate != gDelegate2)
						{
							num3 = -745885791;
							num4 = -745885791;
						}
						else
						{
							num3 = -1689086057;
							num4 = -1689086057;
						}
						num = num3 ^ (int)(num2 * 1023075734);
						continue;
					}
					default:
						return;
					case 0u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
		[CompilerGenerated]
		remove
		{
			GDelegate3 gDelegate = gdelegate3_0;
			GDelegate3 gDelegate2 = default(GDelegate3);
			while (true)
			{
				int num = 271525347;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x257FCEFAu) % 4)
					{
					case 2u:
					{
						GDelegate3 value2 = (GDelegate3)Delegate95.delegate95_1(gDelegate2, value);
						gDelegate = Interlocked.CompareExchange(ref gdelegate3_0, value2, gDelegate2);
						int num3;
						int num4;
						if ((object)gDelegate != gDelegate2)
						{
							num3 = -1277086627;
							num4 = -1277086627;
						}
						else
						{
							num3 = -1753059513;
							num4 = -1753059513;
						}
						num = num3 ^ ((int)num2 * -2073526707);
						continue;
					}
					case 1u:
						gDelegate2 = gDelegate;
						num = 1541483852;
						continue;
					default:
						return;
					case 0u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
	}

	void GInterface8.OnJswEngineEvent(GEnum14 @event, int evtData, string evtString)
	{
		GDelegate3 gDelegate = gdelegate3_0;
		while (true)
		{
			int num = 1558409133;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x7F161C96u) % 4)
				{
				case 3u:
				{
					int num3;
					int num4;
					if (gDelegate != null)
					{
						num3 = -1317591011;
						num4 = -1317591011;
					}
					else
					{
						num3 = -330432972;
						num4 = -330432972;
					}
					num = num3 ^ (int)(num2 * 1060873917);
					continue;
				}
				case 0u:
					gDelegate(@event, evtData, evtString);
					num = (int)((num2 * 1542836433) ^ 0x3B2109FF);
					continue;
				default:
					return;
				case 2u:
					break;
				case 1u:
					return;
				}
				break;
			}
		}
	}
}
