internal delegate void Delegate200(string string_0, byte[] byte_0);
