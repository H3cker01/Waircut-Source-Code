using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using ns1;

namespace Waircut;

[DesignerGenerated]
public class UpdateForm : Form
{
	private IContainer icontainer_0;

	[CompilerGenerated]
	[AccessedThroughProperty("PictureBox1")]
	private PictureBox pictureBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("lbTitle")]
	private Label label_0;

	[CompilerGenerated]
	[AccessedThroughProperty("Label1")]
	private Label label_1;

	[CompilerGenerated]
	[AccessedThroughProperty("Label2")]
	private Label label_2;

	[CompilerGenerated]
	[AccessedThroughProperty("lbVersion")]
	private Label label_3;

	[CompilerGenerated]
	[AccessedThroughProperty("lbLastVersion")]
	private Label label_4;

	[CompilerGenerated]
	[AccessedThroughProperty("btDownload")]
	private Button button_0;

	[CompilerGenerated]
	[AccessedThroughProperty("Panel2")]
	private Panel panel_0;

	[CompilerGenerated]
	[AccessedThroughProperty("ScrollLabel1")]
	private GClass14 gclass14_0;

	public string string_0;

	internal virtual PictureBox PictureBox_0
	{
		[CompilerGenerated]
		get
		{
			return pictureBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			pictureBox_0 = value;
		}
	}

	internal virtual Label Label_0
	{
		[CompilerGenerated]
		get
		{
			return label_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_0 = value;
		}
	}

	internal virtual Label Label_1
	{
		[CompilerGenerated]
		get
		{
			return label_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_1 = value;
		}
	}

	internal virtual Label Label_2
	{
		[CompilerGenerated]
		get
		{
			return label_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_2 = value;
		}
	}

	internal virtual Label Label_3
	{
		[CompilerGenerated]
		get
		{
			return label_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_3 = value;
		}
	}

	internal virtual Label Label_4
	{
		[CompilerGenerated]
		get
		{
			return label_4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_4 = value;
		}
	}

	internal virtual Button Button_0
	{
		[CompilerGenerated]
		get
		{
			return button_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_2;
			Button button = button_0;
			while (true)
			{
				int num = -479677266;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xF906F297u) % 7)
					{
					case 6u:
					{
						int num5;
						int num6;
						if (button == null)
						{
							num5 = 1236819835;
							num6 = 1236819835;
						}
						else
						{
							num5 = 1617709840;
							num6 = 1617709840;
						}
						num = num5 ^ ((int)num2 * -670235760);
						continue;
					}
					case 4u:
						Delegate8.delegate8_200(button, object_);
						num = (int)(num2 * 1549671826) ^ -2061203403;
						continue;
					case 2u:
					{
						int num3;
						int num4;
						if (button != null)
						{
							num3 = -1522848226;
							num4 = -1522848226;
						}
						else
						{
							num3 = -415515691;
							num4 = -415515691;
						}
						num = num3 ^ (int)(num2 * 908590332);
						continue;
					}
					case 1u:
						Delegate8.delegate8_199(button, object_);
						num = (int)(num2 * 545646220) ^ -674092875;
						continue;
					case 0u:
						button_0 = value;
						button = button_0;
						num = -491885454;
						continue;
					default:
						return;
					case 3u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual Panel Panel_0
	{
		[CompilerGenerated]
		get
		{
			return panel_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			panel_0 = value;
		}
	}

	internal virtual GClass14 GClass14_0
	{
		[CompilerGenerated]
		get
		{
			return gclass14_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			gclass14_0 = value;
		}
	}

	public UpdateForm()
	{
		Delegate8.delegate8_3(this, new EventHandler(method_1));
		string_0 = "";
		Delegate22.delegate22_62(this);
	}

	[DebuggerNonUserCode]
	void Form.Dispose(bool disposing)
	{
		try
		{
			if (!disposing)
			{
				return;
			}
			while (true)
			{
				int num = -192926560;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x912DA5A1u) % 4)
					{
					case 1u:
					{
						int num3;
						int num4;
						if (icontainer_0 != null)
						{
							num3 = 193943907;
							num4 = 193943907;
						}
						else
						{
							num3 = 1800849953;
							num4 = 1800849953;
						}
						num = num3 ^ (int)(num2 * 2073134058);
						continue;
					}
					case 0u:
						Delegate22.delegate22_4(icontainer_0);
						num = ((int)num2 * -1256307166) ^ -664346469;
						continue;
					default:
						return;
					case 3u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
		finally
		{
			Delegate5.delegate5_3(this, disposing);
		}
	}

	[DebuggerStepThrough]
	private void method_0()
	{
		object object_ = Delegate7.delegate7_4(Delegate9.delegate9_0(typeof(UpdateForm).TypeHandle));
		Delegate8.delegate8_287(this, Delegate3.delegate3_9());
		Delegate8.delegate8_288(this, Delegate3.delegate3_9());
		Delegate8.delegate8_289(this, Delegate3.delegate3_9());
		Delegate8.delegate8_290(this, Delegate3.delegate3_9());
		Delegate8.delegate8_291(this, Delegate3.delegate3_9());
		Delegate8.delegate8_292(this, Delegate3.delegate3_69());
		Delegate8.delegate8_293(this, Delegate3.delegate3_12());
		Delegate8.delegate8_294(this, Delegate3.delegate3_14());
		Delegate8.delegate8_295(this, Delegate3.delegate3_13());
		Delegate22.delegate22_6(Delegate7.delegate7_242(this));
		Delegate22.delegate22_5(Delegate7.delegate7_243(this));
		Delegate22.delegate22_7(this);
		Delegate27.smethod_0(object_, Delegate7.delegate7_244(this), global::_003CModule_003E.smethod_21<string>(2013993459u, 2934098292u));
		Delegate29.delegate29_0(Delegate7.delegate7_244(this), Delegate28.delegate28_30());
		Delegate30.delegate30_0(Delegate7.delegate7_244(this), global::_003CModule_003E.smethod_18<string>(147383928u, 2978427943u));
		Delegate27.smethod_0(object_, Delegate7.delegate7_245(this), global::_003CModule_003E.smethod_21<string>(2617738730u, 2468667203u));
		Delegate30.delegate30_0(Delegate7.delegate7_245(this), global::_003CModule_003E.smethod_18<string>(1323670101u, 1600381501u));
		Delegate27.smethod_0(object_, Delegate7.delegate7_246(this), global::_003CModule_003E.smethod_18<string>(1916272891u, 1880402910u));
		Delegate30.delegate30_0(Delegate7.delegate7_246(this), global::_003CModule_003E.smethod_19<string>(428453096u, 3234109862u));
		Delegate27.smethod_0(object_, Delegate7.delegate7_247(this), global::_003CModule_003E.smethod_21<string>(2799086607u, 2562635205u));
		Delegate29.delegate29_0(Delegate7.delegate7_247(this), Delegate28.delegate28_22());
		Delegate30.delegate30_0(Delegate7.delegate7_247(this), global::_003CModule_003E.smethod_22<string>(295813821u, 23721422u));
		Delegate27.smethod_0(object_, Delegate7.delegate7_248(this), global::_003CModule_003E.smethod_21<string>(1789029296u, 254463176u));
		Delegate29.delegate29_0(Delegate7.delegate7_248(this), Delegate28.delegate28_7());
		Delegate30.delegate30_0(Delegate7.delegate7_248(this), global::_003CModule_003E.smethod_22<string>(2657743350u, 1146024113u));
		Delegate27.smethod_0(object_, Delegate7.delegate7_249(this), global::_003CModule_003E.smethod_20<string>(939036061u, 1021618224u));
		Delegate8.delegate8_296(Delegate7.delegate7_249(this), Delegate3.delegate3_108());
		Delegate30.delegate30_0(Delegate7.delegate7_249(this), global::_003CModule_003E.smethod_18<string>(1492946032u, 969947931u));
		Delegate5.delegate5_46(Delegate7.delegate7_249(this), bool_0: true);
		Delegate27.smethod_0(object_, Delegate7.delegate7_242(this), global::_003CModule_003E.smethod_19<string>(1338451511u, 3980716878u));
		Delegate8.delegate8_11(Delegate7.delegate7_242(this), Delegate3.delegate3_16());
		Delegate30.delegate30_0(Delegate7.delegate7_242(this), global::_003CModule_003E.smethod_21<string>(2392774567u, 743118874u));
		Delegate5.delegate5_5(Delegate7.delegate7_242(this), bool_0: false);
		Delegate27.smethod_0(object_, Delegate7.delegate7_243(this), global::_003CModule_003E.smethod_21<string>(3145697007u, 2173492225u));
		Delegate29.delegate29_2(Delegate7.delegate7_243(this), Delegate28.delegate28_3());
		Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_243(this)), Delegate7.delegate7_242(this));
		Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_243(this)), Delegate7.delegate7_246(this));
		Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_243(this)), Delegate7.delegate7_248(this));
		Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_243(this)), Delegate7.delegate7_245(this));
		Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_243(this)), Delegate7.delegate7_247(this));
		Delegate30.delegate30_0(Delegate7.delegate7_243(this), global::_003CModule_003E.smethod_22<string>(1818954333u, 2562511487u));
		Delegate27.smethod_0(object_, Delegate7.delegate7_250(this), global::_003CModule_003E.smethod_18<string>(1634545152u, 3605013667u));
		Delegate32.delegate32_0(Delegate7.delegate7_250(this), 60);
		Delegate30.delegate30_0(Delegate7.delegate7_250(this), global::_003CModule_003E.smethod_22<string>(3472395761u, 67178191u));
		Delegate33.delegate33_0(Delegate7.delegate7_250(this), GClass14.GEnum7.vertical);
		Delegate27.smethod_0(object_, (object)this, global::_003CModule_003E.smethod_18<string>(1374701051u, 843525808u));
		Delegate34.delegate34_0(this, AutoScaleMode.Font);
		while (true)
		{
			int num = -2094333726;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xDB1C1D53u) % 8)
				{
				case 7u:
					Delegate5.delegate5_8(this, bool_0: false);
					Delegate30.delegate30_2(this, global::_003CModule_003E.smethod_19<string>(3079308728u, 452686335u));
					num = ((int)num2 * -166997966) ^ 0x4FAA374B;
					continue;
				case 6u:
					Delegate5.delegate5_9(this, bool_0: false);
					Delegate22.delegate22_9(Delegate7.delegate7_242(this));
					num = ((int)num2 * -365764992) ^ -842910711;
					continue;
				case 4u:
					Delegate5.delegate5_6(this, bool_0: true);
					Delegate35.delegate35_0(this, FormBorderStyle.FixedSingle);
					Delegate5.delegate5_7(this, bool_0: false);
					num = ((int)num2 * -1551373154) ^ 0xBBE8EB4;
					continue;
				case 3u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_249(this));
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_244(this));
					num = ((int)num2 * -938280417) ^ -640666990;
					continue;
				case 2u:
					Delegate5.delegate5_10(Delegate7.delegate7_243(this), bool_0: false);
					num = ((int)num2 * -1998564076) ^ -277346290;
					continue;
				case 1u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_250(this));
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_243(this));
					num = ((int)num2 * -123988320) ^ -1401314344;
					continue;
				case 0u:
					break;
				default:
					Delegate22.delegate22_8(Delegate7.delegate7_243(this));
					Delegate5.delegate5_11(this, bool_0: false);
					Delegate22.delegate22_10(this);
					return;
				}
				break;
			}
		}
	}

	private void method_1(object sender, EventArgs e)
	{
		Delegate30.delegate30_4(Delegate7.delegate7_250(this), Delegate36.delegate36_62());
		while (true)
		{
			int num = 1118122395;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x6DAA241Cu) % 4)
				{
				case 3u:
					Delegate30.delegate30_4(Delegate7.delegate7_247(this), Delegate36.delegate36_1());
					num = (int)((num2 * 1012328924) ^ 0x39772F20);
					continue;
				case 0u:
					Delegate30.delegate30_4(Delegate7.delegate7_248(this), string_0);
					num = ((int)num2 * -1106888997) ^ 0x378AB501;
					continue;
				default:
					return;
				case 2u:
					break;
				case 1u:
					return;
				}
				break;
			}
		}
	}

	private void method_2(object sender, EventArgs e)
	{
		try
		{
			Delegate12.delegate12_8(global::_003CModule_003E.smethod_22<string>(4029874406u, 1436797495u));
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			while (true)
			{
				int num = 206421595;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x751C801u) % 3)
					{
					default:
						return;
					case 1u:
						goto IL_0040;
					case 0u:
						break;
					case 2u:
						return;
					}
					break;
					IL_0040:
					Delegate51.delegate51_0();
					num = ((int)num2 * -1052447597) ^ -960389723;
				}
			}
		}
	}
}
