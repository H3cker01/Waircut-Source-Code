using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using ns1;

namespace Waircut;

[DesignerGenerated]
public class PixieForm : Form
{
	public delegate void GDelegate10(GClass8.GEnum1 status);

	private IContainer icontainer_0;

	[CompilerGenerated]
	[AccessedThroughProperty("cbMode")]
	private ComboBox comboBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("Label1")]
	private Label label_0;

	[CompilerGenerated]
	[AccessedThroughProperty("dtpStart")]
	private DateTimePicker dateTimePicker_0;

	[CompilerGenerated]
	[AccessedThroughProperty("Label2")]
	private Label label_1;

	[CompilerGenerated]
	[AccessedThroughProperty("dtpEnd")]
	private DateTimePicker dateTimePicker_1;

	[CompilerGenerated]
	[AccessedThroughProperty("Label3")]
	private Label label_2;

	[CompilerGenerated]
	[AccessedThroughProperty("cbxForce")]
	private CheckBox checkBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("Label4")]
	private Label label_3;

	[CompilerGenerated]
	[AccessedThroughProperty("cbxRNonce")]
	private CheckBox checkBox_1;

	[CompilerGenerated]
	[AccessedThroughProperty("cbxEBssid")]
	private CheckBox checkBox_2;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolStrip1")]
	private ToolStrip toolStrip_0;

	[CompilerGenerated]
	[AccessedThroughProperty("btExcute")]
	private ToolStripButton toolStripButton_0;

	[CompilerGenerated]
	[AccessedThroughProperty("btRetry")]
	private ToolStripButton toolStripButton_1;

	[CompilerGenerated]
	[AccessedThroughProperty("btStop")]
	private ToolStripButton toolStripButton_2;

	[CompilerGenerated]
	[AccessedThroughProperty("Panel1")]
	private Panel panel_0;

	[CompilerGenerated]
	[AccessedThroughProperty("Label5")]
	private Label label_4;

	[CompilerGenerated]
	[AccessedThroughProperty("PictureBox1")]
	private PictureBox pictureBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("cbxLength")]
	private CheckBox checkBox_3;

	private GClass9 gclass9_0;

	private GClass12 gclass12_0;

	[CompilerGenerated]
	[AccessedThroughProperty("jsApi")]
	private GClass8 gclass8_0;

	private Process process_0;

	internal virtual ComboBox ComboBox_0
	{
		[CompilerGenerated]
		get
		{
			return comboBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_2;
			ComboBox comboBox = comboBox_0;
			while (true)
			{
				int num = -58648763;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x916B9E8Au) % 7)
					{
					case 6u:
					{
						int num5;
						int num6;
						if (comboBox != null)
						{
							num5 = -1304472435;
							num6 = -1304472435;
						}
						else
						{
							num5 = -1198038730;
							num6 = -1198038730;
						}
						num = num5 ^ ((int)num2 * -785175504);
						continue;
					}
					case 5u:
						Delegate8.delegate8_250(comboBox, object_);
						num = (int)((num2 * 716752115) ^ 0x9639493);
						continue;
					case 4u:
						Delegate8.delegate8_249(comboBox, object_);
						num = (int)((num2 * 1649842274) ^ 0x35484218);
						continue;
					case 2u:
					{
						int num3;
						int num4;
						if (comboBox == null)
						{
							num3 = -1868708716;
							num4 = -1868708716;
						}
						else
						{
							num3 = -1382518182;
							num4 = -1382518182;
						}
						num = num3 ^ ((int)num2 * -1503160228);
						continue;
					}
					case 0u:
						comboBox_0 = value;
						comboBox = comboBox_0;
						num = -217001904;
						continue;
					default:
						return;
					case 3u:
						break;
					case 1u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual Label Label_0
	{
		[CompilerGenerated]
		get
		{
			return label_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_0 = value;
		}
	}

	internal virtual DateTimePicker DateTimePicker_0
	{
		[CompilerGenerated]
		get
		{
			return dateTimePicker_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dateTimePicker_0 = value;
		}
	}

	internal virtual Label Label_1
	{
		[CompilerGenerated]
		get
		{
			return label_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_1 = value;
		}
	}

	internal virtual DateTimePicker DateTimePicker_1
	{
		[CompilerGenerated]
		get
		{
			return dateTimePicker_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dateTimePicker_1 = value;
		}
	}

	internal virtual Label Label_2
	{
		[CompilerGenerated]
		get
		{
			return label_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_2 = value;
		}
	}

	internal virtual CheckBox CheckBox_0
	{
		[CompilerGenerated]
		get
		{
			return checkBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_3;
			CheckBox checkBox = checkBox_0;
			while (true)
			{
				int num = 1364532811;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x6C292EFFu) % 7)
					{
					case 6u:
					{
						checkBox = checkBox_0;
						int num5;
						int num6;
						if (checkBox != null)
						{
							num5 = 213804944;
							num6 = 213804944;
						}
						else
						{
							num5 = 1086190032;
							num6 = 1086190032;
						}
						num = num5 ^ ((int)num2 * -438104208);
						continue;
					}
					case 5u:
						Delegate8.delegate8_252(checkBox, object_);
						num = (int)(num2 * 1877191317) ^ -1302068469;
						continue;
					case 3u:
						checkBox_0 = value;
						num = 834271997;
						continue;
					case 2u:
					{
						int num3;
						int num4;
						if (checkBox != null)
						{
							num3 = -151828731;
							num4 = -151828731;
						}
						else
						{
							num3 = -2063961076;
							num4 = -2063961076;
						}
						num = num3 ^ ((int)num2 * -372894130);
						continue;
					}
					case 1u:
						Delegate8.delegate8_251(checkBox, object_);
						num = (int)((num2 * 652607781) ^ 0x2968F33E);
						continue;
					default:
						return;
					case 4u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual Label Label_3
	{
		[CompilerGenerated]
		get
		{
			return label_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_3 = value;
		}
	}

	internal virtual CheckBox CheckBox_1
	{
		[CompilerGenerated]
		get
		{
			return checkBox_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			checkBox_1 = value;
		}
	}

	internal virtual CheckBox CheckBox_2
	{
		[CompilerGenerated]
		get
		{
			return checkBox_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			checkBox_2 = value;
		}
	}

	internal virtual ToolStrip ToolStrip_0
	{
		[CompilerGenerated]
		get
		{
			return toolStrip_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStrip_0 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_4;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = 1488127557;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x4E445FC9u) % 8)
					{
					case 7u:
					{
						int num5;
						int num6;
						if (toolStripButton != null)
						{
							num5 = 81197902;
							num6 = 81197902;
						}
						else
						{
							num5 = 25012611;
							num6 = 25012611;
						}
						num = num5 ^ (int)(num2 * 297574273);
						continue;
					}
					case 4u:
						toolStripButton = toolStripButton_0;
						num = ((int)num2 * -577100944) ^ -1890386165;
						continue;
					case 3u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = (int)((num2 * 640523488) ^ 0x70411F68);
						continue;
					case 2u:
					{
						int num3;
						int num4;
						if (toolStripButton != null)
						{
							num3 = -1975076584;
							num4 = -1975076584;
						}
						else
						{
							num3 = -1295297286;
							num4 = -1295297286;
						}
						num = num3 ^ ((int)num2 * -1511875111);
						continue;
					}
					case 1u:
						toolStripButton_0 = value;
						toolStripButton = toolStripButton_0;
						num = 359458702;
						continue;
					case 0u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = ((int)num2 * -318084186) ^ -1338796860;
						continue;
					default:
						return;
					case 6u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripButton ToolStripButton_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_5;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = 905996488;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x62B9B6C0u) % 7)
					{
					case 6u:
					{
						toolStripButton = toolStripButton_1;
						int num5;
						int num6;
						if (toolStripButton == null)
						{
							num5 = -941109875;
							num6 = -941109875;
						}
						else
						{
							num5 = -2100079638;
							num6 = -2100079638;
						}
						num = num5 ^ (int)(num2 * 247411087);
						continue;
					}
					case 5u:
					{
						toolStripButton = toolStripButton_1;
						int num3;
						int num4;
						if (toolStripButton == null)
						{
							num3 = -1545617954;
							num4 = -1545617954;
						}
						else
						{
							num3 = -2022773796;
							num4 = -2022773796;
						}
						num = num3 ^ (int)(num2 * 1476728057);
						continue;
					}
					case 3u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = (int)((num2 * 439145205) ^ 0x108ABA8F);
						continue;
					case 2u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = (int)(num2 * 1066318554) ^ -1933988622;
						continue;
					case 1u:
						toolStripButton_1 = value;
						num = 938667052;
						continue;
					default:
						return;
					case 0u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripButton ToolStripButton_2
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_6;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = -961111874;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xF26393D7u) % 7)
					{
					case 6u:
					{
						toolStripButton_2 = value;
						toolStripButton = toolStripButton_2;
						int num5;
						if (toolStripButton == null)
						{
							num = -1223403496;
							num5 = -1223403496;
						}
						else
						{
							num = -160019868;
							num5 = -160019868;
						}
						continue;
					}
					case 5u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = (int)((num2 * 1617375021) ^ 0x38AC7545);
						continue;
					case 4u:
						toolStripButton = toolStripButton_2;
						num = (int)((num2 * 661974870) ^ 0x333088A1);
						continue;
					case 1u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = (int)(num2 * 298849267) ^ -213797391;
						continue;
					case 0u:
					{
						int num3;
						int num4;
						if (toolStripButton == null)
						{
							num3 = -1936275054;
							num4 = -1936275054;
						}
						else
						{
							num3 = -1807377980;
							num4 = -1807377980;
						}
						num = num3 ^ ((int)num2 * -84514044);
						continue;
					}
					default:
						return;
					case 2u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual Panel Panel_0
	{
		[CompilerGenerated]
		get
		{
			return panel_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			panel_0 = value;
		}
	}

	internal virtual Label Label_4
	{
		[CompilerGenerated]
		get
		{
			return label_4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_4 = value;
		}
	}

	internal virtual PictureBox PictureBox_0
	{
		[CompilerGenerated]
		get
		{
			return pictureBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			pictureBox_0 = value;
		}
	}

	internal virtual CheckBox CheckBox_3
	{
		[CompilerGenerated]
		get
		{
			return checkBox_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			checkBox_3 = value;
		}
	}

	private virtual GClass8 GClass8_0
	{
		[CompilerGenerated]
		get
		{
			return gclass8_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			GClass8.GDelegate8 object_ = method_7;
			GClass8 gClass = default(GClass8);
			while (true)
			{
				int num = -26195315;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xCB2D400Du) % 7)
					{
					case 6u:
					{
						gclass8_0 = value;
						gClass = gclass8_0;
						int num5;
						if (gClass == null)
						{
							num = -658736235;
							num5 = -658736235;
						}
						else
						{
							num = -2005550168;
							num5 = -2005550168;
						}
						continue;
					}
					case 5u:
						Delegate8.delegate8_104(gClass, object_);
						num = ((int)num2 * -96091439) ^ -2022899680;
						continue;
					case 2u:
					{
						int num3;
						int num4;
						if (gClass != null)
						{
							num3 = -1117926953;
							num4 = -1117926953;
						}
						else
						{
							num3 = -1958549455;
							num4 = -1958549455;
						}
						num = num3 ^ ((int)num2 * -1921534170);
						continue;
					}
					case 1u:
						gClass = gclass8_0;
						num = (int)((num2 * 1670484437) ^ 0x3F50131C);
						continue;
					case 0u:
						Delegate8.delegate8_102(gClass, object_);
						num = (int)(num2 * 1619115270) ^ -1838696801;
						continue;
					default:
						return;
					case 3u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	[DebuggerNonUserCode]
	void Form.Dispose(bool disposing)
	{
		try
		{
			if (!disposing)
			{
				return;
			}
			while (true)
			{
				int num = -344951190;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xEC3DC999u) % 4)
					{
					case 3u:
					{
						int num3;
						int num4;
						if (icontainer_0 != null)
						{
							num3 = -1270969463;
							num4 = -1270969463;
						}
						else
						{
							num3 = -803196968;
							num4 = -803196968;
						}
						num = num3 ^ ((int)num2 * -111886280);
						continue;
					}
					case 0u:
						Delegate22.delegate22_4(icontainer_0);
						num = (int)((num2 * 746130784) ^ 0x18299FF0);
						continue;
					default:
						return;
					case 2u:
						break;
					case 1u:
						return;
					}
					break;
				}
			}
		}
		finally
		{
			Delegate5.delegate5_3(this, disposing);
		}
	}

	[DebuggerStepThrough]
	private void method_0()
	{
		ComponentResourceManager object_ = (ComponentResourceManager)Delegate7.delegate7_4(Delegate9.delegate9_0(typeof(PixieForm).TypeHandle));
		Delegate8.delegate8_231(this, Delegate3.delegate3_90());
		while (true)
		{
			int num = 861634795;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x504E2EAEu) % 72)
				{
				case 71u:
					Delegate8.delegate8_77(Delegate7.delegate7_202(this), Delegate3.delegate3_93());
					Delegate27.delegate27_0(object_, Delegate7.delegate7_202(this), global::_003CModule_003E.smethod_19<string>(120467651u, 125729302u));
					num = (int)((num2 * 1770918878) ^ 0x1AAE416C);
					continue;
				case 70u:
					Delegate8.delegate8_234(this, Delegate3.delegate3_9());
					num = (int)((num2 * 423404695) ^ 0x29AC8259);
					continue;
				case 69u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_188(this), global::_003CModule_003E.smethod_21<string>(418596119u, 3802130965u));
					num = ((int)num2 * -1254187709) ^ -213988805;
					continue;
				case 68u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_198(this));
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_197(this));
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_196(this));
					num = (int)(num2 * 2110184432) ^ -1764407177;
					continue;
				case 67u:
					Delegate30.delegate30_0(Delegate7.delegate7_188(this), global::_003CModule_003E.smethod_20<string>(836775729u, 2648680650u));
					num = (int)(num2 * 2116653554) ^ -235278001;
					continue;
				case 66u:
					Delegate22.delegate22_9(Delegate7.delegate7_190(this));
					num = ((int)num2 * -116045407) ^ -1457819369;
					continue;
				case 65u:
					Delegate8.delegate8_236(this, Delegate3.delegate3_9());
					num = (int)(num2 * 327651396) ^ -2040399040;
					continue;
				case 64u:
					Delegate8.delegate8_241(this, Delegate3.delegate3_67());
					num = ((int)num2 * -17847922) ^ 0x75E94B74;
					continue;
				case 63u:
					Delegate30.delegate30_0(Delegate7.delegate7_191(this), global::_003CModule_003E.smethod_20<string>(2542390245u, 669485148u));
					num = (int)((num2 * 852116905) ^ 0x2C3511E0);
					continue;
				case 62u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_201(this));
					num = ((int)num2 * -766203217) ^ 0x6585C81C;
					continue;
				case 61u:
					Delegate8.delegate8_246(this, Delegate3.delegate3_12());
					Delegate8.delegate8_247(this, Delegate3.delegate3_9());
					num = ((int)num2 * -955485811) ^ -38673846;
					continue;
				case 60u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_191(this), global::_003CModule_003E.smethod_20<string>(2542390245u, 3734710547u));
					num = (int)(num2 * 138593334) ^ -733256871;
					continue;
				case 59u:
					Delegate5.delegate5_46(Delegate7.delegate7_206(this), bool_0: true);
					num = ((int)num2 * -1237887240) ^ 0xFE47604;
					continue;
				case 58u:
					Delegate8.delegate8_242(this, Delegate3.delegate3_24());
					num = (int)((num2 * 1734854331) ^ 0x1BA6CD43);
					continue;
				case 57u:
					Delegate30.delegate30_0(Delegate7.delegate7_190(this), global::_003CModule_003E.smethod_18<string>(961764100u, 145664641u));
					Delegate5.delegate5_5(Delegate7.delegate7_190(this), bool_0: false);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_205(this), global::_003CModule_003E.smethod_22<string>(3040409089u, 1566685940u));
					num = ((int)num2 * -357819810) ^ -850355486;
					continue;
				case 56u:
					Delegate30.delegate30_1(Delegate7.delegate7_202(this), global::_003CModule_003E.smethod_18<string>(3559193904u, 2784922130u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_203(this), global::_003CModule_003E.smethod_20<string>(595325870u, 65102048u));
					num = ((int)num2 * -657892380) ^ 0x444BBB63;
					continue;
				case 55u:
					Delegate5.delegate5_44(Delegate7.delegate7_191(this), bool_0: true);
					Delegate164.smethod_0(Delegate7.delegate7_192(Delegate7.delegate7_191(this)), new object[6]
					{
						Delegate163.delegate163_0(object_, global::_003CModule_003E.smethod_19<string>(1433071668u, 3160064212u)),
						Delegate163.delegate163_0(object_, global::_003CModule_003E.smethod_21<string>(3444128276u, 2121797438u)),
						Delegate163.delegate163_0(object_, global::_003CModule_003E.smethod_22<string>(324711117u, 2575035976u)),
						Delegate163.delegate163_0(object_, global::_003CModule_003E.smethod_20<string>(2044025024u, 2849427134u)),
						Delegate163.delegate163_0(object_, global::_003CModule_003E.smethod_22<string>(2256034851u, 2033939937u)),
						Delegate163.delegate163_0(object_, global::_003CModule_003E.smethod_18<string>(1593444815u, 2110205624u))
					});
					num = ((int)num2 * -640694012) ^ 0x1C0222A6;
					continue;
				case 54u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_190(this), global::_003CModule_003E.smethod_22<string>(981879349u, 1821543609u));
					num = (int)(num2 * 1821211330) ^ -230680229;
					continue;
				case 53u:
					Delegate8.delegate8_248(this, Delegate3.delegate3_92());
					num = (int)((num2 * 1551657001) ^ 0x770EF881);
					continue;
				case 51u:
					Delegate165.delegate165_0(Delegate7.delegate7_196(this), DateTimePickerFormat.Custom);
					Delegate30.delegate30_0(Delegate7.delegate7_196(this), global::_003CModule_003E.smethod_22<string>(3628165907u, 3860577480u));
					num = ((int)num2 * -1407115720) ^ -892097123;
					continue;
				case 50u:
					Delegate30.delegate30_0(Delegate7.delegate7_193(this), global::_003CModule_003E.smethod_18<string>(1323670101u, 1908187661u));
					num = ((int)num2 * -1169680506) ^ 0x39135991;
					continue;
				case 49u:
					Delegate30.delegate30_0(Delegate7.delegate7_197(this), global::_003CModule_003E.smethod_20<string>(3696304781u, 1371900269u));
					num = (int)((num2 * 1847747535) ^ 0x7EEF4352);
					continue;
				case 48u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_206(this), global::_003CModule_003E.smethod_18<string>(3662818921u, 743604215u));
					num = ((int)num2 * -411160272) ^ -1413780016;
					continue;
				case 47u:
					Delegate30.delegate30_1(Delegate7.delegate7_204(this), global::_003CModule_003E.smethod_20<string>(3539120687u, 3828043483u));
					Delegate29.delegate29_2(Delegate7.delegate7_189(this), Delegate28.delegate28_27());
					num = ((int)num2 * -1188638180) ^ -909226365;
					continue;
				case 46u:
					Delegate34.delegate34_0(this, AutoScaleMode.Font);
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_206(this));
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_188(this));
					num = (int)(num2 * 719060716) ^ -1229643240;
					continue;
				case 45u:
					Delegate8.delegate8_235(this, Delegate3.delegate3_91());
					num = ((int)num2 * -14899831) ^ 0x38E2DD72;
					continue;
				case 44u:
					Delegate5.delegate5_10(Delegate7.delegate7_189(this), bool_0: false);
					num = (int)((num2 * 2579992) ^ 0x7CEE52C1);
					continue;
				case 43u:
					Delegate8.delegate8_243(this, Delegate3.delegate3_24());
					num = (int)(num2 * 26061654) ^ -1604585135;
					continue;
				case 42u:
					Delegate8.delegate8_237(this, Delegate3.delegate3_92());
					num = ((int)num2 * -1700352620) ^ 0x9F0E298;
					continue;
				case 41u:
					Delegate30.delegate30_0(Delegate7.delegate7_194(this), global::_003CModule_003E.smethod_21<string>(512711424u, 1539712724u));
					num = ((int)num2 * -849501145) ^ -331442933;
					continue;
				case 40u:
					Delegate47.delegate47_0(Delegate7.delegate7_204(this), ToolStripItemAlignment.Right);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_204(this), global::_003CModule_003E.smethod_20<string>(3539120687u, 2427204109u));
					Delegate8.delegate8_77(Delegate7.delegate7_204(this), Delegate3.delegate3_95());
					num = (int)((num2 * 1793022636) ^ 0x722CD159);
					continue;
				case 39u:
					Delegate22.delegate22_8(Delegate7.delegate7_189(this));
					num = (int)(num2 * 989696414) ^ -957982090;
					continue;
				case 38u:
					Delegate5.delegate5_46(Delegate7.delegate7_200(this), bool_0: true);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_201(this), global::_003CModule_003E.smethod_19<string>(2181602763u, 870995387u));
					num = (int)((num2 * 2063152346) ^ 0x7804F46);
					continue;
				case 37u:
					Delegate8.delegate8_244(this, Delegate3.delegate3_24());
					Delegate8.delegate8_245(this, Delegate3.delegate3_14());
					num = ((int)num2 * -1361953125) ^ 0x270C38C;
					continue;
				case 36u:
					Delegate22.delegate22_5(Delegate7.delegate7_189(this));
					Delegate22.delegate22_6(Delegate7.delegate7_190(this));
					num = ((int)num2 * -197800103) ^ 0x6A5E847E;
					continue;
				case 35u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_198(this), global::_003CModule_003E.smethod_22<string>(3348569568u, 1496400885u));
					num = ((int)num2 * -1177229038) ^ 0x74332B2F;
					continue;
				case 34u:
					Delegate31.smethod_0(Delegate7.delegate7_10(Delegate7.delegate7_188(this)), new ToolStripItem[3]
					{
						(ToolStripItem)Delegate7.delegate7_202(this),
						(ToolStripItem)Delegate7.delegate7_203(this),
						(ToolStripItem)Delegate7.delegate7_204(this)
					});
					num = (int)(num2 * 271150278) ^ -660070687;
					continue;
				case 33u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_189(this)), Delegate7.delegate7_205(this));
					num = ((int)num2 * -664492005) ^ 0x4BC575F4;
					continue;
				case 32u:
					Delegate30.delegate30_0(Delegate7.delegate7_195(this), global::_003CModule_003E.smethod_19<string>(428453096u, 1750489757u));
					num = (int)((num2 * 1918794578) ^ 0x1F312A61);
					continue;
				case 31u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_191(this));
					num = ((int)num2 * -158179780) ^ 0x734CFD7F;
					continue;
				case 30u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_193(this));
					num = (int)((num2 * 1176210494) ^ 0x37AABFB5);
					continue;
				case 29u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_194(this));
					num = ((int)num2 * -704271651) ^ -821837751;
					continue;
				case 28u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_199(this), global::_003CModule_003E.smethod_19<string>(2984688571u, 10845474u));
					Delegate30.delegate30_0(Delegate7.delegate7_199(this), global::_003CModule_003E.smethod_19<string>(2984688571u, 1706472992u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_200(this), global::_003CModule_003E.smethod_21<string>(824908159u, 2441860825u));
					num = ((int)num2 * -1112933118) ^ -493555186;
					continue;
				case 27u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_194(this), global::_003CModule_003E.smethod_22<string>(3907762246u, 4019886498u));
					Delegate165.delegate165_0(Delegate7.delegate7_194(this), DateTimePickerFormat.Custom);
					num = (int)((num2 * 843427492) ^ 0x3FAA423B);
					continue;
				case 26u:
					Delegate22.delegate22_5(Delegate7.delegate7_188(this));
					num = ((int)num2 * -1431329900) ^ 0x52FDE1BA;
					continue;
				case 25u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_195(this));
					num = ((int)num2 * -1806422982) ^ 0x23ED81D9;
					continue;
				case 23u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_196(this), global::_003CModule_003E.smethod_22<string>(3628165907u, 2555565575u));
					num = ((int)num2 * -1091975652) ^ 0x484BBA11;
					continue;
				case 22u:
					Delegate30.delegate30_2(this, global::_003CModule_003E.smethod_18<string>(40632677u, 927743130u));
					Delegate5.delegate5_10(Delegate7.delegate7_188(this), bool_0: false);
					Delegate22.delegate22_8(Delegate7.delegate7_188(this));
					num = (int)(num2 * 1093137634) ^ -1861839210;
					continue;
				case 21u:
					Delegate8.delegate8_232(this, Delegate3.delegate3_9());
					Delegate8.delegate8_233(this, Delegate3.delegate3_91());
					num = ((int)num2 * -825230593) ^ 0x77BA1F4B;
					continue;
				case 20u:
					Delegate30.delegate30_1(Delegate7.delegate7_203(this), global::_003CModule_003E.smethod_20<string>(595325870u, 2873709771u));
					num = ((int)num2 * -1517009882) ^ -37594618;
					continue;
				case 19u:
					Delegate22.delegate22_10(this);
					num = (int)(num2 * 1093976482) ^ -1731805752;
					continue;
				case 18u:
					Delegate27.delegate27_0(object_, this, global::_003CModule_003E.smethod_21<string>(1529651468u, 2799904117u));
					num = ((int)num2 * -333242373) ^ -1462639602;
					continue;
				case 17u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_189(this), global::_003CModule_003E.smethod_21<string>(941991551u, 1615509396u));
					Delegate30.delegate30_0(Delegate7.delegate7_189(this), global::_003CModule_003E.smethod_22<string>(1667944877u, 2822305466u));
					Delegate8.delegate8_11(Delegate7.delegate7_190(this), Delegate3.delegate3_96());
					num = (int)(num2 * 204302769) ^ -279535919;
					continue;
				case 16u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_200(this));
					num = (int)(num2 * 1217373897) ^ -403628479;
					continue;
				case 15u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_199(this));
					num = ((int)num2 * -1008704649) ^ 0x307B06BB;
					continue;
				case 14u:
					Delegate8.delegate8_238(this, Delegate3.delegate3_9());
					num = ((int)num2 * -2127027967) ^ 0x1F9F448;
					continue;
				case 13u:
					Delegate8.delegate8_77(Delegate7.delegate7_203(this), Delegate3.delegate3_94());
					num = ((int)num2 * -430361616) ^ 0x553BABCA;
					continue;
				case 12u:
					Delegate22.delegate22_7(this);
					num = (int)(num2 * 907678081) ^ -1517271283;
					continue;
				case 11u:
					Delegate5.delegate5_11(this, bool_0: false);
					num = (int)(num2 * 893050886) ^ -961198249;
					continue;
				case 10u:
					Delegate30.delegate30_0(Delegate7.delegate7_205(this), global::_003CModule_003E.smethod_22<string>(3040409089u, 368046696u));
					num = ((int)num2 * -1627199880) ^ 0x5F393796;
					continue;
				case 9u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_189(this)), Delegate7.delegate7_190(this));
					num = ((int)num2 * -1408973620) ^ -773521061;
					continue;
				case 8u:
					Delegate8.delegate8_239(this, Delegate3.delegate3_92());
					Delegate8.delegate8_240(this, Delegate3.delegate3_92());
					num = (int)((num2 * 893154796) ^ 0x5A876E0E);
					continue;
				case 7u:
					Delegate30.delegate30_0(Delegate7.delegate7_198(this), global::_003CModule_003E.smethod_22<string>(3348569568u, 3301427828u));
					Delegate5.delegate5_46(Delegate7.delegate7_198(this), bool_0: true);
					num = (int)(num2 * 12565986) ^ -110772260;
					continue;
				case 6u:
					Delegate30.delegate30_0(Delegate7.delegate7_206(this), global::_003CModule_003E.smethod_22<string>(1111798856u, 1943748091u));
					num = (int)(num2 * 815906848) ^ -1889759283;
					continue;
				case 5u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_189(this));
					Delegate35.delegate35_0(this, FormBorderStyle.FixedDialog);
					Delegate5.delegate5_7(this, bool_0: false);
					Delegate5.delegate5_8(this, bool_0: false);
					num = ((int)num2 * -362788709) ^ -2142088865;
					continue;
				case 4u:
					Delegate30.delegate30_0(Delegate7.delegate7_201(this), global::_003CModule_003E.smethod_20<string>(4022020405u, 4098774426u));
					Delegate5.delegate5_46(Delegate7.delegate7_201(this), bool_0: true);
					num = (int)(num2 * 1901555190) ^ -266860485;
					continue;
				case 3u:
					Delegate5.delegate5_45(Delegate7.delegate7_196(this), bool_0: true);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_197(this), global::_003CModule_003E.smethod_19<string>(923553459u, 3104001107u));
					num = ((int)num2 * -124087977) ^ -930376014;
					continue;
				case 2u:
					Delegate5.delegate5_45(Delegate7.delegate7_194(this), bool_0: true);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_195(this), global::_003CModule_003E.smethod_19<string>(428453096u, 1515890214u));
					num = ((int)num2 * -2071300525) ^ -677203784;
					continue;
				case 1u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_193(this), global::_003CModule_003E.smethod_20<string>(1265076156u, 3534084068u));
					num = ((int)num2 * -1237518204) ^ -611406512;
					continue;
				case 0u:
					Delegate30.delegate30_0(Delegate7.delegate7_200(this), global::_003CModule_003E.smethod_19<string>(1064686671u, 3326037701u));
					num = ((int)num2 * -1258544655) ^ -320160224;
					continue;
				default:
					return;
				case 52u:
					break;
				case 24u:
					return;
				}
				break;
			}
		}
	}

	public PixieForm(ref GClass8 gclass8_1, ref GClass9 gclass9_1)
	{
		Delegate8.delegate8_3(this, new EventHandler(method_1));
		gclass12_0 = (GClass12)Delegate133.delegate133_0("", GClass12.GEnum5.Manual);
		Delegate22.delegate22_45(this);
		gclass9_0 = gclass9_1;
		Delegate8.delegate8_253(this, gclass8_1);
	}

	private void method_1(object sender, EventArgs e)
	{
		try
		{
			((DateTimePicker)Delegate7.delegate7_194(this)).Value = Delegate25.delegate25_2(Delegate7.delegate7_194(this)).AddMonths(-1);
			while (true)
			{
				int num = -80594559;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x9F006FBCu) % 4)
					{
					case 1u:
					{
						ComboBox_0.SelectedIndex = 0;
						int num3;
						int num4;
						if (gclass9_0 != null)
						{
							num3 = -10913306;
							num4 = -10913306;
						}
						else
						{
							num3 = -2062903535;
							num4 = -2062903535;
						}
						num = num3 ^ (int)(num2 * 228131390);
						continue;
					}
					case 0u:
						ToolStripButton_1.Enabled = (Operators.CompareString(gclass9_0.PKE, "", TextCompare: false) != 0) & (Operators.CompareString(gclass9_0.PKR, "", TextCompare: false) != 0) & (Operators.CompareString(gclass9_0.AuthKey, "", TextCompare: false) != 0) & (Operators.CompareString(gclass9_0.E_HAS1, "", TextCompare: false) != 0) & (Operators.CompareString(gclass9_0.E_HAS2, "", TextCompare: false) != 0);
						num = ((int)num2 * -2084703405) ^ 0x21FF8F43;
						continue;
					default:
						return;
					case 2u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
	}

	private void method_2(object sender, EventArgs e)
	{
		int num;
		switch (Delegate17.delegate17_19(Delegate7.delegate7_191(this)))
		{
		case 0:
			Delegate5.delegate5_29(Delegate7.delegate7_194(this), bool_0: true);
			num = -910134943;
			goto IL_00f1;
		default:
			goto IL_0056;
		case 3:
			goto IL_00aa;
		case 1:
		case 2:
		case 4:
		case 5:
			goto IL_012b;
			IL_00f1:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xF716E547u) % 10)
				{
				case 9u:
					break;
				case 7u:
					goto IL_0056;
				case 5u:
					Delegate5.delegate5_29(Delegate7.delegate7_198(this), bool_0: true);
					num = (int)((num2 * 1531981771) ^ 0x314A15BE);
					continue;
				case 2u:
					Delegate5.delegate5_29(Delegate7.delegate7_196(this), bool_0: true);
					num = ((int)num2 * -1246370414) ^ -823193930;
					continue;
				case 1u:
					goto IL_00aa;
				default:
					return;
				case 3u:
					goto IL_012b;
				case 0u:
					return;
				case 4u:
					return;
				case 6u:
					return;
				case 8u:
					Delegate5.delegate5_29(Delegate7.delegate7_196(this), bool_0: false);
					Delegate5.delegate5_29(Delegate7.delegate7_198(this), bool_0: true);
					return;
				}
				break;
			}
			goto case 0;
			IL_012b:
			Delegate5.delegate5_29(Delegate7.delegate7_194(this), bool_0: false);
			num = -1250379437;
			goto IL_00f1;
			IL_00aa:
			Delegate5.delegate5_29(Delegate7.delegate7_194(this), bool_0: true);
			Delegate5.delegate5_29(Delegate7.delegate7_196(this), bool_0: true);
			Delegate5.delegate5_29(Delegate7.delegate7_198(this), bool_0: true);
			num = -1287437701;
			goto IL_00f1;
			IL_0056:
			num = -1953208009;
			goto IL_00f1;
		}
	}

	private void method_3(object sender, EventArgs e)
	{
		if (Delegate17.delegate17_19(Delegate7.delegate7_191(this)) != 3)
		{
			return;
		}
		while (true)
		{
			int num = -2074970770;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xF2EE5B71u) % 4)
				{
				case 3u:
					Delegate5.delegate5_29(Delegate7.delegate7_194(this), !Delegate21.delegate21_19(Delegate7.delegate7_198(this)));
					num = ((int)num2 * -995147666) ^ -420818861;
					continue;
				case 0u:
					Delegate5.delegate5_29(Delegate7.delegate7_196(this), !Delegate21.delegate21_19(Delegate7.delegate7_198(this)));
					num = (int)(num2 * 591582204) ^ -883280748;
					continue;
				default:
					return;
				case 2u:
					break;
				case 1u:
					return;
				}
				break;
			}
		}
	}

	private void method_4(object sender, EventArgs e)
	{
		Delegate5.delegate5_19(Delegate7.delegate7_202(this), bool_0: false);
		while (true)
		{
			int num = -652560691;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xED1A3ED0u) % 5)
				{
				case 3u:
					Delegate107.delegate107_1(Delegate7.delegate7_207(this), ref gclass9_0);
					num = (int)(num2 * 1471640839) ^ -1964682394;
					continue;
				case 2u:
					Delegate5.delegate5_19(Delegate7.delegate7_203(this), bool_0: false);
					num = (int)(num2 * 34232870) ^ -927746938;
					continue;
				case 1u:
					Delegate5.delegate5_19(Delegate7.delegate7_204(this), bool_0: true);
					Delegate8.delegate8_111(this, Delegate3.delegate3_51());
					num = (int)((num2 * 1291860316) ^ 0x45CFBD58);
					continue;
				default:
					return;
				case 4u:
					break;
				case 0u:
					return;
				}
				break;
			}
		}
	}

	private void method_5(object sender, EventArgs e)
	{
		Delegate5.delegate5_19(Delegate7.delegate7_202(this), bool_0: false);
		while (true)
		{
			int num = 2023792250;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x65A080EDu) % 4)
				{
				case 3u:
					Delegate5.delegate5_19(Delegate7.delegate7_203(this), bool_0: false);
					Delegate5.delegate5_19(Delegate7.delegate7_204(this), bool_0: true);
					num = (int)((num2 * 235665024) ^ 0x2E7219F);
					continue;
				case 2u:
					Delegate8.delegate8_111(this, Delegate3.delegate3_51());
					Delegate22.delegate22_46(this);
					num = ((int)num2 * -760692340) ^ 0x2B8ACF6C;
					continue;
				default:
					return;
				case 0u:
					break;
				case 1u:
					return;
				}
				break;
			}
		}
	}

	private void method_6(object sender, EventArgs e)
	{
		if (process_0 != null)
		{
			goto IL_0188;
		}
		goto IL_01be;
		IL_0188:
		int num = -24181805;
		goto IL_018d;
		IL_018d:
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0xDC6EFD9Au) % 8)
			{
			case 7u:
				Delegate5.delegate5_19(Delegate7.delegate7_203(this), (Delegate56.delegate56_0(Delegate15.delegate15_12(gclass9_0), "", bool_0: false) != 0) & (Delegate56.delegate56_0(Delegate15.delegate15_13(gclass9_0), "", bool_0: false) != 0) & (Delegate56.delegate56_0(Delegate15.delegate15_16(gclass9_0), "", bool_0: false) != 0) & (Delegate56.delegate56_0(Delegate15.delegate15_14(gclass9_0), "", bool_0: false) != 0) & (Delegate56.delegate56_0(Delegate15.delegate15_15(gclass9_0), "", bool_0: false) != 0));
				num = (int)((num2 * 1868231221) ^ 0x55F2565B);
				continue;
			case 6u:
				Delegate22.delegate22_47(process_0);
				num = ((int)num2 * -1011782389) ^ -589343731;
				continue;
			case 3u:
				Delegate8.delegate8_111(this, Delegate3.delegate3_52());
				num = (int)(num2 * 1321980839) ^ -201786925;
				continue;
			case 2u:
				Delegate5.delegate5_19(Delegate7.delegate7_204(this), bool_0: false);
				num = ((int)num2 * -221574108) ^ 0x79982DE9;
				continue;
			case 1u:
			{
				int num3;
				int num4;
				if (Delegate21.delegate21_20(process_0))
				{
					num3 = -1528854283;
					num4 = -1528854283;
				}
				else
				{
					num3 = -1409532666;
					num4 = -1409532666;
				}
				num = num3 ^ ((int)num2 * -1335847142);
				continue;
			}
			case 0u:
				break;
			default:
				return;
			case 5u:
				goto IL_01be;
			case 4u:
				return;
			}
			break;
		}
		goto IL_0188;
		IL_01be:
		Delegate5.delegate5_31(Delegate7.delegate7_207(this), bool_0: true);
		Delegate5.delegate5_19(Delegate7.delegate7_202(this), bool_0: true);
		num = -304318579;
		goto IL_018d;
	}

	private void method_7(GClass8.GEnum1 genum1_0)
	{
		try
		{
			if (Delegate21.delegate21_12(this))
			{
				goto IL_000d;
			}
			goto IL_0066;
			IL_000d:
			int num = -1782304511;
			goto IL_0045;
			IL_0045:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xCDB86060u) % 4)
				{
				case 2u:
					break;
				case 1u:
				{
					GDelegate10 object_ = method_7;
					Delegate112.smethod_0((object)this, (object)object_, new object[1] { genum1_0 });
					num = (int)((num2 * 1614972420) ^ 0x758E8FB);
					continue;
				}
				default:
					return;
				case 0u:
					goto IL_0066;
				case 3u:
					return;
				}
				break;
			}
			goto IL_000d;
			IL_0066:
			Delegate116.delegate116_1(this, genum1_0);
			num = -925572225;
			goto IL_0045;
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			Delegate51.delegate51_0();
		}
	}

	private void method_8(GClass8.GEnum1 genum1_0)
	{
		while (true)
		{
			int num = 1246060951;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x40484F09u) % 10)
				{
				case 7u:
					Delegate101.delegate101_1(Delegate7.delegate7_0(Delegate3.delegate3_1()), Delegate57.delegate57_1(global::_003CModule_003E.smethod_21<string>(2427265163u, 24680922u), Delegate15.delegate15_14(gclass9_0)), Delegate28.delegate28_1(), bool_0: true);
					num = (int)(num2 * 609523128) ^ -1946805781;
					continue;
				case 6u:
					Delegate5.delegate5_31(Delegate7.delegate7_207(this), bool_0: false);
					num = 784757081;
					continue;
				case 4u:
					Delegate101.delegate101_1(Delegate7.delegate7_0(Delegate3.delegate3_1()), Delegate57.delegate57_1(global::_003CModule_003E.smethod_21<string>(3696700302u, 3474615078u), Delegate15.delegate15_16(gclass9_0)), Delegate28.delegate28_1(), bool_0: true);
					Delegate101.delegate101_1(Delegate7.delegate7_0(Delegate3.delegate3_1()), Delegate57.delegate57_1(global::_003CModule_003E.smethod_18<string>(767019002u, 3165171125u), Delegate15.delegate15_12(gclass9_0)), Delegate28.delegate28_1(), bool_0: true);
					num = (int)(num2 * 1978219317) ^ -414820488;
					continue;
				case 3u:
					Delegate101.delegate101_1(Delegate7.delegate7_0(Delegate3.delegate3_1()), Delegate57.delegate57_1(global::_003CModule_003E.smethod_18<string>(197862967u, 3977784033u), Delegate15.delegate15_13(gclass9_0)), Delegate28.delegate28_1(), bool_0: true);
					num = ((int)num2 * -2079380343) ^ 0x2A5E1293;
					continue;
				case 2u:
					switch (genum1_0)
					{
					case GClass8.GEnum1.PixieSucced:
						break;
					default:
						num = ((int)num2 * -1363262061) ^ 0x2B9DF862;
						continue;
					case GClass8.GEnum1.Stop:
					case GClass8.GEnum1.Start:
					case GClass8.GEnum1.Testing:
					case (GClass8.GEnum1)3:
					case GClass8.GEnum1.Success:
					case GClass8.GEnum1.NACK:
					case GClass8.GEnum1.Updated:
					case GClass8.GEnum1.Locked:
					case GClass8.GEnum1.ApNotFound:
					case GClass8.GEnum1.AssociationFailed:
						return;
					}
					goto case 6u;
				case 1u:
					Delegate22.delegate22_46(this);
					num = ((int)num2 * -669737057) ^ 0x3D991FE4;
					continue;
				case 0u:
					Delegate101.delegate101_1(Delegate7.delegate7_0(Delegate3.delegate3_1()), Delegate57.delegate57_1(global::_003CModule_003E.smethod_22<string>(312476236u, 3213428828u), Delegate15.delegate15_15(gclass9_0)), Delegate28.delegate28_1(), bool_0: true);
					Delegate101.delegate101_1(Delegate7.delegate7_0(Delegate3.delegate3_1()), Delegate57.delegate57_1(global::_003CModule_003E.smethod_18<string>(4130924262u, 2575141279u), Delegate15.delegate15_17(gclass9_0)), Delegate28.delegate28_1(), bool_0: true);
					Delegate101.delegate101_1(Delegate7.delegate7_0(Delegate3.delegate3_1()), Delegate57.delegate57_1(global::_003CModule_003E.smethod_21<string>(4146628628u, 100653375u), Delegate15.delegate15_18(gclass9_0)), Delegate28.delegate28_1(), bool_0: true);
					Delegate101.delegate101_1(Delegate7.delegate7_0(Delegate3.delegate3_1()), Class13.string_4, Delegate28.delegate28_9(), bool_0: false);
					num = ((int)num2 * -1092777883) ^ -667420664;
					continue;
				default:
					return;
				case 5u:
					break;
				case 8u:
					return;
				case 9u:
					return;
				}
				break;
			}
		}
	}

	private void method_9()
	{
		string text = "";
		text = Delegate57.delegate57_1(global::_003CModule_003E.smethod_21<string>(2943777862u, 612144233u), Delegate15.delegate15_12(gclass9_0));
		string text2 = default(string);
		while (true)
		{
			int num = -1551971476;
			while (true)
			{
				uint num2;
				int num10;
				switch ((num2 = (uint)num ^ 0x98E0B339u) % 30)
				{
				case 28u:
					num = (int)((num2 * 2084313658) ^ 0x7D6BBECA);
					continue;
				case 27u:
					text += global::_003CModule_003E.smethod_20<string>(2208147368u, 2132307409u);
					num = -187227018;
					continue;
				case 26u:
					text = Delegate71.delegate71_0(text, global::_003CModule_003E.smethod_22<string>(1280518448u, 1742666120u), Delegate15.delegate15_16(gclass9_0));
					num = (int)((num2 * 1848648676) ^ 0x17BC8C18);
					continue;
				case 25u:
					goto IL_00a6;
				case 24u:
					Class6.Class7_0.MainForm_0.method_24(global::_003CModule_003E.smethod_19<string>(565866865u, 2082171133u) + text, Color.White, bool_4: true);
					text2 = GClass3.smethod_28(text, ref process_0);
					Class6.Class7_0.MainForm_0.method_24(text2, Color.White, bool_4: true);
					Class6.Class7_0.MainForm_0.method_24(Class13.string_4, Color.LightGreen, bool_4: false);
					num = (int)(num2 * 91702153) ^ -1042067465;
					continue;
				case 23u:
				{
					text = Delegate71.delegate71_0(text, global::_003CModule_003E.smethod_18<string>(2901492111u, 3906455255u), Delegate15.delegate15_17(gclass9_0));
					int num7;
					int num8;
					if (Delegate21.delegate21_19(Delegate7.delegate7_200(this)))
					{
						num7 = -243488413;
						num8 = -243488413;
					}
					else
					{
						num7 = -1786607604;
						num8 = -1786607604;
					}
					num = num7 ^ (int)(num2 * 1685270178);
					continue;
				}
				case 22u:
					text = Delegate71.delegate71_0(text, global::_003CModule_003E.smethod_20<string>(1532723364u, 2086866848u), Delegate15.delegate15_18(gclass9_0));
					num = ((int)num2 * -591626663) ^ 0x3B031616;
					continue;
				case 21u:
					text = Delegate71.delegate71_0(text, global::_003CModule_003E.smethod_18<string>(713413729u, 2825518150u), Delegate15.delegate15_9(gclass9_0));
					num = (int)(num2 * 1289716012) ^ -365561140;
					continue;
				case 20u:
					num = (int)((num2 * 1730819371) ^ 0x9C41BB4);
					continue;
				case 19u:
					text += global::_003CModule_003E.smethod_20<string>(502532852u, 1778412838u);
					num = ((int)num2 * -2027921317) ^ -1497187901;
					continue;
				case 18u:
					text += global::_003CModule_003E.smethod_19<string>(1571016786u, 2999516587u);
					num = ((int)num2 * -1446866018) ^ 0x478AA389;
					continue;
				case 17u:
					text = Delegate71.delegate71_0(text, global::_003CModule_003E.smethod_22<string>(1839711126u, 2246335328u), Delegate15.delegate15_13(gclass9_0));
					text = Delegate71.delegate71_0(text, global::_003CModule_003E.smethod_18<string>(4039804181u, 3726350501u), Delegate15.delegate15_14(gclass9_0));
					num = (int)(num2 * 311595460) ^ -1418610325;
					continue;
				case 16u:
					goto IL_02f1;
				case 15u:
					text += string.Format(global::_003CModule_003E.smethod_18<string>(968568479u, 3593131215u), DateTimePicker_0.Value.ToString(global::_003CModule_003E.smethod_18<string>(3556067670u, 1149361582u)), DateTimePicker_1.Value.ToString(global::_003CModule_003E.smethod_20<string>(3929227387u, 2395225781u)));
					num = ((int)num2 * -896339992) ^ -1245484194;
					continue;
				case 14u:
					text = Delegate71.delegate71_0(text, global::_003CModule_003E.smethod_21<string>(1362145988u, 2248845050u), Delegate15.delegate15_15(gclass9_0));
					num = (int)(num2 * 717915976) ^ -5320413;
					continue;
				case 13u:
					text += string.Format(global::_003CModule_003E.smethod_20<string>(4170677246u, 2707360885u), Delegate25.delegate25_2(Delegate7.delegate7_194(this)).ToString(global::_003CModule_003E.smethod_19<string>(4127252261u, 1052784428u)), DateTimePicker_1.Value.ToString(global::_003CModule_003E.smethod_22<string>(3346189223u, 2440493198u)));
					num = ((int)num2 * -1814899394) ^ 0x22D5DC61;
					continue;
				case 12u:
					goto IL_043d;
				case 11u:
				{
					int num9;
					if (Delegate21.delegate21_19(Delegate7.delegate7_201(this)))
					{
						num = -1419957248;
						num9 = -1419957248;
					}
					else
					{
						num = -95425536;
						num9 = -95425536;
					}
					continue;
				}
				case 10u:
					num = (int)(num2 * 1506739344) ^ -111903722;
					continue;
				case 9u:
					goto IL_04b6;
				case 8u:
					Class13.smethod_11(text2, ref gclass12_0);
					num = (int)((num2 * 719109467) ^ 0x75BA67CF);
					continue;
				case 7u:
					num = ((int)num2 * -1302649680) ^ -1391122682;
					continue;
				case 6u:
				{
					int num5;
					int num6;
					if (CheckBox_0.Checked)
					{
						num5 = 194051262;
						num6 = 194051262;
					}
					else
					{
						num5 = 350193656;
						num6 = 350193656;
					}
					num = num5 ^ ((int)num2 * -1585880500);
					continue;
				}
				case 5u:
					switch (Delegate17.delegate17_19(Delegate7.delegate7_191(this)))
					{
					case 2:
						break;
					case 5:
						goto IL_00a6;
					case 1:
						goto IL_02f1;
					case 0:
						goto IL_043d;
					case 4:
						goto IL_04b6;
					default:
						goto IL_056f;
					case 3:
						goto IL_0576;
					}
					goto case 27u;
				case 4u:
					goto IL_0576;
				case 3u:
				{
					int num4;
					if (CheckBox_0.Checked)
					{
						num = -1723411661;
						num4 = -1723411661;
					}
					else
					{
						num = -1461475419;
						num4 = -1461475419;
					}
					continue;
				}
				case 2u:
				{
					int num3;
					if (CheckBox_3.Checked)
					{
						num = -1342400708;
						num3 = -1342400708;
					}
					else
					{
						num = -287304700;
						num3 = -287304700;
					}
					continue;
				}
				case 1u:
					process_0 = new Process();
					num = -351137103;
					continue;
				case 29u:
					break;
				default:
					{
						ToolStripButton_2.PerformClick();
						return;
					}
					IL_0576:
					text += global::_003CModule_003E.smethod_19<string>(2515235806u, 67350638u);
					num = -774850177;
					continue;
					IL_056f:
					num = -585284228;
					continue;
					IL_04b6:
					text += global::_003CModule_003E.smethod_21<string>(1311570038u, 1019569688u);
					num = -1224923537;
					continue;
					IL_043d:
					if (!Delegate21.delegate21_19(Delegate7.delegate7_198(this)))
					{
						num = -1639068112;
						num10 = -1639068112;
					}
					else
					{
						num = -187227018;
						num10 = -187227018;
					}
					continue;
					IL_00a6:
					text += global::_003CModule_003E.smethod_22<string>(143756644u, 3170600668u);
					num = -187227018;
					continue;
					IL_02f1:
					text += global::_003CModule_003E.smethod_21<string>(3662209706u, 2600912106u);
					num = -2113171073;
					continue;
				}
				break;
			}
		}
	}
}
