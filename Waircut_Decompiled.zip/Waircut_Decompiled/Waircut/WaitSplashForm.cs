using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using ns1;

namespace Waircut;

[DesignerGenerated]
public class WaitSplashForm : Form
{
	private IContainer icontainer_0;

	[CompilerGenerated]
	[AccessedThroughProperty("Panel1")]
	private Panel panel_0;

	[CompilerGenerated]
	[AccessedThroughProperty("ProgressBar")]
	private ProgressBar progressBar_0;

	[CompilerGenerated]
	[AccessedThroughProperty("lbMessage")]
	private Label label_0;

	private string string_0;

	private int int_0;

	private Form form_0;

	private int int_1;

	internal virtual Panel Panel_0
	{
		[CompilerGenerated]
		get
		{
			return panel_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			panel_0 = value;
		}
	}

	internal virtual ProgressBar ProgressBar_0
	{
		[CompilerGenerated]
		get
		{
			return progressBar_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			progressBar_0 = value;
		}
	}

	internal virtual Label Label_0
	{
		[CompilerGenerated]
		get
		{
			return label_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_0 = value;
		}
	}

	public int Int32_0
	{
		get
		{
			return int_1;
		}
		set
		{
			int_1 = value;
			while (true)
			{
				int num = -1546889689;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xE19690EAu) % 4)
					{
					case 2u:
						Delegate22.delegate22_66(Delegate7.delegate7_256(this));
						num = ((int)num2 * -1205188683) ^ -935988084;
						continue;
					case 1u:
						Delegate32.delegate32_16(Delegate7.delegate7_256(this), checked((int)Delegate69.delegate69_0((double)(int_1 * 100) / (double)int_0)));
						num = ((int)num2 * -1101786633) ^ -406547009;
						continue;
					default:
						return;
					case 3u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
	}

	[DebuggerNonUserCode]
	void Form.Dispose(bool disposing)
	{
		try
		{
			if (!disposing)
			{
				return;
			}
			while (true)
			{
				int num = 893062985;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x576F8C0u) % 4)
					{
					case 1u:
					{
						int num3;
						int num4;
						if (icontainer_0 != null)
						{
							num3 = -194875130;
							num4 = -194875130;
						}
						else
						{
							num3 = -199116647;
							num4 = -199116647;
						}
						num = num3 ^ (int)(num2 * 1360698214);
						continue;
					}
					case 0u:
						Delegate22.delegate22_4(icontainer_0);
						num = (int)((num2 * 1039059345) ^ 0x5A3E9C5F);
						continue;
					default:
						return;
					case 2u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
		finally
		{
			Delegate5.delegate5_3(this, disposing);
		}
	}

	[DebuggerStepThrough]
	private void method_0()
	{
		Delegate8.delegate8_297(this, Delegate3.delegate3_14());
		while (true)
		{
			int num = -678630397;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x994BA911u) % 27)
				{
				case 26u:
					base.Controls.Add(Panel_0);
					num = ((int)num2 * -1837761708) ^ 0x42D2152B;
					continue;
				case 25u:
					Panel_0.Size = new Size(161, 42);
					num = (int)((num2 * 927612370) ^ 0x1416F6E6);
					continue;
				case 24u:
					Panel_0.TabIndex = 2;
					num = ((int)num2 * -124106653) ^ -429604726;
					continue;
				case 23u:
					ProgressBar_0.Dock = DockStyle.Bottom;
					num = (int)(num2 * 631238497) ^ -1880062731;
					continue;
				case 22u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_254(this)), Delegate7.delegate7_255(this));
					num = (int)(num2 * 1211021444) ^ -1842565780;
					continue;
				case 21u:
					ProgressBar_0.Size = new Size(159, 17);
					ProgressBar_0.TabIndex = 2;
					Label_0.Dock = DockStyle.Fill;
					num = (int)((num2 * 627033846) ^ 0x617E57EB);
					continue;
				case 20u:
					Label_0.TextAlign = ContentAlignment.MiddleCenter;
					base.AutoScaleDimensions = new SizeF(6f, 13f);
					base.AutoScaleMode = AutoScaleMode.Font;
					num = (int)(num2 * 655706149) ^ -703746754;
					continue;
				case 18u:
					DoubleBuffered = true;
					base.FormBorderStyle = FormBorderStyle.None;
					base.Name = global::_003CModule_003E.smethod_19<string>(2445200549u, 3985826970u);
					num = ((int)num2 * -502619781) ^ 0x2153EF8D;
					continue;
				case 17u:
					Delegate211.delegate211_0(Delegate7.delegate7_254(this), BorderStyle.FixedSingle);
					num = (int)(num2 * 667988569) ^ -1245431601;
					continue;
				case 16u:
					base.StartPosition = FormStartPosition.CenterParent;
					num = (int)((num2 * 1443490432) ^ 0x3B80B22E);
					continue;
				case 15u:
					Label_0.Location = new Point(0, 0);
					num = (int)((num2 * 373894095) ^ 0x50B1799F);
					continue;
				case 14u:
					Label_0.Name = global::_003CModule_003E.smethod_21<string>(335926392u, 3977509354u);
					num = (int)((num2 * 1667380734) ^ 0x11CE0000);
					continue;
				case 13u:
					base.Opacity = 0.9;
					num = (int)((num2 * 625923566) ^ 0x13A89E8B);
					continue;
				case 12u:
					Label_0.Font = new Font(global::_003CModule_003E.smethod_20<string>(3097883821u, 991085889u), 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
					num = (int)(num2 * 1203119279) ^ -1461016563;
					continue;
				case 11u:
					Panel_0.ResumeLayout(performLayout: false);
					ResumeLayout(performLayout: false);
					num = ((int)num2 * -218197465) ^ -1107179999;
					continue;
				case 10u:
					Delegate8.delegate8_298(this, Delegate3.delegate3_113());
					Delegate8.delegate8_299(this, Delegate3.delegate3_9());
					Delegate22.delegate22_5(Delegate7.delegate7_254(this));
					Delegate22.delegate22_7(this);
					num = ((int)num2 * -2081601646) ^ -791499619;
					continue;
				case 9u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_254(this)), Delegate7.delegate7_256(this));
					Delegate212.delegate212_0(Delegate7.delegate7_254(this), DockStyle.Fill);
					num = ((int)num2 * -1358379267) ^ -676354510;
					continue;
				case 8u:
					ProgressBar_0.Location = new Point(0, 23);
					ProgressBar_0.Name = global::_003CModule_003E.smethod_19<string>(1443770071u, 1994533814u);
					num = (int)((num2 * 1321091968) ^ 0x73919205);
					continue;
				case 7u:
					base.ShowInTaskbar = false;
					num = (int)((num2 * 218194803) ^ 0xE97521B);
					continue;
				case 6u:
					Label_0.Text = global::_003CModule_003E.smethod_18<string>(1587192347u, 3822892495u);
					num = (int)((num2 * 947974841) ^ 0x45975F07);
					continue;
				case 5u:
					Label_0.Size = new Size(159, 23);
					Label_0.TabIndex = 3;
					num = ((int)num2 * -1975840946) ^ -713428617;
					continue;
				case 4u:
					base.TopMost = true;
					num = ((int)num2 * -852652468) ^ -618965181;
					continue;
				case 2u:
					Text = global::_003CModule_003E.smethod_22<string>(2396856615u, 2418699675u);
					num = (int)((num2 * 1751114183) ^ 0x4463DE3C);
					continue;
				case 1u:
					base.ClientSize = new Size(161, 42);
					num = ((int)num2 * -1725268282) ^ -1631196537;
					continue;
				case 0u:
					((Control)Delegate7.delegate7_254(this)).Location = new Point(0, 0);
					Panel_0.Name = global::_003CModule_003E.smethod_18<string>(132763964u, 1616087170u);
					num = ((int)num2 * -1251619541) ^ 0x21A139D6;
					continue;
				default:
					return;
				case 3u:
					break;
				case 19u:
					return;
				}
				break;
			}
		}
	}

	public WaitSplashForm(string string_1, int int_2, Form form_1 = null)
	{
		while (true)
		{
			int num = 1040193876;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x2958CA3Fu) % 5)
				{
				case 4u:
					Delegate8.delegate8_3(this, new EventHandler(method_1));
					string_0 = "";
					int_0 = 100;
					num = (int)(num2 * 1090594331) ^ -231102154;
					continue;
				case 2u:
					form_0 = null;
					Delegate22.delegate22_65(this);
					string_0 = string_1;
					num = (int)((num2 * 756564385) ^ 0x481D77B7);
					continue;
				case 0u:
					int_0 = int_2;
					form_0 = form_1;
					num = ((int)num2 * -1395308682) ^ 0x6B6FDBD1;
					continue;
				default:
					return;
				case 3u:
					break;
				case 1u:
					return;
				}
				break;
			}
		}
	}

	private void method_1(object sender, EventArgs e)
	{
		Delegate30.delegate30_4(Delegate7.delegate7_255(this), string_0);
		Delegate22.delegate22_67(this);
	}

	private void method_2()
	{
		if (form_0 != null)
		{
			goto IL_000b;
		}
		goto IL_00c7;
		IL_000b:
		int num = 1828200884;
		goto IL_009a;
		IL_009a:
		int num4 = default(int);
		Rectangle rectangle = default(Rectangle);
		int num3 = default(int);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0x1046531Eu) % 7)
			{
			case 6u:
				break;
			case 4u:
				checked
				{
					num4 = rectangle.Top + unchecked(checked(rectangle.Height - base.Height) / 3);
				}
				num = (int)((num2 * 675348545) ^ 0x4AF3C6F1);
				continue;
			case 3u:
				rectangle = Delegate213.delegate213_0(form_0, Delegate61.delegate61_1(form_0));
				num = (int)((num2 * 1322080794) ^ 0x5E88A453);
				continue;
			case 1u:
				checked
				{
					num3 = rectangle.Left + unchecked(checked(rectangle.Width - base.Width) / 2);
					num = 1294580211;
					continue;
				}
			case 0u:
				num = ((int)num2 * -788081491) ^ 0xFD3D987;
				continue;
			case 5u:
				goto IL_00c7;
			default:
				base.Location = new Point(num3, num4);
				return;
			}
			break;
		}
		goto IL_000b;
		IL_00c7:
		rectangle = Delegate61.delegate61_2(Delegate215.delegate215_0(Delegate214.delegate214_0(this)));
		num = 401119634;
		goto IL_009a;
	}
}
