using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using ns1;

namespace Waircut;

[DesignerGenerated]
public class WpsPinForm : Form
{
	private IContainer icontainer_0;

	[CompilerGenerated]
	[AccessedThroughProperty("bnavWpsPin")]
	private BindingNavigator bindingNavigator_0;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorAddNewItem")]
	private ToolStripButton toolStripButton_0;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorCountItem")]
	private ToolStripLabel toolStripLabel_0;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorDeleteItem")]
	private ToolStripButton toolStripButton_1;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorMoveFirstItem")]
	private ToolStripButton toolStripButton_2;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorMovePreviousItem")]
	private ToolStripButton toolStripButton_3;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorSeparator")]
	private ToolStripSeparator toolStripSeparator_0;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorPositionItem")]
	private ToolStripTextBox toolStripTextBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorSeparator1")]
	private ToolStripSeparator toolStripSeparator_1;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorMoveNextItem")]
	private ToolStripButton toolStripButton_4;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorMoveLastItem")]
	private ToolStripButton toolStripButton_5;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorSeparator2")]
	private ToolStripSeparator toolStripSeparator_2;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolStripSeparator1")]
	private ToolStripSeparator toolStripSeparator_3;

	[CompilerGenerated]
	[AccessedThroughProperty("tbSearch")]
	private ToolStripTextBox toolStripTextBox_1;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvWps")]
	private DataGridView dataGridView_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tbExport")]
	private ToolStripButton toolStripButton_6;

	[CompilerGenerated]
	[AccessedThroughProperty("tbImport")]
	private ToolStripButton toolStripButton_7;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolStripLabel1")]
	private ToolStripLabel toolStripLabel_1;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolTip1")]
	private ToolTip toolTip_0;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvWPSId")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_0;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvWpsDeviceName")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_1;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvWPSModelName")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_2;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvWPSModelNumber")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_3;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvWpsBssid")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_4;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvWpsPin")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_5;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvWpsAlgorithmId")]
	private DataGridViewComboBoxColumn dataGridViewComboBoxColumn_0;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvWpsPixie")]
	private DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn_0;

	private SQLiteConnection sqliteConnection_0;

	private SQLiteCommand sqliteCommand_0;

	private SQLiteDataAdapter sqliteDataAdapter_0;

	private SQLiteCommandBuilder sqliteCommandBuilder_0;

	private DataTable dataTable_0;

	[CompilerGenerated]
	[AccessedThroughProperty("bsPin")]
	private BindingSource bindingSource_0;

	private SQLiteCommand sqliteCommand_1;

	private SQLiteDataAdapter sqliteDataAdapter_1;

	private DataTable dataTable_1;

	internal virtual BindingNavigator BindingNavigator_0
	{
		[CompilerGenerated]
		get
		{
			return bindingNavigator_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			bindingNavigator_0 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_0 = value;
		}
	}

	internal virtual ToolStripLabel ToolStripLabel_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripLabel_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripLabel_0 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_4;
			ToolStripButton toolStripButton = toolStripButton_1;
			while (true)
			{
				int num = 2033247419;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x18F953B0u) % 7)
					{
					case 6u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = ((int)num2 * -800329954) ^ -2077734228;
						continue;
					case 5u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = ((int)num2 * -929348194) ^ 0x57C00323;
						continue;
					case 4u:
					{
						toolStripButton = toolStripButton_1;
						int num5;
						int num6;
						if (toolStripButton != null)
						{
							num5 = -101739271;
							num6 = -101739271;
						}
						else
						{
							num5 = -1578733112;
							num6 = -1578733112;
						}
						num = num5 ^ (int)(num2 * 1367513266);
						continue;
					}
					case 3u:
					{
						int num3;
						int num4;
						if (toolStripButton != null)
						{
							num3 = 1261414219;
							num4 = 1261414219;
						}
						else
						{
							num3 = 97318565;
							num4 = 97318565;
						}
						num = num3 ^ ((int)num2 * -1234120724);
						continue;
					}
					case 1u:
						toolStripButton_1 = value;
						num = 236343323;
						continue;
					default:
						return;
					case 0u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripButton ToolStripButton_2
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_2 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_3
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_3 = value;
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_0 = value;
		}
	}

	internal virtual ToolStripTextBox ToolStripTextBox_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripTextBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripTextBox_0 = value;
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_1 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_4
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_4 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_5
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_5;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_5 = value;
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_2
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_2 = value;
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_3
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_3 = value;
		}
	}

	internal virtual ToolStripTextBox ToolStripTextBox_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripTextBox_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_2;
			ToolStripTextBox toolStripTextBox = default(ToolStripTextBox);
			while (true)
			{
				int num = -1983734175;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x98FC1B6Fu) % 8)
					{
					case 6u:
						toolStripTextBox = toolStripTextBox_1;
						num = (int)((num2 * 61704333) ^ 0x6CD76811);
						continue;
					case 4u:
						Delegate8.delegate8_90(toolStripTextBox, object_);
						num = (int)(num2 * 88085093) ^ -593947647;
						continue;
					case 3u:
					{
						int num5;
						int num6;
						if (toolStripTextBox != null)
						{
							num5 = -2122915325;
							num6 = -2122915325;
						}
						else
						{
							num5 = -862200313;
							num6 = -862200313;
						}
						num = num5 ^ (int)(num2 * 427947591);
						continue;
					}
					case 2u:
						toolStripTextBox_1 = value;
						toolStripTextBox = toolStripTextBox_1;
						num = -520323740;
						continue;
					case 1u:
						Delegate8.delegate8_91(toolStripTextBox, object_);
						num = (int)((num2 * 1948548698) ^ 0x5A953D10);
						continue;
					case 0u:
					{
						int num3;
						int num4;
						if (toolStripTextBox != null)
						{
							num3 = 1983144003;
							num4 = 1983144003;
						}
						else
						{
							num3 = 321787485;
							num4 = 321787485;
						}
						num = num3 ^ ((int)num2 * -1872020393);
						continue;
					}
					default:
						return;
					case 7u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual DataGridView DataGridView_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridView_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DataGridViewCellEventHandler object_ = method_3;
			DataGridView dataGridView = default(DataGridView);
			DataGridViewDataErrorEventHandler object_2 = default(DataGridViewDataErrorEventHandler);
			DataGridViewCellCancelEventHandler object_3 = default(DataGridViewCellCancelEventHandler);
			KeyEventHandler object_5 = default(KeyEventHandler);
			DataGridViewRowsRemovedEventHandler object_4 = default(DataGridViewRowsRemovedEventHandler);
			while (true)
			{
				int num = 833265357;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x19BD8753u) % 17)
					{
					case 16u:
						Delegate8.delegate8_81(dataGridView, object_2);
						num = (int)(num2 * 1099499194) ^ -1021216801;
						continue;
					case 15u:
						object_2 = method_7;
						num = (int)(num2 * 167375843) ^ -585233649;
						continue;
					case 13u:
						dataGridView_0 = value;
						num = 257897096;
						continue;
					case 12u:
					{
						int num5;
						int num6;
						if (dataGridView != null)
						{
							num5 = 720674115;
							num6 = 720674115;
						}
						else
						{
							num5 = 1321794799;
							num6 = 1321794799;
						}
						num = num5 ^ (int)(num2 * 1244823257);
						continue;
					}
					case 11u:
						object_3 = method_10;
						num = (int)((num2 * 1560357444) ^ 0x2C79E4B3);
						continue;
					case 10u:
						Delegate8.delegate8_339(dataGridView, object_3);
						num = (int)((num2 * 2130690515) ^ 0x369B37C5);
						continue;
					case 9u:
						Delegate8.delegate8_83(dataGridView, object_);
						Delegate8.delegate8_84(dataGridView, object_5);
						Delegate8.delegate8_85(dataGridView, object_4);
						num = ((int)num2 * -1077054126) ^ 0x48AB5B41;
						continue;
					case 8u:
						object_5 = method_5;
						num = ((int)num2 * -282629554) ^ 0x38919458;
						continue;
					case 7u:
						Delegate8.delegate8_79(dataGridView, object_5);
						num = ((int)num2 * -198939942) ^ 0x1499C717;
						continue;
					case 6u:
						Delegate8.delegate8_78(dataGridView, object_);
						num = ((int)num2 * -805514122) ^ 0x329C5923;
						continue;
					case 5u:
						object_4 = method_6;
						num = ((int)num2 * -2008711330) ^ -777793851;
						continue;
					case 4u:
					{
						dataGridView = dataGridView_0;
						int num3;
						int num4;
						if (dataGridView == null)
						{
							num3 = 2111581043;
							num4 = 2111581043;
						}
						else
						{
							num3 = 1980927237;
							num4 = 1980927237;
						}
						num = num3 ^ ((int)num2 * -1223185220);
						continue;
					}
					case 2u:
						dataGridView = dataGridView_0;
						num = (int)((num2 * 140387604) ^ 0x6DBCB86D);
						continue;
					case 1u:
						Delegate8.delegate8_80(dataGridView, object_4);
						num = (int)((num2 * 1873885441) ^ 0x31BACAF4);
						continue;
					case 0u:
						Delegate8.delegate8_86(dataGridView, object_2);
						Delegate8.delegate8_340(dataGridView, object_3);
						num = ((int)num2 * -1667236822) ^ -1553091615;
						continue;
					default:
						return;
					case 14u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripButton ToolStripButton_6
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_6;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_6 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_7
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_7;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_7 = value;
		}
	}

	internal virtual ToolStripLabel ToolStripLabel_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripLabel_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripLabel_1 = value;
		}
	}

	internal virtual ToolTip ToolTip_0
	{
		[CompilerGenerated]
		get
		{
			return toolTip_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolTip_0 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_0 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_1
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_1 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_2
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_2 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_3
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_3 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_4
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_4 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_5
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_5;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_5 = value;
		}
	}

	internal virtual DataGridViewComboBoxColumn DataGridViewComboBoxColumn_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewComboBoxColumn_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewComboBoxColumn_0 = value;
		}
	}

	internal virtual DataGridViewCheckBoxColumn DataGridViewCheckBoxColumn_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewCheckBoxColumn_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewCheckBoxColumn_0 = value;
		}
	}

	private virtual BindingSource BindingSource_0
	{
		[CompilerGenerated]
		get
		{
			return bindingSource_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			AddingNewEventHandler object_ = method_8;
			BindingSource bindingSource = default(BindingSource);
			while (true)
			{
				int num = 1393799757;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x6684C1CEu) % 7)
					{
					case 6u:
						Delegate8.delegate8_342(bindingSource, object_);
						num = ((int)num2 * -1929041875) ^ 0x44F3C845;
						continue;
					case 5u:
						Delegate8.delegate8_341(bindingSource, object_);
						num = ((int)num2 * -317736826) ^ 0x299EB251;
						continue;
					case 4u:
						bindingSource_0 = value;
						num = 908284830;
						continue;
					case 1u:
					{
						bindingSource = bindingSource_0;
						int num5;
						int num6;
						if (bindingSource == null)
						{
							num5 = 1701756857;
							num6 = 1701756857;
						}
						else
						{
							num5 = 2037559391;
							num6 = 2037559391;
						}
						num = num5 ^ ((int)num2 * -1283288210);
						continue;
					}
					case 0u:
					{
						bindingSource = bindingSource_0;
						int num3;
						int num4;
						if (bindingSource != null)
						{
							num3 = 1660384567;
							num4 = 1660384567;
						}
						else
						{
							num3 = 1023567424;
							num4 = 1023567424;
						}
						num = num3 ^ (int)(num2 * 2024944122);
						continue;
					}
					default:
						return;
					case 3u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	public WpsPinForm()
	{
		Delegate8.delegate8_3(this, new EventHandler(method_1));
		sqliteConnection_0 = new SQLiteConnection(global::_003CModule_003E.smethod_19<string>(225254862u, 2328328186u));
		dataTable_0 = new DataTable();
		Delegate8.delegate8_308(this, Delegate3.delegate3_17());
		dataTable_1 = new DataTable();
		Delegate22.delegate22_71(this);
	}

	[DebuggerNonUserCode]
	void Form.Dispose(bool disposing)
	{
		try
		{
			if (!disposing)
			{
				return;
			}
			while (true)
			{
				int num = -1526036699;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x9C3F8AC8u) % 4)
					{
					case 2u:
						Delegate22.delegate22_4(icontainer_0);
						num = ((int)num2 * -1909353457) ^ -168556818;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (icontainer_0 == null)
						{
							num3 = 1324903814;
							num4 = 1324903814;
						}
						else
						{
							num3 = 1749769468;
							num4 = 1749769468;
						}
						num = num3 ^ ((int)num2 * -1357788246);
						continue;
					}
					default:
						return;
					case 3u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
		finally
		{
			Delegate5.delegate5_3(this, disposing);
		}
	}

	[DebuggerStepThrough]
	private void method_0()
	{
		icontainer_0 = (IContainer)Delegate3.delegate3_19();
		ComponentResourceManager object_ = default(ComponentResourceManager);
		DataGridViewCellStyle dataGridViewCellStyle2 = default(DataGridViewCellStyle);
		DataGridViewCellStyle dataGridViewCellStyle = default(DataGridViewCellStyle);
		while (true)
		{
			int num = -339535421;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xA9ADEC57u) % 91)
				{
				case 90u:
					Delegate30.delegate30_1(Delegate7.delegate7_276(this), global::_003CModule_003E.smethod_21<string>(391065187u, 1937292997u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_276(this), global::_003CModule_003E.smethod_20<string>(365872389u, 1087745127u));
					Delegate46.delegate46_0(Delegate7.delegate7_277(this), ToolStripItemDisplayStyle.Image);
					num = ((int)num2 * -422709461) ^ 0x1EC780D;
					continue;
				case 89u:
					Delegate30.delegate30_1(Delegate7.delegate7_280(this), global::_003CModule_003E.smethod_18<string>(2847334927u, 3032138184u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_280(this), global::_003CModule_003E.smethod_22<string>(3954369678u, 2496748456u));
					num = ((int)num2 * -1508651702) ^ 0x26848EF1;
					continue;
				case 88u:
					Delegate30.delegate30_2(this, global::_003CModule_003E.smethod_20<string>(3020556306u, 4292373484u));
					Delegate22.delegate22_9(Delegate7.delegate7_263(this));
					num = ((int)num2 * -208077889) ^ 0x107A029B;
					continue;
				case 87u:
					Delegate46.delegate46_0(Delegate7.delegate7_268(this), ToolStripItemDisplayStyle.Image);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_268(this), global::_003CModule_003E.smethod_18<string>(2509886887u, 1091330213u));
					Delegate30.delegate30_1(Delegate7.delegate7_268(this), global::_003CModule_003E.smethod_20<string>(3165744022u, 1188004000u));
					num = ((int)num2 * -413151584) ^ -1800037239;
					continue;
				case 86u:
					Delegate8.delegate8_77(Delegate7.delegate7_270(this), Delegate3.delegate3_31());
					Delegate30.delegate30_1(Delegate7.delegate7_270(this), global::_003CModule_003E.smethod_19<string>(3687237960u, 630235044u));
					num = ((int)num2 * -2834879) ^ -1267196691;
					continue;
				case 85u:
					Delegate8.delegate8_77(Delegate7.delegate7_277(this), Delegate3.delegate3_34());
					num = (int)(num2 * 1253596112) ^ -1598935654;
					continue;
				case 84u:
					object_ = (ComponentResourceManager)Delegate7.delegate7_4(Delegate9.delegate9_0(typeof(WpsPinForm).TypeHandle));
					dataGridViewCellStyle2 = (DataGridViewCellStyle)Delegate3.delegate3_20();
					num = (int)(num2 * 1512889970) ^ -891744614;
					continue;
				case 83u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_266(this), global::_003CModule_003E.smethod_21<string>(4047873547u, 633541734u));
					num = ((int)num2 * -544994944) ^ -621132104;
					continue;
				case 82u:
					Delegate30.delegate30_6(Delegate7.delegate7_284(this), global::_003CModule_003E.smethod_18<string>(2518254383u, 2976126370u));
					num = ((int)num2 * -2010065106) ^ -1420762168;
					continue;
				case 81u:
					Delegate8.delegate8_330(this, Delegate3.delegate3_23());
					Delegate8.delegate8_331(this, Delegate3.delegate3_23());
					num = (int)(num2 * 171299046) ^ -905557861;
					continue;
				case 80u:
					Delegate30.delegate30_1(Delegate7.delegate7_267(this), global::_003CModule_003E.smethod_19<string>(1948506139u, 2291436419u));
					num = (int)((num2 * 176424334) ^ 0x5B30B853);
					continue;
				case 79u:
					Delegate8.delegate8_320(this, Delegate3.delegate3_24());
					Delegate8.delegate8_321(this, Delegate3.delegate3_26());
					Delegate8.delegate8_322(this, Delegate3.delegate3_24());
					num = ((int)num2 * -1933827832) ^ 0xFB0B7F7;
					continue;
				case 78u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_264(this));
					num = (int)((num2 * 80858535) ^ 0x55BDE68C);
					continue;
				case 77u:
					Delegate5.delegate5_10(Delegate7.delegate7_263(this), bool_0: false);
					Delegate22.delegate22_8(Delegate7.delegate7_263(this));
					num = ((int)num2 * -1137908524) ^ -713836642;
					continue;
				case 76u:
					Delegate30.delegate30_6(Delegate7.delegate7_287(this), global::_003CModule_003E.smethod_20<string>(3503456024u, 2837137587u));
					Delegate30.delegate30_5(Delegate7.delegate7_288(this), global::_003CModule_003E.smethod_19<string>(2055950095u, 715780676u));
					num = ((int)num2 * -1330395791) ^ -686289397;
					continue;
				case 75u:
					Delegate8.delegate8_68(Delegate7.delegate7_285(this), dataGridViewCellStyle);
					num = ((int)num2 * -8063411) ^ -1001855552;
					continue;
				case 74u:
					Delegate41.delegate41_0(Delegate7.delegate7_264(this), DataGridViewSelectionMode.FullRowSelect);
					num = ((int)num2 * -1645301543) ^ -1756921766;
					continue;
				case 73u:
					Delegate8.delegate8_311(this, Delegate3.delegate3_25());
					Delegate8.delegate8_312(this, Delegate3.delegate3_24());
					num = (int)((num2 * 1144482760) ^ 0x3E54A83B);
					continue;
				case 72u:
					Delegate8.delegate8_323(this, Delegate3.delegate3_26());
					Delegate8.delegate8_324(this, Delegate3.delegate3_25());
					Delegate8.delegate8_325(this, Delegate3.delegate3_27());
					Delegate8.delegate8_326(this, Delegate3.delegate3_21());
					num = ((int)num2 * -1852867556) ^ -943202383;
					continue;
				case 71u:
					Delegate8.delegate8_317(this, Delegate3.delegate3_27());
					Delegate8.delegate8_318(this, Delegate3.delegate3_26());
					num = ((int)num2 * -351033887) ^ -1714561583;
					continue;
				case 70u:
					Delegate8.delegate8_77(Delegate7.delegate7_275(this), Delegate3.delegate3_33());
					num = ((int)num2 * -473672843) ^ 0x27AC26FF;
					continue;
				case 69u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_264(this), global::_003CModule_003E.smethod_18<string>(3812785537u, 1734839650u));
					num = (int)(num2 * 2105588178) ^ -1438028010;
					continue;
				case 68u:
					Delegate30.delegate30_1(Delegate7.delegate7_277(this), global::_003CModule_003E.smethod_20<string>(1105687469u, 3224889329u));
					num = (int)((num2 * 1358639558) ^ 0x7E41CADF);
					continue;
				case 67u:
					Delegate39.delegate39_0(Delegate7.delegate7_264(this), DataGridViewColumnHeadersHeightSizeMode.AutoSize);
					num = ((int)num2 * -57604884) ^ -1509686105;
					continue;
				case 66u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_279(this), global::_003CModule_003E.smethod_21<string>(4155831249u, 3586492938u));
					Delegate29.delegate29_4(Delegate7.delegate7_280(this), Delegate28.delegate28_5());
					num = ((int)num2 * -991518264) ^ -785908125;
					continue;
				case 65u:
					Delegate30.delegate30_1(Delegate7.delegate7_265(this), global::_003CModule_003E.smethod_20<string>(1557656181u, 4102457394u));
					num = (int)(num2 * 1930931612) ^ -2071690371;
					continue;
				case 64u:
					Delegate22.delegate22_9(Delegate7.delegate7_264(this));
					Delegate5.delegate5_11(this, bool_0: false);
					num = (int)(num2 * 440913173) ^ -1720450671;
					continue;
				case 63u:
					Delegate8.delegate8_74(Delegate7.delegate7_263(this), Delegate7.delegate7_274(this));
					num = ((int)num2 * -235411499) ^ 0x197A74D6;
					continue;
				case 62u:
					Delegate30.delegate30_5(Delegate7.delegate7_282(this), global::_003CModule_003E.smethod_19<string>(2523808813u, 3875749107u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_282(this), global::_003CModule_003E.smethod_18<string>(2983785401u, 2056357187u));
					Delegate30.delegate30_6(Delegate7.delegate7_282(this), global::_003CModule_003E.smethod_20<string>(1284010784u, 1610399557u));
					Delegate30.delegate30_5(Delegate7.delegate7_283(this), global::_003CModule_003E.smethod_21<string>(2473201337u, 4161347779u));
					num = (int)(num2 * 252171088) ^ -1663592383;
					continue;
				case 61u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_287(this), global::_003CModule_003E.smethod_21<string>(4268197934u, 1804238490u));
					num = (int)((num2 * 2111438441) ^ 0x47494371);
					continue;
				case 60u:
					Delegate46.delegate46_0(Delegate7.delegate7_270(this), ToolStripItemDisplayStyle.Image);
					num = (int)((num2 * 2114207253) ^ 0x27C4F793);
					continue;
				case 59u:
					Delegate30.delegate30_0(Delegate7.delegate7_264(this), global::_003CModule_003E.smethod_21<string>(2642949774u, 275845282u));
					Delegate217.delegate217_0(Delegate7.delegate7_264(this), DataGridViewRowHeadersWidthSizeMode.DisableResizing);
					num = ((int)num2 * -657660261) ^ -291302130;
					continue;
				case 58u:
					Delegate8.delegate8_71(Delegate7.delegate7_263(this), null);
					num = ((int)num2 * -180525997) ^ 0x5839513B;
					continue;
				case 57u:
					Delegate8.delegate8_309(this, Delegate7.delegate7_16(icontainer_0));
					num = (int)(num2 * 1119386015) ^ -978929818;
					continue;
				case 56u:
					Delegate211.delegate211_1(Delegate7.delegate7_280(this), BorderStyle.FixedSingle);
					num = (int)(num2 * 928802236) ^ -711999811;
					continue;
				case 55u:
					Delegate30.delegate30_5(Delegate7.delegate7_281(this), global::_003CModule_003E.smethod_20<string>(672653385u, 2150430555u));
					num = (int)((num2 * 2102140036) ^ 0x16259D7F);
					continue;
				case 54u:
					Delegate8.delegate8_69(Delegate7.delegate7_263(this), Delegate7.delegate7_265(this));
					num = ((int)num2 * -305411108) ^ -2020340948;
					continue;
				case 53u:
					Delegate45.delegate45_0(Delegate7.delegate7_263(this), ToolStripGripStyle.Hidden);
					Delegate31.smethod_0(Delegate7.delegate7_10(Delegate7.delegate7_263(this)), new ToolStripItem[16]
					{
						(ToolStripItem)Delegate7.delegate7_267(this),
						(ToolStripItem)Delegate7.delegate7_268(this),
						(ToolStripItem)Delegate7.delegate7_269(this),
						(ToolStripItem)Delegate7.delegate7_270(this),
						(ToolStripItem)Delegate7.delegate7_271(this),
						(ToolStripItem)Delegate7.delegate7_272(this),
						(ToolStripItem)Delegate7.delegate7_266(this),
						(ToolStripItem)Delegate7.delegate7_273(this),
						(ToolStripItem)Delegate7.delegate7_274(this),
						(ToolStripItem)Delegate7.delegate7_275(this),
						(ToolStripItem)Delegate7.delegate7_276(this),
						(ToolStripItem)Delegate7.delegate7_265(this),
						(ToolStripItem)Delegate7.delegate7_277(this),
						(ToolStripItem)Delegate7.delegate7_278(this),
						(ToolStripItem)Delegate7.delegate7_279(this),
						(ToolStripItem)Delegate7.delegate7_280(this)
					});
					Delegate27.delegate27_0(object_, Delegate7.delegate7_263(this), global::_003CModule_003E.smethod_19<string>(3067016278u, 2365731151u));
					Delegate8.delegate8_72(Delegate7.delegate7_263(this), Delegate7.delegate7_269(this));
					num = (int)(num2 * 1549504547) ^ -1373028614;
					continue;
				case 52u:
					Delegate5.delegate5_12(Delegate7.delegate7_264(this), bool_0: false);
					Delegate5.delegate5_13(Delegate7.delegate7_264(this), bool_0: false);
					Delegate29.delegate29_3(dataGridViewCellStyle2, Delegate28.delegate28_4());
					Delegate8.delegate8_66(Delegate7.delegate7_264(this), dataGridViewCellStyle2);
					num = (int)((num2 * 904185778) ^ 0x60ABE7FA);
					continue;
				case 51u:
					Delegate8.delegate8_336(Delegate7.delegate7_288(this), global::_003CModule_003E.smethod_18<string>(3761754587u, 144427223u));
					Delegate42.delegate42_0(Delegate7.delegate7_288(this), 80f);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_288(this), global::_003CModule_003E.smethod_21<string>(611389574u, 1484493032u));
					Delegate8.delegate8_337(Delegate7.delegate7_288(this), global::_003CModule_003E.smethod_22<string>(1482896026u, 936568855u));
					Delegate30.delegate30_6(Delegate7.delegate7_288(this), global::_003CModule_003E.smethod_22<string>(2728154232u, 1178562065u));
					Delegate8.delegate8_338(Delegate7.delegate7_288(this), global::_003CModule_003E.smethod_21<string>(2149405162u, 2037302997u));
					Delegate27.delegate27_0(object_, this, global::_003CModule_003E.smethod_20<string>(1152083978u, 156633990u));
					Delegate34.delegate34_0(this, AutoScaleMode.Font);
					num = ((int)num2 * -1022107150) ^ 0x5E8AFB8F;
					continue;
				case 50u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_273(this), global::_003CModule_003E.smethod_18<string>(1580387968u, 2018859382u));
					Delegate46.delegate46_0(Delegate7.delegate7_274(this), ToolStripItemDisplayStyle.Image);
					Delegate8.delegate8_77(Delegate7.delegate7_274(this), Delegate3.delegate3_32());
					Delegate30.delegate30_1(Delegate7.delegate7_274(this), global::_003CModule_003E.smethod_18<string>(751387832u, 1751149642u));
					num = (int)((num2 * 62814287) ^ 0x82B2CC4);
					continue;
				case 49u:
					Delegate46.delegate46_0(Delegate7.delegate7_269(this), ToolStripItemDisplayStyle.Image);
					num = ((int)num2 * -821873034) ^ 0xDF3841D;
					continue;
				case 48u:
					Delegate30.delegate30_1(Delegate7.delegate7_266(this), global::_003CModule_003E.smethod_22<string>(4130230305u, 1468063852u));
					Delegate46.delegate46_0(Delegate7.delegate7_267(this), ToolStripItemDisplayStyle.Image);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_267(this), global::_003CModule_003E.smethod_20<string>(3037286341u, 354113897u));
					num = ((int)num2 * -1080484773) ^ -511317218;
					continue;
				case 47u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_277(this), global::_003CModule_003E.smethod_21<string>(4279720443u, 4043360773u));
					Delegate30.delegate30_1(Delegate7.delegate7_278(this), global::_003CModule_003E.smethod_21<string>(1442495827u, 810959514u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_278(this), global::_003CModule_003E.smethod_22<string>(3547900489u, 1702104500u));
					Delegate8.delegate8_77(Delegate7.delegate7_279(this), Delegate3.delegate3_35());
					num = ((int)num2 * -2083135947) ^ -674580241;
					continue;
				case 46u:
					Delegate5.delegate5_8(this, bool_0: false);
					num = ((int)num2 * -1505763393) ^ 0x695434FA;
					continue;
				case 45u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_265(this), global::_003CModule_003E.smethod_20<string>(1557656181u, 1654825029u));
					num = (int)(num2 * 961454993) ^ -1217260361;
					continue;
				case 43u:
					Delegate8.delegate8_314(this, Delegate3.delegate3_24());
					Delegate8.delegate8_315(this, Delegate3.delegate3_24());
					Delegate8.delegate8_316(this, Delegate3.delegate3_26());
					num = ((int)num2 * -2042693262) ^ 0xA0028A1;
					continue;
				case 42u:
					Delegate5.delegate5_15(Delegate7.delegate7_281(this), bool_0: true);
					num = ((int)num2 * -1524725051) ^ -1149484721;
					continue;
				case 41u:
					Delegate46.delegate46_0(Delegate7.delegate7_265(this), ToolStripItemDisplayStyle.Image);
					Delegate8.delegate8_77(Delegate7.delegate7_265(this), Delegate3.delegate3_29());
					num = (int)((num2 * 1995828380) ^ 0x2F9389F0);
					continue;
				case 40u:
					Delegate30.delegate30_1(Delegate7.delegate7_271(this), global::_003CModule_003E.smethod_19<string>(4009641251u, 2427444678u));
					num = ((int)num2 * -442074790) ^ -1084929552;
					continue;
				case 39u:
					Delegate8.delegate8_328(this, Delegate3.delegate3_23());
					Delegate8.delegate8_329(this, Delegate3.delegate3_23());
					num = (int)((num2 * 2140753152) ^ 0x2E5B6AC5);
					continue;
				case 38u:
					Delegate29.delegate29_12(this, Delegate28.delegate28_6());
					num = ((int)num2 * -125873579) ^ 0x1D87F46E;
					continue;
				case 37u:
					Delegate22.delegate22_10(this);
					num = ((int)num2 * -141292260) ^ -1011536638;
					continue;
				case 36u:
					Delegate8.delegate8_332(this, Delegate3.delegate3_23());
					Delegate8.delegate8_333(this, Delegate3.delegate3_115());
					num = ((int)num2 * -460710973) ^ 0x20099B10;
					continue;
				case 35u:
					Delegate40.smethod_0(Delegate7.delegate7_22(Delegate7.delegate7_264(this)), new DataGridViewColumn[8]
					{
						(DataGridViewColumn)Delegate7.delegate7_281(this),
						(DataGridViewColumn)Delegate7.delegate7_282(this),
						(DataGridViewColumn)Delegate7.delegate7_283(this),
						(DataGridViewColumn)Delegate7.delegate7_284(this),
						(DataGridViewColumn)Delegate7.delegate7_285(this),
						(DataGridViewColumn)Delegate7.delegate7_286(this),
						(DataGridViewColumn)Delegate7.delegate7_287(this),
						(DataGridViewColumn)Delegate7.delegate7_288(this)
					});
					num = ((int)num2 * -2123612230) ^ -1867326910;
					continue;
				case 34u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_263(this));
					num = (int)(num2 * 1014640508) ^ -1264994799;
					continue;
				case 33u:
					Delegate38.delegate38_0(Delegate7.delegate7_264(this), DataGridViewClipboardCopyMode.EnableWithoutHeaderText);
					num = ((int)num2 * -1182988787) ^ 0x5501B27;
					continue;
				case 32u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_285(this), global::_003CModule_003E.smethod_19<string>(1604706042u, 1510055807u));
					num = ((int)num2 * -408805652) ^ 0x20AF3610;
					continue;
				case 31u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_281(this), global::_003CModule_003E.smethod_21<string>(604506841u, 975399542u));
					num = (int)((num2 * 1003560809) ^ 0x469E7DB);
					continue;
				case 30u:
					Delegate30.delegate30_1(Delegate7.delegate7_279(this), global::_003CModule_003E.smethod_20<string>(2925558695u, 3719133407u));
					num = (int)(num2 * 1763287489) ^ -218532265;
					continue;
				case 29u:
					Delegate8.delegate8_334(this, Delegate3.delegate3_65());
					num = (int)(num2 * 1112808081) ^ -580024587;
					continue;
				case 28u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_270(this), global::_003CModule_003E.smethod_20<string>(3535651562u, 3535074167u));
					num = (int)(num2 * 2146684210) ^ -858485956;
					continue;
				case 27u:
					dataGridViewCellStyle = (DataGridViewCellStyle)Delegate3.delegate3_20();
					num = ((int)num2 * -1032348033) ^ -904917314;
					continue;
				case 26u:
					Delegate30.delegate30_5(Delegate7.delegate7_285(this), global::_003CModule_003E.smethod_20<string>(930833279u, 337673803u));
					num = ((int)num2 * -124192368) ^ -235236128;
					continue;
				case 25u:
					Delegate30.delegate30_1(Delegate7.delegate7_275(this), global::_003CModule_003E.smethod_19<string>(3664247107u, 3095798235u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_275(this), global::_003CModule_003E.smethod_18<string>(2096949936u, 2989329904u));
					num = ((int)num2 * -509172149) ^ 0x3402AC55;
					continue;
				case 24u:
					Delegate8.delegate8_77(Delegate7.delegate7_269(this), Delegate3.delegate3_30());
					Delegate30.delegate30_1(Delegate7.delegate7_269(this), global::_003CModule_003E.smethod_22<string>(4257103155u, 1521008036u));
					num = ((int)num2 * -1744833301) ^ -847682360;
					continue;
				case 23u:
					Delegate30.delegate30_5(Delegate7.delegate7_286(this), global::_003CModule_003E.smethod_22<string>(2072033721u, 2214856854u));
					Delegate42.delegate42_0(Delegate7.delegate7_286(this), 200f);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_286(this), global::_003CModule_003E.smethod_22<string>(1938686148u, 33573264u));
					Delegate30.delegate30_6(Delegate7.delegate7_286(this), global::_003CModule_003E.smethod_22<string>(1938686148u, 2483919449u));
					num = ((int)num2 * -175217978) ^ 0x4AE750F8;
					continue;
				case 22u:
					Delegate35.delegate35_0(this, FormBorderStyle.FixedSingle);
					Delegate5.delegate5_7(this, bool_0: false);
					num = (int)((num2 * 1710218393) ^ 0x66D04318);
					continue;
				case 20u:
					Delegate30.delegate30_6(Delegate7.delegate7_281(this), global::_003CModule_003E.smethod_19<string>(982890313u, 1031818578u));
					num = (int)(num2 * 1338898411) ^ -482571927;
					continue;
				case 19u:
					Delegate8.delegate8_327(this, Delegate3.delegate3_23());
					num = (int)((num2 * 188439755) ^ 0x6E8A447A);
					continue;
				case 18u:
					Delegate22.delegate22_6(Delegate7.delegate7_263(this));
					Delegate22.delegate22_5(Delegate7.delegate7_263(this));
					Delegate22.delegate22_6(Delegate7.delegate7_264(this));
					num = (int)((num2 * 1106160587) ^ 0x52691032);
					continue;
				case 17u:
					Delegate8.delegate8_67(dataGridViewCellStyle, Delegate43.delegate43_0(global::_003CModule_003E.smethod_21<string>(2241277510u, 4225072414u), 9f, FontStyle.Regular, GraphicsUnit.Point, 0));
					num = ((int)num2 * -1565782465) ^ -587133402;
					continue;
				case 16u:
					Delegate8.delegate8_310(this, Delegate3.delegate3_24());
					num = ((int)num2 * -1944236983) ^ 0x63D8F07;
					continue;
				case 15u:
					Delegate8.delegate8_73(Delegate7.delegate7_263(this), Delegate7.delegate7_275(this));
					num = ((int)num2 * -904615334) ^ 0x42088195;
					continue;
				case 14u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_283(this), global::_003CModule_003E.smethod_18<string>(3087410418u, 3860906715u));
					num = ((int)num2 * -922543297) ^ -161037906;
					continue;
				case 13u:
					Delegate30.delegate30_6(Delegate7.delegate7_283(this), global::_003CModule_003E.smethod_19<string>(3216722497u, 3101611152u));
					num = (int)((num2 * 1104527293) ^ 0xFA826E9);
					continue;
				case 12u:
					Delegate22.delegate22_7(this);
					num = ((int)num2 * -1636053203) ^ -460769864;
					continue;
				case 11u:
					Delegate8.delegate8_313(this, Delegate3.delegate3_24());
					num = (int)(num2 * 1294063923) ^ -1481146054;
					continue;
				case 10u:
					Delegate30.delegate30_6(Delegate7.delegate7_285(this), global::_003CModule_003E.smethod_20<string>(2763640944u, 1352275645u));
					num = (int)((num2 * 1478507767) ^ 0x282E0B10);
					continue;
				case 9u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_274(this), global::_003CModule_003E.smethod_19<string>(1430414923u, 3620402612u));
					num = (int)((num2 * 971096389) ^ 0x6BE4C083);
					continue;
				case 8u:
					Delegate8.delegate8_319(this, Delegate3.delegate3_24());
					num = ((int)num2 * -291463497) ^ -1234720394;
					continue;
				case 7u:
					Delegate46.delegate46_0(Delegate7.delegate7_275(this), ToolStripItemDisplayStyle.Image);
					num = ((int)num2 * -1896026268) ^ -1387095277;
					continue;
				case 6u:
					Delegate8.delegate8_335(this, Delegate7.delegate7_17(icontainer_0));
					num = (int)((num2 * 1024915595) ^ 0x24EB2868);
					continue;
				case 5u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_269(this), global::_003CModule_003E.smethod_21<string>(2059929633u, 1383778572u));
					num = (int)(num2 * 1462733127) ^ -1404820897;
					continue;
				case 4u:
					Delegate30.delegate30_5(Delegate7.delegate7_284(this), global::_003CModule_003E.smethod_18<string>(2689552726u, 3984073611u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_284(this), global::_003CModule_003E.smethod_21<string>(1148550472u, 2719159061u));
					num = (int)((num2 * 988032316) ^ 0x282E5279);
					continue;
				case 3u:
					Delegate8.delegate8_75(Delegate7.delegate7_263(this), Delegate7.delegate7_270(this));
					Delegate30.delegate30_0(Delegate7.delegate7_263(this), global::_003CModule_003E.smethod_18<string>(3140004485u, 3228473852u));
					Delegate8.delegate8_76(Delegate7.delegate7_263(this), Delegate7.delegate7_272(this));
					num = (int)((num2 * 728255614) ^ 0x313E9210);
					continue;
				case 2u:
					Delegate44.delegate44_0(Delegate7.delegate7_286(this), DataGridViewAutoSizeColumnMode.Fill);
					num = ((int)num2 * -513348768) ^ -904842754;
					continue;
				case 1u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_271(this), global::_003CModule_003E.smethod_18<string>(3184231056u, 4102576960u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_272(this), global::_003CModule_003E.smethod_19<string>(1603111995u, 1154584452u));
					Delegate30.delegate30_1(Delegate7.delegate7_272(this), global::_003CModule_003E.smethod_19<string>(1603111995u, 579139411u));
					Delegate30.delegate30_1(Delegate7.delegate7_273(this), global::_003CModule_003E.smethod_21<string>(2654472283u, 2242689328u));
					num = ((int)num2 * -1073881695) ^ -1218710249;
					continue;
				case 0u:
					Delegate8.delegate8_70(Delegate7.delegate7_263(this), Delegate7.delegate7_266(this));
					Delegate30.delegate30_7(Delegate7.delegate7_263(this), global::_003CModule_003E.smethod_18<string>(4010104958u, 995820630u));
					num = (int)((num2 * 802569246) ^ 0x70053BBA);
					continue;
				default:
					return;
				case 44u:
					break;
				case 21u:
					return;
				}
				break;
			}
		}
	}

	private void method_1(object sender, EventArgs e)
	{
		sqliteCommand_0 = new SQLiteCommand(global::_003CModule_003E.smethod_22<string>(364510670u, 1507722698u), sqliteConnection_0);
		sqliteCommand_1 = new SQLiteCommand(global::_003CModule_003E.smethod_20<string>(2602047664u, 806382512u), sqliteConnection_0);
		while (true)
		{
			int num = 1789203028;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x178BB7BAu) % 6)
				{
				case 4u:
					sqliteDataAdapter_0 = new SQLiteDataAdapter(sqliteCommand_0);
					num = ((int)num2 * -1262358972) ^ 0x3D48D4D;
					continue;
				case 3u:
					sqliteDataAdapter_1 = new SQLiteDataAdapter(sqliteCommand_1);
					sqliteCommandBuilder_0 = new SQLiteCommandBuilder(sqliteDataAdapter_0);
					num = ((int)num2 * -941389713) ^ -1691006415;
					continue;
				case 1u:
					sqliteDataAdapter_0.Fill(dataTable_0);
					Delegate8.delegate8_96(Delegate7.delegate7_289(this), dataTable_0);
					sqliteDataAdapter_1.Fill(dataTable_1);
					Delegate8.delegate8_343(Delegate7.delegate7_287(this), dataTable_1);
					Delegate30.delegate30_5(Delegate7.delegate7_287(this), global::_003CModule_003E.smethod_20<string>(4287138549u, 1915733558u));
					Delegate30.delegate30_27(Delegate7.delegate7_287(this), global::_003CModule_003E.smethod_21<string>(749121165u, 3250594971u));
					Delegate30.delegate30_28(Delegate7.delegate7_287(this), global::_003CModule_003E.smethod_19<string>(1454999823u, 1566367839u));
					num = (int)(num2 * 711377958) ^ -855126423;
					continue;
				case 0u:
					dataTable_0.Locale = (CultureInfo)Delegate3.delegate3_37();
					num = (int)((num2 * 782105685) ^ 0x1BD14DA9);
					continue;
				case 2u:
					break;
				default:
					Delegate5.delegate5_18(Delegate7.delegate7_264(this), bool_0: false);
					Delegate8.delegate8_97(Delegate7.delegate7_264(this), Delegate7.delegate7_289(this));
					Delegate8.delegate8_98(Delegate7.delegate7_263(this), Delegate7.delegate7_289(this));
					return;
				}
				break;
			}
		}
	}

	private void method_2(object sender, EventArgs e)
	{
		Delegate30.delegate30_8(Delegate7.delegate7_289(this), Delegate50.delegate50_0(global::_003CModule_003E.smethod_21<string>(1924440999u, 271304274u), Delegate15.delegate15_4(Delegate7.delegate7_280(this))));
	}

	private void method_3(object sender, DataGridViewCellEventArgs e)
	{
		try
		{
			sqliteDataAdapter_0.Update(dataTable_0);
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			Delegate51.delegate51_0();
		}
	}

	private void method_4(object sender, EventArgs e)
	{
		if (Delegate52.delegate52_0(global::_003CModule_003E.smethod_20<string>(2026354928u, 3786363579u), global::_003CModule_003E.smethod_21<string>(760720605u, 1770689106u), MessageBoxButtons.YesNo) != DialogResult.Yes)
		{
			return;
		}
		IEnumerator enumerator = default(IEnumerator);
		try
		{
			enumerator = (IEnumerator)Delegate7.delegate7_75(Delegate7.delegate7_74(Delegate7.delegate7_264(this)));
			DataGridViewRow object_ = default(DataGridViewRow);
			while (true)
			{
				int num;
				int num2;
				if (!Delegate21.delegate21_3(enumerator))
				{
					num = -173727511;
					num2 = -173727511;
				}
				else
				{
					num = -1244037820;
					num2 = -1244037820;
				}
				while (true)
				{
					uint num3;
					switch ((num3 = (uint)num ^ 0xD8501F65u) % 6)
					{
					case 5u:
						object_ = (DataGridViewRow)Delegate7.delegate7_76(enumerator);
						num = -2021031631;
						continue;
					case 2u:
					{
						int num4;
						int num5;
						if (!Delegate21.delegate21_2(object_))
						{
							num4 = 2086127648;
							num5 = 2086127648;
						}
						else
						{
							num4 = 1242954044;
							num5 = 1242954044;
						}
						num = num4 ^ ((int)num3 * -2096465590);
						continue;
					}
					case 1u:
						Delegate32.delegate32_2(Delegate7.delegate7_289(this), Delegate17.delegate17_2(object_));
						num = ((int)num3 * -775704984) ^ 0x71E8723C;
						continue;
					case 0u:
						num = -1244037820;
						continue;
					default:
						return;
					case 3u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
		finally
		{
			if (enumerator is IDisposable)
			{
				while (true)
				{
					IL_016b:
					int num6 = -931057901;
					while (true)
					{
						uint num3;
						switch ((num3 = (uint)num6 ^ 0xD8501F65u) % 3)
						{
						case 1u:
							goto IL_0131;
						default:
							goto end_IL_014e;
						case 2u:
							break;
						case 0u:
							goto end_IL_014e;
						}
						goto IL_016b;
						IL_0131:
						Delegate22.delegate22_4(enumerator as IDisposable);
						num6 = (int)(num3 * 296517742) ^ -542962829;
						continue;
						end_IL_014e:
						break;
					}
					break;
				}
			}
		}
	}

	private void method_5(object sender, KeyEventArgs e)
	{
		if (((uint)(0 - ((Delegate53.delegate53_0(e) == Keys.Delete) ? 1 : 0)) & (uint)(~Delegate54.delegate54_0(Delegate7.delegate7_264(this)))) == 0)
		{
			return;
		}
		while (true)
		{
			int num = 1715637807;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x701769A6u) % 4)
				{
				case 1u:
				{
					int num3;
					int num4;
					if (Delegate17.delegate17_3(Delegate7.delegate7_74(Delegate7.delegate7_264(this))) > 0)
					{
						num3 = -2100146738;
						num4 = -2100146738;
					}
					else
					{
						num3 = -549754780;
						num4 = -549754780;
					}
					num = num3 ^ (int)(num2 * 2043509280);
					continue;
				}
				case 0u:
					Delegate22.delegate22_13(Delegate7.delegate7_277(this));
					num = (int)((num2 * 892517835) ^ 0x4936A55C);
					continue;
				default:
					return;
				case 3u:
					break;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	private void method_6(object sender, DataGridViewRowsRemovedEventArgs e)
	{
		try
		{
			sqliteDataAdapter_0.Update(dataTable_0);
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			Delegate51.delegate51_0();
		}
	}

	private void method_7(object sender, DataGridViewDataErrorEventArgs e)
	{
		Delegate52.delegate52_0(Delegate15.delegate15_0(Delegate7.delegate7_77(e)), global::_003CModule_003E.smethod_20<string>(2283270290u, 2375520824u), MessageBoxButtons.OK);
		while (true)
		{
			int num = -1294014224;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xEBE7F453u) % 3)
				{
				case 1u:
					goto IL_0032;
				default:
					return;
				case 2u:
					break;
				case 0u:
					return;
				}
				break;
				IL_0032:
				Delegate5.delegate5_21(e, bool_0: true);
				num = (int)(num2 * 1978976235) ^ -1369217009;
			}
		}
	}

	private void method_8(object sender, AddingNewEventArgs e)
	{
		DataRowView dataRowView = ((DataView)Delegate7.delegate7_290(Delegate7.delegate7_289(this))).AddNew();
		dataRowView[global::_003CModule_003E.smethod_21<string>(3724154303u, 3435188599u)] = checked(Delegate218.delegate218_0(this, sqliteConnection_0, global::_003CModule_003E.smethod_22<string>(3794838310u, 3633212708u)) + 1);
		dataRowView[global::_003CModule_003E.smethod_20<string>(4287138549u, 972172996u)] = -1;
		dataRowView[global::_003CModule_003E.smethod_18<string>(3336312700u, 3031660312u)] = 0;
		while (true)
		{
			int num = 1933181369;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x1F1E62A4u) % 4)
				{
				case 1u:
					dataRowView[global::_003CModule_003E.smethod_20<string>(3603511763u, 719309528u)] = "";
					dataRowView[global::_003CModule_003E.smethod_21<string>(2473201337u, 500486929u)] = "";
					dataRowView[global::_003CModule_003E.smethod_21<string>(4011216925u, 3032247024u)] = "";
					num = ((int)num2 * -1366833575) ^ -1462821779;
					continue;
				case 0u:
					Delegate8.delegate8_344(e, dataRowView);
					Delegate22.delegate22_72(Delegate7.delegate7_289(this));
					num = (int)(num2 * 542233610) ^ -1654717882;
					continue;
				default:
					return;
				case 3u:
					break;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	private int method_9(SQLiteConnection sqliteConnection_1, string string_0)
	{
		Delegate17 delegate17_ = Delegate17.delegate17_1;
		SQLiteCommand sQLiteCommand = new SQLiteCommand(Delegate57.delegate57_1(global::_003CModule_003E.smethod_21<string>(430041697u, 2633082432u), string_0), sqliteConnection_1);
		sqliteConnection_1.Open();
		int result = delegate17_(sQLiteCommand.ExecuteScalar());
		sqliteConnection_1.Close();
		return result;
	}

	private void method_10(object sender, DataGridViewCellCancelEventArgs e)
	{
		StringListEditor object_ = (StringListEditor)Delegate3.delegate3_116();
		while (true)
		{
			int num = 1051485522;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x2D63DEDBu) % 8)
				{
				case 7u:
				{
					int num6;
					int num7;
					if (!Delegate21.delegate21_4(Delegate7.delegate7_2(Delegate7.delegate7_109(Delegate55.delegate55_6(Delegate7.delegate7_291(Delegate7.delegate7_264(this)), Delegate17.delegate17_27(e))))))
					{
						num6 = 702223339;
						num7 = 702223339;
					}
					else
					{
						num6 = 1730284309;
						num7 = 1730284309;
					}
					num = num6 ^ ((int)num2 * -2067505484);
					continue;
				}
				case 6u:
				{
					Delegate30.delegate30_24(object_, Delegate15.delegate15_44(Delegate55.delegate55_0(Delegate7.delegate7_22(Delegate7.delegate7_264(this)), Delegate17.delegate17_27(e))));
					int num5;
					if (Delegate111.delegate111_0(object_) == DialogResult.OK)
					{
						num = 896514720;
						num5 = 896514720;
					}
					else
					{
						num = 682715990;
						num5 = 682715990;
					}
					continue;
				}
				case 4u:
					Delegate30.delegate30_29(object_, Delegate15.delegate15_2(Delegate7.delegate7_109(Delegate55.delegate55_6(Delegate7.delegate7_291(Delegate7.delegate7_264(this)), Delegate17.delegate17_27(e)))));
					num = ((int)num2 * -469724180) ^ -1179042779;
					continue;
				case 3u:
					Delegate8.delegate8_110(Delegate55.delegate55_6(Delegate7.delegate7_291(Delegate7.delegate7_264(this)), Delegate17.delegate17_27(e)), Delegate15.delegate15_45(object_));
					num = ((int)num2 * -1485521919) ^ -568077523;
					continue;
				case 2u:
					Delegate30.delegate30_29(object_, "");
					num = 779799669;
					continue;
				case 1u:
				{
					int num3;
					int num4;
					if ((Delegate17.delegate17_27(e) == 4) | (Delegate17.delegate17_27(e) == 5))
					{
						num3 = -511060705;
						num4 = -511060705;
					}
					else
					{
						num3 = -1486267059;
						num4 = -1486267059;
					}
					num = num3 ^ ((int)num2 * -1812559997);
					continue;
				}
				default:
					return;
				case 0u:
					break;
				case 5u:
					return;
				}
				break;
			}
		}
	}
}
