using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using ns1;

namespace Waircut;

[DesignerGenerated]
public class AboutForm : Form
{
	private IContainer icontainer_0;

	[CompilerGenerated]
	[AccessedThroughProperty("PictureBox1")]
	private PictureBox pictureBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("Label1")]
	private Label label_0;

	[CompilerGenerated]
	[AccessedThroughProperty("PictureBox2")]
	private PictureBox pictureBox_1;

	[CompilerGenerated]
	[AccessedThroughProperty("StatusStrip1")]
	private StatusStrip statusStrip_0;

	[CompilerGenerated]
	[AccessedThroughProperty("lbVersion")]
	private ToolStripStatusLabel toolStripStatusLabel_0;

	[CompilerGenerated]
	[AccessedThroughProperty("ScrollLabel1")]
	private GClass14 gclass14_0;

	[CompilerGenerated]
	[AccessedThroughProperty("Panel1")]
	private Panel panel_0;

	internal virtual PictureBox PictureBox_0
	{
		[CompilerGenerated]
		get
		{
			return pictureBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			pictureBox_0 = value;
		}
	}

	internal virtual Label Label_0
	{
		[CompilerGenerated]
		get
		{
			return label_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_0 = value;
		}
	}

	internal virtual PictureBox PictureBox_1
	{
		[CompilerGenerated]
		get
		{
			return pictureBox_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			pictureBox_1 = value;
		}
	}

	internal virtual StatusStrip StatusStrip_0
	{
		[CompilerGenerated]
		get
		{
			return statusStrip_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			statusStrip_0 = value;
		}
	}

	internal virtual ToolStripStatusLabel ToolStripStatusLabel_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripStatusLabel_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripStatusLabel_0 = value;
		}
	}

	internal virtual GClass14 GClass14_0
	{
		[CompilerGenerated]
		get
		{
			return gclass14_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			gclass14_0 = value;
		}
	}

	internal virtual Panel Panel_0
	{
		[CompilerGenerated]
		get
		{
			return panel_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			panel_0 = value;
		}
	}

	public AboutForm()
	{
		Delegate8.delegate8_3(this, new EventHandler(method_1));
		Delegate22.delegate22_3(this);
	}

	[DebuggerNonUserCode]
	void Form.Dispose(bool disposing)
	{
		try
		{
			if (!disposing)
			{
				return;
			}
			while (true)
			{
				int num = 218226232;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x48AD73A5u) % 4)
					{
					case 2u:
						Delegate22.delegate22_4(icontainer_0);
						num = ((int)num2 * -1234398725) ^ -1695284896;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (icontainer_0 != null)
						{
							num3 = 1636352375;
							num4 = 1636352375;
						}
						else
						{
							num3 = 717226438;
							num4 = 717226438;
						}
						num = num3 ^ (int)(num2 * 1182367420);
						continue;
					}
					default:
						return;
					case 0u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
		finally
		{
			Delegate5.delegate5_3(this, disposing);
		}
	}

	[DebuggerStepThrough]
	private void method_0()
	{
		ComponentResourceManager object_ = (ComponentResourceManager)Delegate7.delegate7_4(Delegate9.delegate9_0(typeof(AboutForm).TypeHandle));
		Delegate8.delegate8_4(this, Delegate3.delegate3_9());
		while (true)
		{
			int num = -943994967;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xE3B39C58u) % 40)
				{
				case 39u:
					Delegate22.delegate22_10(this);
					num = (int)((num2 * 1448610753) ^ 0x10760509);
					continue;
				case 38u:
					Delegate22.delegate22_9(Delegate7.delegate7_7(this));
					num = (int)(num2 * 806880412) ^ -114255531;
					continue;
				case 37u:
					Delegate5.delegate5_10(Delegate7.delegate7_8(this), bool_0: false);
					Delegate5.delegate5_11(this, bool_0: false);
					num = ((int)num2 * -731965226) ^ 0x5E405EF9;
					continue;
				case 36u:
					Delegate8.delegate8_6(this, Delegate3.delegate3_11());
					num = ((int)num2 * -838099531) ^ 0x6B323504;
					continue;
				case 35u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_5(this));
					num = (int)((num2 * 1752805610) ^ 0x4E269053);
					continue;
				case 34u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_8(this), global::_003CModule_003E.smethod_22<string>(1667944877u, 800206652u));
					num = (int)(num2 * 1073448036) ^ -248186072;
					continue;
				case 33u:
					Delegate8.delegate8_11(Delegate7.delegate7_7(this), Delegate3.delegate3_16());
					num = (int)((num2 * 167500013) ^ 0x4736FA7C);
					continue;
				case 32u:
					Delegate8.delegate8_7(this, Delegate3.delegate3_12());
					Delegate8.delegate8_8(this, Delegate3.delegate3_12());
					num = (int)(num2 * 971157696) ^ -2051502965;
					continue;
				case 31u:
					Delegate22.delegate22_5(Delegate7.delegate7_5(this));
					num = ((int)num2 * -986266407) ^ -1372889318;
					continue;
				case 29u:
					Delegate30.delegate30_0(Delegate7.delegate7_5(this), global::_003CModule_003E.smethod_18<string>(3238388240u, 650904990u));
					Delegate5.delegate5_4(Delegate7.delegate7_5(this), bool_0: false);
					Delegate30.delegate30_1(Delegate7.delegate7_11(this), global::_003CModule_003E.smethod_20<string>(1023626297u, 3189127888u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_11(this), global::_003CModule_003E.smethod_19<string>(3399586623u, 3741262281u));
					num = (int)((num2 * 1629176065) ^ 0x73A59F11);
					continue;
				case 28u:
					Delegate29.delegate29_2(Delegate7.delegate7_7(this), Delegate28.delegate28_2());
					num = ((int)num2 * -384713365) ^ 0x77495AD5;
					continue;
				case 27u:
					Delegate30.delegate30_2(this, global::_003CModule_003E.smethod_21<string>(3655326973u, 3803658759u));
					Delegate5.delegate5_9(this, bool_0: false);
					num = ((int)num2 * -1312741978) ^ -664363915;
					continue;
				case 26u:
					Delegate34.delegate34_0(this, AutoScaleMode.Font);
					num = (int)((num2 * 46091461) ^ 0x2C4B08D);
					continue;
				case 25u:
					Delegate5.delegate5_7(this, bool_0: false);
					Delegate5.delegate5_8(this, bool_0: false);
					num = ((int)num2 * -1896734042) ^ -408304739;
					continue;
				case 24u:
					Delegate30.delegate30_0(Delegate7.delegate7_7(this), global::_003CModule_003E.smethod_21<string>(2392774567u, 3053515988u));
					num = (int)(num2 * 1502634318) ^ -549962995;
					continue;
				case 23u:
					Delegate30.delegate30_0(Delegate7.delegate7_6(this), global::_003CModule_003E.smethod_22<string>(2786330233u, 3367316875u));
					num = (int)(num2 * 1733230871) ^ -1501209947;
					continue;
				case 22u:
					Delegate8.delegate8_10(this, Delegate3.delegate3_14());
					num = (int)(num2 * 1668584388) ^ -2145786769;
					continue;
				case 21u:
					Delegate22.delegate22_6(Delegate7.delegate7_6(this));
					num = (int)(num2 * 1461122925) ^ -1442571937;
					continue;
				case 20u:
					Delegate5.delegate5_5(Delegate7.delegate7_6(this), bool_0: false);
					num = (int)((num2 * 240116834) ^ 0x680C1C94);
					continue;
				case 19u:
					Delegate22.delegate22_5(Delegate7.delegate7_8(this));
					Delegate22.delegate22_7(this);
					num = ((int)num2 * -1126231782) ^ 0x75FD67E;
					continue;
				case 18u:
					Delegate5.delegate5_6(this, bool_0: true);
					Delegate35.delegate35_0(this, FormBorderStyle.FixedSingle);
					num = (int)(num2 * 1780682861) ^ -1615486365;
					continue;
				case 17u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_7(this), global::_003CModule_003E.smethod_18<string>(961764100u, 2694067450u));
					num = ((int)num2 * -52319058) ^ 0x5EC54E86;
					continue;
				case 16u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_9(this), global::_003CModule_003E.smethod_22<string>(2379861044u, 3461390905u));
					Delegate29.delegate29_0(Delegate7.delegate7_9(this), Delegate28.delegate28_0());
					Delegate30.delegate30_0(Delegate7.delegate7_9(this), global::_003CModule_003E.smethod_20<string>(1265076156u, 343419898u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_5(this), global::_003CModule_003E.smethod_20<string>(4208870973u, 432049003u));
					Delegate29.delegate29_1(Delegate7.delegate7_5(this), Delegate28.delegate28_1());
					Delegate31.smethod_0(Delegate7.delegate7_10(Delegate7.delegate7_5(this)), new ToolStripItem[1] { (ToolStripItem)Delegate7.delegate7_11(this) });
					num = (int)(num2 * 655230456) ^ -873730531;
					continue;
				case 15u:
					Delegate5.delegate5_10(Delegate7.delegate7_5(this), bool_0: false);
					num = (int)((num2 * 1661172405) ^ 0x6194BE1);
					continue;
				case 14u:
					Delegate22.delegate22_6(Delegate7.delegate7_7(this));
					num = (int)(num2 * 781777267) ^ -1761649343;
					continue;
				case 13u:
					Delegate5.delegate5_5(Delegate7.delegate7_7(this), bool_0: false);
					Delegate32.delegate32_0(Delegate7.delegate7_12(this), 60);
					num = ((int)num2 * -1214958750) ^ -1146859166;
					continue;
				case 12u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_12(this));
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_6(this));
					num = (int)(num2 * 1393254816) ^ -1515838221;
					continue;
				case 11u:
					Delegate29.delegate29_2(Delegate7.delegate7_8(this), Delegate28.delegate28_3());
					num = (int)(num2 * 349468159) ^ -1880978388;
					continue;
				case 10u:
					Delegate22.delegate22_8(Delegate7.delegate7_5(this));
					Delegate22.delegate22_9(Delegate7.delegate7_6(this));
					num = ((int)num2 * -423587214) ^ 0x765279A;
					continue;
				case 9u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_8(this)), Delegate7.delegate7_7(this));
					num = ((int)num2 * -1995761871) ^ 0x7C414443;
					continue;
				case 8u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_12(this), global::_003CModule_003E.smethod_21<string>(448446939u, 1817247172u));
					Delegate30.delegate30_0(Delegate7.delegate7_12(this), global::_003CModule_003E.smethod_21<string>(448446939u, 107569879u));
					Delegate33.delegate33_0(Delegate7.delegate7_12(this), GClass14.GEnum7.vertical);
					num = ((int)num2 * -1013372229) ^ -1557529149;
					continue;
				case 7u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_8(this));
					num = (int)((num2 * 2133712427) ^ 0x25863B51);
					continue;
				case 6u:
					Delegate29.delegate29_2(Delegate7.delegate7_6(this), Delegate28.delegate28_1());
					Delegate8.delegate8_11(Delegate7.delegate7_6(this), Delegate3.delegate3_15());
					num = (int)((num2 * 1628868907) ^ 0x7F26A0E5);
					continue;
				case 5u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_9(this));
					num = (int)(num2 * 1718827412) ^ -1908986642;
					continue;
				case 4u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_6(this), global::_003CModule_003E.smethod_20<string>(653718757u, 2127544213u));
					num = ((int)num2 * -1867036879) ^ -226861110;
					continue;
				case 3u:
					Delegate8.delegate8_9(this, Delegate3.delegate3_13());
					num = ((int)num2 * -819489542) ^ 0x5E287918;
					continue;
				case 1u:
					Delegate8.delegate8_5(this, Delegate3.delegate3_10());
					num = ((int)num2 * -1848988619) ^ -313352679;
					continue;
				case 0u:
					Delegate30.delegate30_0(Delegate7.delegate7_8(this), global::_003CModule_003E.smethod_22<string>(1667944877u, 3469514373u));
					Delegate27.delegate27_0(object_, this, global::_003CModule_003E.smethod_19<string>(1960267240u, 679622557u));
					num = (int)(num2 * 633348079) ^ -985961558;
					continue;
				default:
					return;
				case 2u:
					break;
				case 30u:
					return;
				}
				break;
			}
		}
	}

	private void method_1(object sender, EventArgs e)
	{
		Delegate5.delegate5_6(this, bool_0: true);
		Delegate30.smethod_0(Delegate7.delegate7_11(this), Delegate37.smethod_0(new string[5]
		{
			Delegate36.delegate36_0(),
			Delegate36.delegate36_1(),
			global::_003CModule_003E.smethod_18<string>(3962200242u, 1490512642u),
			Delegate15.delegate15_3(Delegate7.delegate7_15(Delegate3.delegate3_0())),
			global::_003CModule_003E.smethod_21<string>(2886319179u, 261954677u)
		}));
		Delegate30.delegate30_4(Delegate7.delegate7_12(this), Delegate36.delegate36_2());
	}

	private void method_2(object sender, EventArgs e)
	{
		Delegate22.delegate22_11(this);
	}
}
