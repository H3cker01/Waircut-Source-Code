using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using ns1;

namespace Waircut;

[DesignerGenerated]
public class ApLogForm : Form
{
	private IContainer icontainer_0;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvAp")]
	private DataGridView dataGridView_0;

	[CompilerGenerated]
	[AccessedThroughProperty("bnavAp")]
	private BindingNavigator bindingNavigator_0;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorAddNewItem")]
	private ToolStripButton toolStripButton_0;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorCountItem")]
	private ToolStripLabel toolStripLabel_0;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorDeleteItem")]
	private ToolStripButton toolStripButton_1;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorMoveFirstItem")]
	private ToolStripButton toolStripButton_2;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorMovePreviousItem")]
	private ToolStripButton toolStripButton_3;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorSeparator")]
	private ToolStripSeparator toolStripSeparator_0;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorPositionItem")]
	private ToolStripTextBox toolStripTextBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorSeparator1")]
	private ToolStripSeparator toolStripSeparator_1;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorMoveNextItem")]
	private ToolStripButton toolStripButton_4;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorMoveLastItem")]
	private ToolStripButton toolStripButton_5;

	[CompilerGenerated]
	[AccessedThroughProperty("BindingNavigatorSeparator2")]
	private ToolStripSeparator toolStripSeparator_2;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolStripSeparator1")]
	private ToolStripSeparator toolStripSeparator_3;

	[CompilerGenerated]
	[AccessedThroughProperty("tbSearch")]
	private ToolStripTextBox toolStripTextBox_1;

	[CompilerGenerated]
	[AccessedThroughProperty("Panel1")]
	private Panel panel_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tbDeviceName")]
	private TextBox textBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("Label1")]
	private Label label_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tbConfigMethod")]
	private TextBox textBox_1;

	[CompilerGenerated]
	[AccessedThroughProperty("Label10")]
	private Label label_1;

	[CompilerGenerated]
	[AccessedThroughProperty("tbEncryption")]
	private TextBox textBox_2;

	[CompilerGenerated]
	[AccessedThroughProperty("Label9")]
	private Label label_2;

	[CompilerGenerated]
	[AccessedThroughProperty("tbVersion")]
	private TextBox textBox_3;

	[CompilerGenerated]
	[AccessedThroughProperty("Label8")]
	private Label label_3;

	[CompilerGenerated]
	[AccessedThroughProperty("tbUUID")]
	private TextBox textBox_4;

	[CompilerGenerated]
	[AccessedThroughProperty("Label7")]
	private Label label_4;

	[CompilerGenerated]
	[AccessedThroughProperty("tbRfBand")]
	private TextBox textBox_5;

	[CompilerGenerated]
	[AccessedThroughProperty("Label6")]
	private Label label_5;

	[CompilerGenerated]
	[AccessedThroughProperty("tbSerialNumber")]
	private TextBox textBox_6;

	[CompilerGenerated]
	[AccessedThroughProperty("Label5")]
	private Label label_6;

	[CompilerGenerated]
	[AccessedThroughProperty("tbManufacturer")]
	private TextBox textBox_7;

	[CompilerGenerated]
	[AccessedThroughProperty("Label4")]
	private Label label_7;

	[CompilerGenerated]
	[AccessedThroughProperty("tbModelNumber")]
	private TextBox textBox_8;

	[CompilerGenerated]
	[AccessedThroughProperty("Label3")]
	private Label label_8;

	[CompilerGenerated]
	[AccessedThroughProperty("tbModelName")]
	private TextBox textBox_9;

	[CompilerGenerated]
	[AccessedThroughProperty("Label2")]
	private Label label_9;

	[CompilerGenerated]
	[AccessedThroughProperty("tbImport")]
	private ToolStripButton toolStripButton_6;

	[CompilerGenerated]
	[AccessedThroughProperty("tbExport")]
	private ToolStripButton toolStripButton_7;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolStripLabel1")]
	private ToolStripLabel toolStripLabel_1;

	[CompilerGenerated]
	[AccessedThroughProperty("Label11")]
	private Label label_10;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvApStatus")]
	private DataGridViewImageColumn dataGridViewImageColumn_0;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvApBssid")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_0;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvApSSID")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_1;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvApPin")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_2;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvApKey")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_3;

	[CompilerGenerated]
	[AccessedThroughProperty("tbNetworkKey")]
	private TextBox textBox_10;

	[CompilerGenerated]
	[AccessedThroughProperty("Label12")]
	private Label label_11;

	[CompilerGenerated]
	[AccessedThroughProperty("tbWpsPin")]
	private TextBox textBox_11;

	[CompilerGenerated]
	[AccessedThroughProperty("Label13")]
	private Label label_12;

	[CompilerGenerated]
	[AccessedThroughProperty("tbUpload")]
	private ToolStripButton toolStripButton_8;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolTip1")]
	private ToolTip toolTip_0;

	[CompilerGenerated]
	[AccessedThroughProperty("TimerToolTip")]
	private Timer timer_0;

	private SQLiteConnection sqliteConnection_0;

	private SQLiteCommand sqliteCommand_0;

	private SQLiteDataAdapter sqliteDataAdapter_0;

	private SQLiteCommandBuilder sqliteCommandBuilder_0;

	private DataTable dataTable_0;

	[CompilerGenerated]
	[AccessedThroughProperty("bsAp")]
	private BindingSource bindingSource_0;

	private SQLiteCommand sqliteCommand_1;

	private SQLiteDataAdapter sqliteDataAdapter_1;

	private DataTable dataTable_1;

	private ToolTip toolTip_1;

	internal virtual DataGridView DataGridView_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridView_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DataGridViewCellEventHandler object_ = method_3;
			KeyEventHandler object_2 = method_5;
			DataGridViewRowsRemovedEventHandler object_3 = method_6;
			DataGridViewDataErrorEventHandler object_4 = method_7;
			DataGridViewCellFormattingEventHandler object_5 = method_8;
			DataGridView dataGridView = dataGridView_0;
			while (true)
			{
				int num = 34446184;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x586AA67Au) % 12)
					{
					case 11u:
						dataGridView_0 = value;
						num = 453211016;
						continue;
					case 9u:
						Delegate8.delegate8_81(dataGridView, object_4);
						Delegate8.delegate8_82(dataGridView, object_5);
						num = (int)((num2 * 296593756) ^ 0x5A1EEE61);
						continue;
					case 8u:
						Delegate8.delegate8_86(dataGridView, object_4);
						num = (int)(num2 * 443664359) ^ -1473660663;
						continue;
					case 7u:
						Delegate8.delegate8_80(dataGridView, object_3);
						num = (int)((num2 * 1817840172) ^ 0x56BDED63);
						continue;
					case 6u:
					{
						dataGridView = dataGridView_0;
						int num5;
						int num6;
						if (dataGridView != null)
						{
							num5 = 342443784;
							num6 = 342443784;
						}
						else
						{
							num5 = 347806292;
							num6 = 347806292;
						}
						num = num5 ^ ((int)num2 * -894113455);
						continue;
					}
					case 5u:
						Delegate8.delegate8_84(dataGridView, object_2);
						Delegate8.delegate8_85(dataGridView, object_3);
						num = ((int)num2 * -1411449322) ^ 0x3336C878;
						continue;
					case 4u:
						Delegate8.delegate8_83(dataGridView, object_);
						num = (int)((num2 * 709470064) ^ 0x3323F0FF);
						continue;
					case 3u:
						Delegate8.delegate8_87(dataGridView, object_5);
						num = (int)(num2 * 409702104) ^ -3631570;
						continue;
					case 2u:
					{
						int num3;
						int num4;
						if (dataGridView != null)
						{
							num3 = -1882883989;
							num4 = -1882883989;
						}
						else
						{
							num3 = -2031132483;
							num4 = -2031132483;
						}
						num = num3 ^ ((int)num2 * -915162408);
						continue;
					}
					case 1u:
						Delegate8.delegate8_78(dataGridView, object_);
						Delegate8.delegate8_79(dataGridView, object_2);
						num = ((int)num2 * -1726537431) ^ 0x70332658;
						continue;
					default:
						return;
					case 10u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual BindingNavigator BindingNavigator_0
	{
		[CompilerGenerated]
		get
		{
			return bindingNavigator_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			bindingNavigator_0 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_0 = value;
		}
	}

	internal virtual ToolStripLabel ToolStripLabel_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripLabel_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripLabel_0 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_4;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = -867685552;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xCBD667CAu) % 7)
					{
					case 5u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = ((int)num2 * -1677143993) ^ 0x29860B82;
						continue;
					case 4u:
						toolStripButton = toolStripButton_1;
						num = (int)(num2 * 1014671219) ^ -1093692205;
						continue;
					case 2u:
					{
						int num4;
						int num5;
						if (toolStripButton != null)
						{
							num4 = 1509137253;
							num5 = 1509137253;
						}
						else
						{
							num4 = 1266859007;
							num5 = 1266859007;
						}
						num = num4 ^ (int)(num2 * 1150584819);
						continue;
					}
					case 1u:
					{
						toolStripButton_1 = value;
						toolStripButton = toolStripButton_1;
						int num3;
						if (toolStripButton == null)
						{
							num = -1054478571;
							num3 = -1054478571;
						}
						else
						{
							num = -947378437;
							num3 = -947378437;
						}
						continue;
					}
					case 0u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = ((int)num2 * -1692721581) ^ -1883202012;
						continue;
					default:
						return;
					case 6u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripButton ToolStripButton_2
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_2 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_3
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_3 = value;
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_0 = value;
		}
	}

	internal virtual ToolStripTextBox ToolStripTextBox_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripTextBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripTextBox_0 = value;
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_1 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_4
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_4 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_5
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_5;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_5 = value;
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_2
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_2 = value;
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_3
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_3 = value;
		}
	}

	internal virtual ToolStripTextBox ToolStripTextBox_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripTextBox_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_2;
			ToolStripTextBox toolStripTextBox = default(ToolStripTextBox);
			while (true)
			{
				int num = 108387809;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x52FB5C88u) % 8)
					{
					case 7u:
						toolStripTextBox_1 = value;
						num = 1013735069;
						continue;
					case 5u:
						toolStripTextBox = toolStripTextBox_1;
						num = (int)((num2 * 1103264768) ^ 0x59D5D0B8);
						continue;
					case 4u:
						Delegate8.delegate8_90(toolStripTextBox, object_);
						num = (int)(num2 * 910669697) ^ -102180077;
						continue;
					case 2u:
						Delegate8.delegate8_91(toolStripTextBox, object_);
						num = (int)((num2 * 1040458328) ^ 0x763D7A3B);
						continue;
					case 1u:
					{
						toolStripTextBox = toolStripTextBox_1;
						int num5;
						int num6;
						if (toolStripTextBox != null)
						{
							num5 = 673616643;
							num6 = 673616643;
						}
						else
						{
							num5 = 1588229784;
							num6 = 1588229784;
						}
						num = num5 ^ (int)(num2 * 1399826231);
						continue;
					}
					case 0u:
					{
						int num3;
						int num4;
						if (toolStripTextBox == null)
						{
							num3 = -2122006213;
							num4 = -2122006213;
						}
						else
						{
							num3 = -766463974;
							num4 = -766463974;
						}
						num = num3 ^ ((int)num2 * -127500519);
						continue;
					}
					default:
						return;
					case 6u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual Panel Panel_0
	{
		[CompilerGenerated]
		get
		{
			return panel_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			panel_0 = value;
		}
	}

	internal virtual TextBox TextBox_0
	{
		[CompilerGenerated]
		get
		{
			return textBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			textBox_0 = value;
		}
	}

	internal virtual Label Label_0
	{
		[CompilerGenerated]
		get
		{
			return label_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_0 = value;
		}
	}

	internal virtual TextBox TextBox_1
	{
		[CompilerGenerated]
		get
		{
			return textBox_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			textBox_1 = value;
		}
	}

	internal virtual Label Label_1
	{
		[CompilerGenerated]
		get
		{
			return label_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_1 = value;
		}
	}

	internal virtual TextBox TextBox_2
	{
		[CompilerGenerated]
		get
		{
			return textBox_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			textBox_2 = value;
		}
	}

	internal virtual Label Label_2
	{
		[CompilerGenerated]
		get
		{
			return label_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_2 = value;
		}
	}

	internal virtual TextBox TextBox_3
	{
		[CompilerGenerated]
		get
		{
			return textBox_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			textBox_3 = value;
		}
	}

	internal virtual Label Label_3
	{
		[CompilerGenerated]
		get
		{
			return label_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_3 = value;
		}
	}

	internal virtual TextBox TextBox_4
	{
		[CompilerGenerated]
		get
		{
			return textBox_4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_9;
			TextBox textBox = textBox_4;
			if (textBox != null)
			{
				goto IL_005c;
			}
			goto IL_0092;
			IL_005c:
			int num = 1628708694;
			goto IL_0061;
			IL_0061:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x57C501FCu) % 5)
				{
				case 3u:
					Delegate8.delegate8_92(textBox, object_);
					num = (int)(num2 * 1917172980) ^ -353553090;
					continue;
				case 1u:
					Delegate8.delegate8_93(textBox, object_);
					num = (int)(num2 * 2025255151) ^ -1592106293;
					continue;
				case 0u:
					break;
				default:
					return;
				case 4u:
					goto IL_0092;
				case 2u:
					return;
				}
				break;
			}
			goto IL_005c;
			IL_0092:
			textBox_4 = value;
			textBox = textBox_4;
			int num3;
			if (textBox != null)
			{
				num = 1521139427;
				num3 = 1521139427;
			}
			else
			{
				num = 395321146;
				num3 = 395321146;
			}
			goto IL_0061;
		}
	}

	internal virtual Label Label_4
	{
		[CompilerGenerated]
		get
		{
			return label_4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_4 = value;
		}
	}

	internal virtual TextBox TextBox_5
	{
		[CompilerGenerated]
		get
		{
			return textBox_5;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			textBox_5 = value;
		}
	}

	internal virtual Label Label_5
	{
		[CompilerGenerated]
		get
		{
			return label_5;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_5 = value;
		}
	}

	internal virtual TextBox TextBox_6
	{
		[CompilerGenerated]
		get
		{
			return textBox_6;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_10;
			TextBox textBox = default(TextBox);
			while (true)
			{
				int num = 617919704;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x2173EFC8u) % 7)
					{
					case 6u:
						Delegate8.delegate8_92(textBox, object_);
						num = ((int)num2 * -1521143351) ^ 0x497E5E0C;
						continue;
					case 5u:
					{
						textBox = textBox_6;
						int num5;
						int num6;
						if (textBox != null)
						{
							num5 = -1417573826;
							num6 = -1417573826;
						}
						else
						{
							num5 = -1603381174;
							num6 = -1603381174;
						}
						num = num5 ^ ((int)num2 * -1293710809);
						continue;
					}
					case 3u:
					{
						int num3;
						int num4;
						if (textBox != null)
						{
							num3 = 2091238331;
							num4 = 2091238331;
						}
						else
						{
							num3 = 1083127376;
							num4 = 1083127376;
						}
						num = num3 ^ ((int)num2 * -330046065);
						continue;
					}
					case 1u:
						Delegate8.delegate8_93(textBox, object_);
						num = ((int)num2 * -140480823) ^ -718052005;
						continue;
					case 0u:
						textBox_6 = value;
						textBox = textBox_6;
						num = 551387140;
						continue;
					default:
						return;
					case 2u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual Label Label_6
	{
		[CompilerGenerated]
		get
		{
			return label_6;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_6 = value;
		}
	}

	internal virtual TextBox TextBox_7
	{
		[CompilerGenerated]
		get
		{
			return textBox_7;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			textBox_7 = value;
		}
	}

	internal virtual Label Label_7
	{
		[CompilerGenerated]
		get
		{
			return label_7;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_7 = value;
		}
	}

	internal virtual TextBox TextBox_8
	{
		[CompilerGenerated]
		get
		{
			return textBox_8;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			textBox_8 = value;
		}
	}

	internal virtual Label Label_8
	{
		[CompilerGenerated]
		get
		{
			return label_8;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_8 = value;
		}
	}

	internal virtual TextBox TextBox_9
	{
		[CompilerGenerated]
		get
		{
			return textBox_9;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			textBox_9 = value;
		}
	}

	internal virtual Label Label_9
	{
		[CompilerGenerated]
		get
		{
			return label_9;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_9 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_6
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_6;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_6 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_7
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_7;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_7 = value;
		}
	}

	internal virtual ToolStripLabel ToolStripLabel_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripLabel_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripLabel_1 = value;
		}
	}

	internal virtual Label Label_10
	{
		[CompilerGenerated]
		get
		{
			return label_10;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_10 = value;
		}
	}

	internal virtual DataGridViewImageColumn DataGridViewImageColumn_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewImageColumn_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewImageColumn_0 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_0 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_1
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_1 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_2
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_2 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_3
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_3 = value;
		}
	}

	internal virtual TextBox TextBox_10
	{
		[CompilerGenerated]
		get
		{
			return textBox_10;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_12;
			TextBox textBox = textBox_10;
			while (true)
			{
				int num = -1364196411;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xB7BD8B48u) % 7)
					{
					case 4u:
						Delegate8.delegate8_92(textBox, object_);
						num = (int)((num2 * 1094375665) ^ 0x6B576052);
						continue;
					case 3u:
					{
						int num5;
						int num6;
						if (textBox == null)
						{
							num5 = -1523099064;
							num6 = -1523099064;
						}
						else
						{
							num5 = -470030752;
							num6 = -470030752;
						}
						num = num5 ^ (int)(num2 * 242378185);
						continue;
					}
					case 2u:
						textBox_10 = value;
						textBox = textBox_10;
						num = -1739889293;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (textBox == null)
						{
							num3 = -1977400779;
							num4 = -1977400779;
						}
						else
						{
							num3 = -1313394209;
							num4 = -1313394209;
						}
						num = num3 ^ ((int)num2 * -1424559864);
						continue;
					}
					case 0u:
						Delegate8.delegate8_93(textBox, object_);
						num = (int)(num2 * 939310134) ^ -1094940439;
						continue;
					default:
						return;
					case 5u:
						break;
					case 6u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual Label Label_11
	{
		[CompilerGenerated]
		get
		{
			return label_11;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_11 = value;
		}
	}

	internal virtual TextBox TextBox_11
	{
		[CompilerGenerated]
		get
		{
			return textBox_11;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_11;
			TextBox textBox = textBox_11;
			if (textBox != null)
			{
				goto IL_0026;
			}
			goto IL_0092;
			IL_0026:
			int num = -1025187788;
			goto IL_0061;
			IL_0061:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xD2227D66u) % 5)
				{
				case 4u:
					break;
				case 3u:
					Delegate8.delegate8_92(textBox, object_);
					num = ((int)num2 * -1022659955) ^ 0x78CCB29C;
					continue;
				case 1u:
					Delegate8.delegate8_93(textBox, object_);
					num = (int)((num2 * 1045853679) ^ 0x2DF01B4B);
					continue;
				default:
					return;
				case 2u:
					goto IL_0092;
				case 0u:
					return;
				}
				break;
			}
			goto IL_0026;
			IL_0092:
			textBox_11 = value;
			textBox = textBox_11;
			int num3;
			if (textBox != null)
			{
				num = -1617614384;
				num3 = -1617614384;
			}
			else
			{
				num = -856467295;
				num3 = -856467295;
			}
			goto IL_0061;
		}
	}

	internal virtual Label Label_12
	{
		[CompilerGenerated]
		get
		{
			return label_12;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_12 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_8
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_8;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_13;
			ToolStripButton toolStripButton = toolStripButton_8;
			while (true)
			{
				int num = 570162619;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x1AF697D8u) % 8)
					{
					case 7u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = (int)(num2 * 45719398) ^ -415067613;
						continue;
					case 6u:
						toolStripButton_8 = value;
						num = 497035202;
						continue;
					case 4u:
					{
						int num5;
						int num6;
						if (toolStripButton != null)
						{
							num5 = 940655279;
							num6 = 940655279;
						}
						else
						{
							num5 = 1939069905;
							num6 = 1939069905;
						}
						num = num5 ^ ((int)num2 * -1284921090);
						continue;
					}
					case 3u:
					{
						int num3;
						int num4;
						if (toolStripButton == null)
						{
							num3 = 197112552;
							num4 = 197112552;
						}
						else
						{
							num3 = 859920950;
							num4 = 859920950;
						}
						num = num3 ^ ((int)num2 * -1611325646);
						continue;
					}
					case 2u:
						toolStripButton = toolStripButton_8;
						num = ((int)num2 * -291989274) ^ -1096874776;
						continue;
					case 0u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = (int)((num2 * 702667554) ^ 0x6E99C4CE);
						continue;
					default:
						return;
					case 5u:
						break;
					case 1u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolTip ToolTip_0
	{
		[CompilerGenerated]
		get
		{
			return toolTip_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolTip_0 = value;
		}
	}

	internal virtual Timer Timer_0
	{
		[CompilerGenerated]
		get
		{
			return timer_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_14;
			Timer timer = default(Timer);
			while (true)
			{
				int num = -1641060967;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xAFC227C3u) % 9)
					{
					case 8u:
					{
						int num5;
						int num6;
						if (timer == null)
						{
							num5 = 1376965438;
							num6 = 1376965438;
						}
						else
						{
							num5 = 430981128;
							num6 = 430981128;
						}
						num = num5 ^ ((int)num2 * -658293069);
						continue;
					}
					case 6u:
						timer_0 = value;
						num = -788266967;
						continue;
					case 4u:
						Delegate8.delegate8_95(timer, object_);
						num = (int)((num2 * 1203073706) ^ 0x31A04332);
						continue;
					case 3u:
						timer = timer_0;
						num = ((int)num2 * -1872159231) ^ 0x64F3DC63;
						continue;
					case 2u:
					{
						int num3;
						int num4;
						if (timer == null)
						{
							num3 = 2097173853;
							num4 = 2097173853;
						}
						else
						{
							num3 = 359704478;
							num4 = 359704478;
						}
						num = num3 ^ (int)(num2 * 75254780);
						continue;
					}
					case 1u:
						timer = timer_0;
						num = ((int)num2 * -941054243) ^ -1191653171;
						continue;
					case 0u:
						Delegate8.delegate8_94(timer, object_);
						num = (int)(num2 * 511084206) ^ -794406885;
						continue;
					default:
						return;
					case 5u:
						break;
					case 7u:
						return;
					}
					break;
				}
			}
		}
	}

	private virtual BindingSource BindingSource_0
	{
		[CompilerGenerated]
		get
		{
			return bindingSource_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			bindingSource_0 = value;
		}
	}

	public ApLogForm()
	{
		while (true)
		{
			int num = -1735218859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x9C621CFCu) % 8)
				{
				case 7u:
					sqliteConnection_0 = new SQLiteConnection(global::_003CModule_003E.smethod_18<string>(340013998u, 1233543535u));
					num = (int)(num2 * 806945338) ^ -1463233015;
					continue;
				case 4u:
					dataTable_1 = new DataTable();
					num = ((int)num2 * -185585349) ^ -101262944;
					continue;
				case 3u:
					dataTable_0 = new DataTable();
					Delegate8.delegate8_13(this, Delegate3.delegate3_17());
					num = (int)(num2 * 2074476146) ^ -1120970410;
					continue;
				case 2u:
					Delegate22.delegate22_12(this);
					num = (int)((num2 * 1836249810) ^ 0x201B9745);
					continue;
				case 1u:
					Delegate8.delegate8_3(this, new EventHandler(method_1));
					num = (int)((num2 * 1120563738) ^ 0x287404F1);
					continue;
				case 0u:
					toolTip_1 = (ToolTip)Delegate3.delegate3_18();
					num = ((int)num2 * -1917797801) ^ -590136898;
					continue;
				default:
					return;
				case 6u:
					break;
				case 5u:
					return;
				}
				break;
			}
		}
	}

	[DebuggerNonUserCode]
	void Form.Dispose(bool disposing)
	{
		try
		{
			if (!disposing)
			{
				return;
			}
			while (true)
			{
				int num = -1556769291;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xAEACC51Cu) % 4)
					{
					case 2u:
						Delegate22.delegate22_4(icontainer_0);
						num = ((int)num2 * -1648309552) ^ 0x5435F05C;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (icontainer_0 == null)
						{
							num3 = -1720431932;
							num4 = -1720431932;
						}
						else
						{
							num3 = -846403990;
							num4 = -846403990;
						}
						num = num3 ^ ((int)num2 * -700335304);
						continue;
					}
					default:
						return;
					case 3u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
		finally
		{
			Delegate5.delegate5_3(this, disposing);
		}
	}

	[DebuggerStepThrough]
	private void method_0()
	{
		icontainer_0 = (IContainer)Delegate3.delegate3_19();
		DataGridViewCellStyle dataGridViewCellStyle = default(DataGridViewCellStyle);
		ComponentResourceManager object_ = default(ComponentResourceManager);
		DataGridViewCellStyle dataGridViewCellStyle2 = default(DataGridViewCellStyle);
		while (true)
		{
			int num = 763376688;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x4675D5B6u) % 175)
				{
				case 174u:
					Delegate30.delegate30_5(Delegate7.delegate7_24(this), global::_003CModule_003E.smethod_19<string>(877571753u, 3749980423u));
					Delegate8.delegate8_67(dataGridViewCellStyle, Delegate43.delegate43_0(global::_003CModule_003E.smethod_18<string>(2717136921u, 1818866937u), 9f, FontStyle.Regular, GraphicsUnit.Point, 0));
					num = (int)(num2 * 705680638) ^ -308455264;
					continue;
				case 172u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_29(this), global::_003CModule_003E.smethod_21<string>(4047873547u, 385219881u));
					Delegate30.delegate30_1(Delegate7.delegate7_29(this), global::_003CModule_003E.smethod_19<string>(60068099u, 2993560470u));
					num = (int)(num2 * 2052416858) ^ -684378175;
					continue;
				case 171u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_19(this));
					num = ((int)num2 * -2096067140) ^ 0x50C06017;
					continue;
				case 170u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_49(this), global::_003CModule_003E.smethod_22<string>(751937099u, 3774070560u));
					num = ((int)num2 * -1811930038) ^ -1105516824;
					continue;
				case 169u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_46(this));
					num = (int)((num2 * 1087163677) ^ 0x9D84D0E);
					continue;
				case 168u:
					Delegate8.delegate8_20(this, Delegate7.delegate7_16(icontainer_0));
					Delegate8.delegate8_21(this, Delegate3.delegate3_24());
					Delegate8.delegate8_22(this, Delegate3.delegate3_25());
					Delegate8.delegate8_23(this, Delegate3.delegate3_24());
					num = (int)((num2 * 135308038) ^ 0x7667BD8C);
					continue;
				case 167u:
					Delegate42.delegate42_0(Delegate7.delegate7_25(this), 200f);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_25(this), global::_003CModule_003E.smethod_20<string>(447933561u, 3721623455u));
					Delegate30.delegate30_6(Delegate7.delegate7_25(this), global::_003CModule_003E.smethod_21<string>(3960640975u, 1071988814u));
					num = (int)((num2 * 642098361) ^ 0x34BAFC6F);
					continue;
				case 166u:
					Delegate8.delegate8_41(this, Delegate3.delegate3_28());
					num = (int)(num2 * 591079429) ^ -981681510;
					continue;
				case 165u:
					Delegate22.delegate22_8(Delegate7.delegate7_21(this));
					num = (int)(num2 * 1308198749) ^ -1366225051;
					continue;
				case 164u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_31(this), global::_003CModule_003E.smethod_21<string>(3416597344u, 320855280u));
					num = (int)((num2 * 1246995131) ^ 0x72BE37ED);
					continue;
				case 163u:
					Delegate30.delegate30_5(Delegate7.delegate7_26(this), global::_003CModule_003E.smethod_18<string>(2355230920u, 4094259436u));
					num = ((int)num2 * -1216462104) ^ 0x10490638;
					continue;
				case 162u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_45(this), global::_003CModule_003E.smethod_20<string>(2314201296u, 2694556412u));
					Delegate30.delegate30_0(Delegate7.delegate7_45(this), global::_003CModule_003E.smethod_22<string>(3395177000u, 896430480u));
					num = (int)(num2 * 662870970) ^ -1927666760;
					continue;
				case 161u:
					Delegate46.delegate46_0(Delegate7.delegate7_37(this), ToolStripItemDisplayStyle.Image);
					Delegate8.delegate8_77(Delegate7.delegate7_37(this), Delegate3.delegate3_32());
					num = ((int)num2 * -1610763741) ^ -2099988141;
					continue;
				case 160u:
					Delegate22.delegate22_6(Delegate7.delegate7_19(this));
					num = (int)(num2 * 1395944724) ^ -92441756;
					continue;
				case 159u:
					Delegate46.delegate46_0(Delegate7.delegate7_40(this), ToolStripItemDisplayStyle.Image);
					Delegate8.delegate8_77(Delegate7.delegate7_40(this), Delegate3.delegate3_34());
					Delegate30.delegate30_1(Delegate7.delegate7_40(this), global::_003CModule_003E.smethod_22<string>(13837137u, 1983399695u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_40(this), global::_003CModule_003E.smethod_19<string>(3491550035u, 3234467771u));
					num = (int)((num2 * 1557931065) ^ 0x25BDA741);
					continue;
				case 158u:
					Delegate8.delegate8_31(this, Delegate3.delegate3_24());
					num = ((int)num2 * -1598328046) ^ 0x4780A81C;
					continue;
				case 157u:
					Delegate8.delegate8_38(this, Delegate3.delegate3_14());
					num = (int)((num2 * 2060861562) ^ 0x70059713);
					continue;
				case 156u:
					Delegate39.delegate39_0(Delegate7.delegate7_19(this), DataGridViewColumnHeadersHeightSizeMode.AutoSize);
					Delegate40.smethod_0(Delegate7.delegate7_22(Delegate7.delegate7_19(this)), new DataGridViewColumn[5]
					{
						(DataGridViewColumn)Delegate7.delegate7_23(this),
						(DataGridViewColumn)Delegate7.delegate7_24(this),
						(DataGridViewColumn)Delegate7.delegate7_25(this),
						(DataGridViewColumn)Delegate7.delegate7_26(this),
						(DataGridViewColumn)Delegate7.delegate7_27(this)
					});
					num = ((int)num2 * -883346178) ^ 0x68F3083A;
					continue;
				case 155u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_47(this), global::_003CModule_003E.smethod_20<string>(2072751437u, 4156836574u));
					Delegate30.delegate30_0(Delegate7.delegate7_47(this), global::_003CModule_003E.smethod_18<string>(1554752u, 1327010395u));
					num = (int)((num2 * 2076276331) ^ 0x3B8874A1);
					continue;
				case 154u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_61(this), global::_003CModule_003E.smethod_22<string>(3040409089u, 3746831383u));
					num = (int)((num2 * 72607383) ^ 0x6B417EA2);
					continue;
				case 153u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_51(this), global::_003CModule_003E.smethod_19<string>(4147586369u, 2716971416u));
					num = (int)((num2 * 2100060337) ^ 0x51056FFD);
					continue;
				case 152u:
					Delegate8.delegate8_64(this, Delegate7.delegate7_17(icontainer_0));
					Delegate8.delegate8_65(this, Delegate7.delegate7_18(icontainer_0));
					num = ((int)num2 * -1374311167) ^ -858689009;
					continue;
				case 151u:
					Delegate46.delegate46_0(Delegate7.delegate7_32(this), ToolStripItemDisplayStyle.Image);
					num = ((int)num2 * -601887876) ^ 0x62E99C84;
					continue;
				case 150u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_63(this), global::_003CModule_003E.smethod_21<string>(1674342723u, 2785864672u));
					num = ((int)num2 * -1481017662) ^ 0x3A175E65;
					continue;
				case 149u:
					Delegate47.delegate47_0(Delegate7.delegate7_44(this), ToolStripItemAlignment.Right);
					num = (int)((num2 * 1032032187) ^ 0x7408CA1B);
					continue;
				case 148u:
					Delegate30.delegate30_5(Delegate7.delegate7_25(this), global::_003CModule_003E.smethod_20<string>(2780370979u, 1785979160u));
					num = ((int)num2 * -1924539950) ^ -952870237;
					continue;
				case 147u:
					Delegate5.delegate5_16(Delegate7.delegate7_45(this), bool_0: true);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_46(this), global::_003CModule_003E.smethod_20<string>(3423923916u, 3659656875u));
					num = (int)((num2 * 1309683332) ^ 0x5F02DD32);
					continue;
				case 146u:
					Delegate8.delegate8_58(this, Delegate3.delegate3_28());
					num = ((int)num2 * -1692888572) ^ -1607890469;
					continue;
				case 145u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_20(this));
					Delegate35.delegate35_0(this, FormBorderStyle.FixedSingle);
					Delegate5.delegate5_7(this, bool_0: false);
					num = (int)((num2 * 91045167) ^ 0x65B29FBC);
					continue;
				case 144u:
					Delegate30.delegate30_0(Delegate7.delegate7_55(this), global::_003CModule_003E.smethod_19<string>(152031511u, 599715937u));
					num = ((int)num2 * -2120940754) ^ -170868103;
					continue;
				case 142u:
					Delegate8.delegate8_16(this, Delegate3.delegate3_23());
					Delegate8.delegate8_17(this, Delegate3.delegate3_23());
					Delegate8.delegate8_18(this, Delegate3.delegate3_23());
					Delegate8.delegate8_19(this, Delegate3.delegate3_23());
					num = ((int)num2 * -305098950) ^ 0x2AE2A3F2;
					continue;
				case 141u:
					Delegate5.delegate5_16(Delegate7.delegate7_47(this), bool_0: true);
					num = (int)((num2 * 1027805557) ^ 0x7784F3C9);
					continue;
				case 140u:
					Delegate8.delegate8_29(this, Delegate3.delegate3_26());
					Delegate8.delegate8_30(this, Delegate3.delegate3_24());
					num = (int)((num2 * 2022608353) ^ 0x65C9031C);
					continue;
				case 139u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_35(this), global::_003CModule_003E.smethod_18<string>(234825864u, 510800678u));
					Delegate30.delegate30_1(Delegate7.delegate7_35(this), global::_003CModule_003E.smethod_22<string>(878476793u, 3266074852u));
					num = ((int)num2 * -969512130) ^ 0x3AA0F8A7;
					continue;
				case 138u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_54(this));
					num = ((int)num2 * -408568918) ^ -1387797848;
					continue;
				case 137u:
					Delegate5.delegate5_16(Delegate7.delegate7_68(this), bool_0: true);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_69(this), global::_003CModule_003E.smethod_21<string>(2617738730u, 4262970087u));
					num = (int)(num2 * 1927838218) ^ -1374976215;
					continue;
				case 136u:
					Delegate22.delegate22_8(Delegate7.delegate7_20(this));
					Delegate5.delegate5_10(Delegate7.delegate7_21(this), bool_0: false);
					num = (int)((num2 * 1467075454) ^ 0x42A420DF);
					continue;
				case 135u:
					Delegate30.delegate30_0(Delegate7.delegate7_61(this), global::_003CModule_003E.smethod_22<string>(3040409089u, 2518566257u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_62(this), global::_003CModule_003E.smethod_19<string>(3779201372u, 3717608204u));
					Delegate30.delegate30_0(Delegate7.delegate7_62(this), global::_003CModule_003E.smethod_22<string>(2760812750u, 3426009687u));
					num = ((int)num2 * -609462320) ^ -782670237;
					continue;
				case 134u:
					Delegate5.delegate5_15(Delegate7.delegate7_24(this), bool_0: true);
					num = ((int)num2 * -398186) ^ -1792819817;
					continue;
				case 133u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_57(this), global::_003CModule_003E.smethod_20<string>(4179204499u, 3159045193u));
					Delegate30.delegate30_0(Delegate7.delegate7_57(this), global::_003CModule_003E.smethod_22<string>(2913536239u, 3576543170u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_58(this), global::_003CModule_003E.smethod_21<string>(3843634514u, 234245353u));
					num = (int)(num2 * 32753083) ^ -1182440779;
					continue;
				case 132u:
					Delegate8.delegate8_51(this, Delegate3.delegate3_9());
					Delegate8.delegate8_52(this, Delegate3.delegate3_28());
					num = (int)(num2 * 1183727488) ^ -1685195865;
					continue;
				case 131u:
					Delegate8.delegate8_59(this, Delegate3.delegate3_9());
					Delegate8.delegate8_60(this, Delegate3.delegate3_28());
					Delegate8.delegate8_61(this, Delegate3.delegate3_9());
					Delegate8.delegate8_62(this, Delegate3.delegate3_28());
					num = (int)(num2 * 2034916713) ^ -1993926973;
					continue;
				case 130u:
					Delegate30.delegate30_0(Delegate7.delegate7_69(this), global::_003CModule_003E.smethod_18<string>(1323670101u, 4216832791u));
					num = ((int)num2 * -2036673262) ^ 0x5115D90E;
					continue;
				case 129u:
					Delegate8.delegate8_42(this, Delegate3.delegate3_9());
					num = ((int)num2 * -1472834255) ^ 0x41701D2C;
					continue;
				case 128u:
					Delegate8.delegate8_32(this, Delegate3.delegate3_26());
					num = (int)(num2 * 1458385315) ^ -1309686485;
					continue;
				case 127u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_50(this));
					num = (int)(num2 * 914948112) ^ -954788094;
					continue;
				case 126u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_33(this), global::_003CModule_003E.smethod_22<string>(1031200282u, 3419646275u));
					Delegate30.delegate30_1(Delegate7.delegate7_34(this), global::_003CModule_003E.smethod_19<string>(4009641251u, 2135524159u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_34(this), global::_003CModule_003E.smethod_21<string>(3467096363u, 3301032627u));
					num = (int)((num2 * 182269360) ^ 0x6152C01A);
					continue;
				case 125u:
					Delegate8.delegate8_74(Delegate7.delegate7_20(this), Delegate7.delegate7_37(this));
					num = ((int)num2 * -2046273635) ^ 0x52BF75F4;
					continue;
				case 124u:
					Delegate30.delegate30_0(Delegate7.delegate7_60(this), global::_003CModule_003E.smethod_19<string>(1890763332u, 1265867694u));
					num = ((int)num2 * -23920720) ^ 0x24B6D8AA;
					continue;
				case 123u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_55(this));
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_56(this));
					num = ((int)num2 * -1261650796) ^ 0x708E23AB;
					continue;
				case 122u:
					Delegate5.delegate5_15(Delegate7.delegate7_25(this), bool_0: true);
					num = (int)(num2 * 1621010466) ^ -504548158;
					continue;
				case 121u:
					Delegate8.delegate8_75(Delegate7.delegate7_20(this), Delegate7.delegate7_33(this));
					num = (int)(num2 * 1344249196) ^ -1911953787;
					continue;
				case 120u:
					Delegate22.delegate22_10(this);
					num = (int)((num2 * 1651242461) ^ 0x46C1B885);
					continue;
				case 119u:
					Delegate8.delegate8_45(this, Delegate3.delegate3_9());
					Delegate8.delegate8_46(this, Delegate3.delegate3_28());
					Delegate8.delegate8_47(this, Delegate3.delegate3_9());
					num = (int)((num2 * 1172843925) ^ 0x40DD1439);
					continue;
				case 118u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_52(this), global::_003CModule_003E.smethod_20<string>(238679240u, 2086055095u));
					Delegate30.delegate30_0(Delegate7.delegate7_52(this), global::_003CModule_003E.smethod_20<string>(238679240u, 2581028625u));
					num = (int)(num2 * 516303589) ^ -563175701;
					continue;
				case 117u:
					Delegate5.delegate5_15(Delegate7.delegate7_27(this), bool_0: true);
					Delegate8.delegate8_69(Delegate7.delegate7_20(this), Delegate7.delegate7_28(this));
					Delegate8.delegate8_70(Delegate7.delegate7_20(this), Delegate7.delegate7_29(this));
					num = (int)(num2 * 140406806) ^ -1561131024;
					continue;
				case 116u:
					Delegate8.delegate8_63(this, Delegate3.delegate3_9());
					num = ((int)num2 * -59752526) ^ -1215929123;
					continue;
				case 115u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_59(this));
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_60(this));
					num = ((int)num2 * -1682319341) ^ 0x79478B54;
					continue;
				case 114u:
					Delegate5.delegate5_15(Delegate7.delegate7_26(this), bool_0: true);
					num = ((int)num2 * -1270309880) ^ -1584220221;
					continue;
				case 113u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_41(this), global::_003CModule_003E.smethod_18<string>(259835736u, 1449723163u));
					Delegate8.delegate8_77(Delegate7.delegate7_42(this), Delegate3.delegate3_35());
					num = (int)(num2 * 1424385358) ^ -1735287869;
					continue;
				case 112u:
					Delegate44.delegate44_0(Delegate7.delegate7_27(this), DataGridViewAutoSizeColumnMode.Fill);
					Delegate30.delegate30_5(Delegate7.delegate7_27(this), global::_003CModule_003E.smethod_19<string>(2616303574u, 913866223u));
					num = ((int)num2 * -1722740126) ^ 0x184DA730;
					continue;
				case 111u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_39(this), global::_003CModule_003E.smethod_18<string>(3442512040u, 322401835u));
					num = (int)(num2 * 288948783) ^ -1436003973;
					continue;
				case 110u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_21(this));
					num = ((int)num2 * -580300363) ^ -1465134911;
					continue;
				case 109u:
					Delegate30.delegate30_0(Delegate7.delegate7_49(this), global::_003CModule_003E.smethod_20<string>(850036639u, 900868407u));
					num = ((int)num2 * -812656304) ^ 0x51D03F4D;
					continue;
				case 108u:
					Delegate32.delegate32_1(Delegate7.delegate7_71(this), 1000);
					num = ((int)num2 * -985399068) ^ -915658781;
					continue;
				case 107u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_61(this));
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_62(this));
					num = ((int)num2 * -1767476180) ^ -545177734;
					continue;
				case 106u:
					Delegate45.delegate45_0(Delegate7.delegate7_20(this), ToolStripGripStyle.Hidden);
					num = (int)(num2 * 1678542664) ^ -1307988541;
					continue;
				case 105u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_49(this));
					num = (int)(num2 * 313153619) ^ -793046850;
					continue;
				case 104u:
					Delegate30.delegate30_0(Delegate7.delegate7_66(this), global::_003CModule_003E.smethod_19<string>(3606504300u, 3382897396u));
					Delegate5.delegate5_16(Delegate7.delegate7_66(this), bool_0: true);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_67(this), global::_003CModule_003E.smethod_21<string>(2349235212u, 1402629323u));
					Delegate30.delegate30_0(Delegate7.delegate7_67(this), global::_003CModule_003E.smethod_21<string>(2349235212u, 381596342u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_68(this), global::_003CModule_003E.smethod_22<string>(2048896583u, 1785802180u));
					num = (int)((num2 * 1342136985) ^ 0x74438D06);
					continue;
				case 103u:
					Delegate46.delegate46_0(Delegate7.delegate7_30(this), ToolStripItemDisplayStyle.Image);
					num = (int)((num2 * 1524752029) ^ 0x2EBD20B9);
					continue;
				case 102u:
					Delegate5.delegate5_14(Delegate7.delegate7_19(this), bool_0: true);
					num = (int)(num2 * 2145519096) ^ -233271921;
					continue;
				case 101u:
					Delegate30.delegate30_0(Delegate7.delegate7_63(this), global::_003CModule_003E.smethod_21<string>(1674342723u, 4032204002u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_64(this), global::_003CModule_003E.smethod_21<string>(1449378560u, 278823599u));
					num = ((int)num2 * -1327560658) ^ -1150062249;
					continue;
				case 100u:
					Delegate8.delegate8_53(this, Delegate3.delegate3_9());
					num = (int)((num2 * 2095779067) ^ 0x7E735D30);
					continue;
				case 99u:
					Delegate46.delegate46_0(Delegate7.delegate7_38(this), ToolStripItemDisplayStyle.Image);
					Delegate8.delegate8_77(Delegate7.delegate7_38(this), Delegate3.delegate3_33());
					Delegate30.delegate30_1(Delegate7.delegate7_38(this), global::_003CModule_003E.smethod_19<string>(3664247107u, 1861009945u));
					num = ((int)num2 * -2136886815) ^ -1649822565;
					continue;
				case 98u:
					Delegate46.delegate46_0(Delegate7.delegate7_28(this), ToolStripItemDisplayStyle.Image);
					Delegate8.delegate8_77(Delegate7.delegate7_28(this), Delegate3.delegate3_29());
					num = (int)(num2 * 584374863) ^ -321228326;
					continue;
				case 97u:
					Delegate30.delegate30_1(Delegate7.delegate7_30(this), global::_003CModule_003E.smethod_22<string>(521328537u, 1023338077u));
					Delegate46.delegate46_0(Delegate7.delegate7_31(this), ToolStripItemDisplayStyle.Image);
					num = ((int)num2 * -1630734108) ^ 0x4F1F5DD3;
					continue;
				case 96u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_37(this), global::_003CModule_003E.smethod_18<string>(751387832u, 2832805809u));
					num = (int)((num2 * 758933338) ^ 0x7E94265E);
					continue;
				case 95u:
					Delegate30.delegate30_1(Delegate7.delegate7_33(this), global::_003CModule_003E.smethod_22<string>(1031200282u, 3057573228u));
					num = (int)((num2 * 1626228648) ^ 0x17636581);
					continue;
				case 94u:
					Delegate8.delegate8_57(this, Delegate3.delegate3_9());
					num = ((int)num2 * -381735829) ^ -1599133550;
					continue;
				case 93u:
					Delegate8.delegate8_34(this, Delegate3.delegate3_26());
					Delegate8.delegate8_35(this, Delegate3.delegate3_25());
					num = (int)(num2 * 206524834) ^ -1665844205;
					continue;
				case 92u:
					Delegate5.delegate5_16(Delegate7.delegate7_52(this), bool_0: true);
					num = ((int)num2 * -1213175529) ^ 0x790C52A9;
					continue;
				case 91u:
					dataGridViewCellStyle2 = (DataGridViewCellStyle)Delegate3.delegate3_20();
					object_ = (ComponentResourceManager)Delegate7.delegate7_4(Delegate9.delegate9_0(typeof(ApLogForm).TypeHandle));
					dataGridViewCellStyle = (DataGridViewCellStyle)Delegate3.delegate3_20();
					Delegate8.delegate8_14(this, Delegate3.delegate3_21());
					Delegate8.delegate8_15(this, Delegate3.delegate3_22());
					num = (int)((num2 * 333741963) ^ 0x450F772E);
					continue;
				case 90u:
					Delegate30.delegate30_0(Delegate7.delegate7_20(this), global::_003CModule_003E.smethod_18<string>(957074749u, 3593558113u));
					num = (int)((num2 * 21234710) ^ 0x402F914F);
					continue;
				case 89u:
					Delegate30.delegate30_0(Delegate7.delegate7_65(this), global::_003CModule_003E.smethod_18<string>(2176116992u, 2104778864u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_66(this), global::_003CModule_003E.smethod_21<string>(4293562840u, 4194198980u));
					num = ((int)num2 * -938418705) ^ 0x3FC3A43F;
					continue;
				case 88u:
					Delegate8.delegate8_55(this, Delegate3.delegate3_9());
					Delegate8.delegate8_56(this, Delegate3.delegate3_28());
					num = (int)((num2 * 40060698) ^ 0x7A047F8B);
					continue;
				case 87u:
					Delegate30.delegate30_1(Delegate7.delegate7_41(this), global::_003CModule_003E.smethod_18<string>(259835736u, 841168351u));
					num = (int)((num2 * 1702409329) ^ 0x498F9860);
					continue;
				case 86u:
					Delegate30.delegate30_1(Delegate7.delegate7_36(this), global::_003CModule_003E.smethod_22<string>(1564542321u, 589015976u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_36(this), global::_003CModule_003E.smethod_20<string>(2441394445u, 3804534499u));
					num = ((int)num2 * -125341553) ^ -702775480;
					continue;
				case 85u:
					Delegate34.delegate34_0(this, AutoScaleMode.Font);
					num = ((int)num2 * -415562376) ^ 0x1910A469;
					continue;
				case 84u:
					Delegate8.delegate8_77(Delegate7.delegate7_44(this), Delegate3.delegate3_36());
					Delegate27.delegate27_0(object_, Delegate7.delegate7_44(this), global::_003CModule_003E.smethod_21<string>(3749519209u, 1443312870u));
					Delegate30.delegate30_1(Delegate7.delegate7_44(this), global::_003CModule_003E.smethod_18<string>(467085770u, 3370878890u));
					Delegate29.delegate29_2(Delegate7.delegate7_21(this), Delegate28.delegate28_6());
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_45(this));
					num = (int)(num2 * 1031843533) ^ -667558783;
					continue;
				case 83u:
					Delegate5.delegate5_12(Delegate7.delegate7_19(this), bool_0: false);
					Delegate5.delegate5_13(Delegate7.delegate7_19(this), bool_0: false);
					Delegate29.delegate29_3(dataGridViewCellStyle2, Delegate28.delegate28_4());
					Delegate8.delegate8_66(Delegate7.delegate7_19(this), dataGridViewCellStyle2);
					Delegate38.delegate38_0(Delegate7.delegate7_19(this), DataGridViewClipboardCopyMode.EnableWithoutHeaderText);
					num = (int)((num2 * 686154183) ^ 0x75CAEEB2);
					continue;
				case 82u:
					Delegate8.delegate8_26(this, Delegate3.delegate3_24());
					num = (int)((num2 * 775380202) ^ 0x1576025C);
					continue;
				case 81u:
					Delegate46.delegate46_0(Delegate7.delegate7_44(this), ToolStripItemDisplayStyle.Image);
					num = ((int)num2 * -713630488) ^ -1288538414;
					continue;
				case 80u:
					Delegate5.delegate5_16(Delegate7.delegate7_60(this), bool_0: true);
					num = ((int)num2 * -466710894) ^ 0x5CB69A57;
					continue;
				case 79u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_19(this), global::_003CModule_003E.smethod_18<string>(4169450276u, 1706010055u));
					Delegate30.delegate30_0(Delegate7.delegate7_19(this), global::_003CModule_003E.smethod_18<string>(4169450276u, 1427074387u));
					num = (int)(num2 * 2065215898) ^ -802692610;
					continue;
				case 78u:
					Delegate30.delegate30_1(Delegate7.delegate7_37(this), global::_003CModule_003E.smethod_18<string>(751387832u, 4638478u));
					num = ((int)num2 * -1511707115) ^ 0x4460A27A;
					continue;
				case 77u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_58(this));
					num = (int)((num2 * 1074450754) ^ 0x1A0D121D);
					continue;
				case 76u:
					Delegate30.delegate30_0(Delegate7.delegate7_59(this), global::_003CModule_003E.smethod_19<string>(3157385643u, 2915629436u));
					num = ((int)num2 * -162408651) ^ -1074222428;
					continue;
				case 75u:
					Delegate8.delegate8_39(this, Delegate3.delegate3_28());
					Delegate8.delegate8_40(this, Delegate3.delegate3_9());
					num = ((int)num2 * -1649350442) ^ -1383561219;
					continue;
				case 74u:
					Delegate30.delegate30_0(Delegate7.delegate7_64(this), global::_003CModule_003E.smethod_21<string>(1449378560u, 3675916681u));
					num = ((int)num2 * -975237365) ^ -150234494;
					continue;
				case 73u:
					Delegate30.delegate30_6(Delegate7.delegate7_24(this), global::_003CModule_003E.smethod_22<string>(140709987u, 2598526185u));
					num = (int)((num2 * 142435039) ^ 0x4F07E653);
					continue;
				case 72u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_63(this));
					num = ((int)num2 * -2012082219) ^ -1184693607;
					continue;
				case 71u:
					Delegate5.delegate5_10(Delegate7.delegate7_20(this), bool_0: false);
					num = ((int)num2 * -768013920) ^ -1786859320;
					continue;
				case 70u:
					Delegate8.delegate8_44(this, Delegate3.delegate3_28());
					num = (int)((num2 * 147346326) ^ 0x221AA6A);
					continue;
				case 69u:
					Delegate48.delegate48_0(Delegate7.delegate7_70(this), ToolTipIcon.Info);
					num = ((int)num2 * -765957468) ^ -185567094;
					continue;
				case 68u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_65(this), global::_003CModule_003E.smethod_19<string>(923553459u, 3261821443u));
					num = ((int)num2 * -1719552554) ^ 0x23C0E58A;
					continue;
				case 67u:
					Delegate8.delegate8_36(this, Delegate3.delegate3_27());
					num = (int)(num2 * 2099149229) ^ -1348988607;
					continue;
				case 66u:
					Delegate5.delegate5_16(Delegate7.delegate7_64(this), bool_0: true);
					num = (int)(num2 * 1917142608) ^ -623094621;
					continue;
				case 65u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_69(this));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_21(this), global::_003CModule_003E.smethod_22<string>(1667944877u, 2578386923u));
					num = ((int)num2 * -910383661) ^ -256685141;
					continue;
				case 64u:
					Delegate30.delegate30_6(Delegate7.delegate7_23(this), global::_003CModule_003E.smethod_20<string>(1300740819u, 928398850u));
					Delegate5.delegate5_15(Delegate7.delegate7_23(this), bool_0: true);
					num = ((int)num2 * -682352678) ^ 0x600EDCDD;
					continue;
				case 63u:
					Delegate30.delegate30_1(Delegate7.delegate7_43(this), global::_003CModule_003E.smethod_22<string>(3954369678u, 28533538u));
					num = (int)(num2 * 1219450808) ^ -1349399348;
					continue;
				case 62u:
					Delegate8.delegate8_43(this, Delegate3.delegate3_9());
					num = ((int)num2 * -1180620093) ^ 0x1F53F3F2;
					continue;
				case 61u:
					Delegate30.delegate30_1(Delegate7.delegate7_28(this), global::_003CModule_003E.smethod_22<string>(3444164777u, 3965063274u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_28(this), global::_003CModule_003E.smethod_18<string>(2871792888u, 2066777531u));
					num = (int)((num2 * 1628050124) ^ 0x50E1B71F);
					continue;
				case 60u:
					Delegate5.delegate5_16(Delegate7.delegate7_56(this), bool_0: true);
					num = ((int)num2 * -201668801) ^ 0x6D3726D3;
					continue;
				case 59u:
					Delegate30.delegate30_6(Delegate7.delegate7_27(this), global::_003CModule_003E.smethod_18<string>(4269949059u, 2736367906u));
					num = (int)(num2 * 1480099159) ^ -586141651;
					continue;
				case 58u:
					Delegate8.delegate8_37(this, Delegate3.delegate3_24());
					num = (int)(num2 * 1651656680) ^ -1733690327;
					continue;
				case 57u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_67(this));
					num = ((int)num2 * -2140960465) ^ -227042222;
					continue;
				case 56u:
					Delegate30.delegate30_5(Delegate7.delegate7_23(this), global::_003CModule_003E.smethod_18<string>(1116420067u, 1861674742u));
					num = (int)((num2 * 423102656) ^ 0x178162C2);
					continue;
				case 55u:
					Delegate30.delegate30_0(Delegate7.delegate7_54(this), global::_003CModule_003E.smethod_22<string>(3369326361u, 2782049461u));
					Delegate5.delegate5_16(Delegate7.delegate7_54(this), bool_0: true);
					num = (int)((num2 * 450256704) ^ 0x212DD555);
					continue;
				case 54u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_43(this), global::_003CModule_003E.smethod_20<string>(721578958u, 205623542u));
					num = (int)((num2 * 466767097) ^ 0x5AAC58DF);
					continue;
				case 53u:
					Delegate30.delegate30_0(Delegate7.delegate7_68(this), global::_003CModule_003E.smethod_21<string>(179943421u, 3840150088u));
					num = ((int)num2 * -837313631) ^ -329082701;
					continue;
				case 52u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_59(this), global::_003CModule_003E.smethod_19<string>(3157385643u, 3900411820u));
					num = ((int)num2 * -2146581073) ^ 0x2BFA67F;
					continue;
				case 51u:
					Delegate5.delegate5_8(this, bool_0: false);
					num = (int)((num2 * 1944229634) ^ 0x1553C82D);
					continue;
				case 50u:
					Delegate8.delegate8_33(this, Delegate3.delegate3_24());
					num = (int)(num2 * 1143379187) ^ -932186447;
					continue;
				case 49u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_53(this), global::_003CModule_003E.smethod_21<string>(3611787618u, 501031925u));
					Delegate30.delegate30_0(Delegate7.delegate7_53(this), global::_003CModule_003E.smethod_18<string>(4243927981u, 93381309u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_54(this), global::_003CModule_003E.smethod_21<string>(2255119907u, 1362005961u));
					num = ((int)num2 * -203243677) ^ 0x51D25E7;
					continue;
				case 48u:
					Delegate5.delegate5_16(Delegate7.delegate7_62(this), bool_0: true);
					num = ((int)num2 * -2056189294) ^ 0x74D6BCA2;
					continue;
				case 47u:
					Delegate8.delegate8_24(this, Delegate3.delegate3_24());
					Delegate8.delegate8_25(this, Delegate3.delegate3_24());
					num = (int)(num2 * 1316094820) ^ -813522048;
					continue;
				case 46u:
					Delegate42.delegate42_0(Delegate7.delegate7_23(this), 80f);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_23(this), global::_003CModule_003E.smethod_22<string>(1259095343u, 1970692465u));
					num = (int)((num2 * 656784785) ^ 0x8B9EAA1);
					continue;
				case 45u:
					Delegate31.smethod_0(Delegate7.delegate7_10(Delegate7.delegate7_20(this)), new ToolStripItem[17]
					{
						(ToolStripItem)Delegate7.delegate7_30(this),
						(ToolStripItem)Delegate7.delegate7_31(this),
						(ToolStripItem)Delegate7.delegate7_32(this),
						(ToolStripItem)Delegate7.delegate7_33(this),
						(ToolStripItem)Delegate7.delegate7_34(this),
						(ToolStripItem)Delegate7.delegate7_35(this),
						(ToolStripItem)Delegate7.delegate7_29(this),
						(ToolStripItem)Delegate7.delegate7_36(this),
						(ToolStripItem)Delegate7.delegate7_37(this),
						(ToolStripItem)Delegate7.delegate7_38(this),
						(ToolStripItem)Delegate7.delegate7_39(this),
						(ToolStripItem)Delegate7.delegate7_28(this),
						(ToolStripItem)Delegate7.delegate7_40(this),
						(ToolStripItem)Delegate7.delegate7_41(this),
						(ToolStripItem)Delegate7.delegate7_42(this),
						(ToolStripItem)Delegate7.delegate7_43(this),
						(ToolStripItem)Delegate7.delegate7_44(this)
					});
					Delegate27.delegate27_0(object_, Delegate7.delegate7_20(this), global::_003CModule_003E.smethod_22<string>(3723761116u, 2530633106u));
					Delegate8.delegate8_72(Delegate7.delegate7_20(this), Delegate7.delegate7_32(this));
					Delegate8.delegate8_73(Delegate7.delegate7_20(this), Delegate7.delegate7_38(this));
					num = (int)(num2 * 247764242) ^ -1727776974;
					continue;
				case 44u:
					Delegate30.delegate30_0(Delegate7.delegate7_58(this), global::_003CModule_003E.smethod_22<string>(2633939900u, 2053354360u));
					Delegate5.delegate5_16(Delegate7.delegate7_58(this), bool_0: true);
					num = ((int)num2 * -150695278) ^ -142236327;
					continue;
				case 43u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_56(this), global::_003CModule_003E.smethod_18<string>(3778396963u, 3535577382u));
					Delegate30.delegate30_0(Delegate7.delegate7_56(this), global::_003CModule_003E.smethod_22<string>(1285279138u, 1960062560u));
					num = ((int)num2 * -696442547) ^ -1875502144;
					continue;
				case 42u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_68(this));
					num = ((int)num2 * -1448489341) ^ -1537519839;
					continue;
				case 41u:
					Delegate8.delegate8_68(Delegate7.delegate7_24(this), dataGridViewCellStyle);
					Delegate42.delegate42_0(Delegate7.delegate7_24(this), 150f);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_24(this), global::_003CModule_003E.smethod_19<string>(3111403937u, 3156528185u));
					num = ((int)num2 * -431642253) ^ 0x2AA86763;
					continue;
				case 40u:
					Delegate30.delegate30_1(Delegate7.delegate7_39(this), global::_003CModule_003E.smethod_20<string>(365872389u, 2933880890u));
					num = ((int)num2 * -1583544466) ^ 0x6F8AF7D8;
					continue;
				case 39u:
					Delegate30.delegate30_1(Delegate7.delegate7_31(this), global::_003CModule_003E.smethod_19<string>(681883828u, 2872645005u));
					num = ((int)num2 * -216198978) ^ -2080121959;
					continue;
				case 38u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_57(this));
					num = (int)(num2 * 1525896922) ^ -1988192942;
					continue;
				case 37u:
					Delegate30.delegate30_0(Delegate7.delegate7_51(this), global::_003CModule_003E.smethod_21<string>(1486112113u, 1210101952u));
					num = ((int)num2 * -805785683) ^ 0x4C47173E;
					continue;
				case 36u:
					Delegate8.delegate8_54(this, Delegate3.delegate3_28());
					num = ((int)num2 * -1714670947) ^ -1337176825;
					continue;
				case 35u:
					Delegate8.delegate8_27(this, Delegate3.delegate3_26());
					Delegate8.delegate8_28(this, Delegate3.delegate3_27());
					num = ((int)num2 * -458577784) ^ -536018245;
					continue;
				case 34u:
					Delegate41.delegate41_0(Delegate7.delegate7_19(this), DataGridViewSelectionMode.FullRowSelect);
					num = (int)((num2 * 909081713) ^ 0x744CEC7F);
					continue;
				case 33u:
					Delegate46.delegate46_0(Delegate7.delegate7_33(this), ToolStripItemDisplayStyle.Image);
					Delegate8.delegate8_77(Delegate7.delegate7_33(this), Delegate3.delegate3_31());
					num = ((int)num2 * -1674023135) ^ -1013794756;
					continue;
				case 32u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_42(this), global::_003CModule_003E.smethod_20<string>(2925558695u, 3930410214u));
					Delegate29.delegate29_4(Delegate7.delegate7_43(this), Delegate28.delegate28_5());
					num = ((int)num2 * -413060297) ^ -476898624;
					continue;
				case 31u:
					Delegate30.delegate30_6(Delegate7.delegate7_26(this), global::_003CModule_003E.smethod_18<string>(544137798u, 2991899711u));
					num = ((int)num2 * -2023090684) ^ 0x50E81A50;
					continue;
				case 30u:
					Delegate30.delegate30_1(Delegate7.delegate7_42(this), global::_003CModule_003E.smethod_22<string>(2988707811u, 402712203u));
					num = (int)((num2 * 230082076) ^ 0x713C28C4);
					continue;
				case 29u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_53(this));
					num = (int)(num2 * 938076444) ^ -280807939;
					continue;
				case 28u:
					Delegate5.delegate5_16(Delegate7.delegate7_50(this), bool_0: true);
					num = (int)(num2 * 91203953) ^ -1888510861;
					continue;
				case 27u:
					Delegate5.delegate5_11(this, bool_0: false);
					num = ((int)num2 * -1226151687) ^ -789237446;
					continue;
				case 26u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_47(this));
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_48(this));
					num = (int)(num2 * 922145135) ^ -1686240443;
					continue;
				case 25u:
					Delegate5.delegate5_17(Delegate7.delegate7_70(this), bool_0: true);
					num = ((int)num2 * -1917064133) ^ 0x2F7A5147;
					continue;
				case 24u:
					Delegate42.delegate42_0(Delegate7.delegate7_27(this), 200f);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_27(this), global::_003CModule_003E.smethod_19<string>(2144194064u, 1265851818u));
					num = (int)(num2 * 2053146601) ^ -1537422899;
					continue;
				case 23u:
					Delegate30.delegate30_7(Delegate7.delegate7_20(this), global::_003CModule_003E.smethod_19<string>(3710228813u, 4041705069u));
					num = (int)((num2 * 1961736957) ^ 0x1867F12A);
					continue;
				case 22u:
					Delegate22.delegate22_5(Delegate7.delegate7_21(this));
					Delegate22.delegate22_7(this);
					num = ((int)num2 * -468363445) ^ -1031666205;
					continue;
				case 21u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_38(this), global::_003CModule_003E.smethod_18<string>(2096949936u, 3107283299u));
					num = ((int)num2 * -1361813400) ^ 0x335E08F3;
					continue;
				case 20u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_30(this), global::_003CModule_003E.smethod_21<string>(3641561507u, 4067924245u));
					num = (int)((num2 * 1485241268) ^ 0x3B870242);
					continue;
				case 19u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_60(this), global::_003CModule_003E.smethod_20<string>(1605317222u, 3711532609u));
					num = ((int)num2 * -2122573466) ^ 0x62A9BED0;
					continue;
				case 18u:
					Delegate8.delegate8_76(Delegate7.delegate7_20(this), Delegate7.delegate7_35(this));
					num = ((int)num2 * -1020651446) ^ 0x2DD1045;
					continue;
				case 17u:
					Delegate8.delegate8_71(Delegate7.delegate7_20(this), null);
					num = ((int)num2 * -1939117117) ^ 0x699D1BA6;
					continue;
				case 16u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_51(this));
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_52(this));
					num = (int)((num2 * 386184748) ^ 0x4D89BACE);
					continue;
				case 15u:
					Delegate27.delegate27_0(object_, this, global::_003CModule_003E.smethod_22<string>(1388348538u, 2105289578u));
					num = (int)((num2 * 1387287592) ^ 0x45AEBA6B);
					continue;
				case 14u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_50(this), global::_003CModule_003E.smethod_19<string>(2708266986u, 2158032564u));
					Delegate30.delegate30_0(Delegate7.delegate7_50(this), global::_003CModule_003E.smethod_20<string>(3793831456u, 2386400720u));
					num = (int)((num2 * 800313204) ^ 0x2D5D16ED);
					continue;
				case 13u:
					Delegate8.delegate8_49(this, Delegate3.delegate3_9());
					num = ((int)num2 * -1780801423) ^ -304583411;
					continue;
				case 12u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_65(this));
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_66(this));
					num = ((int)num2 * -1927199075) ^ 0x607C6A4D;
					continue;
				case 11u:
					Delegate8.delegate8_77(Delegate7.delegate7_32(this), Delegate3.delegate3_30());
					Delegate30.delegate30_1(Delegate7.delegate7_32(this), global::_003CModule_003E.smethod_18<string>(129637730u, 1606492657u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_32(this), global::_003CModule_003E.smethod_20<string>(1814571543u, 430164653u));
					num = ((int)num2 * -2128805999) ^ -286218872;
					continue;
				case 10u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_21(this)), Delegate7.delegate7_64(this));
					num = (int)(num2 * 2082013839) ^ -913880781;
					continue;
				case 9u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_55(this), global::_003CModule_003E.smethod_19<string>(152031511u, 448247414u));
					num = (int)((num2 * 1163889629) ^ 0xA1E5BA);
					continue;
				case 8u:
					Delegate30.delegate30_0(Delegate7.delegate7_46(this), global::_003CModule_003E.smethod_21<string>(1580227418u, 1200788991u));
					num = (int)((num2 * 1584651467) ^ 0x24178F8E);
					continue;
				case 7u:
					Delegate42.delegate42_0(Delegate7.delegate7_26(this), 150f);
					num = ((int)num2 * -1035648913) ^ 0x1474F1E8;
					continue;
				case 6u:
					Delegate30.delegate30_2(this, global::_003CModule_003E.smethod_20<string>(3213405063u, 1909764930u));
					Delegate22.delegate22_9(Delegate7.delegate7_19(this));
					Delegate22.delegate22_9(Delegate7.delegate7_20(this));
					num = ((int)num2 * -127268345) ^ -989972225;
					continue;
				case 5u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_26(this), global::_003CModule_003E.smethod_22<string>(3317291927u, 1328572535u));
					num = ((int)num2 * -1117310140) ^ 0x66E2D04B;
					continue;
				case 4u:
					Delegate8.delegate8_50(this, Delegate3.delegate3_28());
					num = ((int)num2 * -2095381773) ^ 0x310206CD;
					continue;
				case 3u:
					Delegate30.delegate30_0(Delegate7.delegate7_21(this), global::_003CModule_003E.smethod_21<string>(941991551u, 3092565471u));
					num = ((int)num2 * -1698271640) ^ 0x26A95F4C;
					continue;
				case 2u:
					Delegate22.delegate22_6(Delegate7.delegate7_20(this));
					Delegate22.delegate22_5(Delegate7.delegate7_20(this));
					num = ((int)num2 * -1972401173) ^ 0x70745261;
					continue;
				case 1u:
					Delegate8.delegate8_48(this, Delegate3.delegate3_28());
					num = (int)(num2 * 843648035) ^ -2082880417;
					continue;
				case 0u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_48(this), global::_003CModule_003E.smethod_19<string>(2325292u, 1658730507u));
					Delegate30.delegate30_0(Delegate7.delegate7_48(this), global::_003CModule_003E.smethod_19<string>(2325292u, 1850410256u));
					num = ((int)num2 * -1674846863) ^ 0x3AA2E597;
					continue;
				default:
					return;
				case 173u:
					break;
				case 143u:
					return;
				}
				break;
			}
		}
	}

	private void method_1(object sender, EventArgs e)
	{
		sqliteCommand_0 = new SQLiteCommand(global::_003CModule_003E.smethod_18<string>(881585838u, 3917930935u), sqliteConnection_0);
		sqliteCommand_1 = new SQLiteCommand(global::_003CModule_003E.smethod_20<string>(2602047664u, 750049756u), sqliteConnection_0);
		while (true)
		{
			int num = -203005254;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xB554D639u) % 16)
				{
				case 15u:
					Delegate8.delegate8_98(Delegate7.delegate7_20(this), Delegate7.delegate7_72(this));
					Delegate5.delegate5_19(Delegate7.delegate7_44(this), Delegate1.delegate1_1());
					num = ((int)num2 * -47229429) ^ 0x73209907;
					continue;
				case 14u:
					Delegate49.delegate49_0(Delegate7.delegate7_73(Delegate7.delegate7_66(this)), global::_003CModule_003E.smethod_21<string>(2893278843u, 3858366921u), Delegate7.delegate7_72(this), global::_003CModule_003E.smethod_22<string>(394788843u, 3175407758u));
					num = ((int)num2 * -1828130164) ^ 0x7F879B56;
					continue;
				case 13u:
					Delegate49.delegate49_0(Delegate7.delegate7_73(Delegate7.delegate7_68(this)), global::_003CModule_003E.smethod_21<string>(2893278843u, 2538793715u), Delegate7.delegate7_72(this), global::_003CModule_003E.smethod_21<string>(122561669u, 2842842712u));
					num = (int)((num2 * 1468943991) ^ 0x715DC80C);
					continue;
				case 12u:
					Delegate49.delegate49_0(Delegate7.delegate7_73(Delegate7.delegate7_56(this)), global::_003CModule_003E.smethod_20<string>(2360597805u, 939092603u), Delegate7.delegate7_72(this), global::_003CModule_003E.smethod_20<string>(3362061904u, 1707331667u));
					num = ((int)num2 * -2010920737) ^ -1081910468;
					continue;
				case 11u:
					Delegate5.delegate5_20(Delegate7.delegate7_71(this), Delegate1.delegate1_1());
					num = (int)(num2 * 1251974945) ^ -334483848;
					continue;
				case 9u:
					sqliteCommandBuilder_0 = new SQLiteCommandBuilder(sqliteDataAdapter_0);
					dataTable_0.Locale = (CultureInfo)Delegate3.delegate3_37();
					num = ((int)num2 * -530296051) ^ -112802504;
					continue;
				case 8u:
					sqliteDataAdapter_1.Fill(dataTable_1);
					Delegate5.delegate5_18(Delegate7.delegate7_19(this), bool_0: false);
					Delegate8.delegate8_97(Delegate7.delegate7_19(this), Delegate7.delegate7_72(this));
					num = (int)((num2 * 1006221310) ^ 0x1EC6EE84);
					continue;
				case 7u:
					Delegate49.delegate49_0(Delegate7.delegate7_73(Delegate7.delegate7_64(this)), global::_003CModule_003E.smethod_22<string>(2861834961u, 1136481051u), Delegate7.delegate7_72(this), global::_003CModule_003E.smethod_22<string>(2885305255u, 65222969u));
					Delegate49.delegate49_0(Delegate7.delegate7_73(Delegate7.delegate7_62(this)), global::_003CModule_003E.smethod_20<string>(2360597805u, 477302952u), Delegate7.delegate7_72(this), global::_003CModule_003E.smethod_21<string>(2066889297u, 3863958063u));
					num = ((int)num2 * -1715718583) ^ -2141904189;
					continue;
				case 6u:
					Delegate49.delegate49_0(Delegate7.delegate7_73(Delegate7.delegate7_45(this)), global::_003CModule_003E.smethod_20<string>(2360597805u, 3540969647u), Delegate7.delegate7_72(this), global::_003CModule_003E.smethod_21<string>(2966669018u, 628006405u));
					num = (int)((num2 * 210887336) ^ 0x3D690CA6);
					continue;
				case 5u:
					Delegate49.delegate49_0(Delegate7.delegate7_73(Delegate7.delegate7_60(this)), global::_003CModule_003E.smethod_18<string>(1088835872u, 3783298489u), Delegate7.delegate7_72(this), global::_003CModule_003E.smethod_22<string>(3571370783u, 2250010816u));
					Delegate49.delegate49_0(Delegate7.delegate7_73(Delegate7.delegate7_58(this)), global::_003CModule_003E.smethod_18<string>(1088835872u, 1362684783u), Delegate7.delegate7_72(this), global::_003CModule_003E.smethod_19<string>(3468027833u, 2142466343u));
					num = ((int)num2 * -229396924) ^ 0x3C12EFD1;
					continue;
				case 4u:
					sqliteDataAdapter_0.Fill(dataTable_0);
					Delegate8.delegate8_96(Delegate7.delegate7_72(this), dataTable_0);
					num = (int)(num2 * 1132216470) ^ -1779891879;
					continue;
				case 3u:
					sqliteDataAdapter_0 = new SQLiteDataAdapter(sqliteCommand_0);
					sqliteDataAdapter_1 = new SQLiteDataAdapter(sqliteCommand_1);
					num = (int)((num2 * 1078323349) ^ 0x1665DC8F);
					continue;
				case 2u:
					Delegate49.delegate49_0(Delegate7.delegate7_73(Delegate7.delegate7_50(this)), global::_003CModule_003E.smethod_19<string>(578159315u, 2818059565u), Delegate7.delegate7_72(this), global::_003CModule_003E.smethod_19<string>(2178414669u, 1247845843u));
					Delegate49.delegate49_0(Delegate7.delegate7_73(Delegate7.delegate7_47(this)), global::_003CModule_003E.smethod_21<string>(2893278843u, 1938540451u), Delegate7.delegate7_72(this), global::_003CModule_003E.smethod_21<string>(2016313347u, 1396694515u));
					num = ((int)num2 * -1254687156) ^ 0x13A55BC7;
					continue;
				case 1u:
					Delegate49.delegate49_0(Delegate7.delegate7_73(Delegate7.delegate7_54(this)), global::_003CModule_003E.smethod_18<string>(1088835872u, 2960493961u), Delegate7.delegate7_72(this), global::_003CModule_003E.smethod_20<string>(2509254646u, 4207711864u));
					Delegate49.delegate49_0(Delegate7.delegate7_73(Delegate7.delegate7_52(this)), global::_003CModule_003E.smethod_22<string>(2861834961u, 3489960372u), Delegate7.delegate7_72(this), global::_003CModule_003E.smethod_21<string>(1254265217u, 1996392346u));
					num = (int)(num2 * 1307147612) ^ -682506025;
					continue;
				default:
					return;
				case 0u:
					break;
				case 10u:
					return;
				}
				break;
			}
		}
	}

	private void method_2(object sender, EventArgs e)
	{
		Delegate30.delegate30_8(Delegate7.delegate7_72(this), Delegate50.delegate50_0(global::_003CModule_003E.smethod_21<string>(3510789580u, 2772824677u), Delegate15.delegate15_4(Delegate7.delegate7_43(this))));
	}

	private void method_3(object sender, DataGridViewCellEventArgs e)
	{
		try
		{
			sqliteDataAdapter_0.Update(dataTable_0);
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			Delegate51.delegate51_0();
		}
	}

	private void method_4(object sender, EventArgs e)
	{
		if (Delegate52.delegate52_0(global::_003CModule_003E.smethod_19<string>(3917146490u, 1001133779u), global::_003CModule_003E.smethod_19<string>(4066852709u, 2223466633u), MessageBoxButtons.YesNo) != DialogResult.Yes)
		{
			return;
		}
		IEnumerator enumerator = default(IEnumerator);
		try
		{
			enumerator = (IEnumerator)Delegate7.delegate7_75(Delegate7.delegate7_74(Delegate7.delegate7_19(this)));
			DataGridViewRow object_ = default(DataGridViewRow);
			while (true)
			{
				int num;
				int num2;
				if (!Delegate21.delegate21_3(enumerator))
				{
					num = -1395409406;
					num2 = -1395409406;
				}
				else
				{
					num = -1021622118;
					num2 = -1021622118;
				}
				while (true)
				{
					uint num3;
					switch ((num3 = (uint)num ^ 0x8B8DF908u) % 6)
					{
					case 5u:
					{
						int num4;
						int num5;
						if (!Delegate21.delegate21_2(object_))
						{
							num4 = -741837443;
							num5 = -741837443;
						}
						else
						{
							num4 = -2076781801;
							num5 = -2076781801;
						}
						num = num4 ^ (int)(num3 * 938365514);
						continue;
					}
					case 3u:
						Delegate32.delegate32_2(Delegate7.delegate7_72(this), Delegate17.delegate17_2(object_));
						num = (int)((num3 * 304291170) ^ 0x485F79EF);
						continue;
					case 2u:
						object_ = (DataGridViewRow)Delegate7.delegate7_76(enumerator);
						num = -1395567357;
						continue;
					case 0u:
						num = -1021622118;
						continue;
					default:
						return;
					case 1u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
		finally
		{
			if (enumerator is IDisposable)
			{
				while (true)
				{
					IL_016b:
					int num6 = -1376450918;
					while (true)
					{
						uint num3;
						switch ((num3 = (uint)num6 ^ 0x8B8DF908u) % 3)
						{
						case 1u:
							goto IL_0131;
						default:
							goto end_IL_014e;
						case 0u:
							break;
						case 2u:
							goto end_IL_014e;
						}
						goto IL_016b;
						IL_0131:
						Delegate22.delegate22_4(enumerator as IDisposable);
						num6 = (int)(num3 * 915930547) ^ -1239624951;
						continue;
						end_IL_014e:
						break;
					}
					break;
				}
			}
		}
	}

	private void method_5(object sender, KeyEventArgs e)
	{
		if (((uint)(0 - ((Delegate53.delegate53_0(e) == Keys.Delete) ? 1 : 0)) & (uint)(~Delegate54.delegate54_0(Delegate7.delegate7_19(this)))) == 0)
		{
			return;
		}
		while (true)
		{
			int num = 1038383078;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x4D657EFu) % 4)
				{
				case 2u:
					Delegate22.delegate22_13(Delegate7.delegate7_40(this));
					num = (int)((num2 * 447351270) ^ 0x53FAC008);
					continue;
				case 1u:
				{
					int num3;
					int num4;
					if (Delegate17.delegate17_3(Delegate7.delegate7_74(Delegate7.delegate7_19(this))) <= 0)
					{
						num3 = 1387137356;
						num4 = 1387137356;
					}
					else
					{
						num3 = 273655681;
						num4 = 273655681;
					}
					num = num3 ^ (int)(num2 * 25920432);
					continue;
				}
				default:
					return;
				case 0u:
					break;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	private void method_6(object sender, DataGridViewRowsRemovedEventArgs e)
	{
		try
		{
			sqliteDataAdapter_0.Update(dataTable_0);
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			while (true)
			{
				int num = -766873548;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xEBF2FFE4u) % 3)
					{
					default:
						return;
					case 1u:
						goto IL_003a;
					case 2u:
						break;
					case 0u:
						return;
					}
					break;
					IL_003a:
					Delegate51.delegate51_0();
					num = (int)((num2 * 1467783051) ^ 0x5440E702);
				}
			}
		}
	}

	private void method_7(object sender, DataGridViewDataErrorEventArgs e)
	{
		Delegate52.delegate52_0(Delegate15.delegate15_0(Delegate7.delegate7_77(e)), global::_003CModule_003E.smethod_22<string>(2657410194u, 2997307574u), MessageBoxButtons.OK);
		Delegate5.delegate5_21(e, bool_0: true);
	}

	private void method_8(object sender, DataGridViewCellFormattingEventArgs e)
	{
		string string_ = Delegate15.delegate15_5(Delegate55.delegate55_0(Delegate7.delegate7_22((DataGridView)sender), Delegate17.delegate17_4(e)));
		while (true)
		{
			int num = -1741459821;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x9D50D0C7u) % 19)
				{
				case 18u:
				{
					int num8;
					int num9;
					if (Delegate56.delegate56_0(string_, global::_003CModule_003E.smethod_21<string>(2705048233u, 3318756095u), bool_0: false) == 0)
					{
						num8 = 1756198177;
						num9 = 1756198177;
					}
					else
					{
						num8 = 937308875;
						num9 = 937308875;
					}
					num = num8 ^ ((int)num2 * -624822323);
					continue;
				}
				case 17u:
					Delegate30.delegate30_9(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_19(this)), Delegate17.delegate17_5(e))), Delegate17.delegate17_4(e)), Delegate36.delegate36_3());
					num = (int)(num2 * 425804898) ^ -68649362;
					continue;
				case 16u:
				{
					int num10;
					int num11;
					if (Delegate56.delegate56_0(string_, global::_003CModule_003E.smethod_20<string>(4131543458u, 1362014509u), bool_0: false) == 0)
					{
						num10 = 1282516002;
						num11 = 1282516002;
					}
					else
					{
						num10 = 316170318;
						num11 = 316170318;
					}
					num = num10 ^ (int)(num2 * 545272150);
					continue;
				}
				case 15u:
				{
					int num5;
					if (!Class13.bool_1)
					{
						num = -1176510497;
						num5 = -1176510497;
					}
					else
					{
						num = -1334863493;
						num5 = -1334863493;
					}
					continue;
				}
				case 14u:
					Delegate8.delegate8_99(e, Delegate3.delegate3_40());
					num = -996171082;
					continue;
				case 13u:
				{
					int num6;
					int num7;
					if (Delegate56.delegate56_0(string_, global::_003CModule_003E.smethod_22<string>(3876484605u, 3464408049u), bool_0: false) != 0)
					{
						num6 = 18499136;
						num7 = 18499136;
					}
					else
					{
						num6 = 1188758323;
						num7 = 1188758323;
					}
					num = num6 ^ (int)(num2 * 994380521);
					continue;
				}
				case 12u:
					Delegate8.delegate8_99(e, Delegate57.delegate57_0(Delegate15.delegate15_2(Delegate7.delegate7_78(e)), global::_003CModule_003E.smethod_21<string>(4243063821u, 1707896578u)));
					num = ((int)num2 * -1950843384) ^ 0x2C490326;
					continue;
				case 11u:
					Delegate8.smethod_0((object)e, Delegate59.smethod_0(Delegate58.smethod_0(Delegate7.delegate7_78(e), (Type)null, global::_003CModule_003E.smethod_18<string>(1449178756u, 2045325695u), new object[2] { 0, 9 }, (string[])null, (Type[])null, (bool[])null), (object)global::_003CModule_003E.smethod_18<string>(2121959808u, 1291287320u)));
					num = -1176510497;
					continue;
				case 9u:
					num = (int)((num2 * 909431468) ^ 0x4F178DA);
					continue;
				case 7u:
					goto IL_0266;
				case 6u:
				{
					int num3;
					int num4;
					if (Delegate56.delegate56_0(string_, global::_003CModule_003E.smethod_19<string>(4055622957u, 1781087529u), bool_0: false) == 0)
					{
						num3 = -1308874563;
						num4 = -1308874563;
					}
					else
					{
						num3 = -256941382;
						num4 = -256941382;
					}
					num = num3 ^ (int)(num2 * 1305889942);
					continue;
				}
				case 4u:
					Delegate5.delegate5_22(e, bool_0: true);
					num = -1780341236;
					continue;
				case 3u:
					goto IL_02dc;
				case 1u:
					switch ((GClass9.GEnum3)Delegate17.delegate17_1(Delegate7.delegate7_78(e)))
					{
					case GClass9.GEnum3.Unknow:
						break;
					case GClass9.GEnum3.Ok:
						goto IL_0266;
					case GClass9.GEnum3.Nok:
						goto IL_02dc;
					default:
						goto IL_037d;
					}
					goto case 14u;
				default:
					return;
				case 10u:
					break;
				case 0u:
					return;
				case 2u:
					return;
				case 5u:
					return;
				case 8u:
					return;
					IL_037d:
					num = -1829374698;
					continue;
					IL_02dc:
					Delegate8.delegate8_99(e, Delegate3.delegate3_39());
					Delegate30.delegate30_9(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_19(this)), Delegate17.delegate17_5(e))), Delegate17.delegate17_4(e)), Delegate36.delegate36_4());
					num = -996171082;
					continue;
					IL_0266:
					Delegate8.delegate8_99(e, Delegate3.delegate3_38());
					num = -1366311189;
					continue;
				}
				break;
			}
		}
	}

	private void method_9(object sender, EventArgs e)
	{
		if (!Class13.bool_1)
		{
			return;
		}
		while (true)
		{
			int num = -714343198;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x986A15A8u) % 3)
				{
				case 1u:
					goto IL_0009;
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
				IL_0009:
				Delegate30.delegate30_10(Delegate7.delegate7_56(this), Delegate57.delegate57_0(Delegate15.delegate15_6(Delegate7.delegate7_56(this)), global::_003CModule_003E.smethod_21<string>(4243063821u, 892507630u)));
				num = (int)((num2 * 987074316) ^ 0x58EBE899);
			}
		}
	}

	private void method_10(object sender, EventArgs e)
	{
		if (!Class13.bool_1)
		{
			return;
		}
		while (true)
		{
			int num = -677547798;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x9B76924Cu) % 3)
				{
				case 1u:
					goto IL_0009;
				default:
					return;
				case 2u:
					break;
				case 0u:
					return;
				}
				break;
				IL_0009:
				Delegate30.delegate30_10(Delegate7.delegate7_60(this), Delegate57.delegate57_0(Delegate15.delegate15_6(Delegate7.delegate7_60(this)), global::_003CModule_003E.smethod_21<string>(4243063821u, 3093268270u)));
				num = ((int)num2 * -23126822) ^ 0x827AE65;
			}
		}
	}

	private void method_11(object sender, EventArgs e)
	{
		if (!Class13.bool_1)
		{
			return;
		}
		while (true)
		{
			int num = 409451974;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x4294D4F3u) % 3)
				{
				case 2u:
					goto IL_0009;
				default:
					return;
				case 0u:
					break;
				case 1u:
					return;
				}
				break;
				IL_0009:
				Delegate30.delegate30_10(Delegate7.delegate7_47(this), Delegate57.delegate57_0(Delegate15.delegate15_6(Delegate7.delegate7_47(this)), global::_003CModule_003E.smethod_20<string>(3151543051u, 291036310u)));
				num = (int)((num2 * 1619094381) ^ 0x74C62ABB);
			}
		}
	}

	private void method_12(object sender, EventArgs e)
	{
		if (!Class13.bool_1)
		{
			return;
		}
		while (true)
		{
			int num = -1813685652;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x81A81625u) % 3)
				{
				case 1u:
					goto IL_0009;
				default:
					return;
				case 2u:
					break;
				case 0u:
					return;
				}
				break;
				IL_0009:
				Delegate30.delegate30_10(Delegate7.delegate7_45(this), Delegate57.delegate57_0(Delegate15.delegate15_6(Delegate7.delegate7_45(this)), global::_003CModule_003E.smethod_18<string>(3260271878u, 1183781110u)));
				num = (int)((num2 * 575189319) ^ 0x4805AA6E);
			}
		}
	}

	private void method_13(object sender, EventArgs e)
	{
		if (!Delegate1.delegate1_1())
		{
			return;
		}
		while (true)
		{
			int num = 1927861034;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x672C9B4Cu) % 4)
				{
				case 2u:
					Delegate7.delegate7_81(Delegate3.delegate3_41());
					num = ((int)num2 * -581557988) ^ 0x6C6EAED1;
					continue;
				case 1u:
					Delegate60.delegate60_0(global::_003CModule_003E.smethod_21<string>(2204620888u, 2062349091u), global::_003CModule_003E.smethod_18<string>(154647602u, 1667929263u), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					num = (int)((num2 * 1453771261) ^ 0x630ACB4E);
					continue;
				default:
					return;
				case 0u:
					break;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	private void method_14(object sender, EventArgs e)
	{
		if (Delegate17.delegate17_6(Delegate7.delegate7_71(this)) < 4000)
		{
			while (true)
			{
				int num = 1542074445;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x1F331212u) % 7)
					{
					case 6u:
						Delegate5.delegate5_23(toolTip_1, bool_0: true);
						num = ((int)num2 * -1495376428) ^ -1966166922;
						continue;
					case 5u:
						Delegate48.delegate48_0(toolTip_1, ToolTipIcon.None);
						Delegate5.delegate5_17(toolTip_1, bool_0: true);
						num = (int)((num2 * 998713383) ^ 0x6758ECE0);
						continue;
					case 3u:
						Delegate5.delegate5_24(toolTip_1, bool_0: true);
						num = ((int)num2 * -274692959) ^ -976526248;
						continue;
					case 0u:
						Delegate32.delegate32_3(toolTip_1, 500);
						toolTip_1.Show(Delegate15.delegate15_7(Delegate7.delegate7_44(this)), this, new Point(Delegate61.delegate61_0(Delegate7.delegate7_44(this)).Location.X, checked(ToolStripButton_8.Bounds.Location.Y - 7)));
						Timer_0.Interval = 4000;
						num = ((int)num2 * -654342473) ^ 0x7597141B;
						continue;
					case 4u:
						break;
					case 1u:
						return;
					default:
						goto end_IL_0165;
					}
					break;
				}
				continue;
				end_IL_0165:
				break;
			}
		}
		toolTip_1.Dispose();
		Timer_0.Enabled = false;
	}
}
