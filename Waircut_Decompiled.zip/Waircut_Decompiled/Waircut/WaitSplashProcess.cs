using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using ns1;

namespace Waircut;

[DesignerGenerated]
public class WaitSplashProcess : Form
{
	private IContainer icontainer_0;

	[CompilerGenerated]
	[AccessedThroughProperty("btStop")]
	private Button button_0;

	[CompilerGenerated]
	[AccessedThroughProperty("PictureBox1")]
	private PictureBox pictureBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("ScrollLabel1")]
	private GClass14 gclass14_0;

	[CompilerGenerated]
	[AccessedThroughProperty("parentFrm")]
	private Control control_0;

	internal virtual Button Button_0
	{
		[CompilerGenerated]
		get
		{
			return button_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_1;
			Button button = default(Button);
			while (true)
			{
				int num = -503318131;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x94729196u) % 7)
					{
					case 5u:
					{
						int num4;
						int num5;
						if (button != null)
						{
							num4 = 1967555444;
							num5 = 1967555444;
						}
						else
						{
							num4 = 364000068;
							num5 = 364000068;
						}
						num = num4 ^ ((int)num2 * -904246911);
						continue;
					}
					case 3u:
						Delegate8.delegate8_200(button, object_);
						num = (int)(num2 * 622462592) ^ -326596039;
						continue;
					case 2u:
						button = button_0;
						num = (int)(num2 * 1658061585) ^ -1458359693;
						continue;
					case 1u:
						Delegate8.delegate8_199(button, object_);
						num = (int)((num2 * 1010450910) ^ 0x77C23982);
						continue;
					case 0u:
					{
						button_0 = value;
						button = button_0;
						int num3;
						if (button != null)
						{
							num = -1955661805;
							num3 = -1955661805;
						}
						else
						{
							num = -978883911;
							num3 = -978883911;
						}
						continue;
					}
					default:
						return;
					case 6u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual PictureBox PictureBox_0
	{
		[CompilerGenerated]
		get
		{
			return pictureBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			pictureBox_0 = value;
		}
	}

	internal virtual GClass14 GClass14_0
	{
		[CompilerGenerated]
		get
		{
			return gclass14_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			gclass14_0 = value;
		}
	}

	private virtual Control Control_0
	{
		[CompilerGenerated]
		get
		{
			return control_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			control_0 = value;
		}
	}

	[DebuggerNonUserCode]
	void Form.Dispose(bool disposing)
	{
		try
		{
			if (!disposing)
			{
				return;
			}
			while (true)
			{
				int num = -1862146272;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x883553B6u) % 4)
					{
					case 3u:
						Delegate22.delegate22_4(icontainer_0);
						num = (int)((num2 * 290305375) ^ 0x68B9234E);
						continue;
					case 2u:
					{
						int num3;
						int num4;
						if (icontainer_0 != null)
						{
							num3 = -1823679445;
							num4 = -1823679445;
						}
						else
						{
							num3 = -1588769075;
							num4 = -1588769075;
						}
						num = num3 ^ ((int)num2 * -498688575);
						continue;
					}
					default:
						return;
					case 0u:
						break;
					case 1u:
						return;
					}
					break;
				}
			}
		}
		finally
		{
			Delegate5.delegate5_3(this, disposing);
		}
	}

	[DebuggerStepThrough]
	private void method_0()
	{
		Delegate8.delegate8_300(this, Delegate3.delegate3_69());
		while (true)
		{
			int num = 2133186650;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xC911D4Bu) % 35)
				{
				case 34u:
					Delegate8.delegate8_301(this, Delegate3.delegate3_12());
					num = ((int)num2 * -2139059110) ^ -1372514535;
					continue;
				case 33u:
					GClass14_0.Location = new Point(0, 50);
					num = ((int)num2 * -413156761) ^ 0x3037185;
					continue;
				case 32u:
					GClass14_0.TabIndex = 2;
					num = (int)((num2 * 1343991316) ^ 0x74B0EE91);
					continue;
				case 31u:
					base.Controls.Add(Button_0);
					DoubleBuffered = true;
					num = ((int)num2 * -654951647) ^ 0xFD2B6D1;
					continue;
				case 30u:
					base.Name = global::_003CModule_003E.smethod_18<string>(4278316555u, 2644501251u);
					num = (int)(num2 * 1193970827) ^ -1690072295;
					continue;
				case 29u:
					base.Opacity = 0.9;
					num = (int)(num2 * 738852391) ^ -707070396;
					continue;
				case 28u:
					PictureBox_0.BackgroundImageLayout = ImageLayout.Stretch;
					num = (int)((num2 * 602562914) ^ 0x4C0FC43F);
					continue;
				case 27u:
					base.AutoScaleDimensions = new SizeF(6f, 13f);
					num = ((int)num2 * -1311826616) ^ 0x2542008E;
					continue;
				case 26u:
					GClass14_0.Name = global::_003CModule_003E.smethod_18<string>(1634545152u, 1446142953u);
					num = (int)((num2 * 803243123) ^ 0x57DE0E2E);
					continue;
				case 25u:
					Button_0.TabIndex = 0;
					num = ((int)num2 * -688640286) ^ -2145901689;
					continue;
				case 24u:
					Delegate8.delegate8_115(Delegate7.delegate7_258(this), Delegate3.delegate3_114());
					Delegate216.delegate216_0(Delegate7.delegate7_258(this), ImageLayout.Stretch);
					num = (int)((num2 * 1059144206) ^ 0x4879C8A9);
					continue;
				case 23u:
					base.Controls.Add(PictureBox_0);
					num = ((int)num2 * -255175724) ^ -2006902415;
					continue;
				case 22u:
					GClass14_0.Text = global::_003CModule_003E.smethod_20<string>(1397002962u, 1459833915u);
					num = (int)(num2 * 751044744) ^ -1617715651;
					continue;
				case 21u:
					GClass14_0.Size = new Size(163, 13);
					num = (int)((num2 * 1813607516) ^ 0x57E19826);
					continue;
				case 20u:
					Delegate22.delegate22_6(Delegate7.delegate7_257(this));
					Delegate22.delegate22_7(this);
					num = (int)((num2 * 233034171) ^ 0x2A160177);
					continue;
				case 19u:
					Text = global::_003CModule_003E.smethod_20<string>(2136818042u, 512477737u);
					num = ((int)num2 * -50649094) ^ -1668297962;
					continue;
				case 18u:
					GClass14_0.Int32_0 = 20;
					num = (int)((num2 * 1369147013) ^ 0x1C0EB1D4);
					continue;
				case 17u:
					Button_0.Size = new Size(40, 40);
					num = ((int)num2 * -73982178) ^ -674649995;
					continue;
				case 16u:
					Delegate8.delegate8_302(this, Delegate3.delegate3_13());
					num = ((int)num2 * -859608473) ^ 0x71BDC6C4;
					continue;
				case 15u:
					base.Controls.Add(GClass14_0);
					num = (int)((num2 * 653851181) ^ 0x12FFB7C1);
					continue;
				case 14u:
					base.FormBorderStyle = FormBorderStyle.None;
					num = ((int)num2 * -1618762193) ^ 0x4384E0F4;
					continue;
				case 13u:
					PictureBox_0.Name = global::_003CModule_003E.smethod_18<string>(961764100u, 3884960026u);
					num = (int)((num2 * 1569018834) ^ 0x19D0A35A);
					continue;
				case 12u:
					PictureBox_0.Location = new Point(12, 6);
					num = (int)(num2 * 102055162) ^ -1561239879;
					continue;
				case 11u:
					GClass14_0.GEnum7_0 = GClass14.GEnum7.horizontal;
					num = (int)(num2 * 1730542652) ^ -256533957;
					continue;
				case 10u:
					base.AutoScaleMode = AutoScaleMode.Font;
					num = ((int)num2 * -1560914798) ^ -1920781660;
					continue;
				case 9u:
					((ISupportInitialize)PictureBox_0).EndInit();
					ResumeLayout(performLayout: false);
					num = (int)((num2 * 770587747) ^ 0x31DB1497);
					continue;
				case 8u:
					((Control)Delegate7.delegate7_258(this)).Location = new Point(111, 12);
					Button_0.Name = global::_003CModule_003E.smethod_18<string>(2420881834u, 2680080470u);
					num = (int)(num2 * 1019470005) ^ -670360278;
					continue;
				case 7u:
					Button_0.UseVisualStyleBackColor = true;
					num = ((int)num2 * -764590165) ^ -1039834464;
					continue;
				case 5u:
					PictureBox_0.Image = GClass0.Bitmap_36;
					num = (int)((num2 * 2070577284) ^ 0x478A2F32);
					continue;
				case 4u:
					PictureBox_0.InitialImage = null;
					num = ((int)num2 * -1170058168) ^ -406443583;
					continue;
				case 3u:
					BackColor = Color.Black;
					base.ClientSize = new Size(163, 63);
					num = (int)(num2 * 750877682) ^ -504760522;
					continue;
				case 1u:
					GClass14_0.ForeColor = Color.Silver;
					num = (int)((num2 * 1924854827) ^ 0x36A7195);
					continue;
				case 0u:
					PictureBox_0.Size = new Size(69, 50);
					PictureBox_0.SizeMode = PictureBoxSizeMode.StretchImage;
					PictureBox_0.TabIndex = 1;
					PictureBox_0.TabStop = false;
					GClass14_0.Dock = DockStyle.Bottom;
					num = (int)(num2 * 585654164) ^ -1308113519;
					continue;
				default:
					return;
				case 6u:
					break;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	public WaitSplashProcess(Control control_1 = null, string string_0 = "Waiting for completion...")
	{
		Delegate8.delegate8_3(this, new EventHandler(method_3));
		Delegate8.delegate8_303(this, new EventHandler(method_5));
		Delegate8.delegate8_304(this, null);
		Delegate22.delegate22_68(this);
		Delegate8.delegate8_304(this, control_1);
		Delegate8.delegate8_305(this, Delegate7.delegate7_259(control_1));
		Delegate30.delegate30_4(Delegate7.delegate7_260(this), string_0);
		Delegate8.delegate8_306(Delegate7.delegate7_261(this), (EventHandler)([SpecialName] (object sender, EventArgs e) =>
		{
			Delegate22.delegate22_69(this);
		}));
		Delegate8.delegate8_307(Delegate7.delegate7_261(this), (EventHandler)([SpecialName] (object sender, EventArgs e) =>
		{
			Delegate22.delegate22_69(this);
		}));
	}

	private void method_1(object sender, EventArgs e)
	{
		Delegate22.delegate22_11(this);
	}

	private void method_2()
	{
		if (Delegate7.delegate7_262(this) != null)
		{
			goto IL_006c;
		}
		goto IL_00a9;
		IL_006c:
		int num = 672283448;
		goto IL_0080;
		IL_0080:
		Rectangle rectangle = default(Rectangle);
		int num4 = default(int);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0x60558D1Du) % 6)
			{
			case 5u:
				rectangle = Delegate213.delegate213_0(Delegate7.delegate7_262(this), Delegate61.delegate61_1(Delegate7.delegate7_262(this)));
				num = ((int)num2 * -442180130) ^ 0x4F97295;
				continue;
			case 4u:
				checked
				{
					num4 = rectangle.Left + unchecked(checked(rectangle.Width - base.Width) / 2);
					num = 229233678;
					continue;
				}
			case 2u:
				break;
			case 0u:
				num = (int)(num2 * 1161735185) ^ -1244214427;
				continue;
			case 3u:
				goto IL_00a9;
			default:
				checked
				{
					int num3 = rectangle.Top + unchecked(checked(rectangle.Height - base.Height) / 3);
					base.Location = new Point(num4, num3);
					return;
				}
			}
			break;
		}
		goto IL_006c;
		IL_00a9:
		rectangle = Delegate61.delegate61_2(Delegate215.delegate215_0(Delegate214.delegate214_0(this)));
		num = 2136090395;
		goto IL_0080;
	}

	private void method_3(object sender, EventArgs e)
	{
		Delegate22.delegate22_69(this);
	}

	private void method_4(object sender, EventArgs e)
	{
		Delegate22.delegate22_69(this);
	}

	private void method_5(object sender, EventArgs e)
	{
		Delegate22.delegate22_70(this);
	}

	[SpecialName]
	[CompilerGenerated]
	private void method_6(object sender, EventArgs e)
	{
		Delegate22.delegate22_69(this);
	}

	[SpecialName]
	[CompilerGenerated]
	private void method_7(object sender, EventArgs e)
	{
		Delegate22.delegate22_69(this);
	}
}
