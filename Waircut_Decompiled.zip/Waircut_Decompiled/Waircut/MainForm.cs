using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using ns1;

namespace Waircut;

[DesignerGenerated]
public class MainForm : Form
{
	public delegate void GDelegate4(string message, Color color, bool autoCrLf);

	public delegate void GDelegate5(GClass8.GEnum1 status);

	[CompilerGenerated]
	[AccessedThroughProperty("jsApi")]
	private GClass8 gclass8_0;

	private GClass15<GClass9> gclass15_0;

	private GClass9 gclass9_0;

	private GClass12 gclass12_0;

	private int int_0;

	private bool bool_0;

	private bool bool_1;

	private bool bool_2;

	private bool bool_3;

	private BindingSource bindingSource_0;

	private BindingSource bindingSource_1;

	[CompilerGenerated]
	[AccessedThroughProperty("NewsMangr")]
	private GClass10 gclass10_0;

	private IContainer icontainer_0;

	[CompilerGenerated]
	[AccessedThroughProperty("SplitContainer1")]
	private SplitContainer splitContainer_0;

	[CompilerGenerated]
	[AccessedThroughProperty("RtbMessage")]
	private RichTextBox richTextBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("BtExpandMessage")]
	private Button button_0;

	[CompilerGenerated]
	[AccessedThroughProperty("ImageList1")]
	private ImageList imageList_0;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolTip1")]
	private ToolTip toolTip_0;

	[CompilerGenerated]
	[AccessedThroughProperty("StatusStrip1")]
	private StatusStrip statusStrip_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tsInterfaces")]
	private ToolStrip toolStrip_0;

	[CompilerGenerated]
	[AccessedThroughProperty("btRefresh")]
	private ToolStripButton toolStripButton_0;

	[CompilerGenerated]
	[AccessedThroughProperty("cbAdapters")]
	private ToolStripComboBox toolStripComboBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolStripSeparator2")]
	private ToolStripSeparator toolStripSeparator_0;

	[CompilerGenerated]
	[AccessedThroughProperty("SplitContainer3")]
	private SplitContainer splitContainer_1;

	[CompilerGenerated]
	[AccessedThroughProperty("SplitContainer2")]
	private SplitContainer splitContainer_2;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvAps")]
	private DataGridView dataGridView_0;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvAttributes")]
	private DataGridView dataGridView_1;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvPins")]
	private DataGridView dataGridView_2;

	[CompilerGenerated]
	[AccessedThroughProperty("tsApToolMenu")]
	private ToolStrip toolStrip_1;

	[CompilerGenerated]
	[AccessedThroughProperty("TsbPin")]
	private ToolStripButton toolStripButton_1;

	[CompilerGenerated]
	[AccessedThroughProperty("TsbAllPin")]
	private ToolStripButton toolStripButton_2;

	[CompilerGenerated]
	[AccessedThroughProperty("TsbRandomPin")]
	private ToolStripButton toolStripButton_3;

	[CompilerGenerated]
	[AccessedThroughProperty("TsbStop")]
	private ToolStripButton toolStripButton_4;

	[CompilerGenerated]
	[AccessedThroughProperty("TsCpyRigth")]
	private ToolStripStatusLabel toolStripStatusLabel_0;

	[CompilerGenerated]
	[AccessedThroughProperty("PbLicense")]
	private PictureBox pictureBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("btAbout")]
	private ToolStripButton toolStripButton_5;

	[CompilerGenerated]
	[AccessedThroughProperty("btPrivateMode")]
	private ToolStripButton toolStripButton_6;

	[CompilerGenerated]
	[AccessedThroughProperty("btDataBase")]
	private ToolStripDropDownButton toolStripDropDownButton_0;

	[CompilerGenerated]
	[AccessedThroughProperty("btPinDb")]
	private ToolStripMenuItem toolStripMenuItem_0;

	[CompilerGenerated]
	[AccessedThroughProperty("btNetsBD")]
	private ToolStripMenuItem toolStripMenuItem_1;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolStripSeparator4")]
	private ToolStripSeparator toolStripSeparator_1;

	[CompilerGenerated]
	[AccessedThroughProperty("ContextMenuPin")]
	private ContextMenuStrip contextMenuStrip_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tbMenuPin_Checksum")]
	private ToolStripMenuItem toolStripMenuItem_2;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolStripMenuItem1")]
	private ToolStripSeparator toolStripSeparator_2;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuAlgorithms")]
	private ToolStripMenuItem toolStripMenuItem_3;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_ZAO")]
	private ToolStripMenuItem toolStripMenuItem_4;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_EasyBox")]
	private ToolStripMenuItem toolStripMenuItem_5;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_Trend")]
	private ToolStripMenuItem toolStripMenuItem_6;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_Dlink")]
	private ToolStripMenuItem toolStripMenuItem_7;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_FTE")]
	private ToolStripMenuItem toolStripMenuItem_8;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_AiroCon")]
	private ToolStripMenuItem toolStripMenuItem_9;

	[CompilerGenerated]
	[AccessedThroughProperty("cbLanguage")]
	private ToolStripComboBox toolStripComboBox_1;

	[CompilerGenerated]
	[AccessedThroughProperty("btClearConsole")]
	private Button button_1;

	[CompilerGenerated]
	[AccessedThroughProperty("TsbPixie")]
	private ToolStripSplitButton toolStripSplitButton_0;

	[CompilerGenerated]
	[AccessedThroughProperty("TsbPixieAdvance")]
	private ToolStripMenuItem toolStripMenuItem_10;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_Asus")]
	private ToolStripMenuItem toolStripMenuItem_11;

	[CompilerGenerated]
	[AccessedThroughProperty("XBitToolStripMenuItem")]
	private ToolStripMenuItem toolStripMenuItem_12;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_28bit")]
	private ToolStripMenuItem toolStripMenuItem_13;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_32bit")]
	private ToolStripMenuItem toolStripMenuItem_14;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_36bit")]
	private ToolStripMenuItem toolStripMenuItem_15;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_40bit")]
	private ToolStripMenuItem toolStripMenuItem_16;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_44bit")]
	private ToolStripMenuItem toolStripMenuItem_17;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_48bit")]
	private ToolStripMenuItem toolStripMenuItem_18;

	[CompilerGenerated]
	[AccessedThroughProperty("AllToolStripMenuItem")]
	private ToolStripSeparator toolStripSeparator_3;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_Allxbit")]
	private ToolStripMenuItem toolStripMenuItem_19;

	[CompilerGenerated]
	[AccessedThroughProperty("AllToolStripMenuItem1")]
	private ToolStripSeparator toolStripSeparator_4;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_All")]
	private ToolStripMenuItem toolStripMenuItem_20;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_24RHbit")]
	private ToolStripMenuItem toolStripMenuItem_21;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_32RHbit")]
	private ToolStripMenuItem toolStripMenuItem_22;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolStripMenuItem3")]
	private ToolStripSeparator toolStripSeparator_5;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_24RNbit")]
	private ToolStripMenuItem toolStripMenuItem_23;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_32RNbit")]
	private ToolStripMenuItem toolStripMenuItem_24;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_48RNbit")]
	private ToolStripMenuItem toolStripMenuItem_25;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolStripMenuItem2")]
	private ToolStripSeparator toolStripSeparator_6;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_48RHbit")]
	private ToolStripMenuItem toolStripMenuItem_26;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvDataCampo")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_0;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvDataValor")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_1;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_LiveBox")]
	private ToolStripMenuItem toolStripMenuItem_27;

	[CompilerGenerated]
	[AccessedThroughProperty("tsMenuPin_Null")]
	private ToolStripMenuItem toolStripMenuItem_28;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvPinsPin")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_2;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvPinsDescription")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_3;

	[CompilerGenerated]
	[AccessedThroughProperty("tbScanTime")]
	private ToolStripTextBox toolStripTextBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("dgvApsStatus")]
	private DataGridViewImageColumn dataGridViewImageColumn_0;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvApsPinStatus")]
	private DataGridViewImageColumn dataGridViewImageColumn_1;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvApsSSID")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_4;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvApsBSSID")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_5;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvApsChannel")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_6;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvApsSignal")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_7;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvApsVersion")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_8;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvApsLocked")]
	private DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tsbPButton")]
	private ToolStripButton toolStripButton_7;

	[CompilerGenerated]
	[AccessedThroughProperty("tsbPbcScan")]
	private ToolStripButton toolStripButton_8;

	[CompilerGenerated]
	[AccessedThroughProperty("btScan")]
	private ToolStripSplitButton toolStripSplitButton_1;

	[CompilerGenerated]
	[AccessedThroughProperty("tsWPSOnly")]
	private ToolStripMenuItem toolStripMenuItem_29;

	private virtual GClass8 GClass8_0
	{
		[CompilerGenerated]
		get
		{
			return gclass8_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			GClass8.GDelegate6 object_ = method_23;
			GClass8 gClass = default(GClass8);
			GClass8.GDelegate8 object_2 = default(GClass8.GDelegate8);
			while (true)
			{
				int num = -1385062648;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xE5879739u) % 8)
					{
					case 7u:
						Delegate8.delegate8_104(gClass, object_2);
						num = ((int)num2 * -1707627908) ^ 0x5C0BD49B;
						continue;
					case 5u:
						Delegate8.delegate8_101(gClass, object_);
						num = ((int)num2 * -582678515) ^ -320665589;
						continue;
					case 4u:
					{
						gclass8_0 = value;
						gClass = gclass8_0;
						int num5;
						if (gClass == null)
						{
							num = -1511780705;
							num5 = -1511780705;
						}
						else
						{
							num = -187255893;
							num5 = -187255893;
						}
						continue;
					}
					case 3u:
						Delegate8.delegate8_102(gClass, object_2);
						num = ((int)num2 * -13884078) ^ -138916453;
						continue;
					case 2u:
						Delegate8.delegate8_103(gClass, object_);
						num = ((int)num2 * -2031061121) ^ -1204338808;
						continue;
					case 1u:
					{
						object_2 = method_26;
						gClass = gclass8_0;
						int num3;
						int num4;
						if (gClass == null)
						{
							num3 = 446538122;
							num4 = 446538122;
						}
						else
						{
							num3 = 215060947;
							num4 = 215060947;
						}
						num = num3 ^ (int)(num2 * 2063086471);
						continue;
					}
					default:
						return;
					case 0u:
						break;
					case 6u:
						return;
					}
					break;
				}
			}
		}
	}

	private virtual GClass10 GClass10_0
	{
		[CompilerGenerated]
		get
		{
			return gclass10_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			GClass10.GDelegate9 object_ = method_63;
			GClass10 gClass = default(GClass10);
			while (true)
			{
				int num = -1993531719;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xB44B3E4Eu) % 8)
					{
					case 7u:
						gClass = gclass10_0;
						num = (int)((num2 * 249366409) ^ 0x458492A1);
						continue;
					case 5u:
					{
						int num5;
						int num6;
						if (gClass != null)
						{
							num5 = 2104051959;
							num6 = 2104051959;
						}
						else
						{
							num5 = 1251091610;
							num6 = 1251091610;
						}
						num = num5 ^ (int)(num2 * 783843778);
						continue;
					}
					case 4u:
						gclass10_0 = value;
						gClass = gclass10_0;
						num = -1145661173;
						continue;
					case 3u:
						Delegate8.delegate8_106(gClass, object_);
						num = (int)((num2 * 749496741) ^ 0x34BC3F4F);
						continue;
					case 1u:
						Delegate8.delegate8_105(gClass, object_);
						num = ((int)num2 * -1455739915) ^ 0x2DF56647;
						continue;
					case 0u:
					{
						int num3;
						int num4;
						if (gClass != null)
						{
							num3 = 242562319;
							num4 = 242562319;
						}
						else
						{
							num3 = 484641906;
							num4 = 484641906;
						}
						num = num3 ^ (int)(num2 * 1680851438);
						continue;
					}
					default:
						return;
					case 2u:
						break;
					case 6u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual SplitContainer SplitContainer_0
	{
		[CompilerGenerated]
		get
		{
			return splitContainer_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			splitContainer_0 = value;
		}
	}

	internal virtual RichTextBox RichTextBox_0
	{
		[CompilerGenerated]
		get
		{
			return richTextBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			richTextBox_0 = value;
		}
	}

	internal virtual Button Button_0
	{
		[CompilerGenerated]
		get
		{
			return button_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_28;
			Button button = default(Button);
			while (true)
			{
				int num = -1392877060;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xADB4D89Fu) % 7)
					{
					case 6u:
						Delegate8.delegate8_200(button, object_);
						num = ((int)num2 * -1846211996) ^ -2017626087;
						continue;
					case 5u:
						button_0 = value;
						num = -1274379376;
						continue;
					case 3u:
						Delegate8.delegate8_199(button, object_);
						num = (int)((num2 * 1987039746) ^ 0x2EF47BA2);
						continue;
					case 2u:
					{
						button = button_0;
						int num5;
						int num6;
						if (button != null)
						{
							num5 = 1786967092;
							num6 = 1786967092;
						}
						else
						{
							num5 = 1638363044;
							num6 = 1638363044;
						}
						num = num5 ^ ((int)num2 * -703001328);
						continue;
					}
					case 0u:
					{
						button = button_0;
						int num3;
						int num4;
						if (button == null)
						{
							num3 = 819287771;
							num4 = 819287771;
						}
						else
						{
							num3 = 595979207;
							num4 = 595979207;
						}
						num = num3 ^ (int)(num2 * 1938442134);
						continue;
					}
					default:
						return;
					case 4u:
						break;
					case 1u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ImageList ImageList_0
	{
		[CompilerGenerated]
		get
		{
			return imageList_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			imageList_0 = value;
		}
	}

	internal virtual ToolTip ToolTip_0
	{
		[CompilerGenerated]
		get
		{
			return toolTip_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolTip_0 = value;
		}
	}

	internal virtual StatusStrip StatusStrip_0
	{
		[CompilerGenerated]
		get
		{
			return statusStrip_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			statusStrip_0 = value;
		}
	}

	internal virtual ToolStrip ToolStrip_0
	{
		[CompilerGenerated]
		get
		{
			return toolStrip_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStrip_0 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_5;
			ToolStripButton toolStripButton = toolStripButton_0;
			while (true)
			{
				int num = -522517766;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xDA3BE105u) % 7)
					{
					case 6u:
						toolStripButton_0 = value;
						toolStripButton = toolStripButton_0;
						num = -759206098;
						continue;
					case 3u:
					{
						int num5;
						int num6;
						if (toolStripButton != null)
						{
							num5 = -1376120787;
							num6 = -1376120787;
						}
						else
						{
							num5 = -431299271;
							num6 = -431299271;
						}
						num = num5 ^ ((int)num2 * -1391763395);
						continue;
					}
					case 2u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = ((int)num2 * -2001705506) ^ -1316804560;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (toolStripButton != null)
						{
							num3 = 489135240;
							num4 = 489135240;
						}
						else
						{
							num3 = 1770962083;
							num4 = 1770962083;
						}
						num = num3 ^ ((int)num2 * -1083688868);
						continue;
					}
					case 0u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = (int)((num2 * 1430359656) ^ 0xC9A90FF);
						continue;
					default:
						return;
					case 5u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripComboBox ToolStripComboBox_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripComboBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_10;
			ToolStripComboBox toolStripComboBox = toolStripComboBox_0;
			if (toolStripComboBox != null)
			{
				goto IL_005b;
			}
			goto IL_00a4;
			IL_005b:
			int num = 1043308881;
			goto IL_007b;
			IL_007b:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x28A2A3CCu) % 6)
				{
				case 5u:
					Delegate8.delegate8_109(toolStripComboBox, object_);
					num = (int)((num2 * 1686046152) ^ 0x14957E2E);
					continue;
				case 3u:
				{
					int num3;
					int num4;
					if (toolStripComboBox == null)
					{
						num3 = -1596177586;
						num4 = -1596177586;
					}
					else
					{
						num3 = -718034783;
						num4 = -718034783;
					}
					num = num3 ^ ((int)num2 * -962950888);
					continue;
				}
				case 2u:
					break;
				case 1u:
					Delegate8.delegate8_201(toolStripComboBox, object_);
					num = ((int)num2 * -1317116112) ^ -718293154;
					continue;
				default:
					return;
				case 4u:
					goto IL_00a4;
				case 0u:
					return;
				}
				break;
			}
			goto IL_005b;
			IL_00a4:
			toolStripComboBox_0 = value;
			toolStripComboBox = toolStripComboBox_0;
			num = 684240311;
			goto IL_007b;
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_0 = value;
		}
	}

	internal virtual SplitContainer SplitContainer_1
	{
		[CompilerGenerated]
		get
		{
			return splitContainer_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			splitContainer_1 = value;
		}
	}

	internal virtual SplitContainer SplitContainer_2
	{
		[CompilerGenerated]
		get
		{
			return splitContainer_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			splitContainer_2 = value;
		}
	}

	internal virtual DataGridView DataGridView_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridView_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_12;
			DataGridViewBindingCompleteEventHandler object_2 = method_13;
			DataGridViewCellFormattingEventHandler object_3 = default(DataGridViewCellFormattingEventHandler);
			DataGridView dataGridView = default(DataGridView);
			while (true)
			{
				int num = 1675448492;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x2E7C9D49u) % 10)
					{
					case 9u:
						dataGridView_0 = value;
						num = 1203701838;
						continue;
					case 7u:
					{
						object_3 = method_36;
						dataGridView = dataGridView_0;
						int num5;
						int num6;
						if (dataGridView != null)
						{
							num5 = 1776064034;
							num6 = 1776064034;
						}
						else
						{
							num5 = 1387850815;
							num6 = 1387850815;
						}
						num = num5 ^ ((int)num2 * -1832534901);
						continue;
					}
					case 6u:
						Delegate8.delegate8_82(dataGridView, object_3);
						num = ((int)num2 * -166318187) ^ 0x5F686224;
						continue;
					case 4u:
						Delegate8.delegate8_202(dataGridView, object_);
						Delegate8.delegate8_203(dataGridView, object_2);
						num = (int)((num2 * 1815285107) ^ 0x19A636A1);
						continue;
					case 3u:
						Delegate8.delegate8_87(dataGridView, object_3);
						num = ((int)num2 * -724728498) ^ 0x2E1211F0;
						continue;
					case 2u:
						Delegate8.delegate8_204(dataGridView, object_);
						Delegate8.delegate8_205(dataGridView, object_2);
						num = (int)(num2 * 2032819133) ^ -192613694;
						continue;
					case 1u:
						dataGridView = dataGridView_0;
						num = ((int)num2 * -1466700091) ^ 0x54AC4E98;
						continue;
					case 0u:
					{
						int num3;
						int num4;
						if (dataGridView != null)
						{
							num3 = 549230933;
							num4 = 549230933;
						}
						else
						{
							num3 = 2009433296;
							num4 = 2009433296;
						}
						num = num3 ^ (int)(num2 * 623508911);
						continue;
					}
					default:
						return;
					case 8u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual DataGridView DataGridView_1
	{
		[CompilerGenerated]
		get
		{
			return dataGridView_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridView_1 = value;
		}
	}

	internal virtual DataGridView DataGridView_2
	{
		[CompilerGenerated]
		get
		{
			return dataGridView_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DataGridViewBindingCompleteEventHandler object_ = method_14;
			DataGridView dataGridView = default(DataGridView);
			DataGridViewDataErrorEventHandler object_2 = default(DataGridViewDataErrorEventHandler);
			DataGridViewCellValidatingEventHandler object_3 = default(DataGridViewCellValidatingEventHandler);
			while (true)
			{
				int num = -1505789173;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xDCCDCCC8u) % 15)
					{
					case 14u:
					{
						int num5;
						int num6;
						if (dataGridView != null)
						{
							num5 = 511863229;
							num6 = 511863229;
						}
						else
						{
							num5 = 2139072427;
							num6 = 2139072427;
						}
						num = num5 ^ (int)(num2 * 309265166);
						continue;
					}
					case 13u:
						Delegate8.delegate8_203(dataGridView, object_);
						num = ((int)num2 * -1928498358) ^ -1537298779;
						continue;
					case 11u:
						Delegate8.delegate8_86(dataGridView, object_2);
						num = ((int)num2 * -832684016) ^ -221245229;
						continue;
					case 10u:
						Delegate8.delegate8_81(dataGridView, object_2);
						num = ((int)num2 * -517758768) ^ 0x6B5C9F08;
						continue;
					case 9u:
						dataGridView = dataGridView_2;
						num = (int)((num2 * 600414343) ^ 0x4D86B8EB);
						continue;
					case 8u:
						Delegate8.delegate8_205(dataGridView, object_);
						num = (int)(num2 * 2075694812) ^ -1779163254;
						continue;
					case 7u:
						object_3 = method_15;
						num = (int)((num2 * 1138763795) ^ 0x574E318F);
						continue;
					case 6u:
						dataGridView_2 = value;
						num = -116802271;
						continue;
					case 5u:
						Delegate8.delegate8_207(dataGridView, object_3);
						num = (int)(num2 * 1423090342) ^ -890199785;
						continue;
					case 4u:
						dataGridView = dataGridView_2;
						num = ((int)num2 * -231058186) ^ -1534921363;
						continue;
					case 3u:
					{
						int num3;
						int num4;
						if (dataGridView == null)
						{
							num3 = 2134337671;
							num4 = 2134337671;
						}
						else
						{
							num3 = 1961736866;
							num4 = 1961736866;
						}
						num = num3 ^ (int)(num2 * 705167353);
						continue;
					}
					case 2u:
						Delegate8.delegate8_206(dataGridView, object_3);
						num = (int)((num2 * 284077414) ^ 0x791D0FEC);
						continue;
					case 1u:
						object_2 = method_16;
						num = (int)(num2 * 2056729457) ^ -255583259;
						continue;
					default:
						return;
					case 0u:
						break;
					case 12u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStrip ToolStrip_1
	{
		[CompilerGenerated]
		get
		{
			return toolStrip_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStrip_1 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_17;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = -258961299;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xB7C799B8u) % 7)
					{
					case 6u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = ((int)num2 * -1936781067) ^ -644325745;
						continue;
					case 5u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = ((int)num2 * -988237666) ^ -1866102184;
						continue;
					case 4u:
					{
						toolStripButton = toolStripButton_1;
						int num5;
						int num6;
						if (toolStripButton == null)
						{
							num5 = -979255610;
							num6 = -979255610;
						}
						else
						{
							num5 = -1522274566;
							num6 = -1522274566;
						}
						num = num5 ^ (int)(num2 * 2087077262);
						continue;
					}
					case 2u:
						toolStripButton_1 = value;
						toolStripButton = toolStripButton_1;
						num = -1094974318;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (toolStripButton == null)
						{
							num3 = 1239994833;
							num4 = 1239994833;
						}
						else
						{
							num3 = 217318934;
							num4 = 217318934;
						}
						num = num3 ^ (int)(num2 * 1662056089);
						continue;
					}
					default:
						return;
					case 3u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripButton ToolStripButton_2
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_18;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = -416342455;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x8F287CD7u) % 9)
					{
					case 7u:
					{
						int num5;
						int num6;
						if (toolStripButton != null)
						{
							num5 = -488380003;
							num6 = -488380003;
						}
						else
						{
							num5 = -2053276541;
							num6 = -2053276541;
						}
						num = num5 ^ (int)(num2 * 1282022723);
						continue;
					}
					case 6u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = ((int)num2 * -1331592112) ^ -1669660131;
						continue;
					case 5u:
					{
						int num3;
						int num4;
						if (toolStripButton != null)
						{
							num3 = 285789611;
							num4 = 285789611;
						}
						else
						{
							num3 = 2079850505;
							num4 = 2079850505;
						}
						num = num3 ^ ((int)num2 * -1708796900);
						continue;
					}
					case 4u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = (int)((num2 * 280191238) ^ 0x5AD4E208);
						continue;
					case 2u:
						toolStripButton = toolStripButton_2;
						num = (int)((num2 * 60704696) ^ 0x71017A24);
						continue;
					case 1u:
						toolStripButton = toolStripButton_2;
						num = ((int)num2 * -582827244) ^ 0x2118295C;
						continue;
					case 0u:
						toolStripButton_2 = value;
						num = -937574857;
						continue;
					default:
						return;
					case 8u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripButton ToolStripButton_3
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_20;
			ToolStripButton toolStripButton = toolStripButton_3;
			if (toolStripButton != null)
			{
				goto IL_001a;
			}
			goto IL_00bc;
			IL_001a:
			int num = 2112172109;
			goto IL_008f;
			IL_008f:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x4498A62Bu) % 7)
				{
				case 6u:
					break;
				case 4u:
				{
					int num3;
					int num4;
					if (toolStripButton == null)
					{
						num3 = -871031265;
						num4 = -871031265;
					}
					else
					{
						num3 = -1592854971;
						num4 = -1592854971;
					}
					num = num3 ^ (int)(num2 * 1319811511);
					continue;
				}
				case 2u:
					Delegate8.delegate8_89(toolStripButton, object_);
					num = ((int)num2 * -403885067) ^ -2097799387;
					continue;
				case 1u:
					Delegate8.delegate8_88(toolStripButton, object_);
					num = (int)((num2 * 980240431) ^ 0x386D78EC);
					continue;
				case 0u:
					toolStripButton = toolStripButton_3;
					num = ((int)num2 * -1850131437) ^ -1296976943;
					continue;
				default:
					return;
				case 5u:
					goto IL_00bc;
				case 3u:
					return;
				}
				break;
			}
			goto IL_001a;
			IL_00bc:
			toolStripButton_3 = value;
			num = 1809149178;
			goto IL_008f;
		}
	}

	internal virtual ToolStripButton ToolStripButton_4
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_22;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = -1289900874;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xD832D3EAu) % 7)
					{
					case 6u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = ((int)num2 * -199416743) ^ 0xF0EA70B;
						continue;
					case 4u:
					{
						int num5;
						int num6;
						if (toolStripButton != null)
						{
							num5 = -1122917253;
							num6 = -1122917253;
						}
						else
						{
							num5 = -1097836318;
							num6 = -1097836318;
						}
						num = num5 ^ ((int)num2 * -777497632);
						continue;
					}
					case 3u:
					{
						toolStripButton = toolStripButton_4;
						int num3;
						int num4;
						if (toolStripButton == null)
						{
							num3 = 1314618152;
							num4 = 1314618152;
						}
						else
						{
							num3 = 1166705195;
							num4 = 1166705195;
						}
						num = num3 ^ ((int)num2 * -1175505120);
						continue;
					}
					case 1u:
						toolStripButton_4 = value;
						toolStripButton = toolStripButton_4;
						num = -1797207184;
						continue;
					case 0u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = ((int)num2 * -1164871333) ^ -19149133;
						continue;
					default:
						return;
					case 2u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripStatusLabel ToolStripStatusLabel_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripStatusLabel_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripStatusLabel_0 = value;
		}
	}

	internal virtual PictureBox PictureBox_0
	{
		[CompilerGenerated]
		get
		{
			return pictureBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			pictureBox_0 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_5
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_5;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_30;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = -2117385201;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xD6F80B56u) % 8)
					{
					case 7u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = ((int)num2 * -347022255) ^ -1639739009;
						continue;
					case 5u:
					{
						int num5;
						int num6;
						if (toolStripButton != null)
						{
							num5 = -799779212;
							num6 = -799779212;
						}
						else
						{
							num5 = -149433629;
							num6 = -149433629;
						}
						num = num5 ^ ((int)num2 * -1403283915);
						continue;
					}
					case 4u:
						toolStripButton_5 = value;
						num = -728925532;
						continue;
					case 3u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = ((int)num2 * -551795337) ^ -1791562841;
						continue;
					case 2u:
					{
						toolStripButton = toolStripButton_5;
						int num3;
						int num4;
						if (toolStripButton != null)
						{
							num3 = 1297920353;
							num4 = 1297920353;
						}
						else
						{
							num3 = 2029489560;
							num4 = 2029489560;
						}
						num = num3 ^ (int)(num2 * 779899252);
						continue;
					}
					case 1u:
						toolStripButton = toolStripButton_5;
						num = (int)(num2 * 2111467399) ^ -1072892572;
						continue;
					default:
						return;
					case 0u:
						break;
					case 6u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripButton ToolStripButton_6
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_6;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_31;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = 1312885607;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x2D809C3Eu) % 8)
					{
					case 7u:
					{
						toolStripButton = toolStripButton_6;
						int num5;
						int num6;
						if (toolStripButton != null)
						{
							num5 = -69857386;
							num6 = -69857386;
						}
						else
						{
							num5 = -764739383;
							num6 = -764739383;
						}
						num = num5 ^ (int)(num2 * 1188185172);
						continue;
					}
					case 6u:
						toolStripButton_6 = value;
						num = 1987393353;
						continue;
					case 5u:
					{
						int num3;
						int num4;
						if (toolStripButton == null)
						{
							num3 = 749176095;
							num4 = 749176095;
						}
						else
						{
							num3 = 1197548827;
							num4 = 1197548827;
						}
						num = num3 ^ (int)(num2 * 393261427);
						continue;
					}
					case 4u:
						Delegate8.delegate8_209(toolStripButton, object_);
						num = (int)(num2 * 1048635313) ^ -1622071647;
						continue;
					case 2u:
						Delegate8.delegate8_208(toolStripButton, object_);
						num = ((int)num2 * -975830250) ^ -744712636;
						continue;
					case 1u:
						toolStripButton = toolStripButton_6;
						num = ((int)num2 * -436794212) ^ -1198486833;
						continue;
					default:
						return;
					case 0u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripDropDownButton ToolStripDropDownButton_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripDropDownButton_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripDropDownButton_0 = value;
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_32;
			ToolStripMenuItem toolStripMenuItem = toolStripMenuItem_0;
			if (toolStripMenuItem != null)
			{
				goto IL_001a;
			}
			goto IL_00bc;
			IL_001a:
			int num = 1474678414;
			goto IL_008f;
			IL_008f:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x7AABA01Fu) % 7)
				{
				case 5u:
					break;
				case 4u:
					Delegate8.delegate8_89(toolStripMenuItem, object_);
					num = (int)(num2 * 674694670) ^ -2055772433;
					continue;
				case 3u:
					toolStripMenuItem = toolStripMenuItem_0;
					num = ((int)num2 * -1577927145) ^ 0x6912FBC9;
					continue;
				case 2u:
					Delegate8.delegate8_88(toolStripMenuItem, object_);
					num = (int)((num2 * 1853027813) ^ 0x7EC44F14);
					continue;
				case 0u:
				{
					int num3;
					int num4;
					if (toolStripMenuItem == null)
					{
						num3 = 1232582433;
						num4 = 1232582433;
					}
					else
					{
						num3 = 1481420423;
						num4 = 1481420423;
					}
					num = num3 ^ ((int)num2 * -1646659287);
					continue;
				}
				default:
					return;
				case 6u:
					goto IL_00bc;
				case 1u:
					return;
				}
				break;
			}
			goto IL_001a;
			IL_00bc:
			toolStripMenuItem_0 = value;
			num = 628533315;
			goto IL_008f;
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_33;
			ToolStripMenuItem toolStripMenuItem = toolStripMenuItem_1;
			while (true)
			{
				int num = -695452630;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xC8710BB3u) % 8)
					{
					case 7u:
						toolStripMenuItem = toolStripMenuItem_1;
						num = (int)(num2 * 1833173497) ^ -971239808;
						continue;
					case 6u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -1856276649) ^ -1787084655;
						continue;
					case 4u:
					{
						int num5;
						int num6;
						if (toolStripMenuItem == null)
						{
							num5 = -2002387042;
							num6 = -2002387042;
						}
						else
						{
							num5 = -218031071;
							num6 = -218031071;
						}
						num = num5 ^ (int)(num2 * 1360208468);
						continue;
					}
					case 2u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = (int)(num2 * 1692585552) ^ -340766834;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = -287062581;
							num4 = -287062581;
						}
						else
						{
							num3 = -1164428155;
							num4 = -1164428155;
						}
						num = num3 ^ ((int)num2 * -1949659648);
						continue;
					}
					case 0u:
						toolStripMenuItem_1 = value;
						num = -557524300;
						continue;
					default:
						return;
					case 3u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_1 = value;
		}
	}

	internal virtual ContextMenuStrip ContextMenuStrip_0
	{
		[CompilerGenerated]
		get
		{
			return contextMenuStrip_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler object_ = method_37;
			ContextMenuStrip contextMenuStrip = contextMenuStrip_0;
			while (true)
			{
				int num = -1637812455;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xEB1102A8u) % 8)
					{
					case 6u:
						contextMenuStrip = contextMenuStrip_0;
						num = (int)(num2 * 141639474) ^ -129049655;
						continue;
					case 5u:
					{
						int num5;
						int num6;
						if (contextMenuStrip != null)
						{
							num5 = -1486303692;
							num6 = -1486303692;
						}
						else
						{
							num5 = -1592730760;
							num6 = -1592730760;
						}
						num = num5 ^ ((int)num2 * -239481565);
						continue;
					}
					case 3u:
						Delegate8.delegate8_211(contextMenuStrip, object_);
						num = ((int)num2 * -385369787) ^ 0x5898A138;
						continue;
					case 2u:
						Delegate8.delegate8_210(contextMenuStrip, object_);
						num = (int)((num2 * 1868764789) ^ 0x261794BA);
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (contextMenuStrip == null)
						{
							num3 = -312797248;
							num4 = -312797248;
						}
						else
						{
							num3 = -2143617974;
							num4 = -2143617974;
						}
						num = num3 ^ ((int)num2 * -1479850712);
						continue;
					}
					case 0u:
						contextMenuStrip_0 = value;
						num = -427931954;
						continue;
					default:
						return;
					case 4u:
						break;
					case 7u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_2
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_38;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = 895318215;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x68D9167Au) % 8)
					{
					case 7u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = (int)(num2 * 635645572) ^ -546971058;
						continue;
					case 6u:
						toolStripMenuItem = toolStripMenuItem_2;
						num = (int)((num2 * 545761532) ^ 0x4C7CA401);
						continue;
					case 5u:
					{
						toolStripMenuItem = toolStripMenuItem_2;
						int num5;
						int num6;
						if (toolStripMenuItem != null)
						{
							num5 = 1350148389;
							num6 = 1350148389;
						}
						else
						{
							num5 = 687218078;
							num6 = 687218078;
						}
						num = num5 ^ ((int)num2 * -1594345543);
						continue;
					}
					case 3u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem != null)
						{
							num3 = 691079312;
							num4 = 691079312;
						}
						else
						{
							num3 = 232657103;
							num4 = 232657103;
						}
						num = num3 ^ (int)(num2 * 403348367);
						continue;
					}
					case 2u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = (int)(num2 * 2108314680) ^ -803997637;
						continue;
					case 1u:
						toolStripMenuItem_2 = value;
						num = 1133425452;
						continue;
					default:
						return;
					case 4u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_2
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_2 = value;
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_3
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripMenuItem_3 = value;
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_4
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_39;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = 1565741214;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x41D87AD7u) % 8)
					{
					case 7u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = (int)((num2 * 87498184) ^ 0x34290BAD);
						continue;
					case 5u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = (int)(num2 * 418216045) ^ -1839257454;
						continue;
					case 3u:
					{
						int num5;
						int num6;
						if (toolStripMenuItem == null)
						{
							num5 = -2144238228;
							num6 = -2144238228;
						}
						else
						{
							num5 = -823439827;
							num6 = -823439827;
						}
						num = num5 ^ (int)(num2 * 1604852949);
						continue;
					}
					case 2u:
						toolStripMenuItem_4 = value;
						toolStripMenuItem = toolStripMenuItem_4;
						num = 797535020;
						continue;
					case 1u:
						toolStripMenuItem = toolStripMenuItem_4;
						num = (int)((num2 * 2142242079) ^ 0x2749DF90);
						continue;
					case 0u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem != null)
						{
							num3 = 1218257696;
							num4 = 1218257696;
						}
						else
						{
							num3 = 1330119173;
							num4 = 1330119173;
						}
						num = num3 ^ (int)(num2 * 883605253);
						continue;
					}
					default:
						return;
					case 6u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_5
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_5;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_41;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = 2014576093;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x754FC7DBu) % 7)
					{
					case 5u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -1533682321) ^ 0x36D1DC03;
						continue;
					case 3u:
					{
						toolStripMenuItem_5 = value;
						toolStripMenuItem = toolStripMenuItem_5;
						int num5;
						if (toolStripMenuItem != null)
						{
							num = 616696867;
							num5 = 616696867;
						}
						else
						{
							num = 862790489;
							num5 = 862790489;
						}
						continue;
					}
					case 2u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = (int)(num2 * 1810009909) ^ -480780031;
						continue;
					case 1u:
						toolStripMenuItem = toolStripMenuItem_5;
						num = ((int)num2 * -1623147839) ^ 0x5D0AFA25;
						continue;
					case 0u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem != null)
						{
							num3 = 1192856095;
							num4 = 1192856095;
						}
						else
						{
							num3 = 162291455;
							num4 = 162291455;
						}
						num = num3 ^ ((int)num2 * -280741869);
						continue;
					}
					default:
						return;
					case 6u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_6
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_6;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_42;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = 855084963;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x3290F633u) % 7)
					{
					case 6u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -278409803) ^ -887557725;
						continue;
					case 5u:
					{
						int num5;
						int num6;
						if (toolStripMenuItem != null)
						{
							num5 = -1125093018;
							num6 = -1125093018;
						}
						else
						{
							num5 = -434258294;
							num6 = -434258294;
						}
						num = num5 ^ ((int)num2 * -1513835992);
						continue;
					}
					case 3u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -927634385) ^ 0x11D0A2B4;
						continue;
					case 1u:
					{
						toolStripMenuItem = toolStripMenuItem_6;
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = 916184264;
							num4 = 916184264;
						}
						else
						{
							num3 = 990281975;
							num4 = 990281975;
						}
						num = num3 ^ ((int)num2 * -501581052);
						continue;
					}
					case 0u:
						toolStripMenuItem_6 = value;
						toolStripMenuItem = toolStripMenuItem_6;
						num = 660888056;
						continue;
					default:
						return;
					case 2u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_7
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_7;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_43;
			ToolStripMenuItem toolStripMenuItem = toolStripMenuItem_7;
			while (true)
			{
				int num = -373682893;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xCDC09C52u) % 8)
					{
					case 7u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -145017430) ^ -640558530;
						continue;
					case 6u:
					{
						int num5;
						int num6;
						if (toolStripMenuItem == null)
						{
							num5 = -1706031601;
							num6 = -1706031601;
						}
						else
						{
							num5 = -1416036984;
							num6 = -1416036984;
						}
						num = num5 ^ (int)(num2 * 91249605);
						continue;
					}
					case 5u:
						toolStripMenuItem = toolStripMenuItem_7;
						num = ((int)num2 * -1680473148) ^ 0x67272000;
						continue;
					case 4u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -197823194) ^ -1207531703;
						continue;
					case 2u:
						toolStripMenuItem_7 = value;
						num = -2037776249;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = -1401782119;
							num4 = -1401782119;
						}
						else
						{
							num3 = -280888508;
							num4 = -280888508;
						}
						num = num3 ^ ((int)num2 * -311423039);
						continue;
					}
					default:
						return;
					case 0u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_8
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_8;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_44;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = 119630673;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x698BA513u) % 8)
					{
					case 7u:
						toolStripMenuItem_8 = value;
						num = 750593136;
						continue;
					case 6u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -396050003) ^ -1005190846;
						continue;
					case 5u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -913408858) ^ 0x69529889;
						continue;
					case 3u:
						toolStripMenuItem = toolStripMenuItem_8;
						num = (int)((num2 * 2039150018) ^ 0x7B75839C);
						continue;
					case 2u:
					{
						toolStripMenuItem = toolStripMenuItem_8;
						int num5;
						int num6;
						if (toolStripMenuItem == null)
						{
							num5 = 737496796;
							num6 = 737496796;
						}
						else
						{
							num5 = 125368901;
							num6 = 125368901;
						}
						num = num5 ^ ((int)num2 * -1167921376);
						continue;
					}
					case 1u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = 846294556;
							num4 = 846294556;
						}
						else
						{
							num3 = 771610733;
							num4 = 771610733;
						}
						num = num3 ^ ((int)num2 * -670124365);
						continue;
					}
					default:
						return;
					case 0u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_9
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_9;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_40;
			ToolStripMenuItem toolStripMenuItem = toolStripMenuItem_9;
			if (toolStripMenuItem != null)
			{
				goto IL_001a;
			}
			goto IL_00bc;
			IL_001a:
			int num = -329442705;
			goto IL_008f;
			IL_008f:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xA3EE6857u) % 7)
				{
				case 6u:
					break;
				case 4u:
					Delegate8.delegate8_88(toolStripMenuItem, object_);
					num = (int)(num2 * 1422237124) ^ -147355313;
					continue;
				case 3u:
					Delegate8.delegate8_89(toolStripMenuItem, object_);
					num = ((int)num2 * -483088166) ^ -341854455;
					continue;
				case 1u:
				{
					int num3;
					int num4;
					if (toolStripMenuItem != null)
					{
						num3 = 781858047;
						num4 = 781858047;
					}
					else
					{
						num3 = 2064265017;
						num4 = 2064265017;
					}
					num = num3 ^ (int)(num2 * 1261682120);
					continue;
				}
				case 0u:
					toolStripMenuItem = toolStripMenuItem_9;
					num = (int)((num2 * 448353266) ^ 0x12E7E2BF);
					continue;
				default:
					return;
				case 2u:
					goto IL_00bc;
				case 5u:
					return;
				}
				break;
			}
			goto IL_001a;
			IL_00bc:
			toolStripMenuItem_9 = value;
			num = -829812699;
			goto IL_008f;
		}
	}

	private virtual ToolStripComboBox ToolStripComboBox_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripComboBox_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripComboBox_1 = value;
		}
	}

	internal virtual Button Button_1
	{
		[CompilerGenerated]
		get
		{
			return button_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_29;
			Button button = default(Button);
			while (true)
			{
				int num = 1878214608;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x21AA617Fu) % 8)
					{
					case 7u:
						button = button_1;
						num = ((int)num2 * -1999613307) ^ -1853762184;
						continue;
					case 6u:
						button_1 = value;
						button = button_1;
						num = 355119550;
						continue;
					case 4u:
					{
						int num5;
						int num6;
						if (button != null)
						{
							num5 = -93225137;
							num6 = -93225137;
						}
						else
						{
							num5 = -1528690703;
							num6 = -1528690703;
						}
						num = num5 ^ ((int)num2 * -1340099322);
						continue;
					}
					case 3u:
						Delegate8.delegate8_200(button, object_);
						num = ((int)num2 * -1884793304) ^ 0x189145E2;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (button == null)
						{
							num3 = 55012055;
							num4 = 55012055;
						}
						else
						{
							num3 = 1217357513;
							num4 = 1217357513;
						}
						num = num3 ^ ((int)num2 * -118022579);
						continue;
					}
					case 0u:
						Delegate8.delegate8_199(button, object_);
						num = (int)(num2 * 1798472783) ^ -396099663;
						continue;
					default:
						return;
					case 2u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripSplitButton ToolStripSplitButton_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripSplitButton_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_21;
			ToolStripSplitButton toolStripSplitButton = toolStripSplitButton_0;
			if (toolStripSplitButton != null)
			{
				goto IL_007d;
			}
			goto IL_00ab;
			IL_007d:
			int num = -45065588;
			goto IL_0082;
			IL_0082:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x8F0C54F7u) % 6)
				{
				case 5u:
					Delegate8.delegate8_213(toolStripSplitButton, object_);
					num = ((int)num2 * -60167595) ^ 0x50AA78DE;
					continue;
				case 3u:
				{
					toolStripSplitButton = toolStripSplitButton_0;
					int num3;
					int num4;
					if (toolStripSplitButton != null)
					{
						num3 = -1957460967;
						num4 = -1957460967;
					}
					else
					{
						num3 = -1976827492;
						num4 = -1976827492;
					}
					num = num3 ^ (int)(num2 * 231888337);
					continue;
				}
				case 1u:
					Delegate8.delegate8_212(toolStripSplitButton, object_);
					num = (int)((num2 * 339747655) ^ 0x4E37FFE8);
					continue;
				case 0u:
					break;
				default:
					return;
				case 4u:
					goto IL_00ab;
				case 2u:
					return;
				}
				break;
			}
			goto IL_007d;
			IL_00ab:
			toolStripSplitButton_0 = value;
			num = -865565198;
			goto IL_0082;
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_10
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_10;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_34;
			ToolStripMenuItem toolStripMenuItem = toolStripMenuItem_10;
			while (true)
			{
				int num = 1817776497;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x714A8094u) % 8)
					{
					case 7u:
						toolStripMenuItem_10 = value;
						num = 539971730;
						continue;
					case 6u:
						toolStripMenuItem = toolStripMenuItem_10;
						num = ((int)num2 * -1941422782) ^ 0x5AC2DDAB;
						continue;
					case 5u:
					{
						int num5;
						int num6;
						if (toolStripMenuItem == null)
						{
							num5 = 1227036029;
							num6 = 1227036029;
						}
						else
						{
							num5 = 410687426;
							num6 = 410687426;
						}
						num = num5 ^ ((int)num2 * -1463847106);
						continue;
					}
					case 3u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem != null)
						{
							num3 = 111709235;
							num4 = 111709235;
						}
						else
						{
							num3 = 475913766;
							num4 = 475913766;
						}
						num = num3 ^ ((int)num2 * -858169382);
						continue;
					}
					case 1u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -171221660) ^ -207454004;
						continue;
					case 0u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = (int)((num2 * 570123653) ^ 0x685256AB);
						continue;
					default:
						return;
					case 2u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_11
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_11;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_45;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = -357636564;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xC55B6A76u) % 8)
					{
					case 7u:
					{
						int num5;
						int num6;
						if (toolStripMenuItem != null)
						{
							num5 = -1247721321;
							num6 = -1247721321;
						}
						else
						{
							num5 = -744229005;
							num6 = -744229005;
						}
						num = num5 ^ ((int)num2 * -1579540584);
						continue;
					}
					case 5u:
						toolStripMenuItem_11 = value;
						toolStripMenuItem = toolStripMenuItem_11;
						num = -1895262107;
						continue;
					case 4u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -794861969) ^ 0x4C10E66C;
						continue;
					case 3u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = -1495975178;
							num4 = -1495975178;
						}
						else
						{
							num3 = -1249823020;
							num4 = -1249823020;
						}
						num = num3 ^ ((int)num2 * -1636993110);
						continue;
					}
					case 2u:
						toolStripMenuItem = toolStripMenuItem_11;
						num = (int)((num2 * 1845533346) ^ 0x180D86C5);
						continue;
					case 1u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -1072237162) ^ -876618595;
						continue;
					default:
						return;
					case 0u:
						break;
					case 6u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_12
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_12;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripMenuItem_12 = value;
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_13
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_13;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_46;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = 2076439913;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x79E1BA0Au) % 6)
					{
					case 4u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = (int)(num2 * 1086202240) ^ -1320021746;
						continue;
					case 2u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = (int)(num2 * 555464175) ^ -396412227;
						continue;
					case 1u:
					{
						toolStripMenuItem = toolStripMenuItem_13;
						int num4;
						int num5;
						if (toolStripMenuItem == null)
						{
							num4 = -1450025453;
							num5 = -1450025453;
						}
						else
						{
							num4 = -270235595;
							num5 = -270235595;
						}
						num = num4 ^ (int)(num2 * 1302912639);
						continue;
					}
					case 0u:
					{
						toolStripMenuItem_13 = value;
						toolStripMenuItem = toolStripMenuItem_13;
						int num3;
						if (toolStripMenuItem == null)
						{
							num = 719389719;
							num3 = 719389719;
						}
						else
						{
							num = 1657667580;
							num3 = 1657667580;
						}
						continue;
					}
					default:
						return;
					case 3u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_14
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_14;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_47;
			ToolStripMenuItem toolStripMenuItem = toolStripMenuItem_14;
			while (true)
			{
				int num = 1544016073;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x67121570u) % 8)
					{
					case 7u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -1149172988) ^ -499899458;
						continue;
					case 6u:
						toolStripMenuItem = toolStripMenuItem_14;
						num = ((int)num2 * -1658218855) ^ -777485042;
						continue;
					case 5u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -459615986) ^ -1793804435;
						continue;
					case 3u:
						toolStripMenuItem_14 = value;
						num = 1573349902;
						continue;
					case 1u:
					{
						int num5;
						int num6;
						if (toolStripMenuItem == null)
						{
							num5 = 1897471987;
							num6 = 1897471987;
						}
						else
						{
							num5 = 630427373;
							num6 = 630427373;
						}
						num = num5 ^ (int)(num2 * 1573791256);
						continue;
					}
					case 0u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = -850034206;
							num4 = -850034206;
						}
						else
						{
							num3 = -156679633;
							num4 = -156679633;
						}
						num = num3 ^ ((int)num2 * -993279730);
						continue;
					}
					default:
						return;
					case 4u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_15
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_15;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_48;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = 1596928931;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x2B8AB112u) % 8)
					{
					case 7u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -417484258) ^ 0x37944E3B;
						continue;
					case 5u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = (int)((num2 * 631492269) ^ 0x6353948F);
						continue;
					case 4u:
						toolStripMenuItem_15 = value;
						num = 979812922;
						continue;
					case 2u:
					{
						int num5;
						int num6;
						if (toolStripMenuItem != null)
						{
							num5 = 2089936427;
							num6 = 2089936427;
						}
						else
						{
							num5 = 980885575;
							num6 = 980885575;
						}
						num = num5 ^ ((int)num2 * -743048301);
						continue;
					}
					case 1u:
					{
						toolStripMenuItem = toolStripMenuItem_15;
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = 106055301;
							num4 = 106055301;
						}
						else
						{
							num3 = 1189477692;
							num4 = 1189477692;
						}
						num = num3 ^ ((int)num2 * -354398677);
						continue;
					}
					case 0u:
						toolStripMenuItem = toolStripMenuItem_15;
						num = ((int)num2 * -1227474044) ^ 0x3231E5C8;
						continue;
					default:
						return;
					case 6u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_16
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_16;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_49;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = -791219652;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x8E71FAA7u) % 7)
					{
					case 6u:
					{
						toolStripMenuItem = toolStripMenuItem_16;
						int num5;
						int num6;
						if (toolStripMenuItem != null)
						{
							num5 = -1700380493;
							num6 = -1700380493;
						}
						else
						{
							num5 = -721692882;
							num6 = -721692882;
						}
						num = num5 ^ ((int)num2 * -760140185);
						continue;
					}
					case 5u:
						toolStripMenuItem_16 = value;
						toolStripMenuItem = toolStripMenuItem_16;
						num = -1018299021;
						continue;
					case 4u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -166886528) ^ 0x331DF8F3;
						continue;
					case 3u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = 5208905;
							num4 = 5208905;
						}
						else
						{
							num3 = 1275060742;
							num4 = 1275060742;
						}
						num = num3 ^ ((int)num2 * -1475313272);
						continue;
					}
					case 2u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = (int)(num2 * 225539958) ^ -720238433;
						continue;
					default:
						return;
					case 0u:
						break;
					case 1u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_17
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_17;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_50;
			ToolStripMenuItem toolStripMenuItem = toolStripMenuItem_17;
			while (true)
			{
				int num = -897130313;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xFD626597u) % 7)
					{
					case 5u:
					{
						toolStripMenuItem = toolStripMenuItem_17;
						int num5;
						int num6;
						if (toolStripMenuItem != null)
						{
							num5 = 889466328;
							num6 = 889466328;
						}
						else
						{
							num5 = 1189437599;
							num6 = 1189437599;
						}
						num = num5 ^ (int)(num2 * 98534117);
						continue;
					}
					case 4u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = -737847270;
							num4 = -737847270;
						}
						else
						{
							num3 = -1783848292;
							num4 = -1783848292;
						}
						num = num3 ^ ((int)num2 * -154862272);
						continue;
					}
					case 3u:
						toolStripMenuItem_17 = value;
						num = -358915985;
						continue;
					case 2u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = (int)((num2 * 77287650) ^ 0x789747AC);
						continue;
					case 1u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = (int)((num2 * 1549928861) ^ 0x268967DC);
						continue;
					default:
						return;
					case 0u:
						break;
					case 6u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_18
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_18;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_51;
			ToolStripMenuItem toolStripMenuItem = toolStripMenuItem_18;
			while (true)
			{
				int num = 1823946321;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x3B9F2D47u) % 7)
					{
					case 6u:
					{
						toolStripMenuItem = toolStripMenuItem_18;
						int num5;
						int num6;
						if (toolStripMenuItem != null)
						{
							num5 = 1249523259;
							num6 = 1249523259;
						}
						else
						{
							num5 = 493000712;
							num6 = 493000712;
						}
						num = num5 ^ ((int)num2 * -2108353701);
						continue;
					}
					case 5u:
						toolStripMenuItem_18 = value;
						num = 1959774079;
						continue;
					case 4u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = (int)(num2 * 595451471) ^ -1137425844;
						continue;
					case 3u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = -146434507;
							num4 = -146434507;
						}
						else
						{
							num3 = -387250516;
							num4 = -387250516;
						}
						num = num3 ^ ((int)num2 * -1930693468);
						continue;
					}
					case 2u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = (int)(num2 * 1170081777) ^ -1290553618;
						continue;
					default:
						return;
					case 0u:
						break;
					case 1u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_3
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_3 = value;
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_19
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_19;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_58;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = -359148013;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xE9132710u) % 8)
					{
					case 7u:
						toolStripMenuItem_19 = value;
						num = -667146790;
						continue;
					case 6u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = (int)(num2 * 940069405) ^ -1417487839;
						continue;
					case 3u:
						toolStripMenuItem = toolStripMenuItem_19;
						num = (int)(num2 * 674184208) ^ -2096688112;
						continue;
					case 2u:
					{
						toolStripMenuItem = toolStripMenuItem_19;
						int num5;
						int num6;
						if (toolStripMenuItem != null)
						{
							num5 = -348598689;
							num6 = -348598689;
						}
						else
						{
							num5 = -172260309;
							num6 = -172260309;
						}
						num = num5 ^ (int)(num2 * 1977153839);
						continue;
					}
					case 1u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -1481976331) ^ -2087977200;
						continue;
					case 0u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = 836240575;
							num4 = 836240575;
						}
						else
						{
							num3 = 2054522534;
							num4 = 2054522534;
						}
						num = num3 ^ ((int)num2 * -1570652068);
						continue;
					}
					default:
						return;
					case 4u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_4
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_4 = value;
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_20
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_20;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_61;
			ToolStripMenuItem toolStripMenuItem = toolStripMenuItem_20;
			if (toolStripMenuItem != null)
			{
				goto IL_0041;
			}
			goto IL_0092;
			IL_0041:
			int num = -1903128253;
			goto IL_0061;
			IL_0061:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xDB586426u) % 5)
				{
				case 3u:
					Delegate8.delegate8_89(toolStripMenuItem, object_);
					num = (int)((num2 * 258132628) ^ 0x2DAEFA81);
					continue;
				case 2u:
					break;
				case 1u:
					Delegate8.delegate8_88(toolStripMenuItem, object_);
					num = ((int)num2 * -706999180) ^ -450199097;
					continue;
				default:
					return;
				case 4u:
					goto IL_0092;
				case 0u:
					return;
				}
				break;
			}
			goto IL_0041;
			IL_0092:
			toolStripMenuItem_20 = value;
			toolStripMenuItem = toolStripMenuItem_20;
			int num3;
			if (toolStripMenuItem == null)
			{
				num = -1499456355;
				num3 = -1499456355;
			}
			else
			{
				num = -1202832483;
				num3 = -1202832483;
			}
			goto IL_0061;
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_21
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_21;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_52;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = -402798598;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x8C4761FBu) % 8)
					{
					case 7u:
						toolStripMenuItem_21 = value;
						num = -68917765;
						continue;
					case 6u:
					{
						int num5;
						int num6;
						if (toolStripMenuItem != null)
						{
							num5 = -1674610967;
							num6 = -1674610967;
						}
						else
						{
							num5 = -1800101658;
							num6 = -1800101658;
						}
						num = num5 ^ ((int)num2 * -1078767280);
						continue;
					}
					case 3u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -1414444558) ^ -2083670262;
						continue;
					case 2u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -1790915640) ^ 0x3543A096;
						continue;
					case 1u:
					{
						toolStripMenuItem = toolStripMenuItem_21;
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = -1066079492;
							num4 = -1066079492;
						}
						else
						{
							num3 = -212248088;
							num4 = -212248088;
						}
						num = num3 ^ ((int)num2 * -395872512);
						continue;
					}
					case 0u:
						toolStripMenuItem = toolStripMenuItem_21;
						num = (int)(num2 * 413120903) ^ -1875893147;
						continue;
					default:
						return;
					case 4u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_22
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_22;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_53;
			ToolStripMenuItem toolStripMenuItem = toolStripMenuItem_22;
			while (true)
			{
				int num = 1859337103;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x49727D34u) % 8)
					{
					case 7u:
						toolStripMenuItem_22 = value;
						num = 1917240565;
						continue;
					case 6u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -1676605137) ^ -25087740;
						continue;
					case 4u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -1011789583) ^ -228823161;
						continue;
					case 3u:
					{
						int num5;
						int num6;
						if (toolStripMenuItem == null)
						{
							num5 = 643355187;
							num6 = 643355187;
						}
						else
						{
							num5 = 1588062400;
							num6 = 1588062400;
						}
						num = num5 ^ ((int)num2 * -1562576168);
						continue;
					}
					case 1u:
						toolStripMenuItem = toolStripMenuItem_22;
						num = (int)(num2 * 1989190865) ^ -1325021947;
						continue;
					case 0u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = 535962750;
							num4 = 535962750;
						}
						else
						{
							num3 = 1000671378;
							num4 = 1000671378;
						}
						num = num3 ^ ((int)num2 * -342057002);
						continue;
					}
					default:
						return;
					case 5u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_5
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_5;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_5 = value;
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_23
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_23;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_55;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = -661232250;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xC2FF8673u) % 7)
					{
					case 6u:
						toolStripMenuItem_23 = value;
						num = -201165762;
						continue;
					case 4u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -1597748731) ^ 0x2BAB2B99;
						continue;
					case 3u:
					{
						toolStripMenuItem = toolStripMenuItem_23;
						int num5;
						int num6;
						if (toolStripMenuItem == null)
						{
							num5 = -2098652324;
							num6 = -2098652324;
						}
						else
						{
							num5 = -1867349678;
							num6 = -1867349678;
						}
						num = num5 ^ ((int)num2 * -1084413940);
						continue;
					}
					case 2u:
					{
						toolStripMenuItem = toolStripMenuItem_23;
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = -30918404;
							num4 = -30918404;
						}
						else
						{
							num3 = -667353230;
							num4 = -667353230;
						}
						num = num3 ^ (int)(num2 * 544731518);
						continue;
					}
					case 1u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -1547442135) ^ 0x2152AC5;
						continue;
					default:
						return;
					case 0u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_24
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_24;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_56;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = 1842793808;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x34BB7EC1u) % 8)
					{
					case 6u:
					{
						int num5;
						int num6;
						if (toolStripMenuItem == null)
						{
							num5 = 697013722;
							num6 = 697013722;
						}
						else
						{
							num5 = 819070795;
							num6 = 819070795;
						}
						num = num5 ^ (int)(num2 * 1936545193);
						continue;
					}
					case 5u:
						toolStripMenuItem_24 = value;
						num = 1549728153;
						continue;
					case 4u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -281757804) ^ -621761740;
						continue;
					case 3u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -1641543489) ^ -1914842178;
						continue;
					case 1u:
						toolStripMenuItem = toolStripMenuItem_24;
						num = ((int)num2 * -745396882) ^ 0x199C0741;
						continue;
					case 0u:
					{
						toolStripMenuItem = toolStripMenuItem_24;
						int num3;
						int num4;
						if (toolStripMenuItem != null)
						{
							num3 = -709270702;
							num4 = -709270702;
						}
						else
						{
							num3 = -1402559213;
							num4 = -1402559213;
						}
						num = num3 ^ (int)(num2 * 1527879171);
						continue;
					}
					default:
						return;
					case 7u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_25
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_25;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_57;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = 2063011468;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x3AA1B057u) % 8)
					{
					case 6u:
					{
						int num5;
						int num6;
						if (toolStripMenuItem == null)
						{
							num5 = 1269446206;
							num6 = 1269446206;
						}
						else
						{
							num5 = 604309091;
							num6 = 604309091;
						}
						num = num5 ^ (int)(num2 * 561009710);
						continue;
					}
					case 4u:
						toolStripMenuItem_25 = value;
						toolStripMenuItem = toolStripMenuItem_25;
						num = 412640257;
						continue;
					case 3u:
						toolStripMenuItem = toolStripMenuItem_25;
						num = (int)(num2 * 848635415) ^ -84841357;
						continue;
					case 2u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -24263693) ^ -2120865963;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem != null)
						{
							num3 = -1128935645;
							num4 = -1128935645;
						}
						else
						{
							num3 = -1921106075;
							num4 = -1921106075;
						}
						num = num3 ^ ((int)num2 * -784665386);
						continue;
					}
					case 0u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = (int)((num2 * 1289229446) ^ 0x49317ECA);
						continue;
					default:
						return;
					case 7u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_6
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_6;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_6 = value;
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_26
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_26;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_54;
			ToolStripMenuItem toolStripMenuItem = toolStripMenuItem_26;
			while (true)
			{
				int num = -1754648038;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xF66C9089u) % 6)
					{
					case 3u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -209809455) ^ -615651181;
						continue;
					case 2u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = (int)(num2 * 236342258) ^ -1561773049;
						continue;
					case 1u:
					{
						int num4;
						int num5;
						if (toolStripMenuItem != null)
						{
							num4 = 1492983797;
							num5 = 1492983797;
						}
						else
						{
							num4 = 770729653;
							num5 = 770729653;
						}
						num = num4 ^ (int)(num2 * 1472956034);
						continue;
					}
					case 0u:
					{
						toolStripMenuItem_26 = value;
						toolStripMenuItem = toolStripMenuItem_26;
						int num3;
						if (toolStripMenuItem != null)
						{
							num = -1318373692;
							num3 = -1318373692;
						}
						else
						{
							num = -280744114;
							num3 = -280744114;
						}
						continue;
					}
					default:
						return;
					case 4u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_0 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_1
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_1 = value;
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_27
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_27;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_59;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = 1990164857;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x358434A7u) % 7)
					{
					case 5u:
					{
						toolStripMenuItem = toolStripMenuItem_27;
						int num5;
						int num6;
						if (toolStripMenuItem == null)
						{
							num5 = -1692968030;
							num6 = -1692968030;
						}
						else
						{
							num5 = -2012025567;
							num6 = -2012025567;
						}
						num = num5 ^ (int)(num2 * 1913563797);
						continue;
					}
					case 4u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -606896260) ^ -547921620;
						continue;
					case 3u:
					{
						toolStripMenuItem = toolStripMenuItem_27;
						int num3;
						int num4;
						if (toolStripMenuItem != null)
						{
							num3 = 186428163;
							num4 = 186428163;
						}
						else
						{
							num3 = 322933202;
							num4 = 322933202;
						}
						num = num3 ^ (int)(num2 * 2057627178);
						continue;
					}
					case 1u:
						toolStripMenuItem_27 = value;
						num = 1587978001;
						continue;
					case 0u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -675609272) ^ 0x295FD3FE;
						continue;
					default:
						return;
					case 6u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_28
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_28;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_60;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = 2143033384;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x21C71792u) % 8)
					{
					case 5u:
						toolStripMenuItem = toolStripMenuItem_28;
						num = (int)((num2 * 84041685) ^ 0x7E322B00);
						continue;
					case 4u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -1227916093) ^ 0x5F6BBD51;
						continue;
					case 3u:
					{
						int num5;
						int num6;
						if (toolStripMenuItem != null)
						{
							num5 = -314451445;
							num6 = -314451445;
						}
						else
						{
							num5 = -2051355168;
							num6 = -2051355168;
						}
						num = num5 ^ ((int)num2 * -905735169);
						continue;
					}
					case 2u:
					{
						toolStripMenuItem = toolStripMenuItem_28;
						int num3;
						int num4;
						if (toolStripMenuItem != null)
						{
							num3 = 1027871437;
							num4 = 1027871437;
						}
						else
						{
							num3 = 1082960500;
							num4 = 1082960500;
						}
						num = num3 ^ ((int)num2 * -1428355385);
						continue;
					}
					case 1u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = (int)(num2 * 1184996740) ^ -1812737210;
						continue;
					case 0u:
						toolStripMenuItem_28 = value;
						num = 993207815;
						continue;
					default:
						return;
					case 6u:
						break;
					case 7u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_2
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_2 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_3
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_3 = value;
		}
	}

	internal virtual ToolStripTextBox ToolStripTextBox_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripTextBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_65;
			ToolStripTextBox toolStripTextBox = default(ToolStripTextBox);
			KeyPressEventHandler object_2 = default(KeyPressEventHandler);
			EventHandler object_3 = default(EventHandler);
			while (true)
			{
				int num = -1572046188;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xE3695987u) % 10)
					{
					case 9u:
						toolStripTextBox = toolStripTextBox_0;
						num = (int)(num2 * 52650586) ^ -839983958;
						continue;
					case 8u:
						Delegate8.delegate8_91(toolStripTextBox, object_);
						Delegate8.delegate8_216(toolStripTextBox, object_2);
						num = (int)(num2 * 1752479449) ^ -449083010;
						continue;
					case 7u:
					{
						toolStripTextBox_0 = value;
						toolStripTextBox = toolStripTextBox_0;
						int num5;
						if (toolStripTextBox != null)
						{
							num = -107317233;
							num5 = -107317233;
						}
						else
						{
							num = -632653309;
							num5 = -632653309;
						}
						continue;
					}
					case 5u:
					{
						int num3;
						int num4;
						if (toolStripTextBox != null)
						{
							num3 = 865985413;
							num4 = 865985413;
						}
						else
						{
							num3 = 700571508;
							num4 = 700571508;
						}
						num = num3 ^ ((int)num2 * -499615404);
						continue;
					}
					case 3u:
						Delegate8.delegate8_217(toolStripTextBox, object_3);
						num = (int)(num2 * 1656841993) ^ -456846534;
						continue;
					case 2u:
						Delegate8.delegate8_215(toolStripTextBox, object_3);
						num = ((int)num2 * -1507290135) ^ 0x16413D1E;
						continue;
					case 1u:
						object_2 = method_66;
						object_3 = method_67;
						num = (int)((num2 * 49201507) ^ 0x6A3F32C5);
						continue;
					case 0u:
						Delegate8.delegate8_90(toolStripTextBox, object_);
						Delegate8.delegate8_214(toolStripTextBox, object_2);
						num = (int)((num2 * 1096950124) ^ 0x6CE9A049);
						continue;
					default:
						return;
					case 6u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual DataGridViewImageColumn DataGridViewImageColumn_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewImageColumn_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewImageColumn_0 = value;
		}
	}

	internal virtual DataGridViewImageColumn DataGridViewImageColumn_1
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewImageColumn_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewImageColumn_1 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_4
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_4 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_5
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_5;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_5 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_6
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_6;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_6 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_7
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_7;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_7 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_8
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_8;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_8 = value;
		}
	}

	internal virtual DataGridViewCheckBoxColumn DataGridViewCheckBoxColumn_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewCheckBoxColumn_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewCheckBoxColumn_0 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_7
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_7;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_19;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = -884928315;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xA8B28676u) % 7)
					{
					case 6u:
						toolStripButton = toolStripButton_7;
						num = ((int)num2 * -583264886) ^ 0x7A05E029;
						continue;
					case 4u:
					{
						toolStripButton_7 = value;
						toolStripButton = toolStripButton_7;
						int num5;
						if (toolStripButton != null)
						{
							num = -1730874360;
							num5 = -1730874360;
						}
						else
						{
							num = -1245704944;
							num5 = -1245704944;
						}
						continue;
					}
					case 3u:
					{
						int num3;
						int num4;
						if (toolStripButton != null)
						{
							num3 = -1352189884;
							num4 = -1352189884;
						}
						else
						{
							num3 = -1873436681;
							num4 = -1873436681;
						}
						num = num3 ^ (int)(num2 * 1860368246);
						continue;
					}
					case 2u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = (int)((num2 * 1000628826) ^ 0x729D56A9);
						continue;
					case 1u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = ((int)num2 * -195825825) ^ 0x640213D2;
						continue;
					default:
						return;
					case 0u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripButton ToolStripButton_8
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_8;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_7;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = -1348916363;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xCC060ED1u) % 8)
					{
					case 6u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = ((int)num2 * -1756112541) ^ -1508984728;
						continue;
					case 4u:
						toolStripButton = toolStripButton_8;
						num = ((int)num2 * -1588992612) ^ 0x5C2F55E8;
						continue;
					case 3u:
						toolStripButton_8 = value;
						toolStripButton = toolStripButton_8;
						num = -738036407;
						continue;
					case 2u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = (int)(num2 * 1534951508) ^ -1186428306;
						continue;
					case 1u:
					{
						int num5;
						int num6;
						if (toolStripButton != null)
						{
							num5 = -1223682150;
							num6 = -1223682150;
						}
						else
						{
							num5 = -1944698809;
							num6 = -1944698809;
						}
						num = num5 ^ ((int)num2 * -1682190627);
						continue;
					}
					case 0u:
					{
						int num3;
						int num4;
						if (toolStripButton != null)
						{
							num3 = 35936675;
							num4 = 35936675;
						}
						else
						{
							num3 = 289115254;
							num4 = 289115254;
						}
						num = num3 ^ ((int)num2 * -1203955854);
						continue;
					}
					default:
						return;
					case 5u:
						break;
					case 7u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripSplitButton ToolStripSplitButton_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripSplitButton_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_6;
			ToolStripSplitButton toolStripSplitButton = default(ToolStripSplitButton);
			while (true)
			{
				int num = 1665434118;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x311B3D4Fu) % 8)
					{
					case 7u:
						toolStripSplitButton_1 = value;
						num = 744298385;
						continue;
					case 6u:
						toolStripSplitButton = toolStripSplitButton_1;
						num = ((int)num2 * -1050611877) ^ 0x1BD1346D;
						continue;
					case 5u:
						Delegate8.delegate8_213(toolStripSplitButton, object_);
						num = (int)((num2 * 2123698547) ^ 0xEDB2FAB);
						continue;
					case 2u:
						Delegate8.delegate8_212(toolStripSplitButton, object_);
						num = ((int)num2 * -365617368) ^ -1453154128;
						continue;
					case 1u:
					{
						toolStripSplitButton = toolStripSplitButton_1;
						int num5;
						int num6;
						if (toolStripSplitButton == null)
						{
							num5 = 570902381;
							num6 = 570902381;
						}
						else
						{
							num5 = 1094626128;
							num6 = 1094626128;
						}
						num = num5 ^ ((int)num2 * -651063899);
						continue;
					}
					case 0u:
					{
						int num3;
						int num4;
						if (toolStripSplitButton != null)
						{
							num3 = -1618407430;
							num4 = -1618407430;
						}
						else
						{
							num3 = -414048476;
							num4 = -414048476;
						}
						num = num3 ^ ((int)num2 * -2065380438);
						continue;
					}
					default:
						return;
					case 4u:
						break;
					case 3u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_29
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_29;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripMenuItem_29 = value;
		}
	}

	public MainForm()
	{
		while (true)
		{
			int num = -767572372;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xA158CE2Du) % 11)
				{
				case 9u:
					bool_0 = false;
					num = (int)((num2 * 2037247885) ^ 0x2216AC2);
					continue;
				case 8u:
				{
					bindingSource_1 = (BindingSource)Delegate3.delegate3_17();
					int num3;
					int num4;
					if (Delegate56.delegate56_0(Delegate15.delegate15_19(Delegate3.delegate3_7()), "", bool_0: false) != 0)
					{
						num3 = 1619030622;
						num4 = 1619030622;
					}
					else
					{
						num3 = 362551967;
						num4 = 362551967;
					}
					num = num3 ^ (int)(num2 * 1213561024);
					continue;
				}
				case 7u:
					Delegate8.delegate8_3(this, new EventHandler(method_0));
					num = ((int)num2 * -1963737053) ^ 0x10012A1D;
					continue;
				case 5u:
					Delegate8.delegate8_107(this, new FormClosingEventHandler(method_1));
					gclass15_0 = new GClass15<GClass9>();
					gclass12_0 = (GClass12)Delegate3.delegate3_48();
					num = (int)(num2 * 568089631) ^ -1512404405;
					continue;
				case 4u:
					Delegate30.delegate30_12(Delegate3.delegate3_7(), Delegate15.delegate15_20(Delegate7.delegate7_88(Delegate3.delegate3_49())));
					num = (int)(num2 * 494372305) ^ -844869748;
					continue;
				case 3u:
					int_0 = 0;
					num = (int)((num2 * 1541299307) ^ 0x76C3CB42);
					continue;
				case 2u:
					bool_1 = false;
					bool_2 = false;
					num = ((int)num2 * -368986599) ^ -1021277056;
					continue;
				case 1u:
					Delegate8.delegate8_108(Delegate3.smethod_2(), Delegate12.delegate12_4(Delegate15.delegate15_19(Delegate3.delegate3_7())));
					Delegate22.delegate22_16(this);
					num = -1879876079;
					continue;
				case 0u:
					bool_3 = false;
					bindingSource_0 = (BindingSource)Delegate3.delegate3_17();
					num = ((int)num2 * -603029580) ^ 0x60BD81B0;
					continue;
				default:
					return;
				case 10u:
					break;
				case 6u:
					return;
				}
				break;
			}
		}
	}

	private void method_0(object sender, EventArgs e)
	{
		Delegate30.delegate30_3(Delegate7.delegate7_89(this), Delegate15.delegate15_3(Delegate7.delegate7_15(Delegate3.delegate3_0())));
		string object_ = Delegate15.delegate15_20(Delegate7.delegate7_88(Delegate3.delegate3_49()));
		DateTime dateTime_ = default(DateTime);
		bool flag = default(bool);
		while (true)
		{
			int num = -2110298797;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xA4142872u) % 38)
				{
				case 37u:
					DataGridView_1.ClearSelection();
					num = (int)(num2 * 2139998282) ^ -591848844;
					continue;
				case 36u:
					Delegate51.delegate51_2();
					num = (int)((num2 * 1053436730) ^ 0x4A48196D);
					continue;
				case 35u:
					Delegate8.delegate8_109(Delegate7.delegate7_90(this), new EventHandler(method_64));
					num = -215461403;
					continue;
				case 34u:
					Application.Exit();
					num = ((int)num2 * -938524529) ^ 0x1BBA7734;
					continue;
				case 33u:
					num = (int)(num2 * 744271136) ^ -736127573;
					continue;
				case 32u:
					dateTime_ = Delegate97.delegate97_0(Delegate15.delegate15_21(Delegate3.delegate3_50()));
					num = (int)(num2 * 2089645636) ^ -1564768771;
					continue;
				case 31u:
					Delegate32.delegate32_5(Delegate7.delegate7_90(this), 1);
					num = -444418611;
					continue;
				case 30u:
				{
					ToolTip_0.SetToolTip(Button_0, Class10.String_5);
					DataGridView_0.AutoGenerateColumns = false;
					GClass10_0 = new GClass10();
					int num17;
					int num18;
					if (Operators.CompareString(Class13.string_6, "", TextCompare: false) != 0)
					{
						num17 = 1163203158;
						num18 = 1163203158;
					}
					else
					{
						num17 = 1671022546;
						num18 = 1671022546;
					}
					num = num17 ^ (int)(num2 * 941102795);
					continue;
				}
				case 29u:
					ToolStripButton_6.Visible = false;
					Text = string.Format(global::_003CModule_003E.smethod_18<string>(1388769104u, 1611004987u), Class6.Form0_0.Info.Description, Class13.Version);
					num = ((int)num2 * -1850729276) ^ -1295108288;
					continue;
				case 28u:
					Delegate32.delegate32_5(Delegate7.delegate7_90(this), 0);
					num = (int)(num2 * 1346300765) ^ -873661132;
					continue;
				case 27u:
				{
					flag = true;
					int num11;
					int num12;
					if (!Delegate96.delegate96_0(object_, global::_003CModule_003E.smethod_19<string>(1694544058u, 213885904u)))
					{
						num11 = 1708241451;
						num12 = 1708241451;
					}
					else
					{
						num11 = 1439364894;
						num12 = 1439364894;
					}
					num = num11 ^ ((int)num2 * -2063017324);
					continue;
				}
				case 26u:
				{
					int num9;
					if (flag == Delegate96.delegate96_0(object_, global::_003CModule_003E.smethod_18<string>(3523242213u, 3772956303u)))
					{
						num = -1316024480;
						num9 = -1316024480;
					}
					else
					{
						num = -1679943639;
						num9 = -1679943639;
					}
					continue;
				}
				case 25u:
				{
					int num6;
					if (Delegate1.smethod_0())
					{
						num = -1354497973;
						num6 = -1354497973;
					}
					else
					{
						num = -1797391738;
						num6 = -1797391738;
					}
					continue;
				}
				case 24u:
					Delegate32.delegate32_5(Delegate7.delegate7_90(this), 3);
					num = (int)(num2 * 614896859) ^ -2081107083;
					continue;
				case 23u:
					Delegate51.smethod_1();
					num = -1708496695;
					continue;
				case 22u:
					MessageBox.Show(Class10.String_55, global::_003CModule_003E.smethod_22<string>(491050364u, 3847891350u), MessageBoxButtons.OK);
					num = (int)(num2 * 841134262) ^ -1887230390;
					continue;
				case 21u:
				{
					int num15;
					int num16;
					if (Delegate1.delegate1_2())
					{
						num15 = 1242472969;
						num16 = 1242472969;
					}
					else
					{
						num15 = 469438312;
						num16 = 469438312;
					}
					num = num15 ^ ((int)num2 * -72917125);
					continue;
				}
				case 19u:
				{
					int num13;
					int num14;
					if (Delegate98.delegate98_0(Delegate25.delegate25_1(Delegate3.delegate3_7()), dateTime_) < 0)
					{
						num13 = 619552999;
						num14 = 619552999;
					}
					else
					{
						num13 = 878714127;
						num14 = 878714127;
					}
					num = num13 ^ (int)(num2 * 548884906);
					continue;
				}
				case 18u:
					Delegate32.delegate32_5(Delegate7.delegate7_90(this), 2);
					num = (int)(num2 * 1524472614) ^ -1533115626;
					continue;
				case 17u:
				{
					int num10;
					if (flag == Delegate96.delegate96_0(object_, global::_003CModule_003E.smethod_19<string>(2339350640u, 2984628615u)))
					{
						num = -1967358502;
						num10 = -1967358502;
					}
					else
					{
						num = -919562447;
						num10 = -919562447;
					}
					continue;
				}
				case 16u:
					method_4();
					num = -904090495;
					continue;
				case 15u:
					num = (int)((num2 * 343678674) ^ 0x52DAB8BB);
					continue;
				case 14u:
					Delegate32.delegate32_5(Delegate7.delegate7_90(this), 1);
					num = ((int)num2 * -1276357507) ^ -1604438149;
					continue;
				case 13u:
				{
					int num7;
					int num8;
					if (GClass8_0.list_0.Count == 0)
					{
						num7 = 860260042;
						num8 = 860260042;
					}
					else
					{
						num7 = 222839958;
						num8 = 222839958;
					}
					num = num7 ^ (int)(num2 * 1086233070);
					continue;
				}
				case 12u:
					num = (int)((num2 * 946195802) ^ 0x3B068D9D);
					continue;
				case 11u:
					Delegate52.delegate52_0(Delegate36.smethod_1(), global::_003CModule_003E.smethod_20<string>(1308003540u, 3438647031u), MessageBoxButtons.OK);
					Delegate51.delegate51_2();
					num = -1354497973;
					continue;
				case 10u:
					num = (int)(num2 * 1841955254) ^ -271919591;
					continue;
				case 9u:
				{
					int num5;
					if (flag != Delegate96.delegate96_0(object_, global::_003CModule_003E.smethod_20<string>(597854934u, 148145170u)))
					{
						num = -1942839142;
						num5 = -1942839142;
					}
					else
					{
						num = -213634788;
						num5 = -213634788;
					}
					continue;
				}
				case 8u:
					method_2();
					num = (int)(num2 * 1752175420) ^ -1013297777;
					continue;
				case 7u:
					method_3();
					num = ((int)num2 * -1206747790) ^ -650672291;
					continue;
				case 6u:
					Class13.string_6 = Class10.String_30;
					num = ((int)num2 * -1088408811) ^ -1318182570;
					continue;
				case 5u:
				{
					int num3;
					int num4;
					if (Delegate60.delegate60_0(Delegate36.delegate36_7(), global::_003CModule_003E.smethod_22<string>(4203354688u, 2772497158u), MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) != DialogResult.Yes)
					{
						num3 = -1502843910;
						num4 = -1502843910;
					}
					else
					{
						num3 = -1629888667;
						num4 = -1629888667;
					}
					num = num3 ^ (int)(num2 * 217555945);
					continue;
				}
				case 4u:
					ToolStripTextBox_0.Text = Conversions.ToString(Class11.MySettings_0.ScanTime);
					num = -1836547940;
					continue;
				case 3u:
					GClass8_0 = new GClass8();
					num = (int)((num2 * 1328273519) ^ 0x763AE590);
					continue;
				case 1u:
					Class13.string_7 = string.Format(global::_003CModule_003E.smethod_22<string>(211454025u, 1864601655u), Delegate64.delegate64_0().Date.ToString(global::_003CModule_003E.smethod_19<string>(1106948934u, 4263400588u)));
					num = -1699063457;
					continue;
				case 0u:
					Delegate99.delegate99_0(Delegate3.delegate3_7(), Delegate64.delegate64_0());
					num = ((int)num2 * -932712640) ^ 0x3F2B2B23;
					continue;
				default:
					return;
				case 2u:
					break;
				case 20u:
					return;
				}
				break;
			}
		}
	}

	private void method_1(object sender, FormClosingEventArgs e)
	{
		if (Delegate7.delegate7_91(this) != null)
		{
			goto IL_0056;
		}
		goto IL_0080;
		IL_0056:
		int num = 1438016856;
		goto IL_005b;
		IL_005b:
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0x4BF56B32u) % 5)
			{
			case 2u:
				Delegate22.delegate22_17(Delegate7.delegate7_91(this));
				num = (int)(num2 * 1128524762) ^ -483783289;
				continue;
			case 1u:
				Delegate22.delegate22_0(Delegate3.delegate3_7());
				num = ((int)num2 * -913852772) ^ -1976402588;
				continue;
			case 0u:
				break;
			default:
				return;
			case 4u:
				goto IL_0080;
			case 3u:
				return;
			}
			break;
		}
		goto IL_0056;
		IL_0080:
		Delegate100.delegate100_0(Delegate36.smethod_2());
		num = 868718165;
		goto IL_005b;
	}

	private void method_2()
	{
		string[] string_ = Class13.string_0;
		int num = 0;
		string string_2 = default(string);
		while (true)
		{
			int num2 = 1233754230;
			while (true)
			{
				uint num3;
				switch ((num3 = (uint)num2 ^ 0xE476DA9u) % 6)
				{
				case 5u:
				{
					int num4;
					if (num >= string_.Length)
					{
						num2 = 285370735;
						num4 = 285370735;
					}
					else
					{
						num2 = 1687917593;
						num4 = 1687917593;
					}
					continue;
				}
				case 4u:
					string_2 = string_[num];
					num2 = 628337084;
					continue;
				case 3u:
					Delegate101.delegate101_0(this, Delegate57.delegate57_1(global::_003CModule_003E.smethod_20<string>(3768898639u, 2964477520u), string_2), Delegate28.delegate28_7(), bool_0: true);
					num = checked(num + 1);
					num2 = ((int)num3 * -69328973) ^ 0x58A5F679;
					continue;
				case 1u:
					num2 = (int)((num3 * 152616772) ^ 0x22EE3EA);
					continue;
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	private void method_3()
	{
		Delegate22.delegate22_18(Delegate7.delegate7_93(Delegate7.delegate7_92(this)));
		Delegate22.delegate22_19(Delegate7.delegate7_94(this));
		using (List<GInterface1>.Enumerator enumerator = ((GClass8)Delegate7.delegate7_94(this)).list_0.GetEnumerator())
		{
			while (true)
			{
				IL_00c5:
				int num;
				int num2;
				if (enumerator.MoveNext())
				{
					num = -210702252;
					num2 = -210702252;
				}
				else
				{
					num = -554687402;
					num2 = -554687402;
				}
				while (true)
				{
					uint num3;
					switch ((num3 = (uint)num ^ 0xDC65234Bu) % 4)
					{
					case 3u:
					{
						GInterface1 current = enumerator.Current;
						Delegate102.delegate102_0(Delegate7.delegate7_93(Delegate7.delegate7_92(this)), Delegate15.delegate15_22(current));
						num = -1043264103;
						continue;
					}
					case 0u:
						num = -210702252;
						continue;
					default:
						goto end_IL_0098;
					case 2u:
						break;
					case 1u:
						goto end_IL_0098;
					}
					goto IL_00c5;
					continue;
					end_IL_0098:
					break;
				}
				break;
			}
		}
		if (Delegate17.delegate17_10(Delegate7.delegate7_93(Delegate7.delegate7_92(this))) <= 0)
		{
			return;
		}
		while (true)
		{
			int num4 = -1469549795;
			while (true)
			{
				uint num3;
				switch ((num3 = (uint)num4 ^ 0xDC65234Bu) % 3)
				{
				case 1u:
					goto IL_0107;
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
				IL_0107:
				Delegate32.delegate32_5(Delegate7.delegate7_92(this), 0);
				num4 = ((int)num3 * -1956221406) ^ 0x7FBB37B9;
			}
		}
	}

	private void method_4()
	{
		Delegate103.delegate103_0(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 14);
		while (true)
		{
			int num = 973191952;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x775B2365u) % 12)
				{
				case 10u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 8)), 0), Delegate36.delegate36_17());
					num = (int)(num2 * 139888332) ^ -1542759503;
					continue;
				case 9u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 6)), 0), global::_003CModule_003E.smethod_22<string>(1487323560u, 419290376u));
					num = (int)(num2 * 1570966709) ^ -547916156;
					continue;
				case 8u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 9)), 0), global::_003CModule_003E.smethod_21<string>(395704963u, 1462676689u));
					num = ((int)num2 * -322067470) ^ 0x74BE63BE;
					continue;
				case 7u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 3)), 0), Delegate36.delegate36_13());
					num = (int)(num2 * 462381341) ^ -121025636;
					continue;
				case 6u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 4)), 0), Delegate36.delegate36_14());
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 5)), 0), Delegate36.delegate36_15());
					num = (int)((num2 * 427868192) ^ 0x253F82F4);
					continue;
				case 5u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 2)), 0), Delegate36.delegate36_12());
					num = (int)(num2 * 1687585417) ^ -1904198557;
					continue;
				case 4u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 7)), 0), Delegate36.delegate36_16());
					num = (int)(num2 * 1058329350) ^ -1395268445;
					continue;
				case 3u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 10)), 0), Delegate36.delegate36_18());
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 11)), 0), Delegate36.delegate36_19());
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 12)), 0), Delegate36.delegate36_20());
					num = ((int)num2 * -816280827) ^ 0x2AFDEF5A;
					continue;
				case 2u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 1)), 0), Delegate36.delegate36_11());
					num = (int)(num2 * 2043411271) ^ -2067470462;
					continue;
				case 1u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 0)), 0), Delegate36.delegate36_10());
					num = (int)((num2 * 1902496445) ^ 0x52D5C7F6);
					continue;
				case 11u:
					break;
				default:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 13)), 0), Delegate36.delegate36_21());
					return;
				}
				break;
			}
		}
	}

	private void method_5(object sender, EventArgs e)
	{
		Delegate22.delegate22_20(this);
	}

	private void method_6(object sender, EventArgs e)
	{
		Delegate8.delegate8_111(this, Delegate3.delegate3_51());
		gclass15_0 = Delegate104.delegate104_0(Delegate7.delegate7_94(this), Delegate21.delegate21_7(Delegate7.delegate7_96(this)), Delegate17.delegate17_11(Delegate3.delegate3_7()));
		Delegate8.delegate8_111(this, Delegate3.delegate3_52());
		Delegate22.delegate22_21(this);
	}

	private void method_7(object sender, EventArgs e)
	{
		if (Delegate21.delegate21_8(Delegate7.delegate7_97(this)))
		{
			goto IL_0041;
		}
		goto IL_0092;
		IL_0041:
		int num = -547122964;
		goto IL_006c;
		IL_006c:
		IEnumerator<GClass9> enumerator = default(IEnumerator<GClass9>);
		GClass9 current = default(GClass9);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0xE56DF1EEu) % 5)
			{
			case 4u:
				Delegate22.delegate22_21(this);
				Delegate5.delegate5_29(Delegate7.delegate7_98(this), bool_0: false);
				num = -528057270;
				continue;
			case 2u:
				break;
			case 1u:
				Delegate21.delegate21_9(Delegate7.delegate7_97(this));
				num = (int)(num2 * 519796198) ^ -1352856488;
				continue;
			case 3u:
				goto IL_0092;
			default:
			{
				Delegate5.delegate5_30(this, bool_0: false);
				Delegate105 delegate105_ = Delegate105.delegate105_0;
				object object_ = Delegate7.delegate7_94(this);
				GClass9 gClass = null;
				ref GClass15<GClass9> reference = ref gclass15_0;
				Control control_ = (Control)Delegate7.delegate7_99(this);
				string obj = delegate105_(object_, ref gClass, ref reference, ref control_);
				Delegate8.delegate8_112(this, (DataGridView)control_);
				string string_ = obj;
				try
				{
					enumerator = gclass15_0.GetEnumerator();
					while (true)
					{
						IL_01fe:
						int num3;
						int num4;
						if (!Delegate21.delegate21_3(enumerator))
						{
							num3 = -272462238;
							num4 = -272462238;
						}
						else
						{
							num3 = -1911098351;
							num4 = -1911098351;
						}
						while (true)
						{
							switch ((num2 = (uint)num3 ^ 0xE56DF1EEu) % 6)
							{
							case 5u:
								Delegate30.delegate30_13(gclass12_0, "");
								gclass12_0.Type = GClass12.GEnum5.PushButton;
								Delegate106.delegate106_0(Delegate7.delegate7_94(this), ref gclass9_0, ref gclass12_0);
								num3 = ((int)num2 * -1862012438) ^ 0x5B2DA3BA;
								continue;
							case 4u:
								gclass9_0 = current;
								num3 = (int)((num2 * 72875447) ^ 0x237EB649);
								continue;
							case 3u:
								num3 = -1911098351;
								continue;
							case 1u:
							{
								current = enumerator.Current;
								int num5;
								if (Delegate56.delegate56_0(Delegate15.delegate15_9(current), string_, bool_0: false) == 0)
								{
									num3 = -2010616898;
									num5 = -2010616898;
								}
								else
								{
									num3 = -1064959300;
									num5 = -1064959300;
								}
								continue;
							}
							default:
								goto end_IL_01c5;
							case 0u:
								break;
							case 2u:
								goto end_IL_01c5;
							}
							goto IL_01fe;
							continue;
							end_IL_01c5:
							break;
						}
						break;
					}
				}
				finally
				{
					if (enumerator != null)
					{
						while (true)
						{
							IL_024e:
							int num6 = -2057749063;
							while (true)
							{
								switch ((num2 = (uint)num6 ^ 0xE56DF1EEu) % 3)
								{
								case 1u:
									goto IL_0217;
								default:
									goto end_IL_0230;
								case 0u:
									break;
								case 2u:
									goto end_IL_0230;
								}
								goto IL_024e;
								IL_0217:
								Delegate22.delegate22_4(enumerator);
								num6 = (int)((num2 * 283267534) ^ 0x2543DD75);
								continue;
								end_IL_0230:
								break;
							}
							break;
						}
					}
				}
				Delegate5.delegate5_29(Delegate7.delegate7_98(this), bool_0: true);
				Delegate5.delegate5_30(this, bool_0: true);
				return;
			}
			}
			break;
		}
		goto IL_0041;
		IL_0092:
		Delegate21.delegate21_10(Delegate7.delegate7_97(this));
		num = -1150673516;
		goto IL_006c;
	}

	private void method_8(int int_1, GClass9.GEnum3 genum3_0)
	{
		int num;
		switch (genum3_0)
		{
		case GClass9.GEnum3.Unknow:
			Delegate8.delegate8_110(Delegate24.delegate24_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_99(this)), int_1)), global::_003CModule_003E.smethod_19<string>(139739061u, 3142651877u)), Delegate3.delegate3_40());
			num = -16202811;
			goto IL_0079;
		default:
			goto IL_0074;
		case GClass9.GEnum3.Ok:
			goto IL_00a7;
		case GClass9.GEnum3.Nok:
			break;
			IL_0079:
			switch ((uint)(num ^ -341225564) % 7u)
			{
			case 2u:
				break;
			case 0u:
				goto IL_0074;
			default:
				return;
			case 3u:
				goto IL_00a7;
			case 4u:
				return;
			case 5u:
				return;
			case 6u:
				return;
			case 1u:
				goto end_IL_0003;
			}
			goto case GClass9.GEnum3.Unknow;
			IL_00a7:
			Delegate8.delegate8_110(Delegate24.delegate24_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_99(this)), int_1)), global::_003CModule_003E.smethod_20<string>(583653963u, 1021077490u)), Delegate3.delegate3_38());
			Delegate30.delegate30_9(Delegate24.delegate24_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_99(this)), int_1)), global::_003CModule_003E.smethod_22<string>(2828843287u, 515550189u)), Delegate36.delegate36_3());
			num = -1818516607;
			goto IL_0079;
			IL_0074:
			num = -665091311;
			goto IL_0079;
			end_IL_0003:
			break;
		}
		Delegate8.delegate8_110(Delegate24.delegate24_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_99(this)), int_1)), global::_003CModule_003E.smethod_20<string>(583653963u, 4198790484u)), Delegate3.delegate3_39());
		Delegate30.delegate30_9(Delegate24.delegate24_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_99(this)), int_1)), global::_003CModule_003E.smethod_21<string>(758400717u, 3759383070u)), Delegate36.delegate36_4());
	}

	private void method_9()
	{
		Delegate8.delegate8_96(bindingSource_0, gclass15_0);
		while (true)
		{
			int num = 1211529189;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x4C0E730u) % 3)
				{
				case 1u:
					goto IL_0018;
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
				IL_0018:
				Delegate8.delegate8_97(Delegate7.delegate7_99(this), bindingSource_0);
				Delegate22.delegate22_22(Delegate7.delegate7_99(this));
				num = ((int)num2 * -1315292955) ^ 0x70C5D02B;
			}
		}
	}

	private void method_10(object sender, EventArgs e)
	{
		if (Delegate17.delegate17_12(Delegate7.delegate7_92(this)) < 0)
		{
			return;
		}
		while (true)
		{
			int num = -898221788;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x95D193ACu) % 6)
				{
				case 5u:
					Delegate22.delegate22_23(Delegate7.delegate7_79(Delegate7.delegate7_95(this)));
					Delegate22.delegate22_24(this);
					num = ((int)num2 * -1921178348) ^ -932731759;
					continue;
				case 4u:
					Delegate22.delegate22_23(Delegate7.delegate7_79(Delegate7.delegate7_99(this)));
					num = (int)((num2 * 1492184502) ^ 0x31FE1BF4);
					continue;
				case 1u:
					Delegate8.delegate8_113(this, Delegate3.delegate3_53());
					num = (int)((num2 * 1569668506) ^ 0xCE2799D);
					continue;
				case 0u:
					Delegate22.delegate22_23(Delegate7.delegate7_79(Delegate7.delegate7_97(this)));
					num = (int)((num2 * 376862870) ^ 0x3E177D8B);
					continue;
				case 2u:
					break;
				default:
					gclass15_0.Clear();
					try
					{
						int_0 = Delegate17.delegate17_12(Delegate7.delegate7_92(this));
						while (true)
						{
							int num3 = -1570618755;
							while (true)
							{
								switch ((num2 = (uint)num3 ^ 0x95D193ACu) % 3)
								{
								case 1u:
									goto IL_012f;
								default:
									return;
								case 0u:
									break;
								case 2u:
									return;
								}
								break;
								IL_012f:
								Delegate32.delegate32_6(Delegate7.delegate7_94(this), int_0);
								num3 = ((int)num2 * -1357917309) ^ 0x66C89F93;
							}
						}
					}
					catch (Exception exception_)
					{
						Delegate14.smethod_0(exception_);
						while (true)
						{
							int num4 = -819150219;
							while (true)
							{
								switch ((num2 = (uint)num4 ^ 0x95D193ACu) % 3)
								{
								default:
									return;
								case 2u:
									goto IL_01a3;
								case 0u:
									break;
								case 1u:
									return;
								}
								break;
								IL_01a3:
								Delegate51.delegate51_0();
								num4 = (int)(num2 * 1102728697) ^ -159893877;
							}
						}
					}
				}
				break;
			}
		}
	}

	private void method_11(ref GClass9 gclass9_1)
	{
		Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 0)), 1), gclass9_1.string_0);
		Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 1)), 1), gclass9_1.string_1);
		while (true)
		{
			int num = 1568622222;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x15356629u) % 10)
				{
				case 8u:
					Delegate29.delegate29_5(Delegate7.delegate7_100(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 13)), 1)), Delegate28.delegate28_8());
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 13)), 1), Delegate15.delegate15_26(gclass9_1));
					num = ((int)num2 * -334176544) ^ 0x341D7B53;
					continue;
				case 7u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 12)), 1), Delegate15.delegate15_25(Delegate7.delegate7_101(gclass9_1)));
					num = ((int)num2 * -301589329) ^ -571722800;
					continue;
				case 5u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 2)), 1), gclass9_1.string_2);
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 3)), 1), gclass9_1.string_3);
					num = ((int)num2 * -507265011) ^ -804879520;
					continue;
				case 4u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 5)), 1), gclass9_1.string_5);
					num = (int)((num2 * 1117564729) ^ 0x10F5172C);
					continue;
				case 3u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 8)), 1), Delegate21.delegate21_11(gclass9_1));
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 9)), 1), Delegate15.delegate15_9(gclass9_1));
					num = ((int)num2 * -1122213898) ^ -1913237627;
					continue;
				case 2u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 10)), 1), gclass9_1.string_9);
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 11)), 1), gclass9_1.string_10);
					Delegate29.delegate29_5(Delegate7.delegate7_100(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 12)), 1)), Delegate28.delegate28_8());
					num = (int)((num2 * 778466061) ^ 0x3ADF802E);
					continue;
				case 1u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 6)), 1), Delegate15.delegate15_23(gclass9_1));
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 7)), 1), Delegate15.delegate15_24(gclass9_1));
					num = ((int)num2 * -635852456) ^ 0x793891BC;
					continue;
				case 0u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_95(this)), 4)), 1), Delegate15.delegate15_11(gclass9_1));
					num = (int)(num2 * 1110939092) ^ -903613863;
					continue;
				default:
					return;
				case 9u:
					break;
				case 6u:
					return;
				}
				break;
			}
		}
	}

	private void method_12(object sender, EventArgs e)
	{
		if (Delegate17.delegate17_3(Delegate7.delegate7_74(Delegate7.delegate7_99(this))) == 0)
		{
			return;
		}
		while (true)
		{
			int num = 1169705644;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x658EB1FEu) % 10)
				{
				case 8u:
					Delegate5.delegate5_19(Delegate7.delegate7_103(this), bool_0: false);
					num = (int)(num2 * 213346396) ^ -1787345109;
					continue;
				case 7u:
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					num = ((int)num2 * -1849127989) ^ -143452141;
					continue;
				case 4u:
					gclass9_0 = (GClass9)Delegate7.delegate7_102(bindingSource_0);
					num = (int)(num2 * 448785473) ^ -1066419017;
					continue;
				case 3u:
					Delegate8.delegate8_96(bindingSource_1, gclass9_0.gclass15_0);
					num = ((int)num2 * -31130819) ^ -818446661;
					continue;
				case 2u:
					Delegate8.delegate8_97(Delegate7.delegate7_97(this), bindingSource_1);
					num = ((int)num2 * -1483895742) ^ 0x3CC650E3;
					continue;
				case 1u:
					Delegate5.delegate5_19(Delegate7.delegate7_104(this), bool_0: false);
					num = (int)(num2 * 298810391) ^ -1089411018;
					continue;
				case 0u:
				{
					int num4;
					int num5;
					if (!((Delegate17.delegate17_3(Delegate7.delegate7_74(Delegate7.delegate7_99(this))) == 0) | (gclass15_0.Count == 0)))
					{
						num4 = -353643783;
						num5 = -353643783;
					}
					else
					{
						num4 = -939635320;
						num5 = -939635320;
					}
					num = num4 ^ ((int)num2 * -2039359655);
					continue;
				}
				case 6u:
					break;
				default:
					try
					{
						Delegate107.delegate107_0(this, ref gclass9_0);
						return;
					}
					catch (Exception exception_)
					{
						Delegate14.smethod_0(exception_);
						while (true)
						{
							int num3 = 1889101004;
							while (true)
							{
								switch ((num2 = (uint)num3 ^ 0x658EB1FEu) % 3)
								{
								default:
									return;
								case 1u:
									goto IL_01f1;
								case 2u:
									break;
								case 0u:
									return;
								}
								break;
								IL_01f1:
								Delegate51.delegate51_0();
								num3 = ((int)num2 * -320201236) ^ 0x4377A37A;
							}
						}
					}
				case 9u:
					Delegate5.delegate5_19(Delegate7.delegate7_105(this), bool_0: false);
					Delegate5.delegate5_19(Delegate7.delegate7_106(this), bool_0: false);
					Delegate5.delegate5_19(Delegate7.delegate7_107(this), bool_0: false);
					return;
				}
				break;
			}
		}
	}

	private void method_13(object sender, DataGridViewBindingCompleteEventArgs e)
	{
		Delegate5.delegate5_29(Delegate7.delegate7_97(this), gclass15_0.Count > 0);
	}

	private void method_14(object sender, DataGridViewBindingCompleteEventArgs e)
	{
		if (bool_1)
		{
			return;
		}
		while (true)
		{
			int num = -672132403;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xA4B6B704u) % 11)
				{
				case 10u:
					Delegate5.delegate5_19(Delegate7.delegate7_107(this), bool_0: false);
					num = (int)((num2 * 1880863065) ^ 0x774DBBB);
					continue;
				case 9u:
				{
					int num3;
					int num4;
					if (gclass15_0.Count > 0)
					{
						num3 = 1571317434;
						num4 = 1571317434;
					}
					else
					{
						num3 = 341867804;
						num4 = 341867804;
					}
					num = num3 ^ ((int)num2 * -311607581);
					continue;
				}
				case 8u:
					Delegate5.delegate5_19(Delegate7.delegate7_107(this), bool_0: true);
					Delegate5.delegate5_19(Delegate7.delegate7_105(this), bool_0: true);
					num = (int)((num2 * 506543361) ^ 0x795921CF);
					continue;
				case 7u:
					Delegate5.delegate5_19(Delegate7.delegate7_105(this), bool_0: false);
					num = ((int)num2 * -248025802) ^ -461370675;
					continue;
				case 6u:
					Delegate5.delegate5_19(Delegate7.delegate7_103(this), bool_0: false);
					num = -1786835767;
					continue;
				case 4u:
					Delegate5.delegate5_19(Delegate7.delegate7_104(this), bool_0: false);
					num = (int)((num2 * 1014851583) ^ 0x5C6474AB);
					continue;
				case 3u:
					Delegate5.delegate5_19(Delegate7.delegate7_103(this), gclass9_0.gclass15_0.Count > 0);
					Delegate5.delegate5_19(Delegate7.delegate7_104(this), gclass9_0.gclass15_0.Count > 1);
					num = ((int)num2 * -1416431378) ^ 0x207E0CD4;
					continue;
				case 1u:
					Delegate5.delegate5_19(Delegate7.delegate7_106(this), bool_0: false);
					num = (int)((num2 * 778438475) ^ 0x4EB90FA2);
					continue;
				default:
					return;
				case 0u:
					break;
				case 2u:
					Delegate5.delegate5_19(Delegate7.delegate7_106(this), bool_0: true);
					return;
				case 5u:
					return;
				}
				break;
			}
		}
	}

	private void method_15(object sender, DataGridViewCellValidatingEventArgs e)
	{
		if (!((Delegate17.delegate17_13(e) >= 0) & (Delegate17.delegate17_14(e) >= 0)))
		{
			return;
		}
		while (true)
		{
			int num = 1053364940;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x2D2C472Du) % 4)
				{
				case 3u:
					Delegate30.delegate30_14((GClass12)Delegate7.delegate7_102(bindingSource_1), global::_003CModule_003E.smethod_18<string>(1596019138u, 2074000865u));
					num = (int)((num2 * 1817986702) ^ 0x71A3F1B1);
					continue;
				case 1u:
				{
					int num3;
					int num4;
					if (!Delegate108.delegate108_0(Delegate7.delegate7_108(e), Delegate7.delegate7_109(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_97(this)), Delegate17.delegate17_13(e))), Delegate17.delegate17_14(e))), bool_0: false))
					{
						num3 = 1326290274;
						num4 = 1326290274;
					}
					else
					{
						num3 = 493674423;
						num4 = 493674423;
					}
					num = num3 ^ ((int)num2 * -1701314343);
					continue;
				}
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	private void method_16(object sender, DataGridViewDataErrorEventArgs e)
	{
	}

	private void method_17(object sender, EventArgs e)
	{
		if (Delegate21.delegate21_8(Delegate7.delegate7_97(this)))
		{
			goto IL_002b;
		}
		goto IL_00c1;
		IL_002b:
		int num = 749191024;
		goto IL_0098;
		IL_0098:
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0x3BA65E48u) % 6)
			{
			case 5u:
				num = ((int)num2 * -1151048172) ^ -750535396;
				continue;
			case 3u:
				break;
			case 2u:
				Delegate21.delegate21_9(Delegate7.delegate7_97(this));
				num = ((int)num2 * -40606037) ^ -1760956925;
				continue;
			case 0u:
				gclass12_0 = (GClass12)Delegate7.delegate7_102(bindingSource_1);
				Delegate109.delegate109_0(Delegate7.delegate7_94(this), ref gclass9_0, gclass12_0);
				num = 831002563;
				continue;
			default:
				return;
			case 4u:
				goto IL_00c1;
			case 1u:
				return;
			}
			break;
		}
		goto IL_002b;
		IL_00c1:
		Delegate21.delegate21_10(Delegate7.delegate7_97(this));
		num = 1359546784;
		goto IL_0098;
	}

	private void method_18(object sender, EventArgs e)
	{
		if (Delegate21.delegate21_8(Delegate7.delegate7_97(this)))
		{
			goto IL_003e;
		}
		goto IL_0064;
		IL_003e:
		int num = 1496629468;
		goto IL_0043;
		IL_0043:
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0x452CA423u) % 4)
			{
			case 3u:
				Delegate21.delegate21_9(Delegate7.delegate7_97(this));
				num = ((int)num2 * -1246101734) ^ 0x3BD120C4;
				continue;
			case 2u:
				break;
			case 0u:
				goto IL_0064;
			default:
			{
				GClass8 object_ = (GClass8)Delegate7.delegate7_94(this);
				object object_2 = Delegate110.delegate110_0(ref object_, ref gclass9_0, bool_0: false);
				Delegate8.delegate8_113(this, object_);
				Delegate111.smethod_0(object_2);
				Delegate22.smethod_1(object_2);
				return;
			}
			}
			break;
		}
		goto IL_003e;
		IL_0064:
		Delegate21.delegate21_10(Delegate7.delegate7_97(this));
		num = 1435132450;
		goto IL_0043;
	}

	private void method_19(object sender, EventArgs e)
	{
		if (Delegate21.delegate21_8(Delegate7.delegate7_97(this)))
		{
			goto IL_0169;
		}
		goto IL_01e4;
		IL_0169:
		int num = -303498828;
		goto IL_01a6;
		IL_01a6:
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0xF995EC7Fu) % 11)
			{
			case 10u:
				Delegate30.delegate30_13(gclass12_0, "");
				num = ((int)num2 * -1759543251) ^ 0x31FF5151;
				continue;
			case 9u:
				Delegate106.delegate106_0(Delegate7.delegate7_94(this), ref gclass9_0, ref gclass12_0);
				num = (int)((num2 * 356121475) ^ 0x35DFD45E);
				continue;
			case 7u:
				gclass12_0.Type = GClass12.GEnum5.PushButton;
				num = (int)(num2 * 1503098331) ^ -10563020;
				continue;
			case 6u:
				Delegate21.delegate21_9(Delegate7.delegate7_97(this));
				num = (int)(num2 * 1180400598) ^ -561420835;
				continue;
			case 5u:
				Delegate5.delegate5_30(this, bool_0: false);
				Delegate5.delegate5_29(Delegate7.delegate7_99(this), bool_0: false);
				num = -2040804115;
				continue;
			case 3u:
			{
				Delegate56 delegate56_ = Delegate56.delegate56_0;
				Delegate105 delegate105_ = Delegate105.delegate105_0;
				object object_ = Delegate7.delegate7_94(this);
				ref GClass9 reference = ref gclass9_0;
				ref GClass15<GClass9> reference2 = ref gclass15_0;
				Control control_ = (Control)Delegate7.delegate7_84(this);
				string string_ = delegate105_(object_, ref reference, ref reference2, ref control_);
				Delegate8.delegate8_114(this, (RichTextBox)control_);
				int num3;
				int num4;
				if (delegate56_(string_, Delegate15.delegate15_9(gclass9_0), bool_0: false) == 0)
				{
					num3 = -1478957137;
					num4 = -1478957137;
				}
				else
				{
					num3 = -749690499;
					num4 = -749690499;
				}
				num = num3 ^ ((int)num2 * -2028205092);
				continue;
			}
			case 2u:
				break;
			case 1u:
				Delegate5.delegate5_30(this, bool_0: true);
				Delegate5.delegate5_29(Delegate7.delegate7_99(this), bool_0: true);
				num = -1780592833;
				continue;
			case 0u:
				num = ((int)num2 * -1007454779) ^ -605332649;
				continue;
			default:
				return;
			case 4u:
				goto IL_01e4;
			case 8u:
				return;
			}
			break;
		}
		goto IL_0169;
		IL_01e4:
		Delegate21.delegate21_10(Delegate7.delegate7_97(this));
		num = -259599865;
		goto IL_01a6;
	}

	private void method_20(object sender, EventArgs e)
	{
		GClass8 object_ = (GClass8)Delegate7.delegate7_94(this);
		while (true)
		{
			int num = -1920109849;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xA810E2E2u) % 3)
				{
				case 1u:
					goto IL_000e;
				default:
					return;
				case 2u:
					break;
				case 0u:
					return;
				}
				break;
				IL_000e:
				object object_2 = Delegate110.delegate110_0(ref object_, ref gclass9_0, bool_0: true);
				Delegate8.delegate8_113(this, object_);
				Delegate111.smethod_0(object_2);
				Delegate22.smethod_1(object_2);
				num = (int)(num2 * 1885391032) ^ -648337680;
			}
		}
	}

	private void method_21(object sender, EventArgs e)
	{
		Delegate107.delegate107_1(Delegate7.delegate7_94(this), ref gclass9_0);
		bool_3 = true;
	}

	private void method_22(object sender, EventArgs e)
	{
		Delegate5.delegate5_31(Delegate7.delegate7_94(this), bool_0: true);
		while (true)
		{
			int num = -1623227846;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xBC5BDA55u) % 3)
				{
				case 1u:
					goto IL_0018;
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
				IL_0018:
				bool_3 = false;
				num = ((int)num2 * -1005284827) ^ -413217650;
			}
		}
	}

	private void method_23(string string_0, Color color_0, bool bool_4)
	{
		if (Delegate21.delegate21_12(this))
		{
			try
			{
				GDelegate4 object_ = method_23;
				Delegate112.smethod_0((object)this, (object)object_, new object[3] { string_0, color_0, bool_4 });
				return;
			}
			catch (Exception exception_)
			{
				Delegate14.smethod_0(exception_);
				while (true)
				{
					int num = 1309454072;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x5F3A968Du) % 3)
						{
						default:
							return;
						case 1u:
							goto IL_0066;
						case 2u:
							break;
						case 0u:
							return;
						}
						break;
						IL_0066:
						Delegate51.delegate51_0();
						num = ((int)num2 * -947502199) ^ -687880377;
					}
				}
			}
		}
		Delegate101.delegate101_0(this, string_0, color_0, bool_4);
	}

	public void method_24(string string_0, Color color_0, bool bool_4)
	{
		try
		{
			if (Delegate113.delegate113_0(Delegate7.delegate7_84(this)).Count() > 2000)
			{
				goto IL_00db;
			}
			goto IL_0199;
			IL_00db:
			int num = 591526328;
			goto IL_0150;
			IL_0150:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x5AB7439Eu) % 10)
				{
				case 9u:
				{
					Delegate29.delegate29_6(Delegate7.delegate7_84(this), color_0);
					int num5;
					int num6;
					if (bool_4)
					{
						num5 = -1682537117;
						num6 = -1682537117;
					}
					else
					{
						num5 = -1115124947;
						num6 = -1115124947;
					}
					num = num5 ^ (int)(num2 * 907054397);
					continue;
				}
				case 8u:
					Delegate114.delegate114_0(Class13.string_7, string_0);
					num = (int)((num2 * 207785408) ^ 0x4830B2A3);
					continue;
				case 6u:
					Delegate22.delegate22_25(Delegate7.delegate7_84(this));
					num = (int)((num2 * 105893394) ^ 0x4346C547);
					continue;
				case 5u:
					Delegate115.delegate115_0((RichTextBox)Delegate7.delegate7_84(this));
					num = 1196683865;
					continue;
				case 4u:
					break;
				case 2u:
					Delegate30.delegate30_15(Delegate7.delegate7_84(this), string_0);
					num = 2038861585;
					continue;
				case 1u:
				{
					int num3;
					int num4;
					if (Class13.bool_2)
					{
						num3 = -299796880;
						num4 = -299796880;
					}
					else
					{
						num3 = -834495321;
						num4 = -834495321;
					}
					num = num3 ^ (int)(num2 * 1438249532);
					continue;
				}
				case 0u:
					string_0 = Delegate57.delegate57_1(string_0, global::_003CModule_003E.smethod_19<string>(2282670531u, 158784463u));
					num = ((int)num2 * -1685421559) ^ 0x13BECAD0;
					continue;
				default:
					return;
				case 7u:
					goto IL_0199;
				case 3u:
					return;
				}
				break;
			}
			goto IL_00db;
			IL_0199:
			int num7;
			if ((object)string_0 != string.Empty)
			{
				num = 2062062271;
				num7 = 2062062271;
			}
			else
			{
				num = 1196683865;
				num7 = 1196683865;
			}
			goto IL_0150;
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			while (true)
			{
				int num8 = 1867400964;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num8 ^ 0x5AB7439Eu) % 3)
					{
					default:
						return;
					case 1u:
						goto IL_01ce;
					case 0u:
						break;
					case 2u:
						return;
					}
					break;
					IL_01ce:
					Delegate51.delegate51_0();
					num8 = (int)(num2 * 1524718103) ^ -513817003;
				}
			}
		}
	}

	private void method_25(bool bool_4)
	{
		try
		{
			Delegate5.delegate5_19(Delegate7.delegate7_110(this), bool_4);
			while (true)
			{
				int num = -1932643574;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xDA3A41B6u) % 5)
					{
					case 4u:
						Delegate5.delegate5_19(Delegate7.delegate7_106(this), bool_4);
						num = ((int)num2 * -1322757662) ^ 0x753C75AB;
						continue;
					case 3u:
						Delegate5.delegate5_19(Delegate7.delegate7_105(this), bool_4);
						num = (int)((num2 * 1686193104) ^ 0x24BFC61B);
						continue;
					case 2u:
						Delegate5.delegate5_19(Delegate7.delegate7_111(this), bool_4);
						Delegate5.delegate5_19(Delegate7.delegate7_112(this), bool_4);
						Delegate5.delegate5_32(Delegate7.delegate7_96(this), bool_4);
						Delegate5.smethod_3(Delegate7.delegate7_104(this), bool_4 & (gclass9_0 != null && gclass9_0.gclass15_0.Count > 1));
						Delegate5.smethod_3(Delegate7.delegate7_103(this), bool_4 & (gclass9_0 != null && gclass9_0.gclass15_0.Count > 0));
						num = -260573612;
						continue;
					case 0u:
						break;
					default:
						Delegate5.delegate5_19(Delegate7.delegate7_107(this), bool_4);
						Delegate5.delegate5_19(Delegate7.delegate7_113(this), !bool_4);
						Delegate5.delegate5_33(Delegate7.delegate7_92(this), bool_4);
						return;
					}
					break;
				}
			}
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			Delegate51.delegate51_0();
		}
	}

	private void method_26(GClass8.GEnum1 genum1_0)
	{
		if (Delegate21.delegate21_12(this))
		{
			try
			{
				GDelegate5 object_ = method_26;
				while (true)
				{
					int num = 2039144432;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x178A4FB7u) % 3)
						{
						case 1u:
							goto IL_001f;
						default:
							return;
						case 0u:
							break;
						case 2u:
							return;
						}
						break;
						IL_001f:
						Delegate112.smethod_0((object)this, (object)object_, new object[1] { genum1_0 });
						num = ((int)num2 * -32290580) ^ -1157508794;
					}
				}
			}
			catch (Exception exception_)
			{
				Delegate14.smethod_0(exception_);
				while (true)
				{
					int num3 = 961437639;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num3 ^ 0x178A4FB7u) % 3)
						{
						default:
							return;
						case 1u:
							goto IL_008f;
						case 0u:
							break;
						case 2u:
							return;
						}
						break;
						IL_008f:
						Delegate51.delegate51_0();
						num3 = ((int)num2 * -1273634063) ^ 0x60C62AAC;
					}
				}
			}
		}
		Delegate116.delegate116_0(this, genum1_0);
	}

	private void method_27(GClass8.GEnum1 genum1_0)
	{
		if (genum1_0 <= GClass8.GEnum1.Start)
		{
			goto IL_02d3;
		}
		goto IL_0415;
		IL_02d3:
		int num = -2003316261;
		goto IL_03a0;
		IL_03a0:
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0xB95F84F3u) % 21)
			{
			case 19u:
			{
				int num9;
				int num10;
				if (genum1_0 == GClass8.GEnum1.PixieSucced)
				{
					num9 = 275975234;
					num10 = 275975234;
				}
				else
				{
					num9 = 998648877;
					num10 = 998648877;
				}
				num = num9 ^ ((int)num2 * -1826824865);
				continue;
			}
			case 18u:
				Delegate101.delegate101_0(this, Delegate57.delegate57_1(global::_003CModule_003E.smethod_20<string>(1451926724u, 4048135825u), Delegate15.delegate15_15(gclass9_0)), Delegate28.delegate28_1(), bool_0: true);
				Delegate101.delegate101_0(this, Delegate57.delegate57_1(global::_003CModule_003E.smethod_18<string>(4130924262u, 3875497582u), Delegate15.delegate15_17(gclass9_0)), Delegate28.delegate28_1(), bool_0: true);
				num = ((int)num2 * -1345821284) ^ 0x4980DF61;
				continue;
			case 17u:
			{
				int num5;
				int num6;
				if (genum1_0 == GClass8.GEnum1.Stop)
				{
					num5 = 9329516;
					num6 = 9329516;
				}
				else
				{
					num5 = 842443316;
					num6 = 842443316;
				}
				num = num5 ^ ((int)num2 * -41281152);
				continue;
			}
			case 15u:
				Delegate101.delegate101_0(this, Delegate57.delegate57_1(global::_003CModule_003E.smethod_20<string>(3044549062u, 524784146u), Delegate15.delegate15_13(gclass9_0)), Delegate28.delegate28_1(), bool_0: true);
				Delegate101.delegate101_0(this, Delegate57.delegate57_1(global::_003CModule_003E.smethod_20<string>(3655906461u, 1412085609u), Delegate15.delegate15_14(gclass9_0)), Delegate28.delegate28_1(), bool_0: true);
				num = (int)((num2 * 566672828) ^ 0x4BDD2071);
				continue;
			case 14u:
				Delegate107.delegate107_0(this, ref gclass9_0);
				bool_1 = false;
				num = (int)((num2 * 519280011) ^ 0x399ECDBB);
				continue;
			case 13u:
			{
				int num7;
				int num8;
				if (!bool_3)
				{
					num7 = 1214034295;
					num8 = 1214034295;
				}
				else
				{
					num7 = 1942149234;
					num8 = 1942149234;
				}
				num = num7 ^ (int)(num2 * 1390750856);
				continue;
			}
			case 12u:
				Delegate5.delegate5_31(Delegate7.delegate7_94(this), bool_0: false);
				Delegate101.delegate101_0(this, Delegate57.delegate57_1(global::_003CModule_003E.smethod_19<string>(2051167954u, 1472976377u), Delegate15.delegate15_16(gclass9_0)), Delegate28.delegate28_1(), bool_0: true);
				Delegate101.delegate101_0(this, Delegate57.delegate57_1(global::_003CModule_003E.smethod_21<string>(1658257369u, 853261236u), Delegate15.delegate15_12(gclass9_0)), Delegate28.delegate28_1(), bool_0: true);
				num = ((int)num2 * -777089198) ^ -2069128384;
				continue;
			case 10u:
				Delegate117.delegate117_0(this, global::_003CModule_003E.smethod_20<string>(1950291945u, 3983431321u), bool_0: true);
				num = ((int)num2 * -1407252390) ^ 0x636B10B5;
				continue;
			case 9u:
				Delegate5.delegate5_30(this, bool_0: false);
				bool_1 = true;
				num = -1633379354;
				continue;
			case 8u:
				break;
			case 6u:
				goto IL_02dd;
			case 5u:
				Delegate101.delegate101_0(this, Delegate57.delegate57_1(global::_003CModule_003E.smethod_19<string>(116748208u, 2993929415u), Delegate15.delegate15_18(gclass9_0)), Delegate28.delegate28_1(), bool_0: true);
				Delegate101.delegate101_0(this, Class13.string_4, Delegate28.delegate28_9(), bool_0: false);
				num = ((int)num2 * -1850763397) ^ -1382638712;
				continue;
			case 3u:
				Delegate5.delegate5_30(this, bool_0: true);
				num = -1572631128;
				continue;
			case 1u:
			{
				int num3;
				int num4;
				if (genum1_0 == GClass8.GEnum1.Start)
				{
					num3 = 2065219881;
					num4 = 2065219881;
				}
				else
				{
					num3 = 984085693;
					num4 = 984085693;
				}
				num = num3 ^ ((int)num2 * -1493431097);
				continue;
			}
			default:
				return;
			case 11u:
				goto IL_0415;
			case 0u:
				return;
			case 2u:
				return;
			case 4u:
				return;
			case 7u:
				Delegate22.delegate22_21(this);
				return;
			case 16u:
				Delegate107.delegate107_0(this, ref gclass9_0);
				return;
			case 20u:
				return;
			}
			break;
			IL_02dd:
			int num11;
			if (bool_3)
			{
				num = -2079426689;
				num11 = -2079426689;
			}
			else
			{
				num = -1894692641;
				num11 = -1894692641;
			}
		}
		goto IL_02d3;
		IL_0415:
		int num12;
		if (genum1_0 == GClass8.GEnum1.Updated)
		{
			num = -1033848218;
			num12 = -1033848218;
		}
		else
		{
			num = -814567971;
			num12 = -814567971;
		}
		goto IL_03a0;
	}

	private void method_28(object sender, EventArgs e)
	{
		bool_0 = !bool_0;
		while (true)
		{
			int num = 222503401;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x7243F380u) % 6)
				{
				case 5u:
					Delegate8.delegate8_115(Delegate7.delegate7_114(this), Delegate3.delegate3_54());
					num = (int)((num2 * 366019170) ^ 0x7F17712C);
					continue;
				case 4u:
					Delegate8.delegate8_115(Delegate7.delegate7_114(this), Delegate3.delegate3_55());
					Delegate27.delegate27_1(Delegate7.delegate7_115(this), Delegate7.delegate7_114(this), Delegate36.delegate36_23());
					num = 1936746033;
					continue;
				case 2u:
					Delegate27.delegate27_1(Delegate7.delegate7_115(this), Delegate7.delegate7_114(this), Delegate36.delegate36_22());
					num = ((int)num2 * -160432071) ^ 0x43713217;
					continue;
				case 1u:
				{
					int num3;
					int num4;
					if (bool_0)
					{
						num3 = 789341149;
						num4 = 789341149;
					}
					else
					{
						num3 = 390591224;
						num4 = 390591224;
					}
					num = num3 ^ ((int)num2 * -973758896);
					continue;
				}
				case 0u:
					break;
				default:
					((GClass8)Delegate7.delegate7_94(this)).bool_2 = bool_0;
					return;
				}
				break;
			}
		}
	}

	private void method_29(object sender, EventArgs e)
	{
		Delegate22.delegate22_25(Delegate7.delegate7_84(this));
		while (true)
		{
			int num = 385447375;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x38EBE8Du) % 3)
				{
				case 1u:
					goto IL_0017;
				default:
					return;
				case 2u:
					break;
				case 0u:
					return;
				}
				break;
				IL_0017:
				Delegate101.delegate101_0(this, Class13.string_4, Delegate28.delegate28_9(), bool_0: false);
				num = (int)(num2 * 832519204) ^ -759329497;
			}
		}
	}

	private void method_30(object sender, EventArgs e)
	{
		Delegate111.delegate111_0(Delegate3.delegate3_56());
	}

	private void method_31(object sender, EventArgs e)
	{
		Class13.bool_1 = Delegate21.delegate21_13(Delegate7.delegate7_116(this));
	}

	private void method_32(object sender, EventArgs e)
	{
		object object_ = Delegate3.delegate3_57();
		Delegate111.smethod_0(object_);
		Delegate22.smethod_1(object_);
	}

	private void method_33(object sender, EventArgs e)
	{
		object object_ = Delegate3.delegate3_58();
		Delegate111.smethod_0(object_);
		Delegate22.smethod_1(object_);
	}

	private void method_34(object sender, EventArgs e)
	{
		GClass8 object_ = (GClass8)Delegate7.delegate7_94(this);
		object object_2 = Delegate118.delegate118_0(ref object_, ref gclass9_0);
		Delegate8.delegate8_113(this, object_);
		Delegate111.smethod_0(object_2);
		Delegate22.smethod_1(object_2);
	}

	private void method_35(object sender, WebBrowserDocumentCompletedEventArgs e)
	{
		bool_2 = true;
	}

	private void method_36(object sender, DataGridViewCellFormattingEventArgs e)
	{
		string string_ = Delegate15.delegate15_5(Delegate55.delegate55_0(Delegate7.delegate7_22((DataGridView)sender), Delegate17.delegate17_4(e)));
		if (Delegate56.delegate56_0(string_, global::_003CModule_003E.smethod_19<string>(139739061u, 4032920702u), bool_0: false) != 0)
		{
			goto IL_0477;
		}
		goto IL_06c9;
		IL_0477:
		int num = -1838589387;
		goto IL_063a;
		IL_063a:
		Bitmap bitmap = default(Bitmap);
		Graphics graphics = default(Graphics);
		bool[] array2 = default(bool[]);
		GClass3.GEnum0 gEnum = default(GClass3.GEnum0);
		GClass9.GEnum3 gEnum2 = default(GClass9.GEnum3);
		DataGridViewCellFormattingEventArgs dataGridViewCellFormattingEventArgs = default(DataGridViewCellFormattingEventArgs);
		object[] array = default(object[]);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0xDC88C589u) % 31)
			{
			case 30u:
				num = ((int)num2 * -1471512519) ^ -1941335262;
				continue;
			case 29u:
				num = (int)(num2 * 1571727110) ^ -2023471824;
				continue;
			case 28u:
				Delegate8.delegate8_99(e, Delegate3.delegate3_40());
				num = -1100760344;
				continue;
			case 27u:
			{
				int num5;
				int num6;
				if (Delegate56.delegate56_0(string_, global::_003CModule_003E.smethod_19<string>(2799699049u, 4196891846u), bool_0: false) != 0)
				{
					num5 = 473657668;
					num6 = 473657668;
				}
				else
				{
					num5 = 1241090762;
					num6 = 1241090762;
				}
				num = num5 ^ (int)(num2 * 82730546);
				continue;
			}
			case 26u:
				num = (int)((num2 * 1752672381) ^ 0x2DB4119A);
				continue;
			case 25u:
				num = ((int)num2 * -671945355) ^ 0x2FEDEEF8;
				continue;
			case 24u:
				goto IL_0102;
			case 23u:
				Delegate8.delegate8_99(e, Delegate3.delegate3_61());
				Delegate30.delegate30_9(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_99(this)), Delegate17.delegate17_5(e))), Delegate17.delegate17_4(e)), Delegate36.delegate36_26());
				num = -1317976768;
				continue;
			case 22u:
				bitmap = (Bitmap)Delegate119.delegate119_0(16, 16);
				num = ((int)num2 * -1977657714) ^ -430099721;
				continue;
			case 21u:
				goto IL_01bf;
			case 19u:
				Delegate30.delegate30_9(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_99(this)), Delegate17.delegate17_5(e))), Delegate17.delegate17_4(e)), Delegate36.delegate36_3());
				num = (int)((num2 * 1363940390) ^ 0x3AEE7627);
				continue;
			case 18u:
				graphics.DrawImage(GClass0.Bitmap_56, new Point(0, 0));
				num = -1183772856;
				continue;
			case 17u:
				e.Value = bitmap;
				DataGridView_0.Rows[e.RowIndex].Cells[e.ColumnIndex].ToolTipText += Class10.String_13;
				num = ((int)num2 * -581877171) ^ 0x892C8D3;
				continue;
			case 16u:
				goto IL_0321;
			case 15u:
			{
				int num3;
				int num4;
				if (array2[0])
				{
					num3 = -637304417;
					num4 = -637304417;
				}
				else
				{
					num3 = -553507413;
					num4 = -553507413;
				}
				num = num3 ^ (int)(num2 * 36093048);
				continue;
			}
			case 14u:
				goto IL_03c8;
			case 13u:
				gEnum = (GClass3.GEnum0)Delegate17.delegate17_1(Delegate7.delegate7_78(e));
				num = -930436892;
				continue;
			case 12u:
				Delegate30.delegate30_9(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_99(this)), Delegate17.delegate17_5(e))), Delegate17.delegate17_4(e)), Delegate36.delegate36_24());
				num = (int)(num2 * 1800065089) ^ -1304853822;
				continue;
			case 10u:
				break;
			case 9u:
				switch (gEnum2)
				{
				case GClass9.GEnum3.Unknow:
					break;
				case GClass9.GEnum3.Ok:
					goto IL_0102;
				default:
					goto IL_0493;
				case GClass9.GEnum3.Nok:
					goto IL_04a6;
				}
				goto case 28u;
			case 5u:
				goto IL_04a6;
			case 8u:
			{
				graphics = (Graphics)Delegate120.delegate120_0(bitmap);
				Graphics instance = graphics;
				string memberName = global::_003CModule_003E.smethod_21<string>(2027835856u, 1300028875u);
				object[] obj = new object[2]
				{
					Delegate7.smethod_0((object)(dataGridViewCellFormattingEventArgs = e)),
					new Point(0, 0)
				};
				array = obj;
				bool[] obj2 = new bool[2] { true, false };
				array2 = obj2;
				NewLateBinding.LateCall(instance, null, memberName, obj, null, null, obj2, IgnoreReturn: true);
				num = ((int)num2 * -1680943017) ^ 0x1025C46A;
				continue;
			}
			case 7u:
				num = ((int)num2 * -242873172) ^ 0x227382FB;
				continue;
			case 6u:
				goto IL_05a1;
			case 3u:
				switch (gEnum)
				{
				case GClass3.GEnum0.EasyBox:
					break;
				case GClass3.GEnum0.FTE:
					goto IL_01bf;
				case GClass3.GEnum0.dLINK:
					goto IL_0321;
				case GClass3.GEnum0.ZAO:
					goto IL_03c8;
				default:
					goto IL_05f7;
				}
				goto case 23u;
			case 2u:
				dataGridViewCellFormattingEventArgs.Value = RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(array[0]));
				num = (int)((num2 * 193686826) ^ 0x7117063F);
				continue;
			case 0u:
				num = ((int)num2 * -99392575) ^ 0x72FC8F1A;
				continue;
			default:
				return;
			case 4u:
				goto IL_06c9;
			case 1u:
				return;
			case 11u:
				return;
			case 20u:
				{
					Delegate5.delegate5_22(e, bool_0: true);
					return;
				}
				IL_05f7:
				num = (int)(num2 * 1053235282) ^ -1597587696;
				continue;
				IL_04a6:
				Delegate8.delegate8_99(e, Delegate3.delegate3_39());
				Delegate30.delegate30_9(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_99(this)), Delegate17.delegate17_5(e))), Delegate17.delegate17_4(e)), Delegate36.delegate36_4());
				num = -359447251;
				continue;
				IL_0493:
				num = ((int)num2 * -1811221124) ^ -1148944465;
				continue;
				IL_03c8:
				Delegate8.delegate8_99(e, Delegate3.delegate3_59());
				num = -1987969100;
				continue;
				IL_0321:
				Delegate8.delegate8_99(e, Delegate3.delegate3_62());
				Delegate30.delegate30_9(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_99(this)), Delegate17.delegate17_5(e))), Delegate17.delegate17_4(e)), Delegate36.delegate36_27());
				num = -646784065;
				continue;
				IL_01bf:
				Delegate8.delegate8_99(e, Delegate3.delegate3_60());
				Delegate30.delegate30_9(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_99(this)), Delegate17.delegate17_5(e))), Delegate17.delegate17_4(e)), Delegate36.delegate36_25());
				num = -428584510;
				continue;
				IL_0102:
				Delegate8.delegate8_99(e, Delegate3.delegate3_38());
				num = -382482285;
				continue;
			}
			break;
			IL_05a1:
			int num7;
			if (!((GClass9)Delegate55.delegate55_3(bindingSource_0, Delegate17.delegate17_5(e))).bool_1)
			{
				num = -555059490;
				num7 = -555059490;
			}
			else
			{
				num = -1065128337;
				num7 = -1065128337;
			}
		}
		goto IL_0477;
		IL_06c9:
		gEnum2 = (GClass9.GEnum3)Delegate17.delegate17_1(Delegate7.delegate7_78(e));
		num = -543474088;
		goto IL_063a;
	}

	private void method_37(object sender, CancelEventArgs e)
	{
		Delegate5.delegate5_32(Delegate7.delegate7_117(this), Delegate56.delegate56_0(Delegate15.delegate15_27(Delegate7.delegate7_119(Delegate7.delegate7_118(this))), global::_003CModule_003E.smethod_21<string>(83508228u, 861260985u), bool_0: false) != 0);
		string string_ = Delegate15.delegate15_27(Delegate7.delegate7_119(Delegate7.delegate7_118(this)));
		if (Delegate56.delegate56_0(string_, global::_003CModule_003E.smethod_21<string>(83508228u, 3886896611u), bool_0: false) != 0)
		{
			while (true)
			{
				int num = -882025389;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x87A6D6EEu) % 6)
					{
					case 4u:
						Delegate5.delegate5_21(e, Delegate17.delegate17_3(Delegate7.delegate7_74(Delegate7.delegate7_97(this))) == 0);
						num = -1314155377;
						continue;
					case 3u:
					{
						int num3;
						int num4;
						if (Delegate56.delegate56_0(string_, global::_003CModule_003E.smethod_20<string>(1467392227u, 3764991525u), bool_0: false) != 0)
						{
							num3 = 1111479570;
							num4 = 1111479570;
						}
						else
						{
							num3 = 1168578357;
							num4 = 1168578357;
						}
						num = num3 ^ ((int)num2 * -1524571315);
						continue;
					}
					default:
						return;
					case 0u:
						break;
					case 1u:
						return;
					case 5u:
						return;
					case 2u:
						goto end_IL_012f;
					}
					break;
				}
				continue;
				end_IL_012f:
				break;
			}
		}
		Delegate5.delegate5_21(e, Delegate17.delegate17_3(Delegate7.delegate7_74(Delegate7.delegate7_99(this))) == 0);
	}

	private void method_38(object sender, EventArgs e)
	{
		if (Delegate17.delegate17_3(Delegate7.delegate7_74(Delegate7.delegate7_97(this))) == 0)
		{
			return;
		}
		string text = default(string);
		while (true)
		{
			int num = 1888413261;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x319CE2CEu) % 7)
				{
				case 6u:
					text = Delegate77.delegate77_0(text, 0, 7);
					num = (int)((num2 * 1717851749) ^ 0x2ED386EF);
					continue;
				case 5u:
					text += Delegate75.delegate75_0(Delegate74.delegate74_1(text));
					num = ((int)num2 * -442085214) ^ 0x206FE6FA;
					continue;
				case 3u:
					text = Delegate15.delegate15_2(Delegate7.delegate7_109(Delegate24.delegate24_2(Delegate7.delegate7_80(Delegate55.delegate55_4(Delegate7.delegate7_74(Delegate7.delegate7_97(this)), 0)), global::_003CModule_003E.smethod_19<string>(2304598686u, 2956420331u))));
					num = ((int)num2 * -1086354193) ^ 0x5991999C;
					continue;
				case 2u:
					DataGridView_2.SelectedRows[0].Cells[global::_003CModule_003E.smethod_19<string>(2304598686u, 2116179724u)].Value = text;
					num = ((int)num2 * -2002622938) ^ -207742750;
					continue;
				case 0u:
				{
					int num3;
					int num4;
					if (Delegate56.delegate56_0(text, "", bool_0: false) == 0)
					{
						num3 = 1542476867;
						num4 = 1542476867;
					}
					else
					{
						num3 = 2046997999;
						num4 = 2046997999;
					}
					num = num3 ^ (int)(num2 * 1346878475);
					continue;
				}
				default:
					return;
				case 4u:
					break;
				case 1u:
					return;
				}
				break;
			}
		}
	}

	private void method_39(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_4(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.ZAO));
		while (true)
		{
			int num = -795413814;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xF85906AFu) % 3)
				{
				case 1u:
					goto IL_0056;
				default:
					return;
				case 2u:
					break;
				case 0u:
					return;
				}
				break;
				IL_0056:
				Delegate22.delegate22_27(bindingSource_1);
				Delegate22.delegate22_22(Delegate7.delegate7_97(this));
				num = ((int)num2 * -1111786240) ^ 0xA58D010;
			}
		}
	}

	private void method_40(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		while (true)
		{
			int num = 2029542394;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x274FD7A7u) % 3)
				{
				case 1u:
					goto IL_0015;
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
				IL_0015:
				gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_7(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.AiroConru));
				Delegate22.delegate22_27(bindingSource_1);
				Delegate22.delegate22_22(Delegate7.delegate7_97(this));
				num = (int)(num2 * 1977824987) ^ -1533401040;
			}
		}
	}

	private void method_41(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		while (true)
		{
			int num = 1162859988;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x359AB392u) % 4)
				{
				case 3u:
					Delegate22.delegate22_27(bindingSource_1);
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					num = (int)(num2 * 1628861504) ^ -1560826797;
					continue;
				case 2u:
					gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_6(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.EasyBox));
					num = ((int)num2 * -665614443) ^ 0xA15F66B;
					continue;
				default:
					return;
				case 0u:
					break;
				case 1u:
					return;
				}
				break;
			}
		}
	}

	private void method_42(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_5(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.TrendNet));
		while (true)
		{
			int num = 340267035;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x741B41A7u) % 3)
				{
				case 1u:
					goto IL_0056;
				case 2u:
					break;
				default:
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					return;
				}
				break;
				IL_0056:
				Delegate22.delegate22_27(bindingSource_1);
				num = ((int)num2 * -178346096) ^ 0x49A98DD4;
			}
		}
	}

	private void method_43(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate15.delegate15_2(Delegate12.delegate12_3(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0)))), GClass3.GEnum0.dLINK));
		while (true)
		{
			int num = 35611474;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x28F77CA3u) % 4)
				{
				case 2u:
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					num = ((int)num2 * -1963393896) ^ 0x4EDF5443;
					continue;
				case 1u:
					Delegate22.delegate22_27(bindingSource_1);
					num = ((int)num2 * -1223043858) ^ -368648929;
					continue;
				default:
					return;
				case 3u:
					break;
				case 0u:
					return;
				}
				break;
			}
		}
	}

	private void method_44(object sender, EventArgs e)
	{
		string text = Delegate15.delegate15_10((GClass9)Delegate7.delegate7_102(bindingSource_0));
		string[] array = default(string[]);
		while (true)
		{
			int num = -1199883874;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x952DC29Fu) % 11)
				{
				case 10u:
					gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate57.delegate57_2(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0)), text), GClass3.GEnum0.FTE));
					Delegate22.delegate22_27(bindingSource_1);
					num = (int)((num2 * 114045897) ^ 0x4C8C4A51);
					continue;
				case 8u:
					array = Delegate123.delegate123_0(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0)));
					Delegate22.delegate22_26(bindingSource_1);
					num = ((int)num2 * -2033885080) ^ 0x50FC89E0;
					continue;
				case 7u:
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					num = ((int)num2 * -871722068) ^ -1963003668;
					continue;
				case 5u:
					Delegate22.delegate22_26(bindingSource_1);
					num = ((int)num2 * -1998078224) ^ -377511823;
					continue;
				case 4u:
				{
					int num3;
					int num4;
					if (Delegate122.delegate122_0(text, global::_003CModule_003E.smethod_19<string>(3421514778u, 2214644396u), CompareMethod.Binary))
					{
						num3 = -699935836;
						num4 = -699935836;
					}
					else
					{
						num3 = -2069328400;
						num4 = -2069328400;
					}
					num = num3 ^ (int)(num2 * 156878680);
					continue;
				}
				case 3u:
					gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(array[0], GClass3.GEnum0.FTE));
					num = (int)(num2 * 713987348) ^ -242051509;
					continue;
				case 2u:
					array = new string[3] { "", "", "" };
					num = -506631489;
					continue;
				case 1u:
					gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(array[1], GClass3.GEnum0.FTE));
					gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(array[2], GClass3.GEnum0.FTE));
					Delegate22.delegate22_27(bindingSource_1);
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					num = (int)((num2 * 826139931) ^ 0x48C5CFBF);
					continue;
				default:
					return;
				case 0u:
					break;
				case 6u:
					return;
				case 9u:
					return;
				}
				break;
			}
		}
	}

	private void method_45(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		while (true)
		{
			int num = -1192982430;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xAE8C2933u) % 5)
				{
				case 3u:
					gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_8(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.Asus));
					num = (int)((num2 * 238639461) ^ 0x4C56BD4E);
					continue;
				case 1u:
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					num = ((int)num2 * -313550220) ^ -734749518;
					continue;
				case 0u:
					Delegate22.delegate22_27(bindingSource_1);
					num = (int)(num2 * 741628850) ^ -151705684;
					continue;
				default:
					return;
				case 2u:
					break;
				case 4u:
					return;
				}
				break;
			}
		}
	}

	private void method_46(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_9(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.d28bit));
		Delegate22.delegate22_27(bindingSource_1);
		while (true)
		{
			int num = 1979323588;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x59D21E12u) % 3)
				{
				case 2u:
					goto IL_0067;
				default:
					return;
				case 0u:
					break;
				case 1u:
					return;
				}
				break;
				IL_0067:
				Delegate22.delegate22_22(Delegate7.delegate7_97(this));
				num = ((int)num2 * -1121658419) ^ -144694819;
			}
		}
	}

	private void method_47(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		while (true)
		{
			int num = 443517688;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x2E5AE411u) % 3)
				{
				case 1u:
					goto IL_0015;
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
				IL_0015:
				gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_10(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.d32bit));
				Delegate22.delegate22_27(bindingSource_1);
				Delegate22.delegate22_22(Delegate7.delegate7_97(this));
				num = (int)(num2 * 1804286797) ^ -1216510284;
			}
		}
	}

	private void method_48(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		while (true)
		{
			int num = -385777968;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xC079334Eu) % 4)
				{
				case 2u:
					gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_11(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.d36bit));
					num = ((int)num2 * -2100031768) ^ 0x1FDC2BA7;
					continue;
				case 1u:
					Delegate22.delegate22_27(bindingSource_1);
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					num = (int)((num2 * 1483490018) ^ 0x63ED6FD0);
					continue;
				default:
					return;
				case 3u:
					break;
				case 0u:
					return;
				}
				break;
			}
		}
	}

	private void method_49(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_12(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.d40bit));
		Delegate22.delegate22_27(bindingSource_1);
		Delegate22.delegate22_22(Delegate7.delegate7_97(this));
	}

	private void method_50(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		while (true)
		{
			int num = 429531793;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x34799D50u) % 3)
				{
				case 2u:
					goto IL_0012;
				case 0u:
					break;
				default:
					Delegate22.delegate22_27(bindingSource_1);
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					return;
				}
				break;
				IL_0012:
				gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_13(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.d44bit));
				num = (int)((num2 * 1265617742) ^ 0x2C8B4EDF);
			}
		}
	}

	private void method_51(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		while (true)
		{
			int num = 799217779;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xE973EFEu) % 4)
				{
				case 3u:
					Delegate22.delegate22_27(bindingSource_1);
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					num = ((int)num2 * -361826271) ^ -353959243;
					continue;
				case 1u:
					gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_14(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.d48bit));
					num = ((int)num2 * -861742631) ^ 0x3BD24DC0;
					continue;
				default:
					return;
				case 2u:
					break;
				case 0u:
					return;
				}
				break;
			}
		}
	}

	private void method_52(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		while (true)
		{
			int num = -283417306;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xB0EC3CC5u) % 3)
				{
				case 1u:
					goto IL_0012;
				case 2u:
					break;
				default:
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					return;
				}
				break;
				IL_0012:
				gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_1(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.d24rhbit));
				Delegate22.delegate22_27(bindingSource_1);
				num = (int)((num2 * 1541364768) ^ 0x6437D8C6);
			}
		}
	}

	private void method_53(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_2(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.d32rhbit));
		Delegate22.delegate22_27(bindingSource_1);
		while (true)
		{
			int num = -438726114;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x90D42373u) % 3)
				{
				case 2u:
					goto IL_0067;
				default:
					return;
				case 0u:
					break;
				case 1u:
					return;
				}
				break;
				IL_0067:
				Delegate22.delegate22_22(Delegate7.delegate7_97(this));
				num = (int)(num2 * 875375709) ^ -944450386;
			}
		}
	}

	private void method_54(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		while (true)
		{
			int num = -504569888;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xD2DC1FD9u) % 4)
				{
				case 2u:
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					num = ((int)num2 * -1723817083) ^ -100688989;
					continue;
				case 1u:
					gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_3(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.d48rhbit));
					Delegate22.delegate22_27(bindingSource_1);
					num = ((int)num2 * -1193874355) ^ 0x750D748E;
					continue;
				default:
					return;
				case 3u:
					break;
				case 0u:
					return;
				}
				break;
			}
		}
	}

	private void method_55(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_15(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.d24rnbit));
		Delegate22.delegate22_27(bindingSource_1);
		Delegate22.delegate22_22(Delegate7.delegate7_97(this));
	}

	private void method_56(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_16(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.d32rnbit));
		Delegate22.delegate22_27(bindingSource_1);
		while (true)
		{
			int num = -188793633;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xABAD0F39u) % 3)
				{
				case 1u:
					goto IL_0067;
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
				IL_0067:
				Delegate22.delegate22_22(Delegate7.delegate7_97(this));
				num = ((int)num2 * -1145695706) ^ -1884513055;
			}
		}
	}

	private void method_57(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		while (true)
		{
			int num = -1851567294;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xD581979Du) % 4)
				{
				case 3u:
					gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate81.delegate81_17(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.d48rnbit));
					num = ((int)num2 * -1115544965) ^ 0x3FA836E1;
					continue;
				case 1u:
					Delegate22.delegate22_27(bindingSource_1);
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					num = (int)(num2 * 1536550565) ^ -231450770;
					continue;
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	private void method_58(object sender, EventArgs e)
	{
		Delegate22.delegate22_13(Delegate7.delegate7_120(this));
		Delegate22.delegate22_13(Delegate7.delegate7_121(this));
		while (true)
		{
			int num = 631801872;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x4A07D18Fu) % 11)
				{
				case 10u:
					Delegate22.delegate22_13(Delegate7.delegate7_125(this));
					num = (int)((num2 * 63895860) ^ 0x44D1687C);
					continue;
				case 9u:
					Delegate22.delegate22_13(Delegate7.delegate7_126(this));
					num = (int)(num2 * 1159171247) ^ -2070320919;
					continue;
				case 8u:
					Delegate22.delegate22_13(Delegate7.delegate7_131(this));
					Delegate22.delegate22_13(Delegate7.delegate7_132(this));
					num = (int)((num2 * 1676563790) ^ 0x6C37AE01);
					continue;
				case 7u:
					Delegate22.delegate22_13(Delegate7.delegate7_129(this));
					Delegate22.delegate22_13(Delegate7.delegate7_130(this));
					num = ((int)num2 * -635987365) ^ 0x674BA817;
					continue;
				case 6u:
					Delegate22.delegate22_13(Delegate7.delegate7_123(this));
					num = ((int)num2 * -1207146861) ^ -56078890;
					continue;
				case 5u:
					Delegate22.delegate22_13(Delegate7.delegate7_128(this));
					num = ((int)num2 * -1080213509) ^ 0x5D8D8D15;
					continue;
				case 4u:
					Delegate22.delegate22_13(Delegate7.delegate7_122(this));
					num = ((int)num2 * -1826295963) ^ -1568831276;
					continue;
				case 3u:
					Delegate22.delegate22_13(Delegate7.delegate7_127(this));
					num = (int)(num2 * 1965275676) ^ -1513028127;
					continue;
				case 1u:
					Delegate22.delegate22_13(Delegate7.delegate7_124(this));
					num = ((int)num2 * -1437825014) ^ 0x750BC4A;
					continue;
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	private void method_59(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		while (true)
		{
			int num = 382051760;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x13724EF0u) % 3)
				{
				case 1u:
					goto IL_0015;
				case 0u:
					break;
				default:
					Delegate22.delegate22_27(bindingSource_1);
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					return;
				}
				break;
				IL_0015:
				gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate57.delegate57_3(Delegate15.delegate15_9((GClass9)Delegate7.delegate7_102(bindingSource_0)), Delegate15.delegate15_11((GClass9)Delegate7.delegate7_102(bindingSource_0))), GClass3.GEnum0.LiveBox));
				num = (int)(num2 * 1465127022) ^ -1994702259;
			}
		}
	}

	private void method_60(object sender, EventArgs e)
	{
		Delegate22.delegate22_26(bindingSource_1);
		while (true)
		{
			int num = -517087396;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xD89874A5u) % 4)
				{
				case 3u:
					Delegate22.delegate22_27(bindingSource_1);
					num = (int)((num2 * 814272110) ^ 0x4C3FB2D9);
					continue;
				case 1u:
					gclass9_0.gclass15_0.Add((GClass12)Delegate121.delegate121_0(Delegate36.delegate36_5(), GClass3.GEnum0.PinNull));
					num = (int)(num2 * 242984107) ^ -1673714639;
					continue;
				case 0u:
					break;
				default:
					Delegate22.delegate22_22(Delegate7.delegate7_97(this));
					return;
				}
				break;
			}
		}
	}

	private void method_61(object sender, EventArgs e)
	{
		Delegate22.delegate22_13(Delegate7.delegate7_133(this));
		Delegate22.delegate22_13(Delegate7.delegate7_134(this));
		while (true)
		{
			int num = -1477452952;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xF463CB79u) % 6)
				{
				case 5u:
					Delegate22.delegate22_13(Delegate7.delegate7_138(this));
					Delegate22.delegate22_13(Delegate7.delegate7_139(this));
					num = (int)(num2 * 1165584544) ^ -1423084726;
					continue;
				case 4u:
					Delegate22.delegate22_13(Delegate7.delegate7_137(this));
					num = (int)(num2 * 595277149) ^ -1226532380;
					continue;
				case 3u:
					Delegate22.delegate22_13(Delegate7.delegate7_140(this));
					num = (int)(num2 * 1714678757) ^ -757137000;
					continue;
				case 1u:
					Delegate22.delegate22_13(Delegate7.delegate7_135(this));
					Delegate22.delegate22_13(Delegate7.delegate7_136(this));
					num = ((int)num2 * -1518963484) ^ -1302342097;
					continue;
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	private void method_62(string string_0, bool bool_4)
	{
		string text = "";
		text = Delegate57.delegate57_1(global::_003CModule_003E.smethod_18<string>(3367023129u, 1537371464u), Delegate15.delegate15_12(gclass9_0));
		text = Delegate71.delegate71_0(text, global::_003CModule_003E.smethod_21<string>(3306473616u, 3402286444u), Delegate15.delegate15_13(gclass9_0));
		text = Delegate71.delegate71_0(text, global::_003CModule_003E.smethod_19<string>(4020339654u, 762859776u), Delegate15.delegate15_14(gclass9_0));
		text = Delegate71.delegate71_0(text, global::_003CModule_003E.smethod_22<string>(35260242u, 4159330956u), Delegate15.delegate15_15(gclass9_0));
		string string_ = default(string);
		while (true)
		{
			int num = -1454654771;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xE9CD579Bu) % 12)
				{
				case 11u:
				{
					int num5;
					if (Delegate125.delegate125_0(gclass9_0) == GClass9.GEnum3.Unknow)
					{
						num = -1148515471;
						num5 = -1148515471;
					}
					else
					{
						num = -1359914404;
						num5 = -1359914404;
					}
					continue;
				}
				case 10u:
					Delegate126.delegate126_0(gclass9_0, GClass9.GEnum3.Nok);
					num = ((int)num2 * -1965500603) ^ 0x609ECB4E;
					continue;
				case 6u:
				{
					Delegate8.delegate8_116(gclass9_0, gclass12_0);
					Delegate101.delegate101_0(this, Class13.string_4, Delegate28.delegate28_9(), bool_0: false);
					int num6;
					int num7;
					if (bool_4)
					{
						num6 = -2085725763;
						num7 = -2085725763;
					}
					else
					{
						num6 = -1185285814;
						num7 = -1185285814;
					}
					num = num6 ^ (int)(num2 * 2121002323);
					continue;
				}
				case 5u:
					string_ = Delegate81.delegate81_18(text);
					Delegate101.delegate101_0(this, string_, Delegate28.delegate28_1(), bool_0: true);
					num = (int)((num2 * 37789362) ^ 0x759DCF2);
					continue;
				case 4u:
					text = Delegate71.delegate71_0(text, global::_003CModule_003E.smethod_20<string>(3865160782u, 974681136u), Delegate15.delegate15_17(gclass9_0));
					num = ((int)num2 * -14066763) ^ 0x402F76E2;
					continue;
				case 3u:
				{
					bool_3 = false;
					int num3;
					int num4;
					if (!Delegate124.delegate124_0(string_, ref gclass12_0))
					{
						num3 = -1545552420;
						num4 = -1545552420;
					}
					else
					{
						num3 = -1834091659;
						num4 = -1834091659;
					}
					num = num3 ^ ((int)num2 * -599805452);
					continue;
				}
				case 2u:
					text = Delegate71.delegate71_0(text, global::_003CModule_003E.smethod_22<string>(1280518448u, 3907432708u), Delegate15.delegate15_16(gclass9_0));
					num = ((int)num2 * -1515280459) ^ -876523591;
					continue;
				case 1u:
					text = Delegate71.delegate71_0(text, global::_003CModule_003E.smethod_20<string>(4169737185u, 2717654455u), string_0);
					Delegate101.delegate101_0(this, Delegate57.delegate57_1(global::_003CModule_003E.smethod_19<string>(565866865u, 821570148u), text), Delegate28.delegate28_1(), bool_0: true);
					num = ((int)num2 * -807474038) ^ -845083464;
					continue;
				case 0u:
					Delegate109.delegate109_0(Delegate7.delegate7_94(this), ref gclass9_0, gclass12_0);
					num = (int)(num2 * 1809150021) ^ -814918073;
					continue;
				default:
					return;
				case 9u:
					break;
				case 7u:
					return;
				case 8u:
					return;
				}
				break;
			}
		}
	}

	private void method_63(string string_0)
	{
		object obj = Delegate3.delegate3_63();
		((UpdateForm)obj).string_0 = string_0;
		Delegate111.smethod_0(obj);
	}

	private void method_64(object sender, EventArgs e)
	{
		if (Delegate60.delegate60_0(Delegate36.delegate36_28(), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
		{
			return;
		}
		while (true)
		{
			int num = -343247569;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xE504E006u) % 11)
				{
				case 10u:
					switch (Delegate17.delegate17_12(Delegate7.delegate7_90(this)))
					{
					case 0:
						goto IL_0065;
					case 1:
						goto IL_008d;
					case 2:
						goto IL_00b5;
					case 3:
						goto IL_00da;
					}
					num = (int)((num2 * 223228999) ^ 0x4908D463);
					continue;
				case 6u:
					goto IL_0065;
				case 5u:
					goto IL_008d;
				case 7u:
					goto IL_00b5;
				case 9u:
					goto IL_00da;
				case 8u:
					num = ((int)num2 * -97956481) ^ -1536449439;
					continue;
				case 4u:
					num = (int)((num2 * 1950373057) ^ 0x710C83AF);
					continue;
				case 3u:
					Delegate51.smethod_2();
					num = -1674925596;
					continue;
				case 2u:
					num = (int)(num2 * 1276534139) ^ -572553136;
					continue;
				default:
					return;
				case 0u:
					break;
				case 1u:
					return;
					IL_00da:
					Delegate30.delegate30_12(Delegate3.smethod_3(), global::_003CModule_003E.smethod_22<string>(2958096482u, 3415576567u));
					num = -954398834;
					continue;
					IL_00b5:
					Delegate30.delegate30_12(Delegate3.smethod_3(), global::_003CModule_003E.smethod_21<string>(2043921210u, 2469126298u));
					num = -954398834;
					continue;
					IL_008d:
					Delegate30.delegate30_12(Delegate3.smethod_3(), global::_003CModule_003E.smethod_20<string>(597854934u, 1820336844u));
					num = -1009989785;
					continue;
					IL_0065:
					Delegate30.delegate30_12(Delegate3.smethod_3(), global::_003CModule_003E.smethod_18<string>(2850461161u, 3041055125u));
					num = -656465513;
					continue;
				}
				break;
			}
		}
	}

	private void method_65(object sender, EventArgs e)
	{
		if (!((Delegate56.delegate56_0(Delegate15.delegate15_4(Delegate7.delegate7_141(this)), "", bool_0: false) != 0) & Delegate21.delegate21_5(Delegate15.delegate15_4(Delegate7.delegate7_141(this)))))
		{
			return;
		}
		while (true)
		{
			int num = -834825346;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x9EC095E6u) % 3)
				{
				case 2u:
					goto IL_004c;
				default:
					return;
				case 0u:
					break;
				case 1u:
					return;
				}
				break;
				IL_004c:
				Delegate32.delegate32_7(Delegate3.delegate3_7(), Delegate74.delegate74_1(Delegate15.delegate15_4(Delegate7.delegate7_141(this))));
				Delegate22.delegate22_0(Delegate3.delegate3_7());
				num = ((int)num2 * -1698603873) ^ 0x3BB74D32;
			}
		}
	}

	private void method_66(object sender, KeyPressEventArgs e)
	{
		if (Delegate128.delegate128_0(Delegate127.delegate127_0(e)) | Delegate128.delegate128_1(Delegate127.delegate127_0(e)))
		{
			while (true)
			{
				int num = -383104448;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xD3017B01u) % 4)
					{
					case 1u:
						Delegate5.delegate5_34(e, bool_0: false);
						num = ((int)num2 * -2121876069) ^ 0x410652C2;
						continue;
					case 3u:
						break;
					case 0u:
						return;
					default:
						goto end_IL_0069;
					}
					break;
				}
				continue;
				end_IL_0069:
				break;
			}
		}
		Delegate5.delegate5_34(e, bool_0: true);
	}

	private void method_67(object sender, EventArgs e)
	{
		Delegate30.delegate30_16(Delegate7.delegate7_141(this), Delegate73.delegate73_0(Delegate17.delegate17_11(Delegate3.delegate3_7())));
	}

	[DebuggerNonUserCode]
	void Form.Dispose(bool disposing)
	{
		try
		{
			if (!disposing)
			{
				return;
			}
			while (true)
			{
				int num = -121470206;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xAEF70E6Fu) % 4)
					{
					case 3u:
						Delegate22.delegate22_4(icontainer_0);
						num = ((int)num2 * -661088281) ^ -381348222;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (icontainer_0 == null)
						{
							num3 = 1431798581;
							num4 = 1431798581;
						}
						else
						{
							num3 = 1630088350;
							num4 = 1630088350;
						}
						num = num3 ^ (int)(num2 * 950984722);
						continue;
					}
					default:
						return;
					case 2u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
		finally
		{
			Delegate5.delegate5_3(this, disposing);
		}
	}

	[DebuggerStepThrough]
	private void method_68()
	{
		icontainer_0 = (IContainer)Delegate3.delegate3_19();
		ComponentResourceManager componentResourceManager = default(ComponentResourceManager);
		DataGridViewCellStyle dataGridViewCellStyle7 = default(DataGridViewCellStyle);
		DataGridViewCellStyle dataGridViewCellStyle = default(DataGridViewCellStyle);
		DataGridViewCellStyle dataGridViewCellStyle10 = default(DataGridViewCellStyle);
		DataGridViewCellStyle dataGridViewCellStyle4 = default(DataGridViewCellStyle);
		DataGridViewCellStyle dataGridViewCellStyle9 = default(DataGridViewCellStyle);
		DataGridViewCellStyle dataGridViewCellStyle8 = default(DataGridViewCellStyle);
		DataGridViewCellStyle dataGridViewCellStyle5 = default(DataGridViewCellStyle);
		DataGridViewCellStyle dataGridViewCellStyle3 = default(DataGridViewCellStyle);
		DataGridViewCellStyle dataGridViewCellStyle2 = default(DataGridViewCellStyle);
		DataGridViewCellStyle dataGridViewCellStyle6 = default(DataGridViewCellStyle);
		while (true)
		{
			int num = -1096751813;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xEA0D9D22u) % 273)
				{
				case 272u:
					SplitContainer_0.Panel1.ResumeLayout(performLayout: false);
					num = ((int)num2 * -182998685) ^ -1464627841;
					continue;
				case 271u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_169(this), global::_003CModule_003E.smethod_18<string>(3411801611u, 18057614u));
					Delegate30.delegate30_1(Delegate7.delegate7_130(this), global::_003CModule_003E.smethod_20<string>(1328202700u, 1324058458u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_130(this), global::_003CModule_003E.smethod_18<string>(2273489541u, 697791113u));
					Delegate30.delegate30_1(Delegate7.delegate7_131(this), global::_003CModule_003E.smethod_21<string>(2897841688u, 1706450731u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_131(this), global::_003CModule_003E.smethod_20<string>(105487902u, 3744461092u));
					Delegate30.delegate30_1(Delegate7.delegate7_132(this), global::_003CModule_003E.smethod_19<string>(2407791850u, 350877390u));
					num = ((int)num2 * -1986077338) ^ -1868032909;
					continue;
				case 270u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_95(this), global::_003CModule_003E.smethod_20<string>(3563113443u, 404375536u));
					num = (int)((num2 * 93205428) ^ 0x2FB416C4);
					continue;
				case 269u:
					Delegate5.delegate5_15(Delegate7.delegate7_153(this), bool_0: true);
					Delegate30.delegate30_5(Delegate7.delegate7_154(this), global::_003CModule_003E.smethod_21<string>(2884076222u, 175626170u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_154(this), global::_003CModule_003E.smethod_18<string>(4028862362u, 2547910821u));
					Delegate30.delegate30_6(Delegate7.delegate7_154(this), global::_003CModule_003E.smethod_18<string>(4028862362u, 600224014u));
					num = (int)(num2 * 355803740) ^ -546210545;
					continue;
				case 268u:
					ToolStripButton_5.Image = GClass0.Bitmap_0;
					componentResourceManager.ApplyResources(ToolStripButton_5, global::_003CModule_003E.smethod_18<string>(2013645440u, 2746111464u));
					num = ((int)num2 * -117610161) ^ 0x5E803423;
					continue;
				case 267u:
					Delegate30.delegate30_1(Delegate7.delegate7_136(this), global::_003CModule_003E.smethod_22<string>(2140397414u, 289839906u));
					num = (int)((num2 * 817904218) ^ 0xF3B160D);
					continue;
				case 266u:
					ToolStripButton_4.Name = global::_003CModule_003E.smethod_20<string>(136418908u, 1410801891u);
					componentResourceManager.ApplyResources(ToolStripButton_1, global::_003CModule_003E.smethod_20<string>(3080213725u, 1140757244u));
					ToolStripButton_1.Image = GClass0.Bitmap_41;
					num = ((int)num2 * -1939538531) ^ -1280541682;
					continue;
				case 265u:
					base.Controls.Add(SplitContainer_0);
					num = (int)(num2 * 860341031) ^ -281265767;
					continue;
				case 264u:
					Delegate8.delegate8_175(this, Delegate3.delegate3_69());
					Delegate8.delegate8_114(this, Delegate3.delegate3_70());
					num = (int)(num2 * 926124176) ^ -1447269374;
					continue;
				case 263u:
					ToolStripButton_4.Margin = new Padding(2);
					num = (int)((num2 * 1536860639) ^ 0x513B1B40);
					continue;
				case 262u:
					componentResourceManager.ApplyResources(ToolStripMenuItem_0, global::_003CModule_003E.smethod_22<string>(1858420730u, 961309822u));
					ToolStripMenuItem_1.Name = global::_003CModule_003E.smethod_22<string>(1578824391u, 4065497011u);
					componentResourceManager.ApplyResources(ToolStripMenuItem_1, global::_003CModule_003E.smethod_18<string>(3668519478u, 2854747178u));
					ToolStripSeparator_1.Alignment = ToolStripItemAlignment.Right;
					num = (int)(num2 * 1377609683) ^ -339673764;
					continue;
				case 261u:
					Delegate29.delegate29_7(dataGridViewCellStyle7, Delegate28.delegate28_13());
					num = (int)(num2 * 201145200) ^ -1751831346;
					continue;
				case 260u:
					Delegate5.delegate5_40(Delegate7.delegate7_95(this), bool_0: false);
					Delegate8.delegate8_67(dataGridViewCellStyle, Delegate43.delegate43_0(global::_003CModule_003E.smethod_21<string>(3673732215u, 2351909859u), 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0));
					num = ((int)num2 * -897614277) ^ -1797575982;
					continue;
				case 259u:
					PictureBox_0.Image = GClass0.Bitmap_7;
					PictureBox_0.Name = global::_003CModule_003E.smethod_18<string>(3408675377u, 4156762671u);
					PictureBox_0.TabStop = false;
					num = (int)((num2 * 1516363746) ^ 0x479C0E0);
					continue;
				case 258u:
					Delegate129.delegate129_0(dataGridViewCellStyle7, DataGridViewContentAlignment.MiddleLeft);
					num = (int)(num2 * 1416142174) ^ -2117455188;
					continue;
				case 257u:
					ToolStripSplitButton_0.Image = GClass0.Bitmap_57;
					ToolStripSplitButton_0.Margin = new Padding(2);
					ToolStripSplitButton_0.Name = global::_003CModule_003E.smethod_21<string>(2723376544u, 3152168908u);
					num = ((int)num2 * -712163720) ^ -311232562;
					continue;
				case 256u:
					Delegate30.delegate30_1(Delegate7.delegate7_166(this), global::_003CModule_003E.smethod_19<string>(968472467u, 1802843344u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_166(this), global::_003CModule_003E.smethod_20<string>(2936290541u, 1053705607u));
					Delegate30.delegate30_1(Delegate7.delegate7_167(this), global::_003CModule_003E.smethod_18<string>(2895239643u, 550919018u));
					num = ((int)num2 * -551122812) ^ 0x4B667A71;
					continue;
				case 255u:
					Delegate8.delegate8_176(this, Delegate7.delegate7_143(icontainer_0));
					num = ((int)num2 * -870208466) ^ 0x14511330;
					continue;
				case 254u:
					dataGridViewCellStyle10 = (DataGridViewCellStyle)Delegate3.delegate3_20();
					dataGridViewCellStyle4 = (DataGridViewCellStyle)Delegate3.delegate3_20();
					dataGridViewCellStyle9 = (DataGridViewCellStyle)Delegate3.delegate3_20();
					dataGridViewCellStyle7 = (DataGridViewCellStyle)Delegate3.delegate3_20();
					num = (int)((num2 * 1201255532) ^ 0x73D11094);
					continue;
				case 253u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_139(this), global::_003CModule_003E.smethod_19<string>(1118178686u, 2888842026u));
					num = ((int)num2 * -1361405972) ^ -6627085;
					continue;
				case 252u:
					Delegate8.delegate8_120(this, Delegate3.delegate3_22());
					Delegate8.delegate8_121(this, Delegate3.delegate3_22());
					num = ((int)num2 * -891012645) ^ 0x2445461F;
					continue;
				case 251u:
					Delegate30.delegate30_1(Delegate7.delegate7_164(this), global::_003CModule_003E.smethod_20<string>(3368060093u, 1997606664u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_164(this), global::_003CModule_003E.smethod_20<string>(3368060093u, 589660634u));
					num = (int)((num2 * 1896987324) ^ 0x79EF8435);
					continue;
				case 250u:
					SplitContainer_2.Panel2.ResumeLayout(performLayout: false);
					((ISupportInitialize)SplitContainer_2).EndInit();
					num = ((int)num2 * -896479867) ^ 0x65C74A5F;
					continue;
				case 249u:
					Delegate130.delegate130_0(dataGridViewCellStyle8, DataGridViewTriState.True);
					num = (int)(num2 * 1792834816) ^ -177748736;
					continue;
				case 248u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_146(Delegate7.delegate7_148(this))), Delegate7.delegate7_95(this));
					num = ((int)num2 * -1685023856) ^ -1343399014;
					continue;
				case 247u:
					Delegate30.delegate30_1(Delegate7.delegate7_124(this), global::_003CModule_003E.smethod_22<string>(540371297u, 1102851785u));
					num = ((int)num2 * -1457009525) ^ 0x5C293880;
					continue;
				case 246u:
					Delegate8.delegate8_170(this, Delegate3.delegate3_24());
					Delegate8.delegate8_171(this, Delegate3.delegate3_68());
					Delegate8.delegate8_172(this, Delegate3.delegate3_66());
					Delegate8.delegate8_173(this, Delegate3.delegate3_24());
					num = ((int)num2 * -181703803) ^ -292280264;
					continue;
				case 245u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_153(this), global::_003CModule_003E.smethod_20<string>(583653963u, 1305981509u));
					Delegate30.delegate30_6(Delegate7.delegate7_153(this), global::_003CModule_003E.smethod_22<string>(2828843287u, 75161077u));
					num = (int)(num2 * 1839336851) ^ -1067285401;
					continue;
				case 244u:
					Delegate8.delegate8_135(this, Delegate3.delegate3_66());
					Delegate8.delegate8_136(this, Delegate3.delegate3_66());
					Delegate8.delegate8_137(this, Delegate3.delegate3_66());
					num = (int)((num2 * 2036131100) ^ 0x6CA66DCB);
					continue;
				case 242u:
					ToolStrip_0.ResumeLayout(performLayout: false);
					num = ((int)num2 * -2087916580) ^ 0x356BDED1;
					continue;
				case 241u:
					ToolStripButton_5.Name = global::_003CModule_003E.smethod_20<string>(2648444173u, 4045246384u);
					ToolStripDropDownButton_0.Alignment = ToolStripItemAlignment.Right;
					num = (int)(num2 * 2128976372) ^ -568829018;
					continue;
				case 240u:
					Delegate8.delegate8_129(this, Delegate3.delegate3_66());
					num = (int)((num2 * 1741677194) ^ 0x39C492B5);
					continue;
				case 239u:
					Delegate22.delegate22_6(Delegate7.delegate7_147(this));
					Delegate22.delegate22_5(Delegate7.delegate7_145(Delegate7.delegate7_147(this)));
					Delegate22.delegate22_5(Delegate7.delegate7_146(Delegate7.delegate7_147(this)));
					num = ((int)num2 * -2109354896) ^ -1524530740;
					continue;
				case 238u:
					Delegate8.delegate8_177(this, Delegate7.delegate7_17(icontainer_0));
					num = (int)(num2 * 799994459) ^ -2002350450;
					continue;
				case 237u:
					Delegate30.delegate30_1(Delegate7.delegate7_122(this), global::_003CModule_003E.smethod_22<string>(2904014859u, 3751796726u));
					num = (int)((num2 * 1752861218) ^ 0x46BCE224);
					continue;
				case 236u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_128(this), global::_003CModule_003E.smethod_19<string>(2281076484u, 1504239015u));
					Delegate30.delegate30_1(Delegate7.delegate7_129(this), global::_003CModule_003E.smethod_20<string>(3773632296u, 3150767407u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_129(this), global::_003CModule_003E.smethod_22<string>(4146892720u, 2806297458u));
					num = ((int)num2 * -708165530) ^ -99281250;
					continue;
				case 235u:
					Delegate8.delegate8_184(this, Delegate3.delegate3_27());
					num = ((int)num2 * -1159544880) ^ 0x24C7DB7A;
					continue;
				case 234u:
					Delegate5.delegate5_35(Delegate7.delegate7_97(this), bool_0: false);
					num = (int)(num2 * 839544628) ^ -1691079013;
					continue;
				case 233u:
					Delegate8.delegate8_68(Delegate7.delegate7_171(this), dataGridViewCellStyle);
					num = ((int)num2 * -1637193668) ^ 0x79660C71;
					continue;
				case 232u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_147(this), global::_003CModule_003E.smethod_21<string>(2115068428u, 1636392754u));
					num = ((int)num2 * -1908979033) ^ 0x31887B26;
					continue;
				case 231u:
					Delegate22.delegate22_6(Delegate7.delegate7_148(this));
					Delegate22.delegate22_5(Delegate7.delegate7_145(Delegate7.delegate7_148(this)));
					Delegate22.delegate22_5(Delegate7.delegate7_146(Delegate7.delegate7_148(this)));
					num = ((int)num2 * -1449618166) ^ 0x5B632C9D;
					continue;
				case 230u:
					((ISupportInitialize)DataGridView_0).EndInit();
					ContextMenuStrip_0.ResumeLayout(performLayout: false);
					((ISupportInitialize)DataGridView_1).EndInit();
					num = (int)(num2 * 20434250) ^ -1726345666;
					continue;
				case 229u:
					Delegate8.delegate8_195(this, Delegate3.delegate3_24());
					num = (int)((num2 * 525722510) ^ 0x7D43CC15);
					continue;
				case 228u:
					Delegate30.delegate30_1(Delegate7.delegate7_165(this), global::_003CModule_003E.smethod_21<string>(4008897037u, 34182877u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_165(this), global::_003CModule_003E.smethod_19<string>(830527349u, 471305788u));
					Delegate30.delegate30_1(Delegate7.delegate7_121(this), global::_003CModule_003E.smethod_21<string>(2652229326u, 3969856320u));
					num = (int)(num2 * 811065999) ^ -121300970;
					continue;
				case 227u:
					Button_1.UseVisualStyleBackColor = false;
					num = (int)(num2 * 525327053) ^ -847352346;
					continue;
				case 226u:
					StatusStrip_0.ResumeLayout(performLayout: false);
					num = ((int)num2 * -1656616370) ^ 0x5C28549F;
					continue;
				case 225u:
					Delegate30.delegate30_6(Delegate7.delegate7_174(this), global::_003CModule_003E.smethod_22<string>(669624492u, 4187990247u));
					Delegate44.delegate44_0(Delegate7.delegate7_175(this), DataGridViewAutoSizeColumnMode.Fill);
					Delegate30.delegate30_5(Delegate7.delegate7_175(this), global::_003CModule_003E.smethod_18<string>(2636958659u, 2373884789u));
					num = ((int)num2 * -1970297261) ^ 0x1DAABFB4;
					continue;
				case 224u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_175(this), global::_003CModule_003E.smethod_18<string>(1135177471u, 2650795078u));
					num = ((int)num2 * -1928221739) ^ 0x48C6D83B;
					continue;
				case 223u:
					Delegate30.delegate30_6(Delegate7.delegate7_156(this), global::_003CModule_003E.smethod_18<string>(2579675241u, 2931642140u));
					Delegate5.delegate5_15(Delegate7.delegate7_156(this), bool_0: true);
					num = (int)(num2 * 1474177559) ^ -1363810831;
					continue;
				case 222u:
					Delegate5.delegate5_15(Delegate7.delegate7_159(this), bool_0: true);
					Delegate30.delegate30_5(Delegate7.delegate7_160(this), global::_003CModule_003E.smethod_19<string>(104987107u, 3779387222u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_160(this), global::_003CModule_003E.smethod_19<string>(81996254u, 2729129642u));
					num = (int)(num2 * 2039792972) ^ -778549725;
					continue;
				case 221u:
					Delegate8.delegate8_130(this, Delegate3.delegate3_26());
					num = (int)((num2 * 106551224) ^ 0x4F2D22E);
					continue;
				case 220u:
					Delegate8.delegate8_152(this, Delegate3.delegate3_66());
					Delegate8.delegate8_153(this, Delegate3.delegate3_66());
					num = (int)((num2 * 920746569) ^ 0x1C1C491E);
					continue;
				case 219u:
					StatusStrip_0.Items.AddRange(new ToolStripItem[1] { ToolStripStatusLabel_0 });
					num = (int)((num2 * 1495370772) ^ 0x644139F2);
					continue;
				case 218u:
					Delegate30.delegate30_1(Delegate7.delegate7_134(this), global::_003CModule_003E.smethod_22<string>(3258782770u, 3873790053u));
					num = ((int)num2 * -1590911571) ^ -1152195860;
					continue;
				case 217u:
					RichTextBox_0.ForeColor = Color.Lime;
					RichTextBox_0.Name = global::_003CModule_003E.smethod_21<string>(2484646915u, 4181914682u);
					RichTextBox_0.ReadOnly = true;
					num = (int)(num2 * 348791811) ^ -494695433;
					continue;
				case 216u:
					ToolStripSplitButton_1.DropDownItems.AddRange(new ToolStripItem[1] { ToolStripMenuItem_29 });
					num = (int)((num2 * 1717642378) ^ 0x1686E3AC);
					continue;
				case 215u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_123(this), global::_003CModule_003E.smethod_20<string>(1420995718u, 2396708839u));
					num = ((int)num2 * -95564716) ^ 0x6C498078;
					continue;
				case 214u:
					Delegate8.delegate8_77(Delegate7.delegate7_140(this), Delegate3.delegate3_84());
					num = ((int)num2 * -1314080586) ^ -1583845557;
					continue;
				case 213u:
					ToolStripMenuItem_0.Name = global::_003CModule_003E.smethod_21<string>(4204010380u, 1502528303u);
					num = (int)((num2 * 629246732) ^ 0x18EFA3A5);
					continue;
				case 212u:
					Delegate8.delegate8_158(this, Delegate3.delegate3_26());
					Delegate8.delegate8_159(this, Delegate3.delegate3_66());
					Delegate8.delegate8_160(this, Delegate3.delegate3_21());
					Delegate8.delegate8_161(this, Delegate3.delegate3_23());
					Delegate8.delegate8_162(this, Delegate3.delegate3_23());
					Delegate8.delegate8_163(this, Delegate3.delegate3_21());
					Delegate8.delegate8_164(this, Delegate3.delegate3_23());
					num = (int)((num2 * 2061617179) ^ 0x6FDBEC9);
					continue;
				case 211u:
					Delegate8.delegate8_145(this, Delegate3.delegate3_66());
					num = (int)(num2 * 1030402928) ^ -1883500306;
					continue;
				case 210u:
					Delegate8.delegate8_185(this, Delegate3.delegate3_68());
					num = (int)((num2 * 867706751) ^ 0x2AB74406);
					continue;
				case 209u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_159(this), global::_003CModule_003E.smethod_22<string>(2318971542u, 775196250u));
					Delegate30.delegate30_6(Delegate7.delegate7_159(this), global::_003CModule_003E.smethod_20<string>(1133149350u, 2538215750u));
					num = (int)(num2 * 1632899388) ^ -1398013311;
					continue;
				case 208u:
					Delegate30.delegate30_5(Delegate7.delegate7_159(this), global::_003CModule_003E.smethod_18<string>(4138739847u, 216725834u));
					num = (int)(num2 * 1957033772) ^ -1523238353;
					continue;
				case 207u:
					Delegate8.delegate8_174(this, Delegate3.delegate3_69());
					num = (int)(num2 * 724041268) ^ -314523939;
					continue;
				case 206u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_155(this), global::_003CModule_003E.smethod_20<string>(3075480068u, 3090326718u));
					Delegate30.delegate30_6(Delegate7.delegate7_155(this), global::_003CModule_003E.smethod_18<string>(1906894189u, 957274293u));
					Delegate5.delegate5_15(Delegate7.delegate7_155(this), bool_0: true);
					num = ((int)num2 * -1075876707) ^ -176124263;
					continue;
				case 205u:
					((ISupportInitialize)SplitContainer_1).EndInit();
					num = ((int)num2 * -1403255859) ^ 0x671D0058;
					continue;
				case 204u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_133(this), global::_003CModule_003E.smethod_20<string>(1775437755u, 1779319977u));
					num = (int)((num2 * 1871418466) ^ 0x241A2C1E);
					continue;
				case 202u:
					Delegate5.delegate5_38(Delegate7.delegate7_95(this), bool_0: false);
					num = (int)(num2 * 971583122) ^ -2141364621;
					continue;
				case 201u:
					Delegate8.delegate8_154(this, Delegate3.delegate3_66());
					Delegate8.delegate8_155(this, Delegate3.delegate3_26());
					num = (int)(num2 * 1249342751) ^ -388307645;
					continue;
				case 200u:
					Delegate8.delegate8_156(this, Delegate3.delegate3_66());
					Delegate8.delegate8_157(this, Delegate3.delegate3_66());
					num = (int)((num2 * 382190330) ^ 0x59E4293F);
					continue;
				case 199u:
					ToolStripButton_1.Name = global::_003CModule_003E.smethod_19<string>(450381251u, 1361410947u);
					componentResourceManager.ApplyResources(ToolStripButton_2, global::_003CModule_003E.smethod_22<string>(2647888814u, 3747995922u));
					num = (int)(num2 * 1048883531) ^ -763321664;
					continue;
				case 198u:
					Delegate31.smethod_0(Delegate7.delegate7_163(Delegate7.delegate7_162(this)), new ToolStripItem[12]
					{
						(ToolStripItem)Delegate7.delegate7_134(this),
						(ToolStripItem)Delegate7.delegate7_135(this),
						(ToolStripItem)Delegate7.delegate7_136(this),
						(ToolStripItem)Delegate7.delegate7_137(this),
						(ToolStripItem)Delegate7.delegate7_138(this),
						(ToolStripItem)Delegate7.delegate7_133(this),
						(ToolStripItem)Delegate7.delegate7_164(this),
						(ToolStripItem)Delegate7.delegate7_120(this),
						(ToolStripItem)Delegate7.delegate7_165(this),
						(ToolStripItem)Delegate7.delegate7_140(this),
						(ToolStripItem)Delegate7.delegate7_166(this),
						(ToolStripItem)Delegate7.delegate7_167(this)
					});
					num = ((int)num2 * -256413900) ^ -993609982;
					continue;
				case 197u:
					componentResourceManager.ApplyResources(ToolStripSeparator_0, global::_003CModule_003E.smethod_20<string>(1055821835u, 3811627366u));
					num = ((int)num2 * -1445224716) ^ -1728002463;
					continue;
				case 196u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_125(this), global::_003CModule_003E.smethod_22<string>(1506033164u, 3553199443u));
					Delegate30.delegate30_1(Delegate7.delegate7_126(this), global::_003CModule_003E.smethod_18<string>(1956362022u, 578989011u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_126(this), global::_003CModule_003E.smethod_18<string>(1956362022u, 4008288100u));
					Delegate30.delegate30_1(Delegate7.delegate7_168(this), global::_003CModule_003E.smethod_20<string>(2530718338u, 3059297554u));
					num = ((int)num2 * -106553246) ^ -757257647;
					continue;
				case 195u:
					Delegate8.delegate8_168(this, Delegate3.delegate3_24());
					num = (int)((num2 * 1482239634) ^ 0x132E0863);
					continue;
				case 194u:
					Delegate30.delegate30_5(Delegate7.delegate7_156(this), global::_003CModule_003E.smethod_22<string>(3749611755u, 3468273617u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_156(this), global::_003CModule_003E.smethod_20<string>(2705572528u, 211442625u));
					num = ((int)num2 * -1685087269) ^ 0x1527FFAE;
					continue;
				case 193u:
					Delegate5.delegate5_15(Delegate7.delegate7_154(this), bool_0: true);
					Delegate44.delegate44_0(Delegate7.delegate7_155(this), DataGridViewAutoSizeColumnMode.Fill);
					num = ((int)num2 * -1549226092) ^ 0xAE4AF32;
					continue;
				case 192u:
					Delegate29.delegate29_3(dataGridViewCellStyle5, Delegate28.delegate28_10());
					num = (int)(num2 * 704943721) ^ -479238197;
					continue;
				case 191u:
					Delegate8.delegate8_190(this, Delegate3.delegate3_72());
					num = ((int)num2 * -1834915580) ^ 0x1F3C33D1;
					continue;
				case 190u:
					Delegate8.delegate8_186(this, Delegate3.delegate3_66());
					num = (int)((num2 * 516598726) ^ 0x185856F3);
					continue;
				case 189u:
					ToolStripButton_6.DisplayStyle = ToolStripItemDisplayStyle.Image;
					ToolStripButton_6.Image = GClass0.Bitmap_46;
					componentResourceManager.ApplyResources(ToolStripButton_6, global::_003CModule_003E.smethod_20<string>(2304409511u, 1211718230u));
					ToolStripButton_6.Name = global::_003CModule_003E.smethod_20<string>(2304409511u, 178688950u);
					componentResourceManager.ApplyResources(this, global::_003CModule_003E.smethod_19<string>(1960267240u, 2905607386u));
					base.AutoScaleMode = AutoScaleMode.Font;
					num = (int)((num2 * 1609266277) ^ 0x11D743F0);
					continue;
				case 188u:
					Delegate8.delegate8_67(dataGridViewCellStyle8, Delegate43.delegate43_0(global::_003CModule_003E.smethod_20<string>(490860945u, 2455324141u), 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0));
					Delegate29.delegate29_5(dataGridViewCellStyle8, Delegate28.delegate28_19());
					Delegate29.delegate29_7(dataGridViewCellStyle8, Delegate28.delegate28_13());
					Delegate29.delegate29_8(dataGridViewCellStyle8, Delegate28.delegate28_14());
					num = (int)((num2 * 571390332) ^ 0x7610E25E);
					continue;
				case 187u:
					Delegate8.delegate8_77(Delegate7.delegate7_138(this), Delegate3.delegate3_79());
					Delegate30.delegate30_1(Delegate7.delegate7_138(this), global::_003CModule_003E.smethod_22<string>(1684607292u, 2778746147u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_138(this), global::_003CModule_003E.smethod_18<string>(248893917u, 2541385530u));
					num = (int)((num2 * 2003211516) ^ 0x6B6D01);
					continue;
				case 186u:
					ToolStripDropDownButton_0.DisplayStyle = ToolStripItemDisplayStyle.Image;
					ToolStripDropDownButton_0.DropDownItems.AddRange(new ToolStripItem[2] { ToolStripMenuItem_0, ToolStripMenuItem_1 });
					ToolStripDropDownButton_0.Image = GClass0.Bitmap_12;
					componentResourceManager.ApplyResources(ToolStripDropDownButton_0, global::_003CModule_003E.smethod_20<string>(2776901854u, 522416933u));
					ToolStripDropDownButton_0.Name = global::_003CModule_003E.smethod_19<string>(392638444u, 2850015043u);
					num = ((int)num2 * -1982941044) ^ 0x59C2C88;
					continue;
				case 185u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_120(this), global::_003CModule_003E.smethod_21<string>(707901698u, 638562912u));
					Delegate31.smethod_0(Delegate7.delegate7_163(Delegate7.delegate7_165(this)), new ToolStripItem[16]
					{
						(ToolStripItem)Delegate7.delegate7_121(this),
						(ToolStripItem)Delegate7.delegate7_122(this),
						(ToolStripItem)Delegate7.delegate7_123(this),
						(ToolStripItem)Delegate7.delegate7_124(this),
						(ToolStripItem)Delegate7.delegate7_125(this),
						(ToolStripItem)Delegate7.delegate7_126(this),
						(ToolStripItem)Delegate7.delegate7_168(this),
						(ToolStripItem)Delegate7.delegate7_127(this),
						(ToolStripItem)Delegate7.delegate7_128(this),
						(ToolStripItem)Delegate7.delegate7_129(this),
						(ToolStripItem)Delegate7.delegate7_169(this),
						(ToolStripItem)Delegate7.delegate7_130(this),
						(ToolStripItem)Delegate7.delegate7_131(this),
						(ToolStripItem)Delegate7.delegate7_132(this),
						(ToolStripItem)Delegate7.delegate7_170(this),
						(ToolStripItem)Delegate7.delegate7_139(this)
					});
					Delegate8.delegate8_77(Delegate7.delegate7_165(this), Delegate3.delegate3_83());
					num = (int)((num2 * 2043269579) ^ 0xC961234);
					continue;
				case 184u:
					StatusStrip_0.Name = global::_003CModule_003E.smethod_22<string>(2100264705u, 1293591608u);
					num = (int)(num2 * 1011014863) ^ -534444225;
					continue;
				case 183u:
					ToolStripButton_5.Margin = new Padding(2);
					num = ((int)num2 * -279529482) ^ -849589405;
					continue;
				case 182u:
					Delegate5.delegate5_12(Delegate7.delegate7_99(this), bool_0: false);
					num = ((int)num2 * -27768609) ^ 0x7410D6F4;
					continue;
				case 181u:
					Delegate8.delegate8_131(this, Delegate3.delegate3_66());
					Delegate8.delegate8_132(this, Delegate3.delegate3_66());
					Delegate8.delegate8_133(this, Delegate3.delegate3_66());
					num = (int)(num2 * 187203223) ^ -805784494;
					continue;
				case 180u:
					Delegate8.delegate8_150(this, Delegate3.delegate3_66());
					Delegate8.delegate8_151(this, Delegate3.delegate3_26());
					num = (int)((num2 * 339982832) ^ 0x338CF375);
					continue;
				case 179u:
					Delegate5.delegate5_37(Delegate7.delegate7_99(this), bool_0: false);
					num = (int)(num2 * 329025971) ^ -545048118;
					continue;
				case 178u:
					componentResourceManager.ApplyResources(ToolStripButton_4, global::_003CModule_003E.smethod_22<string>(3207081492u, 3500855400u));
					num = ((int)num2 * -770564579) ^ 0x1B9E32FE;
					continue;
				case 177u:
					Delegate32.delegate32_8(Delegate7.delegate7_173(Delegate7.delegate7_95(this)), 20);
					num = (int)((num2 * 1396527258) ^ 0x3BC2E1F6);
					continue;
				case 176u:
					ToolStripSplitButton_1.Image = GClass0.Bitmap_51;
					componentResourceManager.ApplyResources(ToolStripSplitButton_1, global::_003CModule_003E.smethod_21<string>(2172450180u, 1108346162u));
					num = ((int)num2 * -563032143) ^ -999007643;
					continue;
				case 175u:
					Delegate30.delegate30_5(Delegate7.delegate7_153(this), global::_003CModule_003E.smethod_22<string>(3446545122u, 4093873919u));
					num = (int)((num2 * 122497575) ^ 0x5803D152);
					continue;
				case 174u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_167(this), global::_003CModule_003E.smethod_21<string>(372736876u, 3816258244u));
					Delegate5.delegate5_12(Delegate7.delegate7_95(this), bool_0: false);
					num = ((int)num2 * -156482995) ^ 0xFCA6BBA;
					continue;
				case 173u:
					Delegate41.delegate41_0(Delegate7.delegate7_99(this), DataGridViewSelectionMode.FullRowSelect);
					num = (int)(num2 * 1193964079) ^ -227762795;
					continue;
				case 172u:
					Delegate30.delegate30_5(Delegate7.delegate7_155(this), global::_003CModule_003E.smethod_21<string>(2785321141u, 589964858u));
					num = (int)((num2 * 1309149106) ^ 0x5373848A);
					continue;
				case 171u:
					Delegate8.delegate8_77(Delegate7.delegate7_162(this), Delegate3.delegate3_74());
					Delegate30.delegate30_1(Delegate7.delegate7_162(this), global::_003CModule_003E.smethod_18<string>(1385642870u, 2923238655u));
					num = (int)((num2 * 387220804) ^ 0x27A1275);
					continue;
				case 170u:
					ToolStripButton_4.Image = GClass0.Bitmap_52;
					num = ((int)num2 * -1505028676) ^ -1609512115;
					continue;
				case 169u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_122(this), global::_003CModule_003E.smethod_22<string>(2904014859u, 1485788578u));
					Delegate30.delegate30_1(Delegate7.delegate7_123(this), global::_003CModule_003E.smethod_19<string>(4158284772u, 3433794364u));
					num = (int)(num2 * 767571351) ^ -743872172;
					continue;
				case 168u:
					Delegate8.delegate8_189(this, Delegate3.delegate3_24());
					num = ((int)num2 * -923369572) ^ -915993313;
					continue;
				case 167u:
					Delegate30.delegate30_5(Delegate7.delegate7_157(this), global::_003CModule_003E.smethod_22<string>(4099952132u, 342408904u));
					Delegate129.delegate129_0(dataGridViewCellStyle10, DataGridViewContentAlignment.MiddleCenter);
					Delegate8.delegate8_68(Delegate7.delegate7_157(this), dataGridViewCellStyle10);
					num = (int)((num2 * 411004392) ^ 0x3739FFAC);
					continue;
				case 166u:
					Delegate29.delegate29_3(dataGridViewCellStyle8, Delegate28.delegate28_18());
					num = ((int)num2 * -1040160894) ^ -1466622114;
					continue;
				case 165u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_134(this), global::_003CModule_003E.smethod_20<string>(3722502130u, 2722846885u));
					num = (int)(num2 * 900662205) ^ -631254385;
					continue;
				case 164u:
					Delegate22.delegate22_7(this);
					num = (int)((num2 * 319016477) ^ 0x2B641773);
					continue;
				case 163u:
					ToolStripSplitButton_0.DropDownButtonWidth = 22;
					ToolStripSplitButton_0.DropDownItems.AddRange(new ToolStripItem[1] { ToolStripMenuItem_10 });
					componentResourceManager.ApplyResources(ToolStripSplitButton_0, global::_003CModule_003E.smethod_22<string>(3333954342u, 2267136046u));
					num = (int)((num2 * 1526207829) ^ 0x357802E8);
					continue;
				case 162u:
					ToolStrip_1.PerformLayout();
					((ISupportInitialize)PictureBox_0).EndInit();
					num = (int)(num2 * 1838275859) ^ -1526168784;
					continue;
				case 161u:
					Delegate8.delegate8_122(this, Delegate3.delegate3_23());
					Delegate8.delegate8_123(this, Delegate3.delegate3_23());
					Delegate8.delegate8_124(this, Delegate3.delegate3_23());
					Delegate8.delegate8_125(this, Delegate3.delegate3_23());
					Delegate8.delegate8_126(this, Delegate3.delegate3_23());
					num = ((int)num2 * -908407498) ^ 0x4B605570;
					continue;
				case 160u:
					ToolStrip_0.PerformLayout();
					ResumeLayout(performLayout: false);
					num = ((int)num2 * -1634463924) ^ 0x103AFD33;
					continue;
				case 159u:
					ToolStripButton_3.Name = global::_003CModule_003E.smethod_18<string>(204115435u, 3712010849u);
					num = ((int)num2 * -554583715) ^ 0x146C4E9B;
					continue;
				case 158u:
					Delegate29.delegate29_7(dataGridViewCellStyle3, Delegate28.delegate28_13());
					Delegate29.delegate29_8(dataGridViewCellStyle3, Delegate28.delegate28_14());
					Delegate130.delegate130_0(dataGridViewCellStyle3, DataGridViewTriState.False);
					Delegate8.delegate8_197(Delegate7.delegate7_99(this), dataGridViewCellStyle3);
					num = ((int)num2 * -1501816820) ^ -1230181136;
					continue;
				case 157u:
					Delegate8.delegate8_77(Delegate7.delegate7_133(this), Delegate3.delegate3_80());
					Delegate30.delegate30_1(Delegate7.delegate7_133(this), global::_003CModule_003E.smethod_22<string>(2650269159u, 3048774337u));
					num = ((int)num2 * -470005771) ^ 0x6FB64350;
					continue;
				case 156u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_118(this), global::_003CModule_003E.smethod_20<string>(3465586768u, 692430299u));
					num = (int)((num2 * 737202246) ^ 0x1221B5FF);
					continue;
				case 155u:
					Delegate5.delegate5_13(Delegate7.delegate7_95(this), bool_0: false);
					Delegate5.delegate5_35(Delegate7.delegate7_95(this), bool_0: false);
					Delegate5.delegate5_36(Delegate7.delegate7_95(this), bool_0: false);
					Delegate29.delegate29_3(dataGridViewCellStyle9, Delegate28.delegate28_15());
					Delegate8.delegate8_66(Delegate7.delegate7_95(this), dataGridViewCellStyle9);
					Delegate29.delegate29_9(Delegate7.delegate7_95(this), Delegate28.delegate28_5());
					Delegate39.delegate39_0(Delegate7.delegate7_95(this), DataGridViewColumnHeadersHeightSizeMode.AutoSize);
					Delegate5.delegate5_39(Delegate7.delegate7_95(this), bool_0: false);
					num = ((int)num2 * -825185103) ^ 0x6613015F;
					continue;
				case 154u:
					Delegate29.delegate29_3(dataGridViewCellStyle3, Delegate28.delegate28_11());
					Delegate8.delegate8_67(dataGridViewCellStyle3, Delegate43.delegate43_0(global::_003CModule_003E.smethod_20<string>(3874628096u, 157985044u), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0));
					Delegate29.delegate29_5(dataGridViewCellStyle3, Delegate28.delegate28_12());
					num = (int)((num2 * 1593218654) ^ 0x7EDBC321);
					continue;
				case 153u:
					Delegate8.delegate8_141(this, Delegate3.delegate3_66());
					Delegate8.delegate8_142(this, Delegate3.delegate3_66());
					num = ((int)num2 * -1230868059) ^ -600305346;
					continue;
				case 152u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_121(this), global::_003CModule_003E.smethod_21<string>(2652229326u, 891682434u));
					num = ((int)num2 * -1387856933) ^ 0x3A305B36;
					continue;
				case 151u:
					Delegate22.delegate22_6(Delegate7.delegate7_149(this));
					num = (int)((num2 * 2048046509) ^ 0x3AE4CE04);
					continue;
				case 150u:
					Delegate5.delegate5_15(Delegate7.delegate7_160(this), bool_0: true);
					Delegate130.delegate130_1(Delegate7.delegate7_160(this), DataGridViewTriState.False);
					num = ((int)num2 * -828982302) ^ 0x397582B9;
					continue;
				case 149u:
					ToolStripMenuItem_29.CheckState = CheckState.Checked;
					num = ((int)num2 * -1323389573) ^ 0x7DEEC748;
					continue;
				case 148u:
					Delegate30.delegate30_0(Delegate7.delegate7_99(this), global::_003CModule_003E.smethod_18<string>(4132487379u, 4006698608u));
					num = ((int)num2 * -337347758) ^ -651198111;
					continue;
				case 147u:
					Delegate30.delegate30_6(Delegate7.delegate7_175(this), global::_003CModule_003E.smethod_21<string>(3942312664u, 2899363079u));
					num = ((int)num2 * -2101599812) ^ 0x66034A6B;
					continue;
				case 146u:
					Delegate22.delegate22_5(Delegate7.delegate7_151(this));
					num = (int)(num2 * 971616835) ^ -1640972523;
					continue;
				case 145u:
					Delegate8.delegate8_197(Delegate7.delegate7_97(this), dataGridViewCellStyle2);
					num = (int)(num2 * 256170130) ^ -1752748331;
					continue;
				case 144u:
					Delegate22.delegate22_5(Delegate7.delegate7_145(Delegate7.delegate7_144(this)));
					num = ((int)num2 * -871262499) ^ 0x29F4A7E1;
					continue;
				case 143u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_97(this), global::_003CModule_003E.smethod_22<string>(949220831u, 3948666474u));
					num = ((int)num2 * -2021093854) ^ 0x715BABF9;
					continue;
				case 142u:
					ToolStripComboBox_1.Margin = new Padding(2, 0, 2, 0);
					num = ((int)num2 * -1989470643) ^ -1957081329;
					continue;
				case 141u:
					Delegate8.delegate8_77(Delegate7.delegate7_136(this), Delegate3.delegate3_77());
					num = ((int)num2 * -1795836270) ^ -502612239;
					continue;
				case 140u:
					StatusStrip_0.PerformLayout();
					num = ((int)num2 * -1964400638) ^ -118009752;
					continue;
				case 139u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_124(this), global::_003CModule_003E.smethod_22<string>(540371297u, 1424235335u));
					Delegate30.delegate30_1(Delegate7.delegate7_125(this), global::_003CModule_003E.smethod_22<string>(1506033164u, 3891514193u));
					num = (int)(num2 * 1025574067) ^ -1245278320;
					continue;
				case 138u:
					Delegate40.smethod_0(Delegate7.delegate7_22(Delegate7.delegate7_97(this)), new DataGridViewColumn[2]
					{
						(DataGridViewColumn)Delegate7.delegate7_174(this),
						(DataGridViewColumn)Delegate7.delegate7_175(this)
					});
					Delegate8.delegate8_196(Delegate7.delegate7_97(this), Delegate7.delegate7_118(this));
					Delegate129.delegate129_0(dataGridViewCellStyle2, DataGridViewContentAlignment.MiddleLeft);
					num = ((int)num2 * -2017945823) ^ 0x3CD7CEF6;
					continue;
				case 137u:
					ToolStripSplitButton_1.Margin = new Padding(2);
					num = (int)((num2 * 834515090) ^ 0x424CBD61);
					continue;
				case 136u:
					Button_1.Name = global::_003CModule_003E.smethod_22<string>(307715546u, 2160935658u);
					ToolTip_0.SetToolTip(Button_1, componentResourceManager.GetString(global::_003CModule_003E.smethod_22<string>(1273377413u, 3212168323u)));
					num = (int)(num2 * 146813994) ^ -133293148;
					continue;
				case 135u:
					Button_0.UseVisualStyleBackColor = false;
					RichTextBox_0.BackColor = Color.Black;
					num = ((int)num2 * -1370705822) ^ 0x7349B324;
					continue;
				case 134u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_146(Delegate7.delegate7_144(this))), Delegate7.delegate7_152(this));
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_146(Delegate7.delegate7_144(this))), Delegate7.delegate7_114(this));
					num = (int)(num2 * 60154480) ^ -1335218927;
					continue;
				case 133u:
					ToolStripMenuItem_10.Name = global::_003CModule_003E.smethod_19<string>(2983625873u, 1621664336u);
					num = (int)(num2 * 299472813) ^ -695512925;
					continue;
				case 132u:
					SplitContainer_0.ResumeLayout(performLayout: false);
					num = (int)(num2 * 1351641704) ^ -1774889486;
					continue;
				case 131u:
					Delegate8.delegate8_139(this, Delegate3.delegate3_66());
					Delegate8.delegate8_140(this, Delegate3.delegate3_66());
					num = (int)((num2 * 726161256) ^ 0x3592FB80);
					continue;
				case 130u:
					Delegate29.delegate29_2(Delegate7.delegate7_144(this), Delegate28.delegate28_6());
					num = ((int)num2 * -1599855847) ^ 0x5AC3818;
					continue;
				case 129u:
					base.Controls.Add(ToolStrip_0);
					num = (int)((num2 * 1105540636) ^ 0x4BEB4F20);
					continue;
				case 128u:
					Delegate22.delegate22_5(Delegate7.delegate7_98(this));
					num = ((int)num2 * -332806504) ^ 0x302ED708;
					continue;
				case 127u:
					Delegate29.delegate29_5(dataGridViewCellStyle2, Delegate28.delegate28_12());
					Delegate29.delegate29_7(dataGridViewCellStyle2, Delegate28.delegate28_13());
					num = ((int)num2 * -1706610769) ^ -1821068019;
					continue;
				case 126u:
					ToolStripButton_6.CheckOnClick = true;
					num = ((int)num2 * -1215979285) ^ 0x5422E8;
					continue;
				case 125u:
					Delegate5.delegate5_38(Delegate7.delegate7_97(this), bool_0: false);
					num = ((int)num2 * -1628469010) ^ -1069670413;
					continue;
				case 124u:
					Delegate8.delegate8_144(this, Delegate3.delegate3_66());
					num = (int)((num2 * 648546014) ^ 0x73E1F84B);
					continue;
				case 123u:
					dataGridViewCellStyle6 = (DataGridViewCellStyle)Delegate3.delegate3_20();
					dataGridViewCellStyle2 = (DataGridViewCellStyle)Delegate3.delegate3_20();
					dataGridViewCellStyle8 = (DataGridViewCellStyle)Delegate3.delegate3_20();
					num = (int)(num2 * 1032509775) ^ -1490998999;
					continue;
				case 122u:
					Delegate132.delegate132_0(Delegate7.delegate7_160(this), DataGridViewColumnSortMode.Automatic);
					num = ((int)num2 * -1179136704) ^ -2068154487;
					continue;
				case 121u:
					Delegate29.delegate29_8(dataGridViewCellStyle7, Delegate28.delegate28_14());
					Delegate130.delegate130_0(dataGridViewCellStyle7, DataGridViewTriState.False);
					Delegate8.delegate8_197(Delegate7.delegate7_95(this), dataGridViewCellStyle7);
					num = ((int)num2 * -943414341) ^ -431098343;
					continue;
				case 120u:
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_146(Delegate7.delegate7_144(this))), Delegate7.delegate7_84(this));
					num = ((int)num2 * -242081177) ^ 0x3470DB82;
					continue;
				case 119u:
					Delegate8.delegate8_178(this, Delegate3.delegate3_12());
					num = (int)((num2 * 1444459775) ^ 0x7624A3CF);
					continue;
				case 118u:
					ToolStripComboBox_0.Name = global::_003CModule_003E.smethod_22<string>(3409125914u, 131191937u);
					componentResourceManager.ApplyResources(ToolStripTextBox_0, global::_003CModule_003E.smethod_19<string>(2971864772u, 1476831429u));
					ToolStripTextBox_0.Name = global::_003CModule_003E.smethod_22<string>(1604675030u, 2530329699u);
					num = (int)((num2 * 943778484) ^ 0x3EB3EFB2);
					continue;
				case 117u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_132(this), global::_003CModule_003E.smethod_19<string>(2407791850u, 614822950u));
					num = ((int)num2 * -636152661) ^ -1435764024;
					continue;
				case 116u:
					Button_0.BackgroundImage = GClass0.Bitmap_4;
					Button_0.FlatAppearance.BorderSize = 0;
					Button_0.Name = global::_003CModule_003E.smethod_22<string>(3484297486u, 3475727766u);
					num = ((int)num2 * -704054139) ^ -1851535829;
					continue;
				case 115u:
					Delegate5.delegate5_35(Delegate7.delegate7_99(this), bool_0: false);
					Delegate5.delegate5_36(Delegate7.delegate7_99(this), bool_0: false);
					num = ((int)num2 * -1810514644) ^ -3693142;
					continue;
				case 114u:
					Delegate8.delegate8_166(this, Delegate3.delegate3_67());
					Delegate8.delegate8_167(this, Delegate3.delegate3_24());
					num = (int)((num2 * 444523173) ^ 0x5E542DA6);
					continue;
				case 113u:
					Delegate5.delegate5_14(Delegate7.delegate7_99(this), bool_0: true);
					num = (int)((num2 * 406516010) ^ 0x4CDFDF7E);
					continue;
				case 112u:
					Delegate8.delegate8_117(this, Delegate3.delegate3_64());
					Delegate8.delegate8_118(this, Delegate3.delegate3_64());
					num = ((int)num2 * -93114156) ^ 0x65268CD1;
					continue;
				case 111u:
					ToolStripComboBox_1.Name = global::_003CModule_003E.smethod_20<string>(2674317051u, 1356181366u);
					componentResourceManager.ApplyResources(ToolStripComboBox_1, global::_003CModule_003E.smethod_18<string>(3176967382u, 2411576993u));
					num = ((int)num2 * -1342752028) ^ -706715815;
					continue;
				case 110u:
					ToolStripSplitButton_1.Name = global::_003CModule_003E.smethod_22<string>(4095191442u, 2746781332u);
					ToolStripMenuItem_29.Checked = true;
					num = ((int)num2 * -1261373324) ^ 0xC8F7981;
					continue;
				case 109u:
					Delegate130.delegate130_1(Delegate7.delegate7_158(this), DataGridViewTriState.False);
					num = (int)(num2 * 1574910490) ^ -1934846842;
					continue;
				case 108u:
					Delegate30.delegate30_6(Delegate7.delegate7_160(this), global::_003CModule_003E.smethod_18<string>(765455885u, 1695684225u));
					num = (int)(num2 * 2058733377) ^ -860199290;
					continue;
				case 107u:
					ToolStripButton_6.BackColor = SystemColors.Control;
					num = (int)(num2 * 625519768) ^ -873243242;
					continue;
				case 106u:
					base.Controls.Add(PictureBox_0);
					num = (int)((num2 * 70341627) ^ 0x671F0DFD);
					continue;
				case 105u:
					Delegate5.delegate5_38(Delegate7.delegate7_99(this), bool_0: false);
					num = ((int)num2 * -1980903601) ^ -276263749;
					continue;
				case 104u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_117(this), global::_003CModule_003E.smethod_19<string>(2638231729u, 4069773471u));
					Delegate30.delegate30_1(Delegate7.delegate7_161(this), global::_003CModule_003E.smethod_20<string>(38892233u, 3747522716u));
					num = (int)((num2 * 553091314) ^ 0x60C4372B);
					continue;
				case 103u:
					Delegate22.delegate22_5(Delegate7.delegate7_144(this));
					num = (int)((num2 * 714219225) ^ 0x72D1A53C);
					continue;
				case 102u:
					Delegate8.delegate8_169(this, Delegate3.delegate3_24());
					num = ((int)num2 * -1531160830) ^ 0x5E088D28;
					continue;
				case 101u:
					ToolStripMenuItem_29.Name = global::_003CModule_003E.smethod_22<string>(3815595103u, 1718004975u);
					num = ((int)num2 * -1736542205) ^ -1200915542;
					continue;
				case 100u:
					Button_1.FlatAppearance.BorderSize = 0;
					num = ((int)num2 * -1528746548) ^ 0x3C66D030;
					continue;
				case 99u:
					ToolTip_0.SetToolTip(PictureBox_0, componentResourceManager.GetString(global::_003CModule_003E.smethod_19<string>(2499755262u, 1139166661u)));
					componentResourceManager.ApplyResources(StatusStrip_0, global::_003CModule_003E.smethod_21<string>(1261071019u, 3347071634u));
					num = ((int)num2 * -1711392790) ^ 0x50D83625;
					continue;
				case 98u:
					Delegate5.delegate5_13(Delegate7.delegate7_99(this), bool_0: false);
					num = (int)(num2 * 1316987708) ^ -229148082;
					continue;
				case 97u:
					Delegate8.delegate8_127(this, Delegate3.delegate3_65());
					Delegate8.delegate8_128(this, Delegate7.delegate7_142(icontainer_0));
					num = ((int)num2 * -937058287) ^ -489428197;
					continue;
				case 96u:
					Delegate29.delegate29_3(dataGridViewCellStyle7, Delegate28.delegate28_16());
					Delegate8.delegate8_67(dataGridViewCellStyle7, Delegate43.delegate43_0(global::_003CModule_003E.smethod_19<string>(3973826599u, 3651816975u), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0));
					num = ((int)num2 * -668571484) ^ 0x1A12D41F;
					continue;
				case 95u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_170(this), global::_003CModule_003E.smethod_22<string>(1350929330u, 2473849910u));
					Delegate30.delegate30_1(Delegate7.delegate7_139(this), global::_003CModule_003E.smethod_22<string>(791736652u, 1229381621u));
					num = ((int)num2 * -964115099) ^ -857171698;
					continue;
				case 94u:
					componentResourceManager.ApplyResources(ToolStripStatusLabel_0, global::_003CModule_003E.smethod_19<string>(3144561844u, 1832842899u));
					num = (int)(num2 * 153051014) ^ -906145645;
					continue;
				case 93u:
					componentResourceManager.ApplyResources(ToolStripMenuItem_10, global::_003CModule_003E.smethod_20<string>(2597314007u, 798340401u));
					componentResourceManager.ApplyResources(ToolStripButton_7, global::_003CModule_003E.smethod_19<string>(1428820876u, 3363216467u));
					ToolStripButton_7.Image = GClass0.Bitmap_60;
					ToolStripButton_7.Name = global::_003CModule_003E.smethod_21<string>(3478618872u, 2978860725u);
					componentResourceManager.ApplyResources(Button_1, global::_003CModule_003E.smethod_18<string>(666520219u, 1282918964u));
					Button_1.BackColor = Color.Black;
					Button_1.BackgroundImage = GClass0.Bitmap_10;
					num = (int)(num2 * 687813846) ^ -2003444097;
					continue;
				case 92u:
					componentResourceManager.ApplyResources(ToolStripButton_8, global::_003CModule_003E.smethod_22<string>(2011144219u, 507213827u));
					ToolStripButton_8.Image = GClass0.Bitmap_60;
					ToolStripButton_8.Name = global::_003CModule_003E.smethod_19<string>(2476764409u, 1237593548u);
					num = (int)(num2 * 57224260) ^ -1297747730;
					continue;
				case 91u:
					((ISupportInitialize)DataGridView_2).EndInit();
					ToolStrip_1.ResumeLayout(performLayout: false);
					num = ((int)num2 * -1748870115) ^ -994514545;
					continue;
				case 90u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_157(this), global::_003CModule_003E.smethod_18<string>(872207136u, 2767269328u));
					Delegate30.delegate30_6(Delegate7.delegate7_157(this), global::_003CModule_003E.smethod_22<string>(3820355793u, 2351449996u));
					Delegate5.delegate5_15(Delegate7.delegate7_157(this), bool_0: true);
					Delegate130.delegate130_1(Delegate7.delegate7_157(this), DataGridViewTriState.False);
					Delegate30.delegate30_5(Delegate7.delegate7_158(this), global::_003CModule_003E.smethod_20<string>(2355864148u, 792935815u));
					num = ((int)num2 * -1164995932) ^ -1078463406;
					continue;
				case 89u:
					Delegate8.delegate8_198(Delegate7.delegate7_97(this), dataGridViewCellStyle8);
					num = (int)(num2 * 2055139926) ^ -1642789280;
					continue;
				case 88u:
					ToolStrip_1.Name = global::_003CModule_003E.smethod_19<string>(1717003562u, 2649499332u);
					num = ((int)num2 * -859206341) ^ -1502156103;
					continue;
				case 87u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_161(this), global::_003CModule_003E.smethod_18<string>(2523954940u, 3776025237u));
					num = (int)((num2 * 1317404498) ^ 0x61ADD1B0);
					continue;
				case 86u:
					Delegate8.delegate8_138(this, Delegate3.delegate3_66());
					num = ((int)num2 * -191586020) ^ -1001379861;
					continue;
				case 85u:
					base.Name = global::_003CModule_003E.smethod_20<string>(100429774u, 1490481321u);
					num = ((int)num2 * -1799052240) ^ -784582796;
					continue;
				case 84u:
					Delegate8.delegate8_179(this, Delegate3.delegate3_10());
					Delegate8.delegate8_180(this, Delegate3.delegate3_11());
					Delegate8.delegate8_181(this, Delegate3.delegate3_67());
					Delegate8.delegate8_182(this, Delegate3.delegate3_24());
					Delegate8.delegate8_183(this, Delegate3.delegate3_71());
					num = ((int)num2 * -1305521595) ^ -834132755;
					continue;
				case 83u:
					Delegate22.delegate22_5(Delegate7.delegate7_147(this));
					num = ((int)num2 * -560554735) ^ -1132076117;
					continue;
				case 82u:
					Delegate22.delegate22_5(Delegate7.delegate7_150(this));
					num = ((int)num2 * -2000936160) ^ 0x5E4E5FF9;
					continue;
				case 81u:
					Delegate30.delegate30_1(Delegate7.delegate7_120(this), global::_003CModule_003E.smethod_20<string>(1164080356u, 2740669000u));
					num = ((int)num2 * -1786416518) ^ -877812499;
					continue;
				case 80u:
					ToolStripComboBox_1.Items.AddRange(new object[4]
					{
						componentResourceManager.GetString(global::_003CModule_003E.smethod_21<string>(1040746632u, 4261929770u)),
						componentResourceManager.GetString(global::_003CModule_003E.smethod_21<string>(859398755u, 2565306429u)),
						componentResourceManager.GetString(global::_003CModule_003E.smethod_22<string>(1146504563u, 266165402u)),
						componentResourceManager.GetString(global::_003CModule_003E.smethod_21<string>(1981822751u, 2546132379u))
					});
					num = (int)(num2 * 304940493) ^ -1549692994;
					continue;
				case 79u:
					Delegate22.delegate22_6(Delegate7.delegate7_99(this));
					Delegate22.delegate22_5(Delegate7.delegate7_118(this));
					num = ((int)num2 * -1966100509) ^ -1272946398;
					continue;
				case 78u:
					Delegate8.delegate8_191(this, Delegate3.delegate3_66());
					Delegate8.delegate8_192(this, Delegate3.delegate3_66());
					Delegate8.delegate8_193(this, Delegate3.delegate3_26());
					num = ((int)num2 * -1623333167) ^ 0x1FB33FDC;
					continue;
				case 77u:
					componentResourceManager.ApplyResources(Button_0, global::_003CModule_003E.smethod_20<string>(3968685646u, 3570444519u));
					Button_0.BackColor = Color.Black;
					num = ((int)num2 * -1383258987) ^ -1870968071;
					continue;
				case 76u:
					Delegate8.delegate8_187(this, Delegate3.delegate3_24());
					Delegate8.delegate8_188(this, Delegate3.delegate3_26());
					num = (int)((num2 * 1879883969) ^ 0x53083162);
					continue;
				case 75u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_136(this), global::_003CModule_003E.smethod_22<string>(2140397414u, 1388061547u));
					Delegate8.delegate8_77(Delegate7.delegate7_137(this), Delegate3.delegate3_78());
					Delegate30.delegate30_1(Delegate7.delegate7_137(this), global::_003CModule_003E.smethod_22<string>(3106059281u, 852527879u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_137(this), global::_003CModule_003E.smethod_22<string>(3106059281u, 1118362029u));
					num = (int)(num2 * 287334515) ^ -27311505;
					continue;
				case 74u:
					base.Controls.Add(StatusStrip_0);
					num = (int)(num2 * 1389743189) ^ -1785706382;
					continue;
				case 73u:
					Delegate30.delegate30_5(Delegate7.delegate7_174(this), global::_003CModule_003E.smethod_21<string>(3044775900u, 3099596142u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_174(this), global::_003CModule_003E.smethod_18<string>(2994175309u, 2803261546u));
					Delegate32.delegate32_9(Delegate7.delegate7_174(this), 50);
					num = ((int)num2 * -793131192) ^ 0x391A6496;
					continue;
				case 72u:
					((ToolStrip)Delegate7.delegate7_98(this)).ImageScalingSize = new Size(24, 24);
					num = ((int)num2 * -720450141) ^ -1847204275;
					continue;
				case 71u:
					SplitContainer_0.Panel2.ResumeLayout(performLayout: false);
					((ISupportInitialize)SplitContainer_0).EndInit();
					num = (int)(num2 * 459398670) ^ -2037567071;
					continue;
				case 70u:
					ToolStripMenuItem_29.CheckOnClick = true;
					num = ((int)num2 * -318894093) ^ 0x5BEBB158;
					continue;
				case 69u:
					Delegate5.delegate5_14(Delegate7.delegate7_95(this), bool_0: true);
					num = ((int)num2 * -191859378) ^ -1051046849;
					continue;
				case 68u:
					dataGridViewCellStyle5 = (DataGridViewCellStyle)Delegate3.delegate3_20();
					num = ((int)num2 * -1407467959) ^ 0x5E04C744;
					continue;
				case 67u:
					Delegate30.delegate30_0(Delegate7.delegate7_147(this), global::_003CModule_003E.smethod_22<string>(3287013754u, 2131956518u));
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_145(Delegate7.delegate7_147(this))), Delegate7.delegate7_148(this));
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_146(Delegate7.delegate7_147(this))), Delegate7.delegate7_97(this));
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_146(Delegate7.delegate7_147(this))), Delegate7.delegate7_98(this));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_148(this), global::_003CModule_003E.smethod_22<string>(4252675621u, 4140899368u));
					num = ((int)num2 * -1339019057) ^ -75472424;
					continue;
				case 66u:
					ToolStripButton_0.Margin = new Padding(2);
					ToolStripButton_0.Name = global::_003CModule_003E.smethod_19<string>(738032588u, 3318493562u);
					num = (int)(num2 * 1228624053) ^ -318451632;
					continue;
				case 65u:
					SplitContainer_1.Panel1.ResumeLayout(performLayout: false);
					SplitContainer_1.Panel2.ResumeLayout(performLayout: false);
					num = (int)((num2 * 929913858) ^ 0x26627F5B);
					continue;
				case 64u:
					ToolStrip_1.Items.AddRange(new ToolStripItem[6] { ToolStripButton_4, ToolStripButton_1, ToolStripButton_2, ToolStripButton_3, ToolStripSplitButton_0, ToolStripButton_7 });
					num = (int)(num2 * 1679348162) ^ -1452219660;
					continue;
				case 63u:
					Delegate8.delegate8_194(this, Delegate3.delegate3_71());
					num = ((int)num2 * -1700124969) ^ -1322267212;
					continue;
				case 62u:
					Delegate40.smethod_0(Delegate7.delegate7_22(Delegate7.delegate7_99(this)), new DataGridViewColumn[8]
					{
						(DataGridViewColumn)Delegate7.delegate7_153(this),
						(DataGridViewColumn)Delegate7.delegate7_154(this),
						(DataGridViewColumn)Delegate7.delegate7_155(this),
						(DataGridViewColumn)Delegate7.delegate7_156(this),
						(DataGridViewColumn)Delegate7.delegate7_157(this),
						(DataGridViewColumn)Delegate7.delegate7_158(this),
						(DataGridViewColumn)Delegate7.delegate7_159(this),
						(DataGridViewColumn)Delegate7.delegate7_160(this)
					});
					num = (int)(num2 * 32122574) ^ -631121618;
					continue;
				case 61u:
					Delegate30.delegate30_1(Delegate7.delegate7_140(this), global::_003CModule_003E.smethod_20<string>(2324933142u, 3664429065u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_140(this), global::_003CModule_003E.smethod_21<string>(1678905568u, 3175678272u));
					num = ((int)num2 * -1232257896) ^ 0x6FB335C4;
					continue;
				case 60u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_168(this), global::_003CModule_003E.smethod_18<string>(1387205987u, 3725363610u));
					Delegate30.delegate30_1(Delegate7.delegate7_127(this), global::_003CModule_003E.smethod_22<string>(970310780u, 136774569u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_127(this), global::_003CModule_003E.smethod_20<string>(3403724756u, 636633066u));
					Delegate30.delegate30_1(Delegate7.delegate7_128(this), global::_003CModule_003E.smethod_20<string>(2181009958u, 1476973189u));
					num = ((int)num2 * -1566557586) ^ 0x7B624407;
					continue;
				case 59u:
					Delegate22.delegate22_6(Delegate7.delegate7_144(this));
					num = (int)(num2 * 591316283) ^ -1710536142;
					continue;
				case 58u:
					Delegate5.delegate5_15(Delegate7.delegate7_175(this), bool_0: true);
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_98(this), global::_003CModule_003E.smethod_19<string>(1717003562u, 3765262500u));
					num = ((int)num2 * -1333916372) ^ -647882676;
					continue;
				case 57u:
					ToolStripButton_5.Alignment = ToolStripItemAlignment.Right;
					ToolStripButton_5.DisplayStyle = ToolStripItemDisplayStyle.Image;
					num = (int)(num2 * 196012733) ^ -440941376;
					continue;
				case 56u:
					componentResourceManager.ApplyResources(ToolStrip_0, global::_003CModule_003E.smethod_18<string>(3615925411u, 608766524u));
					ToolStrip_0.GripStyle = ToolStripGripStyle.Hidden;
					ToolStrip_0.ImageScalingSize = new Size(24, 24);
					ToolStrip_0.Items.AddRange(new ToolStripItem[11]
					{
						ToolStripButton_0, ToolStripComboBox_0, ToolStripTextBox_0, ToolStripSplitButton_1, ToolStripButton_8, ToolStripSeparator_0, ToolStripButton_5, ToolStripDropDownButton_0, ToolStripSeparator_1, ToolStripComboBox_1,
						ToolStripButton_6
					});
					ToolStrip_0.Name = global::_003CModule_003E.smethod_22<string>(815206946u, 3395543165u);
					ToolStripButton_0.DisplayStyle = ToolStripItemDisplayStyle.Image;
					ToolStripButton_0.Image = GClass0.Bitmap_49;
					componentResourceManager.ApplyResources(ToolStripButton_0, global::_003CModule_003E.smethod_20<string>(4112608830u, 1043675181u));
					num = ((int)num2 * -1741168212) ^ 0x52388F40;
					continue;
				case 55u:
					Delegate22.delegate22_5(Delegate7.delegate7_148(this));
					num = ((int)num2 * -1500188239) ^ -1493253929;
					continue;
				case 54u:
					componentResourceManager.ApplyResources(ToolStripMenuItem_29, global::_003CModule_003E.smethod_20<string>(316006755u, 3892121154u));
					num = (int)(num2 * 1528145408) ^ -701853740;
					continue;
				case 53u:
					Delegate5.delegate5_37(Delegate7.delegate7_97(this), bool_0: false);
					Delegate30.delegate30_0(Delegate7.delegate7_97(this), global::_003CModule_003E.smethod_18<string>(1752238222u, 3841198207u));
					Delegate129.delegate129_0(dataGridViewCellStyle8, DataGridViewContentAlignment.MiddleLeft);
					num = (int)((num2 * 68407119) ^ 0x1DE2E6AC);
					continue;
				case 52u:
					Delegate131.delegate131_0(Delegate7.delegate7_99(this), DataGridViewHeaderBorderStyle.None);
					num = (int)((num2 * 1749830271) ^ 0x7D284D94);
					continue;
				case 51u:
					Delegate8.delegate8_77(Delegate7.delegate7_117(this), Delegate3.delegate3_73());
					Delegate30.delegate30_1(Delegate7.delegate7_117(this), global::_003CModule_003E.smethod_22<string>(3411506259u, 994457447u));
					num = ((int)num2 * -895540274) ^ -2092094248;
					continue;
				case 50u:
					Delegate39.delegate39_0(Delegate7.delegate7_99(this), DataGridViewColumnHeadersHeightSizeMode.AutoSize);
					num = ((int)num2 * -1563937505) ^ 0xBA071D0;
					continue;
				case 49u:
					SplitContainer_1.ResumeLayout(performLayout: false);
					SplitContainer_2.Panel1.ResumeLayout(performLayout: false);
					num = ((int)num2 * -1256165870) ^ -1371728227;
					continue;
				case 48u:
					Delegate29.delegate29_5(dataGridViewCellStyle7, Delegate28.delegate28_12());
					num = ((int)num2 * -1017522970) ^ 0x4419F0F;
					continue;
				case 47u:
					Delegate5.delegate5_36(Delegate7.delegate7_97(this), bool_0: false);
					Delegate29.delegate29_3(dataGridViewCellStyle6, Delegate28.delegate28_17());
					Delegate8.delegate8_66(Delegate7.delegate7_97(this), dataGridViewCellStyle6);
					num = (int)(num2 * 1929148246) ^ -1944502753;
					continue;
				case 46u:
					Delegate8.delegate8_165(this, Delegate3.delegate3_23());
					num = (int)(num2 * 1715360133) ^ -1831883697;
					continue;
				case 45u:
					ImageList_0.ImageStream = (ImageListStreamer)componentResourceManager.GetObject(global::_003CModule_003E.smethod_21<string>(4022662503u, 3494781958u));
					ImageList_0.TransparentColor = Color.Transparent;
					ImageList_0.Images.SetKeyName(0, global::_003CModule_003E.smethod_20<string>(1153348510u, 2964463354u));
					ImageList_0.Images.SetKeyName(1, global::_003CModule_003E.smethod_18<string>(1493957238u, 4022804704u));
					componentResourceManager.ApplyResources(PictureBox_0, global::_003CModule_003E.smethod_21<string>(3928547198u, 1089153956u));
					num = (int)(num2 * 706656290) ^ -1699779660;
					continue;
				case 44u:
					ToolStripSeparator_0.Margin = new Padding(2);
					ToolStripSeparator_0.Name = global::_003CModule_003E.smethod_22<string>(206693335u, 2670282638u);
					num = (int)(num2 * 2018803841) ^ -411743966;
					continue;
				case 43u:
					Delegate8.delegate8_77(Delegate7.delegate7_135(this), Delegate3.delegate3_76());
					Delegate30.delegate30_1(Delegate7.delegate7_135(this), global::_003CModule_003E.smethod_20<string>(2499787332u, 1818164789u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_135(this), global::_003CModule_003E.smethod_21<string>(1288678882u, 3185726908u));
					num = (int)((num2 * 642169647) ^ 0x2D6D47C7);
					continue;
				case 42u:
					Delegate31.smethod_0(Delegate7.delegate7_10(Delegate7.delegate7_118(this)), new ToolStripItem[3]
					{
						(ToolStripItem)Delegate7.delegate7_117(this),
						(ToolStripItem)Delegate7.delegate7_161(this),
						(ToolStripItem)Delegate7.delegate7_162(this)
					});
					Delegate30.delegate30_0(Delegate7.delegate7_118(this), global::_003CModule_003E.smethod_21<string>(2014070390u, 267297912u));
					num = (int)((num2 * 1851344482) ^ 0x1BC1E79D);
					continue;
				case 41u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_162(this), global::_003CModule_003E.smethod_18<string>(1385642870u, 1688755231u));
					num = ((int)num2 * -1566331662) ^ -2035763376;
					continue;
				case 40u:
					Delegate30.delegate30_0(Delegate7.delegate7_95(this), global::_003CModule_003E.smethod_22<string>(1428481247u, 2493460459u));
					num = ((int)num2 * -738907853) ^ 0x597DE60B;
					continue;
				case 39u:
					Delegate41.delegate41_0(Delegate7.delegate7_97(this), DataGridViewSelectionMode.FullRowSelect);
					num = (int)((num2 * 1737802510) ^ 0x16BC3CB8);
					continue;
				case 38u:
					SplitContainer_2.ResumeLayout(performLayout: false);
					num = (int)((num2 * 1128139677) ^ 0x47A2007E);
					continue;
				case 37u:
					Delegate30.delegate30_1(Delegate7.delegate7_169(this), global::_003CModule_003E.smethod_20<string>(2550917498u, 4168638581u));
					num = (int)(num2 * 171909294) ^ -1697062375;
					continue;
				case 36u:
					Delegate8.delegate8_146(this, Delegate3.delegate3_66());
					Delegate8.delegate8_147(this, Delegate3.delegate3_26());
					Delegate8.delegate8_148(this, Delegate3.delegate3_66());
					Delegate8.delegate8_149(this, Delegate3.delegate3_66());
					num = (int)((num2 * 1911227397) ^ 0x80B41D3);
					continue;
				case 35u:
					Delegate8.delegate8_143(this, Delegate3.delegate3_66());
					num = ((int)num2 * -844342975) ^ -973874794;
					continue;
				case 34u:
					Delegate8.delegate8_66(Delegate7.delegate7_99(this), dataGridViewCellStyle5);
					num = (int)((num2 * 1611377987) ^ 0x78E7E26);
					continue;
				case 33u:
					Delegate30.delegate30_6(Delegate7.delegate7_158(this), global::_003CModule_003E.smethod_19<string>(4077551112u, 1393704674u));
					Delegate5.delegate5_15(Delegate7.delegate7_158(this), bool_0: true);
					num = (int)(num2 * 241200310) ^ -1674476154;
					continue;
				case 32u:
					Delegate8.delegate8_119(this, Delegate3.delegate3_64());
					Delegate8.delegate8_112(this, Delegate3.delegate3_21());
					num = ((int)num2 * -1313220348) ^ -1459154301;
					continue;
				case 31u:
					Delegate8.delegate8_77(Delegate7.delegate7_120(this), Delegate3.delegate3_82());
					num = (int)((num2 * 1605881013) ^ 0x647BAD2);
					continue;
				case 30u:
					ToolStripSeparator_1.Name = global::_003CModule_003E.smethod_18<string>(615489269u, 2293600671u);
					componentResourceManager.ApplyResources(ToolStripSeparator_1, global::_003CModule_003E.smethod_22<string>(1299228052u, 187036964u));
					ToolStripComboBox_1.Alignment = ToolStripItemAlignment.Right;
					num = ((int)num2 * -1829278640) ^ 0x60613259;
					continue;
				case 29u:
					Delegate39.delegate39_0(Delegate7.delegate7_97(this), DataGridViewColumnHeadersHeightSizeMode.AutoSize);
					num = (int)(num2 * 1737824115) ^ -1315777106;
					continue;
				case 28u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_158(this), global::_003CModule_003E.smethod_18<string>(558205851u, 4292892521u));
					num = (int)((num2 * 1555897709) ^ 0x6593E003);
					continue;
				case 27u:
					Delegate5.delegate5_37(Delegate7.delegate7_95(this), bool_0: false);
					num = (int)((num2 * 585445972) ^ 0x6ED8A51B);
					continue;
				case 26u:
					componentResourceManager.ApplyResources(ToolStripComboBox_0, global::_003CModule_003E.smethod_19<string>(1854948680u, 2231314065u));
					ToolStripComboBox_0.DropDownWidth = 121;
					ToolStripComboBox_0.Margin = new Padding(2);
					num = ((int)num2 * -1181717664) ^ 0x3C92F480;
					continue;
				case 25u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_99(this), global::_003CModule_003E.smethod_21<string>(83508228u, 45495357u));
					num = (int)(num2 * 1506094796) ^ -1652856215;
					continue;
				case 24u:
					Delegate22.delegate22_6(Delegate7.delegate7_95(this));
					Delegate22.delegate22_6(Delegate7.delegate7_97(this));
					num = ((int)num2 * -1550868938) ^ -1739774604;
					continue;
				case 23u:
					Delegate8.delegate8_134(this, Delegate3.delegate3_66());
					num = ((int)num2 * -1518632421) ^ -730780153;
					continue;
				case 22u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_171(this), global::_003CModule_003E.smethod_19<string>(300675032u, 2590933567u));
					Delegate30.delegate30_6(Delegate7.delegate7_171(this), global::_003CModule_003E.smethod_22<string>(2394143114u, 2790625726u));
					Delegate5.delegate5_15(Delegate7.delegate7_171(this), bool_0: true);
					Delegate44.delegate44_0(Delegate7.delegate7_172(this), DataGridViewAutoSizeColumnMode.Fill);
					num = ((int)num2 * -1842071366) ^ -707258858;
					continue;
				case 21u:
					ToolStripButton_2.Margin = new Padding(2);
					ToolStripButton_2.Name = global::_003CModule_003E.smethod_18<string>(3826301679u, 1217060102u);
					componentResourceManager.ApplyResources(ToolStripButton_3, global::_003CModule_003E.smethod_22<string>(843437930u, 751862531u));
					ToolStripButton_3.Image = GClass0.Bitmap_48;
					ToolStripButton_3.Margin = new Padding(2);
					num = (int)((num2 * 16475168) ^ 0x3588357B);
					continue;
				case 20u:
					Delegate129.delegate129_0(dataGridViewCellStyle4, DataGridViewContentAlignment.MiddleCenter);
					Delegate8.delegate8_68(Delegate7.delegate7_158(this), dataGridViewCellStyle4);
					num = ((int)num2 * -1105855439) ^ -1362997874;
					continue;
				case 19u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_144(this), global::_003CModule_003E.smethod_18<string>(2268800190u, 4000502783u));
					Delegate30.delegate30_0(Delegate7.delegate7_144(this), global::_003CModule_003E.smethod_19<string>(1337388813u, 2349861423u));
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_145(Delegate7.delegate7_144(this))), Delegate7.delegate7_147(this));
					num = ((int)num2 * -999061532) ^ -100764734;
					continue;
				case 18u:
					componentResourceManager = (ComponentResourceManager)Delegate7.delegate7_4(Delegate9.delegate9_0(typeof(MainForm).TypeHandle));
					num = ((int)num2 * -556394921) ^ 0x5ADDA815;
					continue;
				case 17u:
					Delegate8.delegate8_77(Delegate7.delegate7_134(this), Delegate3.delegate3_75());
					num = ((int)num2 * -637247862) ^ 0x3F7F554F;
					continue;
				case 16u:
					dataGridViewCellStyle3 = (DataGridViewCellStyle)Delegate3.delegate3_20();
					num = (int)(num2 * 1227033059) ^ -26523187;
					continue;
				case 15u:
					Delegate30.delegate30_1(Delegate7.delegate7_170(this), global::_003CModule_003E.smethod_20<string>(475395442u, 1656497724u));
					num = ((int)num2 * -2089220028) ^ 0x1F2D6495;
					continue;
				case 14u:
					Delegate29.delegate29_8(dataGridViewCellStyle2, Delegate28.delegate28_14());
					Delegate130.delegate130_0(dataGridViewCellStyle2, DataGridViewTriState.False);
					num = (int)((num2 * 1302659) ^ 0x3CF1252A);
					continue;
				case 13u:
					ToolStripButton_1.Margin = new Padding(2);
					num = ((int)num2 * -1893830912) ^ -1193054065;
					continue;
				case 12u:
					Delegate22.delegate22_5(Delegate7.delegate7_146(Delegate7.delegate7_144(this)));
					num = ((int)num2 * -666446145) ^ 0x1AC1A481;
					continue;
				case 11u:
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_172(this), global::_003CModule_003E.smethod_19<string>(1417591124u, 29458128u));
					Delegate30.delegate30_6(Delegate7.delegate7_172(this), global::_003CModule_003E.smethod_20<string>(989226166u, 856705052u));
					Delegate5.delegate5_15(Delegate7.delegate7_172(this), bool_0: true);
					num = ((int)num2 * -835306355) ^ 0x31474869;
					continue;
				case 10u:
					ToolStripStatusLabel_0.Name = global::_003CModule_003E.smethod_19<string>(3144561844u, 3625813834u);
					num = (int)(num2 * 1539325601) ^ -1665044017;
					continue;
				case 9u:
					Delegate129.delegate129_0(dataGridViewCellStyle3, DataGridViewContentAlignment.MiddleLeft);
					num = ((int)num2 * -708920953) ^ 0x565BB437;
					continue;
				case 8u:
					componentResourceManager.ApplyResources(RichTextBox_0, global::_003CModule_003E.smethod_18<string>(2788488392u, 1717677234u));
					num = (int)(num2 * 1413556552) ^ -862986770;
					continue;
				case 7u:
					Delegate8.delegate8_196(Delegate7.delegate7_99(this), Delegate7.delegate7_118(this));
					num = (int)(num2 * 1627355349) ^ -1411151069;
					continue;
				case 6u:
					Delegate29.delegate29_3(dataGridViewCellStyle2, Delegate28.delegate28_1());
					Delegate8.delegate8_67(dataGridViewCellStyle2, Delegate43.delegate43_0(global::_003CModule_003E.smethod_19<string>(3973826599u, 2495001210u), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0));
					num = (int)(num2 * 802445701) ^ -1644725360;
					continue;
				case 5u:
					ToolStripMenuItem_10.Image = GClass0.Bitmap_58;
					num = (int)((num2 * 27408493) ^ 0x60DF0BE3);
					continue;
				case 4u:
					Delegate8.delegate8_77(Delegate7.delegate7_164(this), Delegate3.delegate3_81());
					num = ((int)num2 * -1874679689) ^ -1046251395;
					continue;
				case 3u:
					ToolStripButton_2.Image = GClass0.Bitmap_42;
					num = (int)((num2 * 129449418) ^ 0xD21B71);
					continue;
				case 2u:
					Delegate40.smethod_0(Delegate7.delegate7_22(Delegate7.delegate7_95(this)), new DataGridViewColumn[2]
					{
						(DataGridViewColumn)Delegate7.delegate7_171(this),
						(DataGridViewColumn)Delegate7.delegate7_172(this)
					});
					num = (int)(num2 * 46973287) ^ -1923909400;
					continue;
				case 1u:
					dataGridViewCellStyle = (DataGridViewCellStyle)Delegate3.delegate3_20();
					num = (int)(num2 * 1232354833) ^ -1328914049;
					continue;
				case 0u:
					Delegate30.delegate30_0(Delegate7.delegate7_148(this), global::_003CModule_003E.smethod_19<string>(865279303u, 193967671u));
					Delegate8.delegate8_12(Delegate7.delegate7_13(Delegate7.delegate7_145(Delegate7.delegate7_148(this))), Delegate7.delegate7_99(this));
					num = ((int)num2 * -473548045) ^ 0x3D9A29D1;
					continue;
				default:
					return;
				case 243u:
					break;
				case 203u:
					return;
				}
				break;
			}
		}
	}
}
