using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using ns1;

namespace Waircut;

[DesignerGenerated]
public class RandomPinForm : Form
{
	public enum GEnum6
	{
		None,
		Ok,
		NoOk,
		fHalfOk,
		Fault,
		ApLocked,
		PinNotFound,
		ApNotFound,
		AssociationFailed
	}

	public delegate void GDelegate11(GClass8.GEnum1 status);

	public delegate void GDelegate12(object sender, EventArgs e);

	private IContainer icontainer_0;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolStrip1")]
	private ToolStrip toolStrip_0;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolStripSeparator1")]
	private ToolStripSeparator toolStripSeparator_0;

	[CompilerGenerated]
	[AccessedThroughProperty("TbTime")]
	private ToolStripTextBox toolStripTextBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("TbStart")]
	private ToolStripButton toolStripButton_0;

	[CompilerGenerated]
	[AccessedThroughProperty("TbStop")]
	private ToolStripButton toolStripButton_1;

	[CompilerGenerated]
	[AccessedThroughProperty("TUpdate")]
	private Timer timer_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tsbOpen")]
	private ToolStripButton toolStripButton_2;

	[CompilerGenerated]
	[AccessedThroughProperty("ProgressBar1")]
	private Class12 class12_0;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvInfo")]
	private DataGridView dataGridView_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tsbSaveMenu")]
	private ToolStripDropDownButton toolStripDropDownButton_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tsbAutoSave")]
	private ToolStripMenuItem toolStripMenuItem_0;

	[CompilerGenerated]
	[AccessedThroughProperty("TsbSave")]
	private ToolStripMenuItem toolStripMenuItem_1;

	[CompilerGenerated]
	[AccessedThroughProperty("OpenFileDialog1")]
	private OpenFileDialog openFileDialog_0;

	[CompilerGenerated]
	[AccessedThroughProperty("SaveFileDialog1")]
	private SaveFileDialog saveFileDialog_0;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvDataCampo")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_0;

	[CompilerGenerated]
	[AccessedThroughProperty("DgvDataValor")]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_1;

	[CompilerGenerated]
	[AccessedThroughProperty("lbResult")]
	private Label label_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tsFormatMenu")]
	private ToolStrip toolStrip_1;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolStripLabel1")]
	private ToolStripLabel toolStripLabel_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tbPinFormat1")]
	private ToolStripTextBox toolStripTextBox_1;

	[CompilerGenerated]
	[AccessedThroughProperty("tsbCalculate")]
	private ToolStripButton toolStripButton_3;

	[CompilerGenerated]
	[AccessedThroughProperty("tbPinFormat2")]
	private ToolStripTextBox toolStripTextBox_2;

	private const int int_0 = 10000;

	private const int int_1 = 1000;

	private GClass13 gclass13_0;

	private GClass9 gclass9_0;

	private GClass12 gclass12_0;

	private string string_0;

	private bool bool_0;

	[CompilerGenerated]
	[AccessedThroughProperty("jsApi")]
	private GClass8 gclass8_0;

	private int int_2;

	private bool bool_1;

	private static bool bool_2 = false;

	private TimeSpan timeSpan_0;

	private TimeSpan timeSpan_1;

	private double double_0;

	private int int_3;

	private int int_4;

	private string string_1;

	private bool bool_3;

	private int int_5;

	private int int_6;

	private bool bool_4;

	private string string_2;

	private GEnum6 genum6_0;

	private GEnum6 genum6_1;

	private int int_7;

	private bool bool_5;

	private List<string> list_0;

	private bool bool_6;

	internal virtual ToolStrip ToolStrip_0
	{
		[CompilerGenerated]
		get
		{
			return toolStrip_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStrip_0 = value;
		}
	}

	internal virtual ToolStripSeparator ToolStripSeparator_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_0 = value;
		}
	}

	internal virtual ToolStripTextBox ToolStripTextBox_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripTextBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			KeyPressEventHandler object_ = method_22;
			ToolStripTextBox toolStripTextBox = default(ToolStripTextBox);
			while (true)
			{
				int num = 1813606277;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x1BE62908u) % 9)
					{
					case 8u:
					{
						int num5;
						int num6;
						if (toolStripTextBox == null)
						{
							num5 = -32168121;
							num6 = -32168121;
						}
						else
						{
							num5 = -1502332070;
							num6 = -1502332070;
						}
						num = num5 ^ (int)(num2 * 1031614158);
						continue;
					}
					case 7u:
						Delegate8.delegate8_216(toolStripTextBox, object_);
						num = (int)((num2 * 1710838309) ^ 0x7390B075);
						continue;
					case 4u:
						Delegate8.delegate8_214(toolStripTextBox, object_);
						num = (int)((num2 * 1474948684) ^ 0x58B2D50A);
						continue;
					case 3u:
						toolStripTextBox = toolStripTextBox_0;
						num = (int)((num2 * 1670103358) ^ 0x4B0CF98B);
						continue;
					case 2u:
					{
						int num3;
						int num4;
						if (toolStripTextBox != null)
						{
							num3 = 29090583;
							num4 = 29090583;
						}
						else
						{
							num3 = 1967458741;
							num4 = 1967458741;
						}
						num = num3 ^ (int)(num2 * 1598950419);
						continue;
					}
					case 1u:
						toolStripTextBox_0 = value;
						num = 832617944;
						continue;
					case 0u:
						toolStripTextBox = toolStripTextBox_0;
						num = (int)(num2 * 1658228440) ^ -517706029;
						continue;
					default:
						return;
					case 6u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripButton ToolStripButton_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_6;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = -1820715224;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x8F3FBCF9u) % 6)
					{
					case 5u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = ((int)num2 * -1454096681) ^ -456628916;
						continue;
					case 4u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = ((int)num2 * -1152654153) ^ 0x115F2614;
						continue;
					case 3u:
					{
						toolStripButton = toolStripButton_0;
						int num4;
						int num5;
						if (toolStripButton == null)
						{
							num4 = 668429230;
							num5 = 668429230;
						}
						else
						{
							num4 = 1374193539;
							num5 = 1374193539;
						}
						num = num4 ^ (int)(num2 * 1583632954);
						continue;
					}
					case 1u:
					{
						toolStripButton_0 = value;
						toolStripButton = toolStripButton_0;
						int num3;
						if (toolStripButton != null)
						{
							num = -369433894;
							num3 = -369433894;
						}
						else
						{
							num = -4002775;
							num3 = -4002775;
						}
						continue;
					}
					default:
						return;
					case 0u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripButton ToolStripButton_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_7;
			ToolStripButton toolStripButton = toolStripButton_1;
			while (true)
			{
				int num = -1445608035;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x91AE8EE3u) % 6)
					{
					case 5u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = (int)((num2 * 605530836) ^ 0x1275FCFB);
						continue;
					case 3u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = ((int)num2 * -1175757208) ^ 0x65D59FC4;
						continue;
					case 2u:
					{
						int num4;
						int num5;
						if (toolStripButton != null)
						{
							num4 = -255072288;
							num5 = -255072288;
						}
						else
						{
							num4 = -1063808460;
							num5 = -1063808460;
						}
						num = num4 ^ ((int)num2 * -960890564);
						continue;
					}
					case 1u:
					{
						toolStripButton_1 = value;
						toolStripButton = toolStripButton_1;
						int num3;
						if (toolStripButton == null)
						{
							num = -820343001;
							num3 = -820343001;
						}
						else
						{
							num = -1486604648;
							num3 = -1486604648;
						}
						continue;
					}
					default:
						return;
					case 4u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual Timer Timer_0
	{
		[CompilerGenerated]
		get
		{
			return timer_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_14;
			Timer timer = timer_0;
			while (true)
			{
				int num = -1688241941;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xD883B5C2u) % 8)
					{
					case 7u:
						Delegate8.delegate8_95(timer, object_);
						num = ((int)num2 * -969303765) ^ -1442967910;
						continue;
					case 4u:
						timer = timer_0;
						num = ((int)num2 * -2090156429) ^ 0x74800705;
						continue;
					case 3u:
					{
						int num5;
						int num6;
						if (timer != null)
						{
							num5 = 881814535;
							num6 = 881814535;
						}
						else
						{
							num5 = 266272213;
							num6 = 266272213;
						}
						num = num5 ^ (int)(num2 * 856298758);
						continue;
					}
					case 2u:
						timer_0 = value;
						num = -1807316738;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (timer != null)
						{
							num3 = 1207797518;
							num4 = 1207797518;
						}
						else
						{
							num3 = 668725132;
							num4 = 668725132;
						}
						num = num3 ^ ((int)num2 * -1196796372);
						continue;
					}
					case 0u:
						Delegate8.delegate8_94(timer, object_);
						num = (int)(num2 * 875138473) ^ -1760700608;
						continue;
					default:
						return;
					case 6u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripButton ToolStripButton_2
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_16;
			ToolStripButton toolStripButton = toolStripButton_2;
			while (true)
			{
				int num = 547429783;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xF8223B4u) % 7)
					{
					case 6u:
						toolStripButton_2 = value;
						toolStripButton = toolStripButton_2;
						num = 575998443;
						continue;
					case 5u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = ((int)num2 * -1418243236) ^ 0x2C2F8A97;
						continue;
					case 3u:
					{
						int num5;
						int num6;
						if (toolStripButton == null)
						{
							num5 = -1747392129;
							num6 = -1747392129;
						}
						else
						{
							num5 = -1259025638;
							num6 = -1259025638;
						}
						num = num5 ^ ((int)num2 * -1957746636);
						continue;
					}
					case 2u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = ((int)num2 * -1420763620) ^ 0x53AB928B;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (toolStripButton == null)
						{
							num3 = -1070689024;
							num4 = -1070689024;
						}
						else
						{
							num3 = -1641251359;
							num4 = -1641251359;
						}
						num = num3 ^ ((int)num2 * -1810297499);
						continue;
					}
					default:
						return;
					case 0u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual Class12 Class12_0
	{
		[CompilerGenerated]
		get
		{
			return class12_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			class12_0 = value;
		}
	}

	internal virtual DataGridView DataGridView_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridView_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridView_0 = value;
		}
	}

	internal virtual ToolStripDropDownButton ToolStripDropDownButton_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripDropDownButton_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_18;
			ToolStripDropDownButton toolStripDropDownButton = default(ToolStripDropDownButton);
			while (true)
			{
				int num = -782358877;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xF3783643u) % 7)
					{
					case 6u:
					{
						toolStripDropDownButton = toolStripDropDownButton_0;
						int num5;
						int num6;
						if (toolStripDropDownButton != null)
						{
							num5 = -1957367970;
							num6 = -1957367970;
						}
						else
						{
							num5 = -1243222784;
							num6 = -1243222784;
						}
						num = num5 ^ (int)(num2 * 1207945759);
						continue;
					}
					case 5u:
						Delegate8.delegate8_89(toolStripDropDownButton, object_);
						num = (int)((num2 * 1026357799) ^ 0x633201F3);
						continue;
					case 3u:
					{
						int num3;
						int num4;
						if (toolStripDropDownButton != null)
						{
							num3 = 1531207053;
							num4 = 1531207053;
						}
						else
						{
							num3 = 2053056101;
							num4 = 2053056101;
						}
						num = num3 ^ (int)(num2 * 280690838);
						continue;
					}
					case 2u:
						Delegate8.delegate8_88(toolStripDropDownButton, object_);
						num = ((int)num2 * -1188850583) ^ 0x68E09925;
						continue;
					case 0u:
						toolStripDropDownButton_0 = value;
						toolStripDropDownButton = toolStripDropDownButton_0;
						num = -599000900;
						continue;
					default:
						return;
					case 4u:
						break;
					case 1u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_21;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = 1734094351;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x6752340Cu) % 7)
					{
					case 5u:
					{
						toolStripMenuItem_0 = value;
						toolStripMenuItem = toolStripMenuItem_0;
						int num5;
						if (toolStripMenuItem == null)
						{
							num = 357479928;
							num5 = 357479928;
						}
						else
						{
							num = 1192750113;
							num5 = 1192750113;
						}
						continue;
					}
					case 4u:
						Delegate8.delegate8_278(toolStripMenuItem, object_);
						num = ((int)num2 * -290659105) ^ -31674697;
						continue;
					case 3u:
					{
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = -437461544;
							num4 = -437461544;
						}
						else
						{
							num3 = -1394558915;
							num4 = -1394558915;
						}
						num = num3 ^ ((int)num2 * -1594756306);
						continue;
					}
					case 2u:
						toolStripMenuItem = toolStripMenuItem_0;
						num = (int)(num2 * 253956672) ^ -290052341;
						continue;
					case 1u:
						Delegate8.delegate8_279(toolStripMenuItem, object_);
						num = (int)((num2 * 1870605435) ^ 0x51472C67);
						continue;
					default:
						return;
					case 0u:
						break;
					case 6u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripMenuItem ToolStripMenuItem_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripMenuItem_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_17;
			ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
			while (true)
			{
				int num = -1828918497;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xFEE4846Cu) % 8)
					{
					case 7u:
						toolStripMenuItem_1 = value;
						num = -250879250;
						continue;
					case 6u:
					{
						int num5;
						int num6;
						if (toolStripMenuItem != null)
						{
							num5 = -319809923;
							num6 = -319809923;
						}
						else
						{
							num5 = -1387898711;
							num6 = -1387898711;
						}
						num = num5 ^ ((int)num2 * -1456712306);
						continue;
					}
					case 5u:
						Delegate8.delegate8_89(toolStripMenuItem, object_);
						num = ((int)num2 * -1772981127) ^ -794182272;
						continue;
					case 4u:
						Delegate8.delegate8_88(toolStripMenuItem, object_);
						num = ((int)num2 * -321067025) ^ 0x10EEB3FF;
						continue;
					case 3u:
					{
						toolStripMenuItem = toolStripMenuItem_1;
						int num3;
						int num4;
						if (toolStripMenuItem == null)
						{
							num3 = -1459883783;
							num4 = -1459883783;
						}
						else
						{
							num3 = -343279918;
							num4 = -343279918;
						}
						num = num3 ^ ((int)num2 * -133869954);
						continue;
					}
					case 2u:
						toolStripMenuItem = toolStripMenuItem_1;
						num = (int)((num2 * 841445973) ^ 0x2902EF78);
						continue;
					default:
						return;
					case 0u:
						break;
					case 1u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual OpenFileDialog OpenFileDialog_0
	{
		[CompilerGenerated]
		get
		{
			return openFileDialog_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			openFileDialog_0 = value;
		}
	}

	internal virtual SaveFileDialog SaveFileDialog_0
	{
		[CompilerGenerated]
		get
		{
			return saveFileDialog_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			saveFileDialog_0 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_0 = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_1
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_1 = value;
		}
	}

	internal virtual Label Label_0
	{
		[CompilerGenerated]
		get
		{
			return label_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			label_0 = value;
		}
	}

	internal virtual ToolStrip ToolStrip_1
	{
		[CompilerGenerated]
		get
		{
			return toolStrip_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStrip_1 = value;
		}
	}

	internal virtual ToolStripLabel ToolStripLabel_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripLabel_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripLabel_0 = value;
		}
	}

	internal virtual ToolStripTextBox ToolStripTextBox_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripTextBox_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			KeyPressEventHandler object_ = method_8;
			ToolStripTextBox toolStripTextBox = default(ToolStripTextBox);
			while (true)
			{
				int num = -1348821993;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x8F776825u) % 8)
					{
					case 7u:
					{
						int num5;
						int num6;
						if (toolStripTextBox == null)
						{
							num5 = 443448862;
							num6 = 443448862;
						}
						else
						{
							num5 = 1030045074;
							num6 = 1030045074;
						}
						num = num5 ^ ((int)num2 * -1377635862);
						continue;
					}
					case 6u:
						Delegate8.delegate8_214(toolStripTextBox, object_);
						num = (int)(num2 * 1289534512) ^ -1710708175;
						continue;
					case 4u:
						toolStripTextBox_1 = value;
						num = -2135810955;
						continue;
					case 2u:
					{
						toolStripTextBox = toolStripTextBox_1;
						int num3;
						int num4;
						if (toolStripTextBox == null)
						{
							num3 = -1926385437;
							num4 = -1926385437;
						}
						else
						{
							num3 = -866499831;
							num4 = -866499831;
						}
						num = num3 ^ (int)(num2 * 76298401);
						continue;
					}
					case 1u:
						Delegate8.delegate8_216(toolStripTextBox, object_);
						num = ((int)num2 * -1913577090) ^ 0x559633C6;
						continue;
					case 0u:
						toolStripTextBox = toolStripTextBox_1;
						num = ((int)num2 * -1516122996) ^ 0x2EF56E52;
						continue;
					default:
						return;
					case 3u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripButton ToolStripButton_3
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_10;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = 976723999;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x7E3A72D4u) % 7)
					{
					case 6u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = (int)(num2 * 1230422620) ^ -853156994;
						continue;
					case 5u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = (int)((num2 * 1607241908) ^ 0x3CA2B95B);
						continue;
					case 4u:
					{
						toolStripButton = toolStripButton_3;
						int num5;
						int num6;
						if (toolStripButton == null)
						{
							num5 = -102406179;
							num6 = -102406179;
						}
						else
						{
							num5 = -1665799763;
							num6 = -1665799763;
						}
						num = num5 ^ ((int)num2 * -1572117742);
						continue;
					}
					case 3u:
					{
						toolStripButton = toolStripButton_3;
						int num3;
						int num4;
						if (toolStripButton == null)
						{
							num3 = 2088256648;
							num4 = 2088256648;
						}
						else
						{
							num3 = 981705413;
							num4 = 981705413;
						}
						num = num3 ^ ((int)num2 * -1970955610);
						continue;
					}
					case 1u:
						toolStripButton_3 = value;
						num = 2110604337;
						continue;
					default:
						return;
					case 0u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripTextBox ToolStripTextBox_2
	{
		[CompilerGenerated]
		get
		{
			return toolStripTextBox_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			KeyPressEventHandler object_ = method_9;
			ToolStripTextBox toolStripTextBox = default(ToolStripTextBox);
			while (true)
			{
				int num = 275613712;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x54EA152Du) % 7)
					{
					case 5u:
					{
						toolStripTextBox = toolStripTextBox_2;
						int num5;
						int num6;
						if (toolStripTextBox == null)
						{
							num5 = 940973836;
							num6 = 940973836;
						}
						else
						{
							num5 = 1613595679;
							num6 = 1613595679;
						}
						num = num5 ^ (int)(num2 * 27342513);
						continue;
					}
					case 4u:
						Delegate8.delegate8_214(toolStripTextBox, object_);
						num = ((int)num2 * -754915984) ^ -592706895;
						continue;
					case 2u:
					{
						int num3;
						int num4;
						if (toolStripTextBox == null)
						{
							num3 = 1416224915;
							num4 = 1416224915;
						}
						else
						{
							num3 = 1310517868;
							num4 = 1310517868;
						}
						num = num3 ^ ((int)num2 * -574622770);
						continue;
					}
					case 1u:
						Delegate8.delegate8_216(toolStripTextBox, object_);
						num = (int)((num2 * 914475923) ^ 0x17D2A240);
						continue;
					case 0u:
						toolStripTextBox_2 = value;
						toolStripTextBox = toolStripTextBox_2;
						num = 540506821;
						continue;
					default:
						return;
					case 3u:
						break;
					case 6u:
						return;
					}
					break;
				}
			}
		}
	}

	private virtual GClass8 GClass8_0
	{
		[CompilerGenerated]
		get
		{
			return gclass8_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			GClass8.GDelegate8 object_ = method_11;
			GClass8 gClass = default(GClass8);
			while (true)
			{
				int num = -401445457;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xC577E352u) % 9)
					{
					case 8u:
					{
						int num5;
						int num6;
						if (gClass == null)
						{
							num5 = 533804011;
							num6 = 533804011;
						}
						else
						{
							num5 = 275028456;
							num6 = 275028456;
						}
						num = num5 ^ ((int)num2 * -1540364168);
						continue;
					}
					case 7u:
						gClass = gclass8_0;
						num = (int)(num2 * 146090515) ^ -1883142502;
						continue;
					case 5u:
					{
						int num3;
						int num4;
						if (gClass != null)
						{
							num3 = 993706347;
							num4 = 993706347;
						}
						else
						{
							num3 = 1441450711;
							num4 = 1441450711;
						}
						num = num3 ^ ((int)num2 * -373941120);
						continue;
					}
					case 4u:
						Delegate8.delegate8_102(gClass, object_);
						num = ((int)num2 * -1385137289) ^ 0x69A786A8;
						continue;
					case 3u:
						Delegate8.delegate8_104(gClass, object_);
						num = (int)((num2 * 728193061) ^ 0x39F25309);
						continue;
					case 2u:
						gClass = gclass8_0;
						num = (int)((num2 * 331802039) ^ 0x2A74BC3A);
						continue;
					case 1u:
						gclass8_0 = value;
						num = -275056310;
						continue;
					default:
						return;
					case 0u:
						break;
					case 6u:
						return;
					}
					break;
				}
			}
		}
	}

	[DebuggerNonUserCode]
	void Form.Dispose(bool disposing)
	{
		try
		{
			if (!disposing)
			{
				return;
			}
			while (true)
			{
				int num = -1316202548;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xBE76D457u) % 4)
					{
					case 3u:
					{
						int num3;
						int num4;
						if (icontainer_0 == null)
						{
							num3 = -762172246;
							num4 = -762172246;
						}
						else
						{
							num3 = -1586741093;
							num4 = -1586741093;
						}
						num = num3 ^ (int)(num2 * 1192653908);
						continue;
					}
					case 0u:
						Delegate22.delegate22_4(icontainer_0);
						num = ((int)num2 * -739558026) ^ -59134698;
						continue;
					default:
						return;
					case 2u:
						break;
					case 1u:
						return;
					}
					break;
				}
			}
		}
		finally
		{
			Delegate5.delegate5_3(this, disposing);
		}
	}

	[DebuggerStepThrough]
	private void method_0()
	{
		icontainer_0 = (IContainer)Delegate3.delegate3_19();
		ComponentResourceManager object_ = (ComponentResourceManager)Delegate7.delegate7_4(Delegate9.delegate9_0(typeof(RandomPinForm).TypeHandle));
		DataGridViewCellStyle dataGridViewCellStyle = (DataGridViewCellStyle)Delegate3.delegate3_20();
		DataGridViewCellStyle dataGridViewCellStyle2 = (DataGridViewCellStyle)Delegate3.delegate3_20();
		DataGridViewCellStyle dataGridViewCellStyle3 = default(DataGridViewCellStyle);
		while (true)
		{
			int num = -1936669237;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xCB5702F2u) % 87)
				{
				case 86u:
					Delegate8.delegate8_272(this, Delegate3.delegate3_25());
					num = (int)((num2 * 1907215033) ^ 0x71170543);
					continue;
				case 85u:
					Delegate30.delegate30_6(Delegate7.delegate7_223(this), global::_003CModule_003E.smethod_21<string>(3855080092u, 4256254516u));
					Delegate5.delegate5_15(Delegate7.delegate7_223(this), bool_0: true);
					Delegate44.delegate44_0(Delegate7.delegate7_224(this), DataGridViewAutoSizeColumnMode.Fill);
					Delegate27.delegate27_0(object_, Delegate7.delegate7_224(this), global::_003CModule_003E.smethod_21<string>(1098128384u, 712272211u));
					Delegate30.delegate30_6(Delegate7.delegate7_224(this), global::_003CModule_003E.smethod_22<string>(589692230u, 906762918u));
					Delegate5.delegate5_15(Delegate7.delegate7_224(this), bool_0: true);
					Delegate30.delegate30_21(Delegate7.delegate7_225(this), global::_003CModule_003E.smethod_18<string>(2004818649u, 169659735u));
					num = ((int)num2 * -1436724430) ^ 0x374AF94B;
					continue;
				case 84u:
					Delegate8.delegate8_260(this, Delegate3.delegate3_26());
					num = ((int)num2 * -1716721533) ^ 0xDAA6E15;
					continue;
				case 83u:
					Delegate8.delegate8_265(this, Delegate3.delegate3_21());
					num = (int)(num2 * 502869098) ^ -379812762;
					continue;
				case 82u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_220(this), global::_003CModule_003E.smethod_22<string>(677098683u, 139632259u));
					Delegate5.delegate5_48(Delegate7.delegate7_221(this), bool_0: true);
					num = ((int)num2 * -942716319) ^ -1315226743;
					continue;
				case 81u:
					Delegate8.delegate8_266(this, Delegate3.delegate3_23());
					Delegate8.delegate8_267(this, Delegate3.delegate3_23());
					num = ((int)num2 * -932627573) ^ -388725727;
					continue;
				case 80u:
					Delegate5.delegate5_9(this, bool_0: false);
					num = ((int)num2 * -1538346470) ^ 0x63A5FD38;
					continue;
				case 79u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_227(this), global::_003CModule_003E.smethod_20<string>(2608985914u, 2443526513u));
					Delegate29.delegate29_0(Delegate7.delegate7_227(this), Delegate28.delegate28_1());
					num = (int)((num2 * 1129268355) ^ 0x35C2A825);
					continue;
				case 78u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_229(this), global::_003CModule_003E.smethod_21<string>(1362069057u, 1378268727u));
					num = ((int)num2 * -119415773) ^ 0x4E314F6C;
					continue;
				case 77u:
					Delegate30.delegate30_1(Delegate7.delegate7_217(this), global::_003CModule_003E.smethod_20<string>(2721978092u, 537583409u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_217(this), global::_003CModule_003E.smethod_19<string>(108706550u, 50540980u));
					num = ((int)num2 * -1001172034) ^ 0x162AFC6D;
					continue;
				case 76u:
					Delegate30.delegate30_1(Delegate7.delegate7_215(this), global::_003CModule_003E.smethod_19<string>(1375328861u, 3048008980u));
					Delegate8.delegate8_77(Delegate7.delegate7_220(this), Delegate3.delegate3_103());
					num = (int)((num2 * 697796292) ^ 0x10267CCE);
					continue;
				case 75u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_219(this), global::_003CModule_003E.smethod_18<string>(3143130719u, 4109586123u));
					Delegate8.delegate8_77(Delegate7.delegate7_219(this), Delegate3.delegate3_95());
					num = ((int)num2 * -56467622) ^ 0x536797E;
					continue;
				case 74u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_218(this), global::_003CModule_003E.smethod_21<string>(3118166075u, 185812735u));
					num = ((int)num2 * -1692169250) ^ 0x17027F7D;
					continue;
				case 73u:
					Delegate30.delegate30_0(Delegate7.delegate7_213(this), global::_003CModule_003E.smethod_21<string>(3306396685u, 2030903680u));
					num = ((int)num2 * -1500285477) ^ -329874730;
					continue;
				case 72u:
					Delegate31.smethod_0(Delegate7.delegate7_163(Delegate7.delegate7_215(this)), new ToolStripItem[2]
					{
						(ToolStripItem)Delegate7.delegate7_220(this),
						(ToolStripItem)Delegate7.delegate7_221(this)
					});
					num = ((int)num2 * -1476841468) ^ -497168895;
					continue;
				case 71u:
					Delegate31.smethod_0(Delegate7.delegate7_10(Delegate7.delegate7_211(this)), new ToolStripItem[6]
					{
						(ToolStripItem)Delegate7.delegate7_214(this),
						(ToolStripItem)Delegate7.delegate7_215(this),
						(ToolStripItem)Delegate7.delegate7_216(this),
						(ToolStripItem)Delegate7.delegate7_217(this),
						(ToolStripItem)Delegate7.delegate7_218(this),
						(ToolStripItem)Delegate7.delegate7_219(this)
					});
					num = ((int)num2 * -214011853) ^ -615859549;
					continue;
				case 70u:
					Delegate8.delegate8_77(Delegate7.delegate7_231(this), Delegate3.delegate3_104());
					num = (int)((num2 * 629834079) ^ 0x357B4E92);
					continue;
				case 69u:
					Delegate5.delegate5_49(Delegate7.delegate7_221(this), bool_0: true);
					Delegate175.delegate175_0(Delegate7.delegate7_221(this), CheckState.Checked);
					num = ((int)num2 * -60081582) ^ -1938341756;
					continue;
				case 68u:
					Delegate22.delegate22_5(Delegate7.delegate7_211(this));
					Delegate22.delegate22_6(Delegate7.delegate7_212(this));
					Delegate22.delegate22_5(Delegate7.delegate7_213(this));
					num = ((int)num2 * -1284976091) ^ -1333637134;
					continue;
				case 67u:
					Delegate8.delegate8_261(this, Delegate3.delegate3_27());
					Delegate8.delegate8_262(this, Delegate3.delegate3_24());
					num = ((int)num2 * -1741582169) ^ -885001625;
					continue;
				case 66u:
					Delegate8.delegate8_197(Delegate7.delegate7_212(this), dataGridViewCellStyle2);
					num = (int)(num2 * 897487669) ^ -183156247;
					continue;
				case 65u:
					Delegate8.delegate8_259(this, Delegate3.delegate3_66());
					num = (int)(num2 * 672693060) ^ -1537696854;
					continue;
				case 64u:
					Delegate8.delegate8_67(dataGridViewCellStyle2, Delegate43.delegate43_0(global::_003CModule_003E.smethod_20<string>(490860945u, 2471896715u), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0));
					Delegate29.delegate29_5(dataGridViewCellStyle2, Delegate28.delegate28_12());
					num = ((int)num2 * -1117692349) ^ -1581729197;
					continue;
				case 63u:
					Delegate167.delegate167_1(Delegate7.delegate7_232(this), ProgressBarStyle.Continuous);
					Delegate27.delegate27_0(object_, this, global::_003CModule_003E.smethod_22<string>(1388348538u, 1590357056u));
					num = ((int)num2 * -1619674202) ^ 0x60F1F781;
					continue;
				case 62u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_213(this));
					num = ((int)num2 * -1040812104) ^ -568347417;
					continue;
				case 61u:
					Delegate22.delegate22_8(Delegate7.delegate7_213(this));
					Delegate5.delegate5_11(this, bool_0: false);
					num = (int)(num2 * 784837900) ^ -1814836243;
					continue;
				case 60u:
					Delegate8.delegate8_273(this, Delegate3.delegate3_27());
					num = (int)((num2 * 1082033161) ^ 0x9CBAE78);
					continue;
				case 59u:
					Delegate8.delegate8_277(Delegate7.delegate7_229(this), "");
					Delegate27.delegate27_0(object_, Delegate7.delegate7_230(this), global::_003CModule_003E.smethod_19<string>(857237645u, 3333732202u));
					num = ((int)num2 * -1210501108) ^ -832977894;
					continue;
				case 58u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_216(this), global::_003CModule_003E.smethod_20<string>(4148273493u, 1020403333u));
					num = (int)((num2 * 734844995) ^ 0x166409CD);
					continue;
				case 57u:
					Delegate8.delegate8_269(this, Delegate3.delegate3_100());
					num = ((int)num2 * -1671895988) ^ -1529386283;
					continue;
				case 56u:
					Delegate5.delegate5_39(Delegate7.delegate7_212(this), bool_0: false);
					num = (int)(num2 * 311380425) ^ -820742850;
					continue;
				case 55u:
					Delegate29.delegate29_10(Delegate7.delegate7_229(this), Delegate28.delegate28_28());
					Delegate30.delegate30_1(Delegate7.delegate7_229(this), global::_003CModule_003E.smethod_19<string>(85715697u, 3771897857u));
					num = ((int)num2 * -1417570513) ^ -687429889;
					continue;
				case 54u:
					Delegate29.delegate29_11(Delegate7.delegate7_232(this), Delegate28.delegate28_22());
					num = ((int)num2 * -817771351) ^ -501511169;
					continue;
				case 53u:
					Delegate29.delegate29_7(dataGridViewCellStyle2, Delegate28.delegate28_13());
					Delegate29.delegate29_8(dataGridViewCellStyle2, Delegate28.delegate28_14());
					Delegate130.delegate130_0(dataGridViewCellStyle2, DataGridViewTriState.False);
					num = (int)((num2 * 1014754356) ^ 0x2369E9C9);
					continue;
				case 52u:
					Delegate35.delegate35_0(this, FormBorderStyle.FixedSingle);
					num = ((int)num2 * -36449393) ^ -1726799124;
					continue;
				case 51u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_232(this), global::_003CModule_003E.smethod_20<string>(4217073755u, 3440171205u));
					Delegate29.delegate29_0(Delegate7.delegate7_232(this), Delegate28.delegate28_29());
					num = (int)((num2 * 251858006) ^ 0x744DAADA);
					continue;
				case 50u:
					Delegate45.delegate45_0(Delegate7.delegate7_211(this), ToolStripGripStyle.Hidden);
					num = (int)(num2 * 1075771617) ^ -1334833326;
					continue;
				case 49u:
					Delegate5.delegate5_7(this, bool_0: false);
					Delegate5.delegate5_8(this, bool_0: false);
					Delegate30.delegate30_2(this, global::_003CModule_003E.smethod_18<string>(1021162546u, 3586717055u));
					num = (int)(num2 * 1095629818) ^ -374297468;
					continue;
				case 48u:
					Delegate39.delegate39_0(Delegate7.delegate7_212(this), DataGridViewColumnHeadersHeightSizeMode.AutoSize);
					num = (int)((num2 * 167570492) ^ 0x75E7393E);
					continue;
				case 47u:
					Delegate46.delegate46_0(Delegate7.delegate7_231(this), ToolStripItemDisplayStyle.Image);
					num = (int)((num2 * 31004023) ^ 0x36B636A7);
					continue;
				case 46u:
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_211(this));
					num = (int)((num2 * 74782706) ^ 0x3C1D2973);
					continue;
				case 45u:
					Delegate5.delegate5_12(Delegate7.delegate7_212(this), bool_0: false);
					Delegate5.delegate5_13(Delegate7.delegate7_212(this), bool_0: false);
					num = (int)((num2 * 2350453) ^ 0x6AB1494A);
					continue;
				case 44u:
					Delegate8.delegate8_275(this, Delegate3.delegate3_24());
					num = (int)(num2 * 1435678486) ^ -2032120616;
					continue;
				case 43u:
					Delegate30.delegate30_1(Delegate7.delegate7_218(this), global::_003CModule_003E.smethod_21<string>(3118166075u, 3453941371u));
					num = (int)((num2 * 447343348) ^ 0x257AD7DA);
					continue;
				case 42u:
					Delegate30.delegate30_1(Delegate7.delegate7_221(this), global::_003CModule_003E.smethod_20<string>(1612255472u, 1601150181u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_221(this), global::_003CModule_003E.smethod_18<string>(1434099497u, 1572663792u));
					num = ((int)num2 * -33042039) ^ -1320680288;
					continue;
				case 40u:
					Delegate30.delegate30_0(Delegate7.delegate7_232(this), global::_003CModule_003E.smethod_21<string>(1449301629u, 586203444u));
					num = (int)(num2 * 2074724843) ^ -1777096068;
					continue;
				case 39u:
					Delegate41.delegate41_0(Delegate7.delegate7_212(this), DataGridViewSelectionMode.FullRowSelect);
					num = ((int)num2 * -1371922987) ^ 0x452BC5DB;
					continue;
				case 38u:
					Delegate8.delegate8_257(this, Delegate3.delegate3_72());
					Delegate8.delegate8_258(this, Delegate3.delegate3_66());
					num = ((int)num2 * -440260603) ^ 0x5615F91B;
					continue;
				case 37u:
					Delegate29.delegate29_10(Delegate7.delegate7_230(this), Delegate28.delegate28_28());
					num = (int)((num2 * 600453044) ^ 0x629B96D5);
					continue;
				case 36u:
					Delegate5.delegate5_10(Delegate7.delegate7_211(this), bool_0: false);
					num = ((int)num2 * -518001287) ^ 0x46042DFA;
					continue;
				case 35u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_223(this), global::_003CModule_003E.smethod_18<string>(1291396555u, 873704504u));
					num = ((int)num2 * -746441866) ^ -1939812973;
					continue;
				case 34u:
					dataGridViewCellStyle3 = (DataGridViewCellStyle)Delegate3.delegate3_20();
					Delegate8.delegate8_255(this, Delegate3.delegate3_67());
					Delegate8.delegate8_256(this, Delegate3.delegate3_24());
					num = (int)(num2 * 626046107) ^ -1142548734;
					continue;
				case 33u:
					Delegate34.delegate34_0(this, AutoScaleMode.Font);
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_227(this));
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_212(this));
					Delegate8.delegate8_12(Delegate7.delegate7_14(this), Delegate7.delegate7_232(this));
					num = (int)(num2 * 1819813496) ^ -1648424797;
					continue;
				case 32u:
					Delegate30.delegate30_22(Delegate7.delegate7_225(this), global::_003CModule_003E.smethod_20<string>(2239078374u, 3936109733u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_225(this), global::_003CModule_003E.smethod_19<string>(2641951172u, 1637750914u));
					num = (int)((num2 * 1121215087) ^ 0x4DF21F34);
					continue;
				case 31u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_213(this), global::_003CModule_003E.smethod_20<string>(2737443595u, 701192232u));
					num = (int)(num2 * 1310656777) ^ -1653456640;
					continue;
				case 29u:
					Delegate8.delegate8_268(this, Delegate3.delegate3_99());
					num = (int)((num2 * 142535565) ^ 0xF825E73);
					continue;
				case 28u:
					Delegate8.delegate8_66(Delegate7.delegate7_212(this), dataGridViewCellStyle);
					Delegate29.delegate29_9(Delegate7.delegate7_212(this), Delegate28.delegate28_5());
					num = (int)((num2 * 953463290) ^ 0x42363320);
					continue;
				case 27u:
					Delegate8.delegate8_77(Delegate7.delegate7_214(this), Delegate3.delegate3_102());
					Delegate27.delegate27_0(object_, Delegate7.delegate7_214(this), global::_003CModule_003E.smethod_21<string>(2167810404u, 3287804140u));
					Delegate30.delegate30_1(Delegate7.delegate7_214(this), global::_003CModule_003E.smethod_20<string>(3204877810u, 3351925330u));
					Delegate46.delegate46_0(Delegate7.delegate7_215(this), ToolStripItemDisplayStyle.Image);
					num = (int)(num2 * 1962264059) ^ -860639272;
					continue;
				case 26u:
					Delegate22.delegate22_7(this);
					num = (int)((num2 * 678537147) ^ 0x2AC3412F);
					continue;
				case 25u:
					Delegate8.delegate8_77(Delegate7.delegate7_215(this), Delegate3.delegate3_103());
					num = ((int)num2 * -1059785346) ^ 0x6AA06010;
					continue;
				case 24u:
					Delegate30.delegate30_1(Delegate7.delegate7_216(this), global::_003CModule_003E.smethod_22<string>(3547900489u, 3103065222u));
					num = ((int)num2 * -1007128543) ^ 0x33D07C7D;
					continue;
				case 23u:
					Delegate8.delegate8_276(this, Delegate3.delegate3_101());
					num = ((int)num2 * -399187366) ^ 0x659F414;
					continue;
				case 22u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_231(this), global::_003CModule_003E.smethod_20<string>(3107351135u, 431826635u));
					Delegate30.delegate30_1(Delegate7.delegate7_231(this), global::_003CModule_003E.smethod_18<string>(3970567738u, 4250562683u));
					num = (int)(num2 * 1904124100) ^ -1427670347;
					continue;
				case 21u:
					Delegate8.delegate8_263(this, Delegate3.delegate3_24());
					Delegate8.delegate8_264(this, Delegate7.delegate7_18(icontainer_0));
					num = ((int)num2 * -2046806238) ^ 0x2E26D44;
					continue;
				case 20u:
					Delegate5.delegate5_35(Delegate7.delegate7_212(this), bool_0: false);
					Delegate5.delegate5_36(Delegate7.delegate7_212(this), bool_0: false);
					Delegate29.delegate29_3(dataGridViewCellStyle, Delegate28.delegate28_15());
					num = ((int)num2 * -221043424) ^ 0x1C5A5DD;
					continue;
				case 19u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_212(this), global::_003CModule_003E.smethod_19<string>(2319547881u, 835278684u));
					Delegate5.delegate5_37(Delegate7.delegate7_212(this), bool_0: false);
					Delegate30.delegate30_0(Delegate7.delegate7_212(this), global::_003CModule_003E.smethod_21<string>(2581005177u, 3747538753u));
					Delegate5.delegate5_14(Delegate7.delegate7_212(this), bool_0: true);
					num = ((int)num2 * -1628926483) ^ 0x313BA0F;
					continue;
				case 18u:
					Delegate30.delegate30_1(Delegate7.delegate7_228(this), global::_003CModule_003E.smethod_18<string>(3416490962u, 2316108096u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_228(this), global::_003CModule_003E.smethod_22<string>(2988707811u, 2811053644u));
					num = (int)(num2 * 1471929798) ^ -31681692;
					continue;
				case 17u:
					Delegate30.delegate30_1(Delegate7.delegate7_220(this), global::_003CModule_003E.smethod_22<string>(677098683u, 1649180306u));
					num = ((int)num2 * -2122343079) ^ -468768368;
					continue;
				case 16u:
					Delegate30.delegate30_1(Delegate7.delegate7_219(this), global::_003CModule_003E.smethod_18<string>(3143130719u, 1237529234u));
					Delegate32.delegate32_1(Delegate7.delegate7_222(this), 1000);
					num = (int)((num2 * 931399139) ^ 0x1968AC09);
					continue;
				case 15u:
					Delegate30.delegate30_23(Delegate7.delegate7_225(this), global::_003CModule_003E.smethod_22<string>(1593439617u, 3208045927u));
					Delegate30.delegate30_21(Delegate7.delegate7_226(this), global::_003CModule_003E.smethod_22<string>(3677486840u, 94159543u));
					Delegate27.delegate27_0(object_, Delegate7.delegate7_226(this), global::_003CModule_003E.smethod_19<string>(1029934717u, 794301425u));
					num = (int)(num2 * 328773296) ^ -1291592915;
					continue;
				case 14u:
					Delegate40.smethod_0(Delegate7.delegate7_22(Delegate7.delegate7_212(this)), new DataGridViewColumn[2]
					{
						(DataGridViewColumn)Delegate7.delegate7_223(this),
						(DataGridViewColumn)Delegate7.delegate7_224(this)
					});
					Delegate129.delegate129_0(dataGridViewCellStyle2, DataGridViewContentAlignment.MiddleLeft);
					Delegate29.delegate29_3(dataGridViewCellStyle2, Delegate28.delegate28_16());
					num = (int)(num2 * 1383985929) ^ -1273798688;
					continue;
				case 13u:
					Delegate5.delegate5_50(Delegate7.delegate7_212(this), bool_0: true);
					Delegate8.delegate8_67(dataGridViewCellStyle3, Delegate43.delegate43_0(global::_003CModule_003E.smethod_18<string>(2998864660u, 1947244851u), 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0));
					Delegate8.delegate8_68(Delegate7.delegate7_223(this), dataGridViewCellStyle3);
					num = ((int)num2 * -1210842212) ^ -1172794876;
					continue;
				case 12u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_215(this), global::_003CModule_003E.smethod_20<string>(3333335491u, 995588684u));
					num = ((int)num2 * -194976068) ^ -1240493386;
					continue;
				case 11u:
					Delegate5.delegate5_40(Delegate7.delegate7_212(this), bool_0: false);
					num = ((int)num2 * -1517720446) ^ -447928741;
					continue;
				case 10u:
					Delegate30.delegate30_23(Delegate7.delegate7_226(this), global::_003CModule_003E.smethod_22<string>(1593439617u, 557220751u));
					num = ((int)num2 * -783418588) ^ -1142711604;
					continue;
				case 9u:
					Delegate22.delegate22_8(Delegate7.delegate7_211(this));
					Delegate22.delegate22_9(Delegate7.delegate7_212(this));
					Delegate5.delegate5_10(Delegate7.delegate7_213(this), bool_0: false);
					num = ((int)num2 * -1275406797) ^ 0x615B35BC;
					continue;
				case 8u:
					Delegate8.delegate8_270(this, Delegate3.delegate3_9());
					Delegate8.delegate8_271(this, Delegate3.delegate3_67());
					num = (int)(num2 * 1448739333) ^ -1726028746;
					continue;
				case 7u:
					Delegate8.delegate8_274(this, Delegate3.delegate3_27());
					num = (int)(num2 * 391290903) ^ -1219369329;
					continue;
				case 6u:
					Delegate27.delegate27_0(object_, Delegate7.delegate7_211(this), global::_003CModule_003E.smethod_19<string>(3298518855u, 3163060940u));
					Delegate30.delegate30_0(Delegate7.delegate7_211(this), global::_003CModule_003E.smethod_22<string>(3755038757u, 947079175u));
					Delegate46.delegate46_0(Delegate7.delegate7_214(this), ToolStripItemDisplayStyle.Image);
					num = (int)(num2 * 1698371438) ^ -253103373;
					continue;
				case 5u:
					Delegate30.delegate30_0(Delegate7.delegate7_227(this), global::_003CModule_003E.smethod_22<string>(3804359690u, 4139823194u));
					Delegate45.delegate45_0(Delegate7.delegate7_213(this), ToolStripGripStyle.Hidden);
					Delegate31.smethod_0(Delegate7.delegate7_10(Delegate7.delegate7_213(this)), new ToolStripItem[4]
					{
						(ToolStripItem)Delegate7.delegate7_228(this),
						(ToolStripItem)Delegate7.delegate7_229(this),
						(ToolStripItem)Delegate7.delegate7_230(this),
						(ToolStripItem)Delegate7.delegate7_231(this)
					});
					num = (int)(num2 * 722139280) ^ -1273587597;
					continue;
				case 4u:
					Delegate29.delegate29_2(Delegate7.delegate7_227(this), Delegate28.delegate28_22());
					num = ((int)num2 * -2105524366) ^ -124181419;
					continue;
				case 3u:
					Delegate8.delegate8_77(Delegate7.delegate7_218(this), Delegate3.delegate3_94());
					num = ((int)num2 * -187071079) ^ -1284429602;
					continue;
				case 2u:
					Delegate30.delegate30_1(Delegate7.delegate7_230(this), global::_003CModule_003E.smethod_20<string>(3477258675u, 4127092384u));
					num = (int)(num2 * 1273917999) ^ -183624896;
					continue;
				case 1u:
					Delegate5.delegate5_38(Delegate7.delegate7_212(this), bool_0: false);
					num = ((int)num2 * -287064696) ^ 0xD296C93;
					continue;
				case 0u:
					Delegate22.delegate22_10(this);
					num = (int)((num2 * 1558706660) ^ 0x479706BD);
					continue;
				default:
					return;
				case 30u:
					break;
				case 41u:
					return;
				}
				break;
			}
		}
	}

	public RandomPinForm(ref GClass8 gclass8_1, ref GClass9 gclass9_1, bool bool_7)
	{
		IEnumerator<GClass12> enumerator = default(IEnumerator<GClass12>);
		while (true)
		{
			int num = -849042123;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xC9891C23u) % 21)
				{
				case 20u:
					bool_6 = true;
					num = ((int)num2 * -1848982627) ^ 0x432B2D72;
					continue;
				case 19u:
					bool_1 = false;
					num = (int)(num2 * 408639311) ^ -341123537;
					continue;
				case 18u:
					string_0 = "";
					num = (int)(num2 * 781537163) ^ -598785438;
					continue;
				case 17u:
					Delegate30.delegate30_24(this, Delegate36.delegate36_53());
					num = (int)((num2 * 1095280801) ^ 0x62F5F058);
					continue;
				case 16u:
					genum6_1 = GEnum6.None;
					int_7 = -1;
					num = ((int)num2 * -812096297) ^ -1241079407;
					continue;
				case 15u:
					bool_0 = false;
					num = (int)(num2 * 1059508508) ^ -1776259366;
					continue;
				case 14u:
					list_0 = Delegate176.delegate176_0(gclass13_0, bool_6);
					num = (int)((num2 * 2071467959) ^ 0x36A6F4E1);
					continue;
				case 13u:
					int_4 = 0;
					num = (int)((num2 * 1753299645) ^ 0x2DC25322);
					continue;
				case 12u:
					int_6 = 0;
					num = (int)((num2 * 2109728463) ^ 0x1F84A3CA);
					continue;
				case 11u:
					int_3 = 0;
					num = (int)((num2 * 1481155249) ^ 0x15661773);
					continue;
				case 10u:
					bool_5 = false;
					list_0 = new List<string>();
					num = ((int)num2 * -1147811894) ^ 0x6726B546;
					continue;
				case 7u:
					gclass13_0 = (GClass13)Delegate3.delegate3_105();
					gclass12_0 = (GClass12)Delegate133.delegate133_0(global::_003CModule_003E.smethod_19<string>(3288351801u, 1786145603u), GClass12.GEnum5.Manual);
					num = ((int)num2 * -582195638) ^ 0x2DED90C8;
					continue;
				case 6u:
					string_1 = "";
					bool_3 = false;
					int_5 = 0;
					num = (int)(num2 * 342007875) ^ -1581164354;
					continue;
				case 5u:
					double_0 = 0.0;
					num = (int)((num2 * 144360696) ^ 0x265AEE6C);
					continue;
				case 3u:
					bool_4 = false;
					string_2 = "";
					genum6_0 = GEnum6.None;
					num = ((int)num2 * -682859998) ^ 0x2A48FA31;
					continue;
				case 2u:
				{
					Delegate22.delegate22_49(this);
					int num3;
					int num4;
					if (bool_7)
					{
						num3 = 506436768;
						num4 = 506436768;
					}
					else
					{
						num3 = 1784013412;
						num4 = 1784013412;
					}
					num = num3 ^ (int)(num2 * 1741350254);
					continue;
				}
				case 1u:
					Delegate8.delegate8_3(this, new EventHandler(method_1));
					Delegate8.delegate8_280(this, new FormClosedEventHandler(method_3));
					num = ((int)num2 * -275037855) ^ 0x4F895485;
					continue;
				case 0u:
					int_2 = 0;
					num = ((int)num2 * -994816521) ^ 0x1C00DAEA;
					continue;
				case 4u:
					break;
				default:
					try
					{
						enumerator = gclass9_1.gclass15_0.GetEnumerator();
						while (Delegate21.delegate21_3(enumerator))
						{
							GClass12 current = enumerator.Current;
							list_0.Add(Delegate15.delegate15_25(current));
						}
					}
					finally
					{
						if (enumerator != null)
						{
							Delegate22.delegate22_4(enumerator);
						}
					}
					Delegate30.delegate30_24(this, Delegate36.delegate36_54());
					Delegate5.delegate5_51(Delegate7.delegate7_213(this), bool_0: false);
					goto case 9u;
				case 9u:
					int_7 = 0;
					gclass12_0 = (GClass12)Delegate133.delegate133_0(list_0[int_7], GClass12.GEnum5.BruteForce);
					Delegate32.delegate32_15(Delegate7.delegate7_232(this), list_0.Count);
					bool_5 = bool_7;
					gclass9_0 = gclass9_1;
					Delegate8.delegate8_281(this, gclass8_1);
					string_2 = Delegate71.delegate71_0(global::_003CModule_003E.smethod_21<string>(455329672u, 1346261097u), Delegate76.delegate76_0(Delegate15.delegate15_9(gclass9_1), global::_003CModule_003E.smethod_19<string>(635370773u, 2125650388u), ""), global::_003CModule_003E.smethod_18<string>(2935880685u, 2176610975u));
					Delegate22.delegate22_50(this);
					Delegate8.delegate8_277(Delegate7.delegate7_229(this), "");
					Delegate8.delegate8_277(Delegate7.delegate7_230(this), "");
					return;
				}
				break;
			}
		}
	}

	private void method_1(object sender, EventArgs e)
	{
		Delegate22.delegate22_51(this);
		Delegate22.delegate22_52(Delegate7.delegate7_212(this));
		Delegate5.delegate5_52(Delegate7.delegate7_214(this), bool_5);
		while (true)
		{
			int num = 1810634546;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x6A09266Bu) % 6)
				{
				case 5u:
					Delegate5.delegate5_52(Delegate7.delegate7_215(this), bool_5);
					num = (int)((num2 * 33789954) ^ 0x53399A6D);
					continue;
				case 4u:
				{
					int num5;
					int num6;
					if (Delegate60.delegate60_0(Delegate36.delegate36_55(), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
					{
						num5 = 1461124146;
						num6 = 1461124146;
					}
					else
					{
						num5 = 664667819;
						num6 = 664667819;
					}
					num = num5 ^ ((int)num2 * -1636578139);
					continue;
				}
				case 2u:
				{
					int num3;
					int num4;
					if (!Delegate177.delegate177_0(string_2))
					{
						num3 = -1207713480;
						num4 = -1207713480;
					}
					else
					{
						num3 = -762964887;
						num4 = -762964887;
					}
					num = num3 ^ (int)(num2 * 1928108815);
					continue;
				}
				case 0u:
					Delegate22.delegate22_53(this);
					num = (int)(num2 * 125201734) ^ -990695792;
					continue;
				default:
					return;
				case 3u:
					break;
				case 1u:
					return;
				}
				break;
			}
		}
	}

	private void method_2()
	{
		list_0.Clear();
		if (!Delegate96.delegate96_2(this, string_2))
		{
			return;
		}
		while (true)
		{
			int num = -386763527;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x838E50F0u) % 8)
				{
				case 7u:
				{
					int num5;
					if (int_7 >= list_0.Count)
					{
						num = -793869948;
						num5 = -793869948;
					}
					else
					{
						num = -545341411;
						num5 = -545341411;
					}
					continue;
				}
				case 5u:
					gclass12_0 = (GClass12)Delegate133.delegate133_0(list_0[int_7], GClass12.GEnum5.BruteForce);
					num = -2067678760;
					continue;
				case 4u:
					int_7 = checked(list_0.Count - 1);
					num = (int)((num2 * 1266661149) ^ 0x1B836639);
					continue;
				case 2u:
					int_7 = 0;
					num = (int)(num2 * 323799146) ^ -169404781;
					continue;
				case 1u:
				{
					int num3;
					int num4;
					if (int_7 != -1)
					{
						num3 = 1708713822;
						num4 = 1708713822;
					}
					else
					{
						num3 = 904088883;
						num4 = 904088883;
					}
					num = num3 ^ (int)(num2 * 677954593);
					continue;
				}
				case 0u:
					Delegate22.delegate22_51(this);
					num = ((int)num2 * -1701701823) ^ -1065753581;
					continue;
				default:
					return;
				case 6u:
					break;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	private void method_3(object sender, FormClosedEventArgs e)
	{
		Delegate22.delegate22_13(Delegate7.delegate7_219(this));
	}

	private void method_4()
	{
		Delegate103.delegate103_0(Delegate7.delegate7_79(Delegate7.delegate7_212(this)), 7);
		Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_212(this)), 0)), 0), global::_003CModule_003E.smethod_21<string>(2785321141u, 1288277026u));
		while (true)
		{
			int num = 217857649;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xA0E474Au) % 7)
				{
				case 5u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_212(this)), 5)), 0), global::_003CModule_003E.smethod_21<string>(2016313347u, 3122119290u));
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_212(this)), 6)), 0), global::_003CModule_003E.smethod_21<string>(2966669018u, 3409427748u));
					num = (int)(num2 * 150607472) ^ -1272591575;
					continue;
				case 4u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_212(this)), 1)), 0), global::_003CModule_003E.smethod_21<string>(1653617593u, 2356482101u));
					num = ((int)num2 * -327243229) ^ 0x55C4A28B;
					continue;
				case 3u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_212(this)), 4)), 0), Delegate36.delegate36_58());
					num = ((int)num2 * -48961969) ^ 0x622B6D8;
					continue;
				case 2u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_212(this)), 3)), 0), Delegate36.delegate36_57());
					num = ((int)num2 * -2135141355) ^ -1138777583;
					continue;
				case 1u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_212(this)), 2)), 0), Delegate36.delegate36_56());
					num = (int)((num2 * 1588199654) ^ 0x6989A0EE);
					continue;
				default:
					return;
				case 6u:
					break;
				case 0u:
					return;
				}
				break;
			}
		}
	}

	private void method_5()
	{
		timeSpan_0 = Delegate178.delegate178_0(double_0);
		Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_212(this)), 0)), 1), Delegate15.delegate15_10(gclass9_0));
		GEnum6 gEnum = default(GEnum6);
		while (true)
		{
			int num = -65223736;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x9B6CA114u) % 35)
				{
				case 34u:
					DataGridView_0.Rows[5].Cells[1].Style.ForeColor = Color.Red;
					num = -606147532;
					continue;
				case 33u:
					goto IL_009f;
				case 32u:
					goto IL_00d4;
				case 31u:
					goto IL_0109;
				case 30u:
					Class12_0.Color_0 = Color.Red;
					Label_0.Text = Class10.String_71;
					num = (int)(num2 * 1919435415) ^ -333657975;
					continue;
				case 29u:
					Label_0.BackColor = Color.Red;
					num = (int)(num2 * 1016167189) ^ -811548574;
					continue;
				case 28u:
					goto IL_0177;
				case 27u:
					DataGridView_0.Rows[6].Cells[1].Style.ForeColor = Color.Green;
					DataGridView_0.Rows[6].Cells[1].Value = gclass9_0.NetworkKey;
					Class12_0.Maximum = list_0.Count;
					Class12_0.Value = int_7;
					num = ((int)num2 * -641087645) ^ -731161585;
					continue;
				case 26u:
					Label_0.Text = Class10.String_69;
					Label_0.BackColor = Color.Green;
					num = ((int)num2 * -1319789075) ^ -2024452042;
					continue;
				case 25u:
					num = ((int)num2 * -1182232435) ^ -1593240796;
					continue;
				case 24u:
					goto IL_028b;
				case 23u:
					((DataGridViewCell)Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_212(this)), 2)), 1)).Value = string.Format(Delegate36.delegate36_59(), timeSpan_0.Days, timeSpan_0.Hours, timeSpan_0.Minutes, timeSpan_0.Seconds, timeSpan_1.Days, timeSpan_1.Hours, timeSpan_1.Minutes, timeSpan_1.Seconds);
					num = (int)((num2 * 1140548294) ^ 0x51D1A980);
					continue;
				case 22u:
					gEnum = genum6_1;
					num = (int)((num2 * 1128076104) ^ 0x52FBB82F);
					continue;
				case 21u:
					string_1 = "";
					num = ((int)num2 * -1002713832) ^ 0x61828B6C;
					continue;
				case 19u:
					num = ((int)num2 * -876193968) ^ -532323413;
					continue;
				case 18u:
					num = (int)(num2 * 876227483) ^ -1446055121;
					continue;
				case 17u:
					num = (int)((num2 * 1449324492) ^ 0x728C7203);
					continue;
				case 16u:
					Class12_0.Color_0 = Color.Green;
					num = (int)((num2 * 1243220800) ^ 0x5374DFBA);
					continue;
				case 15u:
					switch (gEnum)
					{
					case GEnum6.Fault:
						break;
					case GEnum6.None:
						goto IL_009f;
					case GEnum6.NoOk:
						goto IL_00d4;
					case GEnum6.PinNotFound:
						goto IL_0109;
					case GEnum6.Ok:
						goto IL_0177;
					case GEnum6.ApLocked:
						goto IL_028b;
					default:
						goto IL_044e;
					case GEnum6.fHalfOk:
						goto IL_0460;
					}
					goto case 34u;
				case 12u:
					goto IL_0460;
				case 13u:
					DataGridView_0.Rows[4].Cells[1].Value = int_2;
					num = (int)(num2 * 1095401089) ^ -1159094439;
					continue;
				case 11u:
					string_1 = Class10.String_71;
					num = ((int)num2 * -1656595315) ^ -1803761886;
					continue;
				case 10u:
					Class12_0.Color_0 = Color.Red;
					num = ((int)num2 * -1301745671) ^ 0x7F2FA373;
					continue;
				case 9u:
					string_1 = Class10.String_68;
					num = (int)(num2 * 1218587944) ^ -720022116;
					continue;
				case 8u:
					Delegate8.delegate8_110(Delegate55.delegate55_2(Delegate7.delegate7_80(Delegate55.delegate55_1(Delegate7.delegate7_79(Delegate7.delegate7_212(this)), 1)), 1), Delegate15.delegate15_9(gclass9_0));
					num = ((int)num2 * -1405539861) ^ 0x7FC08118;
					continue;
				case 7u:
					Label_0.Visible = true;
					num = (int)(num2 * 1543300190) ^ -843640801;
					continue;
				case 6u:
					num = ((int)num2 * -1049652641) ^ -149977845;
					continue;
				case 5u:
					Label_0.BackColor = Color.Red;
					Label_0.Visible = true;
					num = ((int)num2 * -929008503) ^ 0x40E61590;
					continue;
				case 4u:
					Label_0.Visible = true;
					num = (int)(num2 * 414462538) ^ -18038287;
					continue;
				case 3u:
					Label_0.Visible = true;
					num = ((int)num2 * -917871455) ^ -356550614;
					continue;
				case 2u:
					DataGridView_0.Rows[5].Cells[1].Value = string.Format(global::_003CModule_003E.smethod_19<string>(1006943864u, 800601955u), gclass12_0.Pin, string_1);
					num = -1493200949;
					continue;
				case 1u:
					DataGridView_0.Rows[3].Cells[1].Value = string.Format(Class10.String_72, int_7.ToString(global::_003CModule_003E.smethod_20<string>(531259265u, 1074350353u)), list_0.Count.ToString(global::_003CModule_003E.smethod_22<string>(850578965u, 466432925u)));
					num = ((int)num2 * -1414308338) ^ -1271011722;
					continue;
				case 0u:
					Label_0.BackColor = Color.Red;
					num = ((int)num2 * -785528899) ^ 0x58D246EE;
					continue;
				default:
					return;
				case 20u:
					break;
				case 14u:
					return;
					IL_0460:
					DataGridView_0.Rows[5].Cells[1].Style.ForeColor = Color.Orange;
					string_1 = Class10.String_66;
					Class12_0.Color_0 = Color.Yellow;
					num = -1029164241;
					continue;
					IL_044e:
					num = (int)(num2 * 954396781) ^ -469564735;
					continue;
					IL_028b:
					Label_0.Text = Class10.String_62;
					num = -2071413552;
					continue;
					IL_0177:
					DataGridView_0.Rows[5].Cells[1].Style.ForeColor = Color.Green;
					string_1 = Class10.String_75;
					num = -2136186186;
					continue;
					IL_0109:
					Label_0.Text = Class10.String_70;
					num = -1341892441;
					continue;
					IL_00d4:
					DataGridView_0.Rows[5].Cells[1].Style.ForeColor = Color.Red;
					num = -1063240808;
					continue;
					IL_009f:
					DataGridView_0.Rows[5].Cells[1].Style.ForeColor = Control.DefaultForeColor;
					num = -520576857;
					continue;
				}
				break;
			}
		}
	}

	private void method_6(object sender, EventArgs e)
	{
		if (Delegate74.delegate74_1(Delegate15.delegate15_4(Delegate7.delegate7_217(this))) < 5)
		{
			goto IL_0144;
		}
		goto IL_0284;
		IL_0144:
		int num = -534432220;
		goto IL_023a;
		IL_023a:
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0xCA97ED93u) % 14)
			{
			case 13u:
			{
				Delegate5.delegate5_33(Delegate7.delegate7_230(this), bool_0: false);
				Delegate5.delegate5_19(Delegate7.delegate7_231(this), bool_0: false);
				int num3;
				int num4;
				if (int_7 > 0)
				{
					num3 = 1172007677;
					num4 = 1172007677;
				}
				else
				{
					num3 = 553692749;
					num4 = 553692749;
				}
				num = num3 ^ (int)(num2 * 318988223);
				continue;
			}
			case 12u:
				genum6_0 = GEnum6.None;
				num = ((int)num2 * -120368945) ^ 0x77521899;
				continue;
			case 11u:
				Delegate5.delegate5_19(Delegate7.delegate7_215(this), bool_0: true);
				num = ((int)num2 * -22360615) ^ 0x59DD7CE2;
				continue;
			case 10u:
				bool_1 = true;
				num = ((int)num2 * -1413825721) ^ -1956515837;
				continue;
			case 9u:
				timeSpan_1 = Delegate178.delegate178_0(checked(list_0.Count * Delegate74.delegate74_1(Delegate15.delegate15_4(Delegate7.delegate7_217(this))) + int_7 * 4));
				num = -1370302513;
				continue;
			case 8u:
				bool_2 = true;
				num = ((int)num2 * -966460168) ^ 0x1304E448;
				continue;
			case 4u:
				break;
			case 3u:
				Delegate5.delegate5_20(Delegate7.delegate7_222(this), bool_0: true);
				Delegate5.delegate5_19(Delegate7.delegate7_214(this), bool_0: false);
				num = (int)(num2 * 1304411617) ^ -212940541;
				continue;
			case 2u:
				Delegate5.delegate5_19(Delegate7.delegate7_219(this), bool_0: true);
				Delegate5.delegate5_19(Delegate7.delegate7_218(this), bool_0: false);
				Delegate5.delegate5_51(Delegate7.delegate7_227(this), bool_0: false);
				Delegate5.delegate5_33(Delegate7.delegate7_229(this), bool_0: false);
				num = ((int)num2 * -434432036) ^ 0x57BC309E;
				continue;
			case 1u:
				Delegate30.delegate30_16(Delegate7.delegate7_217(this), global::_003CModule_003E.smethod_20<string>(1401736619u, 3346526857u));
				num = ((int)num2 * -2134538340) ^ 0x3AED1996;
				continue;
			case 0u:
				genum6_1 = GEnum6.None;
				num = ((int)num2 * -1822661979) ^ 0x402763F7;
				continue;
			default:
				return;
			case 7u:
				goto IL_0284;
			case 5u:
				timeSpan_1 = Delegate178.delegate178_0(double_0 / (double)int_7 * (double)checked(list_0.Count - int_7));
				return;
			case 6u:
				return;
			}
			break;
		}
		goto IL_0144;
		IL_0284:
		Delegate5.delegate5_33(Delegate7.delegate7_217(this), bool_0: false);
		Delegate109.delegate109_0(Delegate7.delegate7_233(this), ref gclass9_0, gclass12_0);
		num = -678417277;
		goto IL_023a;
	}

	private void method_7(object sender, EventArgs e)
	{
		Delegate5.delegate5_33(Delegate7.delegate7_217(this), bool_0: true);
		while (true)
		{
			int num = -174372376;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xFA62D244u) % 10)
				{
				case 9u:
					bool_1 = false;
					bool_2 = false;
					Delegate5.delegate5_31(Delegate7.delegate7_233(this), bool_0: true);
					Delegate5.delegate5_20(Delegate7.delegate7_222(this), bool_0: false);
					num = (int)((num2 * 315205628) ^ 0x792080F);
					continue;
				case 8u:
					Delegate5.delegate5_33(Delegate7.delegate7_230(this), bool_0: true);
					Delegate5.delegate5_19(Delegate7.delegate7_231(this), bool_0: true);
					num = ((int)num2 * -622851953) ^ 0x79D4EF71;
					continue;
				case 6u:
					Delegate22.delegate22_51(this);
					num = ((int)num2 * -1816371790) ^ 0x7EA1306B;
					continue;
				case 5u:
					Delegate5.delegate5_19(Delegate7.delegate7_219(this), bool_0: false);
					num = ((int)num2 * -1378055369) ^ -1469247473;
					continue;
				case 4u:
					Delegate5.delegate5_33(Delegate7.delegate7_229(this), bool_0: true);
					num = ((int)num2 * -209437858) ^ 0x79DEE912;
					continue;
				case 3u:
					int_2 = 0;
					num = (int)(num2 * 507936828) ^ -2129202411;
					continue;
				case 2u:
					Delegate5.delegate5_19(Delegate7.delegate7_218(this), bool_0: true);
					num = (int)((num2 * 523056868) ^ 0x7F26C068);
					continue;
				case 1u:
					Delegate5.delegate5_19(Delegate7.delegate7_214(this), bool_0: true);
					Delegate5.delegate5_19(Delegate7.delegate7_215(this), bool_0: true);
					num = ((int)num2 * -1410079528) ^ 0x75092B45;
					continue;
				default:
					return;
				case 0u:
					break;
				case 7u:
					return;
				}
				break;
			}
		}
	}

	private void method_8(object sender, KeyPressEventArgs e)
	{
		string object_ = global::_003CModule_003E.smethod_20<string>(3364266497u, 1272637733u);
		int num = 4;
		string text = "";
		Delegate8.delegate8_277(Delegate7.delegate7_229(this), "");
		int num10 = default(int);
		int num18 = default(int);
		int num4 = default(int);
		int num6 = default(int);
		object object_2 = default(object);
		char c = default(char);
		while (true)
		{
			int num2 = 566871298;
			while (true)
			{
				uint num3;
				switch ((num3 = (uint)num2 ^ 0x4DC3E4DFu) % 43)
				{
				case 42u:
					num2 = ((int)num3 * -61306768) ^ -1924027864;
					continue;
				case 40u:
				{
					int num24;
					if (num10 > num18)
					{
						num2 = 1120563290;
						num24 = 1120563290;
					}
					else
					{
						num2 = 1443023841;
						num24 = 1443023841;
					}
					continue;
				}
				case 39u:
				{
					int num7;
					if (num4 > num6)
					{
						num2 = 1501177350;
						num7 = 1501177350;
					}
					else
					{
						num2 = 1737403652;
						num7 = 1737403652;
					}
					continue;
				}
				case 38u:
					num18 = checked(Delegate17.delegate17_23(Delegate7.delegate7_229(this)) - 1);
					num2 = (int)(num3 * 1733895800) ^ -1234704076;
					continue;
				case 37u:
				{
					int num22;
					int num23;
					if (Delegate108.delegate108_1(object_2, global::_003CModule_003E.smethod_19<string>(281403622u, 1548214441u), bool_0: false))
					{
						num22 = -1459827602;
						num23 = -1459827602;
					}
					else
					{
						num22 = -975685736;
						num23 = -975685736;
					}
					num2 = num22 ^ (int)(num3 * 1906272921);
					continue;
				}
				case 36u:
					num10 = checked(num10 + 1);
					num2 = 1694284146;
					continue;
				case 35u:
				{
					int num28;
					int num29;
					if (Delegate56.delegate56_0(text, global::_003CModule_003E.smethod_18<string>(1131040031u, 3405229227u), bool_0: false) == 0)
					{
						num28 = -92178269;
						num29 = -92178269;
					}
					else
					{
						num28 = -2017494396;
						num29 = -2017494396;
					}
					num2 = num28 ^ (int)(num3 * 1566283949);
					continue;
				}
				case 34u:
					num2 = ((int)num3 * -1911543742) ^ -1369896851;
					continue;
				case 33u:
				{
					int num25;
					if (Delegate127.delegate127_0(e) >= ' ')
					{
						num2 = 2117465672;
						num25 = 2117465672;
					}
					else
					{
						num2 = 1823546951;
						num25 = 1823546951;
					}
					continue;
				}
				case 32u:
					object_ = global::_003CModule_003E.smethod_21<string>(1745413010u, 1427634611u);
					num2 = 1723150696;
					continue;
				case 31u:
					num2 = ((int)num3 * -340817185) ^ -2113747201;
					continue;
				case 30u:
				{
					int num14;
					int num15;
					if (c != ']')
					{
						num14 = 415774064;
						num15 = 415774064;
					}
					else
					{
						num14 = 1834586295;
						num15 = 1834586295;
					}
					num2 = num14 ^ ((int)num3 * -318061661);
					continue;
				}
				case 29u:
					num4 = checked(num4 + 1);
					num2 = 814550781;
					continue;
				case 28u:
					object_ = global::_003CModule_003E.smethod_22<string>(472673916u, 1098490664u);
					num2 = 38161259;
					continue;
				case 27u:
					num2 = (int)((num3 * 717862657) ^ 0x5A5B4AA5);
					continue;
				case 26u:
					Delegate5.delegate5_34(e, bool_0: true);
					num2 = (int)(num3 * 253213935) ^ -1570292647;
					continue;
				case 25u:
					num10 = 0;
					num2 = ((int)num3 * -1823577225) ^ 0x251D0125;
					continue;
				case 24u:
					Delegate8.delegate8_277(Delegate7.delegate7_229(this), global::_003CModule_003E.smethod_21<string>(3574977134u, 3297067168u));
					num2 = 1756562856;
					continue;
				case 23u:
					object_2 = Delegate7.delegate7_234(Delegate7.delegate7_229(this));
					num2 = 115438125;
					continue;
				case 22u:
				{
					int num26;
					int num27;
					if (Delegate56.delegate56_0(text, global::_003CModule_003E.smethod_22<string>(1515887700u, 168292272u), bool_0: false) != 0)
					{
						num26 = 1418268409;
						num27 = 1418268409;
					}
					else
					{
						num26 = 2141928896;
						num27 = 2141928896;
					}
					num2 = num26 ^ (int)(num3 * 1357626718);
					continue;
				}
				case 21u:
					num = checked(num + 4);
					num2 = (int)(num3 * 1069280775) ^ -259818840;
					continue;
				case 20u:
					Delegate8.delegate8_277(Delegate7.delegate7_229(this), "");
					num2 = 1756562856;
					continue;
				case 19u:
				{
					int num20;
					int num21;
					if (Delegate17.delegate17_23(Delegate7.delegate7_229(this)) <= 0)
					{
						num20 = 2087382477;
						num21 = 2087382477;
					}
					else
					{
						num20 = 125571250;
						num21 = 125571250;
					}
					num2 = num20 ^ ((int)num3 * -1894541309);
					continue;
				}
				case 18u:
					object_ = global::_003CModule_003E.smethod_21<string>(4096052678u, 38453856u);
					num2 = (int)(num3 * 420511646) ^ -323567993;
					continue;
				case 17u:
					num2 = (int)(num3 * 1852849056) ^ -1107563246;
					continue;
				case 16u:
				{
					int num19;
					if (Delegate96.delegate96_0(object_, Delegate172.delegate172_0(Delegate127.delegate127_0(e))) & (Delegate17.delegate17_7(Delegate15.delegate15_4(Delegate7.delegate7_229(this))) >= num))
					{
						num2 = 1380509302;
						num19 = 1380509302;
					}
					else
					{
						num2 = 261618045;
						num19 = 261618045;
					}
					continue;
				}
				case 15u:
					num2 = ((int)num3 * -1310701199) ^ -515894254;
					continue;
				case 14u:
					num2 = (int)((num3 * 418173121) ^ 0x52DA1DC4);
					continue;
				case 13u:
				{
					int num16;
					int num17;
					if (c == '[')
					{
						num16 = -329060982;
						num17 = -329060982;
					}
					else
					{
						num16 = -2079153434;
						num17 = -2079153434;
					}
					num2 = num16 ^ ((int)num3 * -2022330633);
					continue;
				}
				case 12u:
				{
					int num12;
					int num13;
					if (c == '-')
					{
						num12 = -912871414;
						num13 = -912871414;
					}
					else
					{
						num12 = -1509935597;
						num13 = -1509935597;
					}
					num2 = num12 ^ (int)(num3 * 1290233776);
					continue;
				}
				case 11u:
					num6 = checked(Delegate17.delegate17_7(Delegate15.delegate15_4(Delegate7.delegate7_229(this))) - 1);
					num2 = 1807779302;
					continue;
				case 10u:
					text = Delegate172.delegate172_0(Delegate179.delegate179_0(Delegate15.delegate15_4(Delegate7.delegate7_229(this)), checked(Delegate17.delegate17_23(Delegate7.delegate7_229(this)) - 1)));
					num2 = ((int)num3 * -876106875) ^ -1280346670;
					continue;
				case 8u:
					c = Delegate179.delegate179_0(Delegate15.delegate15_4(Delegate7.delegate7_229(this)), num10);
					num2 = 701371119;
					continue;
				case 7u:
					object_ = global::_003CModule_003E.smethod_20<string>(923570558u, 4164163838u);
					num2 = ((int)num3 * -2109307574) ^ -749069296;
					continue;
				case 6u:
					Delegate8.delegate8_277(Delegate7.delegate7_229(this), global::_003CModule_003E.smethod_18<string>(3710723637u, 3473916847u));
					num2 = 1756562856;
					continue;
				case 5u:
					object_ = global::_003CModule_003E.smethod_18<string>(1228412580u, 1113655940u);
					num2 = 741724979;
					continue;
				case 4u:
				{
					int num11;
					if (!Delegate108.delegate108_1(object_2, global::_003CModule_003E.smethod_20<string>(3975623896u, 3631225401u), bool_0: false))
					{
						num2 = 1655926864;
						num11 = 1655926864;
					}
					else
					{
						num2 = 1581325750;
						num11 = 1581325750;
					}
					continue;
				}
				case 3u:
				{
					int num8;
					int num9;
					if (Delegate96.delegate96_0(object_, Delegate172.delegate172_0(Delegate127.delegate127_0(e))))
					{
						num8 = -1672059857;
						num9 = -1672059857;
					}
					else
					{
						num8 = -512440971;
						num9 = -512440971;
					}
					num2 = num8 ^ (int)(num3 * 851373528);
					continue;
				}
				case 2u:
				{
					int num5;
					if (Delegate56.delegate56_0(Delegate172.delegate172_0(Delegate179.delegate179_0(Delegate15.delegate15_4(Delegate7.delegate7_229(this)), num4)), global::_003CModule_003E.smethod_21<string>(992490570u, 1270744049u), bool_0: false) != 0)
					{
						num2 = 132474934;
						num5 = 132474934;
					}
					else
					{
						num2 = 1363645485;
						num5 = 1363645485;
					}
					continue;
				}
				case 1u:
					num4 = 0;
					num2 = (int)((num3 * 35729784) ^ 0x41077545);
					continue;
				case 0u:
					Delegate5.delegate5_34(e, bool_0: true);
					num2 = ((int)num3 * -46816841) ^ -2069899598;
					continue;
				default:
					return;
				case 9u:
					break;
				case 41u:
					return;
				}
				break;
			}
		}
	}

	private void method_9(object sender, KeyPressEventArgs e)
	{
		string object_ = global::_003CModule_003E.smethod_21<string>(1811997383u, 3849513092u);
		char c = default(char);
		int num23 = default(int);
		object object_2 = default(object);
		int num3 = default(int);
		string text = default(string);
		int num4 = default(int);
		int num10 = default(int);
		int num9 = default(int);
		while (true)
		{
			int num = 676432071;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x49415D3Eu) % 44)
				{
				case 43u:
					Delegate8.delegate8_277(Delegate7.delegate7_230(this), global::_003CModule_003E.smethod_19<string>(534834354u, 3974205180u));
					num = 1808946689;
					continue;
				case 42u:
				{
					int num12;
					int num13;
					if (c != '[')
					{
						num12 = -1839684861;
						num13 = -1839684861;
					}
					else
					{
						num12 = -1502648078;
						num13 = -1502648078;
					}
					num = num12 ^ ((int)num2 * -2119790945);
					continue;
				}
				case 41u:
				{
					int num27;
					if (Delegate96.delegate96_0(object_, Delegate172.delegate172_0(Delegate127.delegate127_0(e))) & (Delegate17.delegate17_7(Delegate15.delegate15_4(Delegate7.delegate7_230(this))) >= num23))
					{
						num = 1508302624;
						num27 = 1508302624;
					}
					else
					{
						num = 2120322786;
						num27 = 2120322786;
					}
					continue;
				}
				case 40u:
				{
					object_2 = Delegate7.delegate7_234(Delegate7.delegate7_230(this));
					int num20;
					if (!Delegate108.delegate108_1(object_2, global::_003CModule_003E.smethod_21<string>(992490570u, 4085174306u), bool_0: false))
					{
						num = 814333756;
						num20 = 814333756;
					}
					else
					{
						num = 419244011;
						num20 = 419244011;
					}
					continue;
				}
				case 39u:
				{
					int num18;
					int num19;
					if (!Delegate96.delegate96_0(object_, Delegate172.delegate172_0(Delegate127.delegate127_0(e))))
					{
						num18 = -620891549;
						num19 = -620891549;
					}
					else
					{
						num18 = -1138560634;
						num19 = -1138560634;
					}
					num = num18 ^ ((int)num2 * -4349);
					continue;
				}
				case 38u:
				{
					int num8;
					if (Delegate108.delegate108_1(object_2, global::_003CModule_003E.smethod_20<string>(3975623896u, 990689646u), bool_0: false))
					{
						num = 1593636042;
						num8 = 1593636042;
					}
					else
					{
						num = 1771669022;
						num8 = 1771669022;
					}
					continue;
				}
				case 37u:
					num = ((int)num2 * -673230300) ^ -1834733382;
					continue;
				case 36u:
					Delegate5.delegate5_34(e, bool_0: true);
					num = (int)(num2 * 1251210891) ^ -444409125;
					continue;
				case 35u:
					num3 = 0;
					num = (int)(num2 * 1680310775) ^ -1437482263;
					continue;
				case 34u:
					Delegate5.delegate5_34(e, bool_0: true);
					num = (int)((num2 * 1252003501) ^ 0x17711CA4);
					continue;
				case 33u:
					object_ = global::_003CModule_003E.smethod_18<string>(3614914205u, 3851409915u);
					num = 1337781630;
					continue;
				case 32u:
				{
					int num24;
					if (Delegate17.delegate17_23(Delegate7.delegate7_230(this)) == checked(num23 - 1))
					{
						num = 1841860490;
						num24 = 1841860490;
					}
					else
					{
						num = 1790657739;
						num24 = 1790657739;
					}
					continue;
				}
				case 31u:
					num23 = checked(num23 + 4);
					num = ((int)num2 * -1328983413) ^ 0x73669D46;
					continue;
				case 30u:
					text = Delegate172.delegate172_0(Delegate179.delegate179_0(Delegate15.delegate15_4(Delegate7.delegate7_230(this)), checked(Delegate17.delegate17_23(Delegate7.delegate7_230(this)) - 1)));
					num = ((int)num2 * -1740448307) ^ 0x3AA409EE;
					continue;
				case 29u:
					num4 = checked(Delegate17.delegate17_7(Delegate15.delegate15_4(Delegate7.delegate7_230(this))) - 1);
					num = 91456449;
					continue;
				case 28u:
				{
					int num15;
					if (Delegate127.delegate127_0(e) >= ' ')
					{
						num = 193392929;
						num15 = 193392929;
					}
					else
					{
						num = 969540827;
						num15 = 969540827;
					}
					continue;
				}
				case 27u:
					num10 = checked(num10 + 1);
					num = 2118903055;
					continue;
				case 26u:
				{
					int num6;
					int num7;
					if (c != '-')
					{
						num6 = 1886888822;
						num7 = 1886888822;
					}
					else
					{
						num6 = 1266569755;
						num7 = 1266569755;
					}
					num = num6 ^ (int)(num2 * 1334090879);
					continue;
				}
				case 25u:
					object_ = global::_003CModule_003E.smethod_22<string>(3522383006u, 841160814u);
					num = ((int)num2 * -150852651) ^ 0x6CA11747;
					continue;
				case 24u:
					num = ((int)num2 * -1408708304) ^ 0x5FF737BE;
					continue;
				case 23u:
					c = Delegate179.delegate179_0(Delegate15.delegate15_4(Delegate7.delegate7_230(this)), num10);
					num = 1888980392;
					continue;
				case 22u:
					Delegate8.delegate8_277(Delegate7.delegate7_230(this), "");
					num = 1808946689;
					continue;
				case 21u:
					num23 = 4;
					num = ((int)num2 * -1575675616) ^ -1494156146;
					continue;
				case 20u:
					num = ((int)num2 * -1542198947) ^ 0x2F752CA;
					continue;
				case 19u:
				{
					int num28;
					int num29;
					if (c == ']')
					{
						num28 = 502427874;
						num29 = 502427874;
					}
					else
					{
						num28 = 362224395;
						num29 = 362224395;
					}
					num = num28 ^ ((int)num2 * -342094974);
					continue;
				}
				case 18u:
					num = ((int)num2 * -1107288254) ^ -1711926437;
					continue;
				case 17u:
					object_ = global::_003CModule_003E.smethod_19<string>(212431063u, 1804653374u);
					num = 1337781630;
					continue;
				case 16u:
				{
					text = "";
					Delegate8.delegate8_277(Delegate7.delegate7_230(this), "");
					int num25;
					int num26;
					if (Delegate17.delegate17_23(Delegate7.delegate7_230(this)) <= 0)
					{
						num25 = -1532700733;
						num26 = -1532700733;
					}
					else
					{
						num25 = -1714332456;
						num26 = -1714332456;
					}
					num = num25 ^ ((int)num2 * -1280768760);
					continue;
				}
				case 15u:
					num = (int)((num2 * 68319892) ^ 0x2C66A47D);
					continue;
				case 14u:
				{
					int num21;
					int num22;
					if (Delegate56.delegate56_0(text, global::_003CModule_003E.smethod_21<string>(992490570u, 160152935u), bool_0: false) == 0)
					{
						num21 = -748560567;
						num22 = -748560567;
					}
					else
					{
						num21 = -1837446207;
						num22 = -1837446207;
					}
					num = num21 ^ ((int)num2 * -942520214);
					continue;
				}
				case 12u:
					object_ = global::_003CModule_003E.smethod_20<string>(1663385638u, 1941161932u);
					num = (int)((num2 * 1107403247) ^ 0x49E62876);
					continue;
				case 11u:
				{
					int num16;
					int num17;
					if (Delegate56.delegate56_0(text, global::_003CModule_003E.smethod_19<string>(2480483852u, 3292537626u), bool_0: false) == 0)
					{
						num16 = 1400064964;
						num17 = 1400064964;
					}
					else
					{
						num16 = 1738576848;
						num17 = 1738576848;
					}
					num = num16 ^ ((int)num2 * -479139491);
					continue;
				}
				case 10u:
					num = ((int)num2 * -1561349953) ^ 0x3CA5F4D1;
					continue;
				case 9u:
				{
					int num14;
					if (num10 > num9)
					{
						num = 583633731;
						num14 = 583633731;
					}
					else
					{
						num = 778475797;
						num14 = 778475797;
					}
					continue;
				}
				case 7u:
				{
					int num11;
					if (Delegate56.delegate56_0(Delegate172.delegate172_0(Delegate179.delegate179_0(Delegate15.delegate15_4(Delegate7.delegate7_230(this)), num3)), global::_003CModule_003E.smethod_19<string>(281403622u, 193219503u), bool_0: false) != 0)
					{
						num = 865123859;
						num11 = 865123859;
					}
					else
					{
						num = 349905057;
						num11 = 349905057;
					}
					continue;
				}
				case 6u:
					Delegate8.delegate8_277(Delegate7.delegate7_230(this), global::_003CModule_003E.smethod_19<string>(281403622u, 1286629228u));
					num = 669049050;
					continue;
				case 5u:
					num3 = checked(num3 + 1);
					num = 479000947;
					continue;
				case 4u:
					object_ = global::_003CModule_003E.smethod_22<string>(2963190328u, 4213120724u);
					num = ((int)num2 * -773342961) ^ 0x4CA6A432;
					continue;
				case 3u:
					object_ = global::_003CModule_003E.smethod_22<string>(472673916u, 860949930u);
					num = 485097498;
					continue;
				case 2u:
					num9 = checked(Delegate17.delegate17_23(Delegate7.delegate7_230(this)) - 1);
					num10 = 0;
					num = ((int)num2 * -1591210445) ^ 0x74B3CECE;
					continue;
				case 1u:
				{
					int num5;
					if (num3 > num4)
					{
						num = 1588752912;
						num5 = 1588752912;
					}
					else
					{
						num = 476587265;
						num5 = 476587265;
					}
					continue;
				}
				case 0u:
					num = ((int)num2 * -1437957026) ^ 0x3AE71FB9;
					continue;
				default:
					return;
				case 13u:
					break;
				case 8u:
					return;
				}
				break;
			}
		}
	}

	private void method_10(object sender, EventArgs e)
	{
		list_0 = Delegate180.delegate180_0(gclass13_0, Delegate15.delegate15_4(Delegate7.delegate7_229(this)), Delegate15.delegate15_4(Delegate7.delegate7_230(this)));
		while (true)
		{
			int num = -2022972075;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xF7B7E7BCu) % 5)
				{
				case 4u:
					gclass12_0 = (GClass12)Delegate133.delegate133_0(list_0[int_7], GClass12.GEnum5.BruteForce);
					num = (int)(num2 * 603031164) ^ -1666748791;
					continue;
				case 3u:
					genum6_1 = GEnum6.None;
					string_1 = "";
					Delegate22.delegate22_51(this);
					num = (int)((num2 * 1745763549) ^ 0x72F85419);
					continue;
				case 2u:
					int_7 = 0;
					num = (int)(num2 * 679118162) ^ -1117502008;
					continue;
				default:
					return;
				case 0u:
					break;
				case 1u:
					return;
				}
				break;
			}
		}
	}

	private void method_11(GClass8.GEnum1 genum1_0)
	{
		try
		{
			if (Delegate21.delegate21_12(this))
			{
				goto IL_0051;
			}
			goto IL_007b;
			IL_0051:
			int num = -1361394028;
			goto IL_0056;
			IL_0056:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x988AEB13u) % 5)
				{
				case 4u:
				{
					GDelegate11 object_ = method_11;
					Delegate112.smethod_0((object)this, (object)object_, new object[1] { genum1_0 });
					num = ((int)num2 * -1889052107) ^ -1096146531;
					continue;
				}
				case 2u:
					num = ((int)num2 * -1893915894) ^ 0x2921AD8E;
					continue;
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_007b;
				case 3u:
					return;
				}
				break;
			}
			goto IL_0051;
			IL_007b:
			Delegate116.delegate116_2(this, genum1_0);
			num = -360708500;
			goto IL_0056;
		}
		catch (Exception exception_)
		{
			Delegate14.smethod_0(exception_);
			Delegate51.delegate51_0();
		}
	}

	private void method_12(GClass8.GEnum1 genum1_0)
	{
		while (true)
		{
			int num = -548674422;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xB555F597u) % 32)
				{
				case 31u:
				{
					int num5;
					if (!bool_1)
					{
						num = -206812698;
						num5 = -206812698;
					}
					else
					{
						num = -1370142638;
						num5 = -1370142638;
					}
					continue;
				}
				case 29u:
					switch (genum1_0)
					{
					case GClass8.GEnum1.Stop:
						break;
					default:
						goto IL_005d;
					case GClass8.GEnum1.Start:
						goto IL_006f;
					case GClass8.GEnum1.Locked:
						goto IL_0087;
					case GClass8.GEnum1.ApNotFound:
						goto IL_0098;
					case GClass8.GEnum1.AssociationFailed:
						goto IL_00a9;
					case GClass8.GEnum1.Testing:
					case (GClass8.GEnum1)3:
					case GClass8.GEnum1.Success:
					case GClass8.GEnum1.NACK:
					case GClass8.GEnum1.Updated:
					case GClass8.GEnum1.PixieSucced:
						return;
					}
					goto case 31u;
				case 21u:
					goto IL_006f;
				case 20u:
					goto IL_0087;
				case 16u:
					goto IL_0098;
				case 19u:
					goto IL_00a9;
				case 28u:
					num = (int)((num2 * 922755037) ^ 0x4042890A);
					continue;
				case 27u:
					genum6_0 = GEnum6.fHalfOk;
					bool_2 = false;
					num = -1576129403;
					continue;
				case 24u:
					bool_2 = false;
					num = (int)((num2 * 669554676) ^ 0x2B653593);
					continue;
				case 23u:
					checked
					{
						int_6++;
					}
					num = ((int)num2 * -1426602004) ^ 0x4444FB8B;
					continue;
				case 22u:
					bool_2 = false;
					num = (int)(num2 * 1595131336) ^ -511145463;
					continue;
				case 18u:
					num = ((int)num2 * -1235225879) ^ -1663705980;
					continue;
				case 17u:
					bool_4 = true;
					num = -2047112587;
					continue;
				case 15u:
					goto IL_0155;
				case 13u:
					num = (int)((num2 * 2017824059) ^ 0x41B49CD9);
					continue;
				case 12u:
					goto IL_0178;
				case 9u:
					bool_2 = false;
					num = (int)(num2 * 1524644048) ^ -836906213;
					continue;
				case 8u:
				{
					int num3;
					int num4;
					if (int_6 > 5)
					{
						num3 = -383334745;
						num4 = -383334745;
					}
					else
					{
						num3 = -22042202;
						num4 = -22042202;
					}
					num = num3 ^ ((int)num2 * -1585792418);
					continue;
				}
				case 7u:
					goto IL_01d4;
				case 6u:
					bool_2 = false;
					num = ((int)num2 * -1646196924) ^ -2140464648;
					continue;
				case 5u:
					switch (((GClass8)Delegate7.delegate7_233(this)).genum2_0)
					{
					case GClass8.GEnum2.fHalfOk:
						break;
					case GClass8.GEnum2.Nok:
						goto IL_0155;
					case GClass8.GEnum2.Ok:
						goto IL_0178;
					case GClass8.GEnum2.Fault:
						goto IL_01d4;
					default:
						goto IL_0226;
					}
					goto case 27u;
				case 4u:
					num = (int)(num2 * 559195083) ^ -491112790;
					continue;
				case 1u:
					int_2 = Delegate74.delegate74_1(Delegate15.delegate15_4(Delegate7.delegate7_217(this)));
					num = -1347543276;
					continue;
				case 0u:
					Delegate22.delegate22_13(Delegate7.delegate7_219(this));
					num = (int)((num2 * 1550077755) ^ 0x1F1C1529);
					continue;
				default:
					return;
				case 26u:
					break;
				case 2u:
					return;
				case 3u:
					return;
				case 10u:
					return;
				case 11u:
					return;
				case 14u:
					return;
				case 25u:
					return;
				case 30u:
					return;
					IL_0226:
					num = (int)(num2 * 768498589) ^ -2025391477;
					continue;
					IL_01d4:
					genum6_0 = GEnum6.Fault;
					num = -668636305;
					continue;
					IL_005d:
					num = (int)(num2 * 1773162837) ^ -1354891588;
					continue;
					IL_006f:
					genum6_0 = GEnum6.None;
					int_6 = 0;
					num = -331882820;
					continue;
					IL_0178:
					genum6_0 = GEnum6.Ok;
					bool_2 = false;
					num = -206812698;
					continue;
					IL_0155:
					genum6_0 = GEnum6.NoOk;
					num = -111376898;
					continue;
					IL_00a9:
					genum6_0 = GEnum6.AssociationFailed;
					num = -877258994;
					continue;
					IL_0098:
					genum6_0 = GEnum6.ApNotFound;
					num = -1936894159;
					continue;
					IL_0087:
					genum6_0 = GEnum6.ApLocked;
					num = -345337471;
					continue;
				}
				break;
			}
		}
	}

	private void method_13()
	{
		GEnum6 gEnum = genum6_0;
		checked
		{
			while (true)
			{
				int num = -2097308016;
				while (true)
				{
					uint num2;
					int num3;
					int num4;
					switch (unchecked((num2 = (uint)num ^ 0x91A19618u) % 32))
					{
					case 31u:
						genum6_1 = genum6_0;
						genum6_0 = GEnum6.None;
						num = -1788435593;
						continue;
					case 30u:
						int_5++;
						num = unchecked((int)num2 * -2142363720) ^ 0x6F6C8BBD;
						continue;
					case 29u:
						num = unchecked((int)(num2 * 1386049243)) ^ -1858018104;
						continue;
					case 28u:
						num = unchecked((int)((num2 * 1825550929) ^ 0x577F9D9C));
						continue;
					case 27u:
						Delegate22.delegate22_13(Delegate7.delegate7_219(this));
						num = unchecked((int)num2 * -2106782431) ^ 0x50760D1C;
						continue;
					case 26u:
						int_7 = 0;
						num = unchecked((int)(num2 * 1816818392)) ^ -887682956;
						continue;
					case 25u:
						int_2 = Delegate74.delegate74_1(Delegate15.delegate15_4(Delegate7.delegate7_217(this)));
						num = -524085005;
						continue;
					case 24u:
						int_2 = Delegate74.delegate74_1(Delegate15.delegate15_4(Delegate7.delegate7_217(this)));
						num = -1791657433;
						continue;
					case 23u:
						num = unchecked((int)(num2 * 138921939)) ^ -1170199406;
						continue;
					case 22u:
					{
						int num7;
						int num8;
						if (int_6 <= 5)
						{
							num7 = 1312792907;
							num8 = 1312792907;
						}
						else
						{
							num7 = 1434916137;
							num8 = 1434916137;
						}
						num = num7 ^ unchecked((int)(num2 * 539483871));
						continue;
					}
					case 21u:
					{
						int num5;
						int num6;
						if (int_5 >= 6)
						{
							num5 = -927922871;
							num6 = -927922871;
						}
						else
						{
							num5 = -1788083140;
							num6 = -1788083140;
						}
						num = num5 ^ unchecked((int)(num2 * 724588859));
						continue;
					}
					case 20u:
						goto IL_0176;
					case 19u:
						int_2 = Delegate74.delegate74_1(Delegate15.delegate15_4(Delegate7.delegate7_217(this)));
						num = unchecked((int)((num2 * 681157279) ^ 0x537F0390));
						continue;
					case 18u:
						int_2 = Delegate74.delegate74_1(Delegate15.delegate15_4(Delegate7.delegate7_217(this)));
						num = unchecked((int)(num2 * 103609436)) ^ -425426209;
						continue;
					case 17u:
						goto IL_0203;
					case 16u:
						goto IL_021a;
					case 14u:
						Delegate22.delegate22_13(Delegate7.delegate7_219(this));
						num = unchecked((int)num2 * -637727463) ^ -1543406663;
						continue;
					case 13u:
						goto IL_0252;
					case 11u:
						num = unchecked((int)num2 * -8674740) ^ 0x52A959E3;
						continue;
					case 10u:
						list_0.Remove(Delegate174.delegate174_0(Delegate173.delegate173_0(Delegate15.delegate15_25(gclass12_0))));
						num = unchecked((int)((num2 * 1411103018) ^ 0x65B440E6));
						continue;
					case 9u:
						string_0 = Delegate77.delegate77_0(Delegate15.delegate15_25(gclass12_0), 0, 4);
						bool_0 = true;
						list_0 = Delegate181.delegate181_0(gclass13_0, Delegate74.delegate74_1(string_0), bool_0: true);
						num = unchecked((int)((num2 * 319581493) ^ 0x40391AAF));
						continue;
					case 8u:
						switch (gEnum)
						{
						case GEnum6.PinNotFound:
							break;
						case GEnum6.ApLocked:
							goto IL_0176;
						case GEnum6.NoOk:
							goto IL_0203;
						case GEnum6.Fault:
							goto IL_021a;
						case GEnum6.fHalfOk:
							goto IL_0252;
						default:
							goto IL_035e;
						case GEnum6.Ok:
							goto IL_0370;
						case GEnum6.ApNotFound:
							goto IL_038f;
						case GEnum6.AssociationFailed:
							goto IL_03a6;
						}
						goto case 31u;
					case 0u:
						goto IL_0370;
					case 2u:
						goto IL_038f;
					case 7u:
						goto IL_03a6;
					case 6u:
						genum6_0 = GEnum6.Fault;
						Delegate22.delegate22_13(Delegate7.delegate7_219(this));
						num = -1146713009;
						continue;
					case 5u:
						num = unchecked((int)(num2 * 1752385040)) ^ -1055713161;
						continue;
					case 4u:
						num = unchecked((int)num2 * -992530001) ^ -1435776709;
						continue;
					case 3u:
						num = unchecked((int)num2 * -546798998) ^ -1283405351;
						continue;
					case 1u:
						int_7++;
						num = -1049936960;
						continue;
					default:
						return;
					case 12u:
						break;
					case 15u:
						return;
						IL_03a6:
						int_6++;
						if (int_6 > 5)
						{
							num = -377015722;
							num3 = -377015722;
						}
						else
						{
							num = -1791657433;
							num3 = -1791657433;
						}
						continue;
						IL_038f:
						int_6++;
						num = -1753536178;
						continue;
						IL_0370:
						Delegate22.delegate22_13(Delegate7.delegate7_219(this));
						num = -1845985541;
						continue;
						IL_035e:
						num = unchecked((int)num2 * -1509952568) ^ 0x54468E25;
						continue;
						IL_0252:
						if (!bool_0 & bool_5)
						{
							num = -1455715279;
							num4 = -1455715279;
						}
						else
						{
							num = -266204935;
							num4 = -266204935;
						}
						continue;
						IL_021a:
						bool_3 = true;
						num = -161719642;
						continue;
						IL_0203:
						int_7++;
						num = -83308438;
						continue;
						IL_0176:
						Delegate22.delegate22_13(Delegate7.delegate7_219(this));
						num = -178501700;
						continue;
					}
					break;
				}
			}
		}
	}

	private void method_14(object sender, EventArgs e)
	{
		if (Delegate21.delegate21_12(this))
		{
			goto IL_000d;
		}
		goto IL_007c;
		IL_000d:
		int num = -3183904;
		goto IL_0053;
		IL_0053:
		GDelegate12 object_ = default(GDelegate12);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0xA7896E11u) % 6)
			{
			case 2u:
				break;
			case 1u:
				object_ = method_14;
				num = ((int)num2 * -659278509) ^ 0x3960E91C;
				continue;
			case 0u:
				Delegate112.smethod_0((object)this, (object)object_, new object[2] { sender, e });
				num = ((int)num2 * -638791445) ^ -1372634566;
				continue;
			default:
				return;
			case 4u:
				goto IL_007c;
			case 3u:
				return;
			case 5u:
				return;
			}
			break;
		}
		goto IL_000d;
		IL_007c:
		Delegate13.delegate13_1(this, Delegate7.delegate7_2(sender), e);
		num = -930351088;
		goto IL_0053;
	}

	private void method_15(object sender, EventArgs e)
	{
		Delegate22.delegate22_54(Delegate7.delegate7_222(this));
		while (true)
		{
			int num = -1529705290;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x8C905BEFu) % 29)
				{
				case 28u:
				{
					int num15;
					int num16;
					if (int_7 < list_0.Count)
					{
						num15 = -1623593805;
						num16 = -1623593805;
					}
					else
					{
						num15 = -1103480078;
						num16 = -1103480078;
					}
					num = num15 ^ (int)(num2 * 796372815);
					continue;
				}
				case 27u:
					checked
					{
						int_2--;
						bool_2 = false;
					}
					num = ((int)num2 * -1761585067) ^ -955979354;
					continue;
				case 26u:
					genum6_0 = GEnum6.PinNotFound;
					num = (int)(num2 * 1327892801) ^ -2087913270;
					continue;
				case 25u:
					bool_3 = false;
					genum6_0 = GEnum6.None;
					num = ((int)num2 * -866372574) ^ -459860848;
					continue;
				case 24u:
				{
					int num5;
					int num6;
					if (int_2 <= 0)
					{
						num5 = -1248826446;
						num6 = -1248826446;
					}
					else
					{
						num5 = -1308279692;
						num6 = -1308279692;
					}
					num = num5 ^ ((int)num2 * -499126943);
					continue;
				}
				case 23u:
					Delegate22.delegate22_55(this);
					num = (int)(num2 * 524567410) ^ -1075364995;
					continue;
				case 22u:
					checked
					{
						int_3++;
					}
					num = ((int)num2 * -1384146175) ^ 0x3816E2DA;
					continue;
				case 21u:
					num = ((int)num2 * -698385253) ^ 0x54AE81CE;
					continue;
				case 20u:
					Delegate22.delegate22_51(this);
					Delegate22.delegate22_13(Delegate7.delegate7_219(this));
					num = (int)(num2 * 1527201671) ^ -1238808979;
					continue;
				case 19u:
					gclass12_0 = (GClass12)Delegate133.delegate133_0(list_0[int_7], GClass12.GEnum5.BruteForce);
					num = ((int)num2 * -1315507431) ^ 0x74787A3A;
					continue;
				case 18u:
				{
					int num9;
					if (bool_2)
					{
						num = -1944402392;
						num9 = -1944402392;
					}
					else
					{
						num = -2197262;
						num9 = -2197262;
					}
					continue;
				}
				case 17u:
					Delegate22.delegate22_51(this);
					num = ((int)num2 * -153288382) ^ -1781364716;
					continue;
				case 16u:
					num = ((int)num2 * -912846342) ^ 0x6A9E95CB;
					continue;
				case 15u:
					int_4 = int_3;
					timeSpan_1 = Delegate178.delegate178_0(checked((Delegate74.delegate74_1(Delegate15.delegate15_4(Delegate7.delegate7_217(this))) + int_4) * (list_0.Count - int_7)));
					num = -403850849;
					continue;
				case 14u:
				{
					int num13;
					int num14;
					if (!bool_1)
					{
						num13 = -1257135751;
						num14 = -1257135751;
					}
					else
					{
						num13 = -1157770973;
						num14 = -1157770973;
					}
					num = num13 ^ (int)(num2 * 2015363876);
					continue;
				}
				case 13u:
				{
					double_0 += 1.0;
					int num12;
					if ((!bool_2 & (genum6_0 != GEnum6.None)) | (bool_2 & (genum6_0 == GEnum6.AssociationFailed)))
					{
						num = -116922566;
						num12 = -116922566;
					}
					else
					{
						num = -1200165209;
						num12 = -1200165209;
					}
					continue;
				}
				case 12u:
				{
					int num11;
					if ((int_2 == 0) & !bool_2 & bool_1)
					{
						num = -499386218;
						num11 = -499386218;
					}
					else
					{
						num = -645019768;
						num11 = -645019768;
					}
					continue;
				}
				case 11u:
				{
					int num10;
					if (!(bool_4 & bool_5))
					{
						num = -609197401;
						num10 = -609197401;
					}
					else
					{
						num = -1837092685;
						num10 = -1837092685;
					}
					continue;
				}
				case 10u:
				{
					int num7;
					int num8;
					if (int_7 >= list_0.Count)
					{
						num7 = -1376708864;
						num8 = -1376708864;
					}
					else
					{
						num7 = -886630542;
						num8 = -886630542;
					}
					num = num7 ^ ((int)num2 * -1524788827);
					continue;
				}
				case 9u:
					Delegate109.delegate109_0(Delegate7.delegate7_233(this), ref gclass9_0, gclass12_0);
					bool_2 = true;
					int_3 = 0;
					num = (int)((num2 * 509751607) ^ 0x2F7FD60A);
					continue;
				case 8u:
					Delegate22.delegate22_51(this);
					num = -1608649987;
					continue;
				case 6u:
				{
					int num3;
					int num4;
					if (Delegate21.delegate21_7(Delegate7.delegate7_221(this)) & (Delegate56.delegate56_0(string_2, "", bool_0: false) != 0))
					{
						num3 = 975213179;
						num4 = 975213179;
					}
					else
					{
						num3 = 1251825387;
						num4 = 1251825387;
					}
					num = num3 ^ (int)(num2 * 386298917);
					continue;
				}
				case 5u:
					genum6_1 = genum6_0;
					num = ((int)num2 * -540272484) ^ -1628670806;
					continue;
				case 4u:
					int_7 = list_0.Count;
					num = -179712159;
					continue;
				case 3u:
					genum6_1 = genum6_0;
					num = ((int)num2 * -1297666635) ^ 0x1DE0EC72;
					continue;
				case 2u:
					Delegate22.delegate22_13(Delegate7.delegate7_220(this));
					num = (int)(num2 * 1638186739) ^ -2012338513;
					continue;
				case 1u:
					num = (int)((num2 * 416344237) ^ 0x201647AD);
					continue;
				case 0u:
					break;
				default:
					Delegate22.delegate22_56(Delegate7.delegate7_222(this));
					return;
				}
				break;
			}
		}
	}

	private void method_16(object sender, EventArgs e)
	{
		Delegate30.delegate30_22(Delegate7.delegate7_225(this), string_2);
		while (true)
		{
			int num = -1062322438;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xDF16A308u) % 5)
				{
				case 4u:
				{
					int num3;
					int num4;
					if (Delegate111.delegate111_1(Delegate7.delegate7_225(this)) != DialogResult.OK)
					{
						num3 = 1352940060;
						num4 = 1352940060;
					}
					else
					{
						num3 = 750139695;
						num4 = 750139695;
					}
					num = num3 ^ ((int)num2 * -578591913);
					continue;
				}
				case 2u:
					Delegate22.delegate22_53(this);
					num = (int)((num2 * 646204008) ^ 0x7E9C3B22);
					continue;
				case 1u:
					string_2 = Delegate15.delegate15_36(Delegate7.delegate7_225(this));
					num = (int)((num2 * 1656270583) ^ 0x10EADF57);
					continue;
				default:
					return;
				case 0u:
					break;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	private void method_17(object sender, EventArgs e)
	{
		if (Delegate56.delegate56_0(string_2, "", bool_0: false) == 0)
		{
			goto IL_00e7;
		}
		goto IL_0128;
		IL_00e7:
		int num = -834709600;
		goto IL_00ec;
		IL_00ec:
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0xB076DAC2u) % 7)
			{
			case 6u:
				Delegate30.delegate30_25(this, string_2);
				bool_4 = false;
				num = ((int)num2 * -1828061055) ^ 0x4BABF5D0;
				continue;
			case 4u:
			{
				int num3;
				int num4;
				if (Delegate111.delegate111_1(Delegate7.delegate7_226(this)) == DialogResult.OK)
				{
					num3 = 1848863114;
					num4 = 1848863114;
				}
				else
				{
					num3 = 334441433;
					num4 = 334441433;
				}
				num = num3 ^ (int)(num2 * 186979421);
				continue;
			}
			case 3u:
				Delegate30.delegate30_22(Delegate7.delegate7_226(this), string_2);
				num = ((int)num2 * -717734580) ^ -1092765472;
				continue;
			case 2u:
				string_2 = Delegate15.delegate15_36(Delegate7.delegate7_226(this));
				num = ((int)num2 * -1129167475) ^ 0x324AB959;
				continue;
			case 0u:
				break;
			default:
				return;
			case 1u:
				goto IL_0128;
			case 5u:
				return;
			}
			break;
		}
		goto IL_00e7;
		IL_0128:
		int num5;
		if (Delegate56.delegate56_0(string_2, "", bool_0: false) == 0)
		{
			num = -2101693076;
			num5 = -2101693076;
		}
		else
		{
			num = -1515112322;
			num5 = -1515112322;
		}
		goto IL_00ec;
	}

	private void method_18(object sender, EventArgs e)
	{
		Delegate5.delegate5_32(Delegate7.delegate7_220(this), !Delegate21.delegate21_7(Delegate7.delegate7_221(this)));
	}

	public bool method_19(string string_3)
	{
		FileStream fileStream = (FileStream)Delegate182.delegate182_0(string_3, FileMode.Open, FileAccess.Read);
		int num8 = default(int);
		BinaryReader binaryReader = default(BinaryReader);
		bool result = default(bool);
		int num4 = default(int);
		int num3 = default(int);
		string text = default(string);
		int num5 = default(int);
		while (true)
		{
			int num = 1526815550;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x4C4B3803u) % 26)
				{
				case 25u:
				{
					int num11;
					if (num8 < 2)
					{
						num = 21668020;
						num11 = 21668020;
					}
					else
					{
						num = 859806043;
						num11 = 859806043;
					}
					continue;
				}
				case 23u:
					num3 = binaryReader.ReadInt32();
					num = (int)(num2 * 2084052593) ^ -1830528550;
					continue;
				case 22u:
					num = ((int)num2 * -1554541108) ^ -1807114430;
					continue;
				case 21u:
					fileStream.Close();
					result = true;
					num = (int)((num2 * 1800572074) ^ 0xA3A99C8);
					continue;
				case 20u:
					Delegate52.delegate52_0(Delegate36.delegate36_61(), global::_003CModule_003E.smethod_18<string>(2580227152u, 4046851023u), MessageBoxButtons.OK);
					num = ((int)num2 * -1755150753) ^ -2014744392;
					continue;
				case 19u:
				{
					object obj = Delegate7.delegate7_217(this);
					num4 = Delegate17.delegate17_24(binaryReader);
					((ToolStripControlHost)obj).Text = num4.ToString();
					num = 828014318;
					continue;
				}
				case 18u:
					Delegate52.delegate52_0(Delegate36.delegate36_60(), global::_003CModule_003E.smethod_20<string>(2274743037u, 2319346244u), MessageBoxButtons.OK);
					result = false;
					num = (int)((num2 * 696141716) ^ 0xEADBB2);
					continue;
				case 17u:
				{
					num3 = 0;
					object obj2 = Delegate184.delegate184_0(Delegate183.delegate183_0(binaryReader, 7));
					checked
					{
						num8 = (int)Delegate185.delegate185_0(binaryReader);
						num3 = (int)Delegate185.delegate185_0(binaryReader);
						text = (string)Delegate184.delegate184_0(Delegate183.delegate183_0(binaryReader, num3));
						num3 = (int)Delegate185.delegate185_0(binaryReader);
						Delegate184.delegate184_0(Delegate183.delegate183_0(binaryReader, num3));
					}
					int num9;
					int num10;
					if (Delegate56.smethod_0((string)obj2, global::_003CModule_003E.smethod_19<string>(3318852963u, 3101040679u), bool_0: false) != 0 || num8 > 2)
					{
						num9 = 621126902;
						num10 = 621126902;
					}
					else
					{
						num9 = 1770397098;
						num10 = 1770397098;
					}
					num = num9 ^ ((int)num2 * -1291914985);
					continue;
				}
				case 16u:
					Delegate30.delegate30_16(Delegate7.delegate7_230(this), (string)Delegate184.delegate184_0(Delegate183.delegate183_0(binaryReader, num3)));
					num = (int)(num2 * 1436952618) ^ -470120472;
					continue;
				case 15u:
					num8 = 0;
					num = ((int)num2 * -181205612) ^ -538233004;
					continue;
				case 14u:
					Delegate30.delegate30_16(Delegate7.delegate7_229(this), (string)Delegate184.delegate184_0(Delegate183.delegate183_0(binaryReader, num3)));
					num = (int)(num2 * 1273418944) ^ -2074693637;
					continue;
				case 13u:
					list_0.Add(Conversions.ToString(binaryReader.ReadUInt32()));
					num = 1031262243;
					continue;
				case 12u:
					num3 = checked((int)Delegate185.delegate185_0(binaryReader));
					num = (int)((num2 * 975506372) ^ 0x3E15BB95);
					continue;
				case 11u:
				{
					int num7;
					if (num5 <= num4)
					{
						num = 1703696182;
						num7 = 1703696182;
					}
					else
					{
						num = 1424161755;
						num7 = 1424161755;
					}
					continue;
				}
				case 10u:
					num3 = checked((int)Delegate185.delegate185_0(binaryReader));
					num = ((int)num2 * -1961928673) ^ -1330062013;
					continue;
				case 8u:
					num5 = checked(num5 + 1);
					num = ((int)num2 * -1222671969) ^ 0x45ED4762;
					continue;
				case 7u:
					text = "";
					num = (int)((num2 * 416358003) ^ 0xD913797);
					continue;
				case 6u:
					binaryReader.Close();
					num = ((int)num2 * -715583509) ^ 0x50776B66;
					continue;
				case 5u:
					result = false;
					num = (int)(num2 * 1752018493) ^ -1506951400;
					continue;
				case 4u:
					num = (int)(num2 * 553380432) ^ -1863023798;
					continue;
				case 3u:
					int_7 = binaryReader.ReadInt32();
					bool_0 = binaryReader.ReadBoolean();
					double_0 = binaryReader.ReadInt32();
					num = (int)((num2 * 1349770634) ^ 0x58844992);
					continue;
				case 2u:
				{
					int num6;
					if (Delegate56.delegate56_0(text, Delegate15.delegate15_9(gclass9_0), bool_0: false) == 0)
					{
						num = 1023370836;
						num6 = 1023370836;
					}
					else
					{
						num = 1653739469;
						num6 = 1653739469;
					}
					continue;
				}
				case 1u:
					binaryReader = (BinaryReader)Delegate7.delegate7_235(fileStream);
					num = ((int)num2 * -869100371) ^ -2013876441;
					continue;
				case 0u:
					num4 = checked(num3 - 1);
					num5 = 0;
					num = ((int)num2 * -802886731) ^ -1955889903;
					continue;
				case 24u:
					break;
				default:
					return result;
				}
				break;
			}
		}
	}

	private void method_20(string string_3)
	{
		FileStream object_ = (FileStream)Delegate182.delegate182_0(string_3, FileMode.Create, FileAccess.Write);
		BinaryWriter object_2 = default(BinaryWriter);
		while (true)
		{
			int num = -2065828155;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xDA93BABCu) % 10)
				{
				case 9u:
					object_2 = (BinaryWriter)Delegate7.delegate7_82(object_);
					num = (int)((num2 * 800848034) ^ 0x6ED802DB);
					continue;
				case 8u:
					Delegate32.delegate32_4(object_2, 2);
					num = (int)(num2 * 778920654) ^ -718611253;
					continue;
				case 7u:
					Delegate66.delegate66_0(object_2, Delegate65.delegate65_0(global::_003CModule_003E.smethod_20<string>(2585317629u, 2073155499u)));
					num = (int)(num2 * 1044914738) ^ -759288954;
					continue;
				case 4u:
					Delegate66.delegate66_0(object_2, Delegate65.delegate65_1(Delegate15.delegate15_4(Delegate7.delegate7_230(this))));
					Delegate32.delegate32_4(object_2, Delegate74.delegate74_1(Delegate15.delegate15_4(Delegate7.delegate7_217(this))));
					num = ((int)num2 * -171236200) ^ 0x78B35C5E;
					continue;
				case 3u:
					Delegate32.delegate32_4(object_2, Delegate17.delegate17_7(Delegate15.delegate15_9(gclass9_0)));
					Delegate66.delegate66_0(object_2, Delegate65.delegate65_1(Delegate15.delegate15_9(gclass9_0)));
					Delegate32.delegate32_4(object_2, Delegate17.delegate17_7(Delegate15.delegate15_10(gclass9_0)));
					num = (int)(num2 * 956005351) ^ -1877077948;
					continue;
				case 2u:
					Delegate5.delegate5_53(object_2, bool_0);
					num = ((int)num2 * -223941023) ^ -505389797;
					continue;
				case 1u:
					Delegate66.delegate66_0(object_2, Delegate65.delegate65_1(Delegate15.delegate15_10(gclass9_0)));
					Delegate32.delegate32_4(object_2, Delegate17.delegate17_7(Delegate15.delegate15_4(Delegate7.delegate7_229(this))));
					Delegate66.delegate66_0(object_2, Delegate65.delegate65_1(Delegate15.delegate15_4(Delegate7.delegate7_229(this))));
					Delegate32.delegate32_4(object_2, Delegate17.delegate17_7(Delegate15.delegate15_4(Delegate7.delegate7_230(this))));
					num = ((int)num2 * -549760328) ^ 0xDFB8F22;
					continue;
				case 0u:
					Delegate32.delegate32_4(object_2, int_7);
					num = (int)((num2 * 1613923611) ^ 0x79F13E46);
					continue;
				case 6u:
					break;
				default:
				{
					Delegate32.delegate32_4(object_2, checked((int)Delegate69.delegate69_0(double_0)));
					Delegate32.delegate32_4(object_2, list_0.Count);
					using (List<string>.Enumerator enumerator = list_0.GetEnumerator())
					{
						while (true)
						{
							IL_034e:
							int num3;
							int num4;
							if (!enumerator.MoveNext())
							{
								num3 = -1067025401;
								num4 = -1067025401;
							}
							else
							{
								num3 = -1512448643;
								num4 = -1512448643;
							}
							while (true)
							{
								switch ((num2 = (uint)num3 ^ 0xDA93BABCu) % 4)
								{
								case 2u:
									num3 = -1512448643;
									continue;
								case 1u:
								{
									uint uint_ = Delegate173.delegate173_0(enumerator.Current);
									Delegate186.delegate186_0(object_2, uint_);
									num3 = -1302625868;
									continue;
								}
								default:
									goto end_IL_0320;
								case 0u:
									break;
								case 3u:
									goto end_IL_0320;
								}
								goto IL_034e;
								continue;
								end_IL_0320:
								break;
							}
							break;
						}
					}
					Delegate22.delegate22_57(object_2);
					Delegate22.delegate22_58(object_);
					return;
				}
				}
				break;
			}
		}
	}

	private void method_21(object sender, EventArgs e)
	{
		if (Delegate21.delegate21_7(Delegate7.delegate7_221(this)))
		{
			goto IL_0047;
		}
		goto IL_0071;
		IL_0047:
		int num = 194741064;
		goto IL_004c;
		IL_004c:
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0x7A898C19u) % 5)
			{
			case 2u:
				Delegate8.delegate8_77(Delegate7.delegate7_215(this), Delegate3.delegate3_106());
				num = ((int)num2 * -261127417) ^ -548058350;
				continue;
			case 0u:
				break;
			default:
				return;
			case 3u:
				goto IL_0071;
			case 1u:
				return;
			case 4u:
				return;
			}
			break;
		}
		goto IL_0047;
		IL_0071:
		Delegate8.delegate8_77(Delegate7.delegate7_215(this), Delegate3.delegate3_103());
		num = 109431636;
		goto IL_004c;
	}

	private void method_22(object sender, KeyPressEventArgs e)
	{
		if (Delegate128.delegate128_0(Delegate127.delegate127_0(e)) | Delegate128.delegate128_1(Delegate127.delegate127_0(e)))
		{
			Delegate5.delegate5_34(e, bool_0: false);
		}
		else
		{
			Delegate5.delegate5_34(e, bool_0: true);
		}
	}
}
