using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using ns1;

namespace Waircut;

[DesignerGenerated]
public class StringListEditor : Form
{
	private IContainer icontainer_0;

	[CompilerGenerated]
	[AccessedThroughProperty("TextBox1")]
	private TextBox textBox_0;

	[CompilerGenerated]
	[AccessedThroughProperty("ToolStrip1")]
	private ToolStrip toolStrip_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tsbAcept")]
	private ToolStripButton toolStripButton_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tsbCancel")]
	private ToolStripButton toolStripButton_1;

	internal virtual TextBox TextBox_0
	{
		[CompilerGenerated]
		get
		{
			return textBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			textBox_0 = value;
		}
	}

	internal virtual ToolStrip ToolStrip_0
	{
		[CompilerGenerated]
		get
		{
			return toolStrip_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStrip_0 = value;
		}
	}

	internal virtual ToolStripButton ToolStripButton_0
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_2;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = 9034535;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x2CA81136u) % 8)
					{
					case 6u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = ((int)num2 * -848937827) ^ 0x4A106A62;
						continue;
					case 5u:
					{
						int num5;
						int num6;
						if (toolStripButton == null)
						{
							num5 = 2103029;
							num6 = 2103029;
						}
						else
						{
							num5 = 293880201;
							num6 = 293880201;
						}
						num = num5 ^ ((int)num2 * -2122356275);
						continue;
					}
					case 4u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = ((int)num2 * -169030056) ^ -1778903859;
						continue;
					case 3u:
						toolStripButton_0 = value;
						num = 1164085934;
						continue;
					case 1u:
					{
						toolStripButton = toolStripButton_0;
						int num3;
						int num4;
						if (toolStripButton != null)
						{
							num3 = 1078330115;
							num4 = 1078330115;
						}
						else
						{
							num3 = 91891668;
							num4 = 91891668;
						}
						num = num3 ^ (int)(num2 * 803066537);
						continue;
					}
					case 0u:
						toolStripButton = toolStripButton_0;
						num = (int)(num2 * 1822409120) ^ -1228396581;
						continue;
					default:
						return;
					case 7u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	internal virtual ToolStripButton ToolStripButton_1
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = method_1;
			ToolStripButton toolStripButton = default(ToolStripButton);
			while (true)
			{
				int num = -714117954;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xE4417657u) % 7)
					{
					case 6u:
						Delegate8.delegate8_89(toolStripButton, object_);
						num = ((int)num2 * -2043656012) ^ -2011295749;
						continue;
					case 4u:
						Delegate8.delegate8_88(toolStripButton, object_);
						num = ((int)num2 * -248307474) ^ -1520688132;
						continue;
					case 3u:
						toolStripButton_1 = value;
						num = -1024572369;
						continue;
					case 2u:
					{
						toolStripButton = toolStripButton_1;
						int num5;
						int num6;
						if (toolStripButton != null)
						{
							num5 = 1203625331;
							num6 = 1203625331;
						}
						else
						{
							num5 = 485036682;
							num6 = 485036682;
						}
						num = num5 ^ (int)(num2 * 922481170);
						continue;
					}
					case 1u:
					{
						toolStripButton = toolStripButton_1;
						int num3;
						int num4;
						if (toolStripButton != null)
						{
							num3 = -1020853167;
							num4 = -1020853167;
						}
						else
						{
							num3 = -1603115317;
							num4 = -1603115317;
						}
						num = num3 ^ ((int)num2 * -1236782749);
						continue;
					}
					default:
						return;
					case 0u:
						break;
					case 5u:
						return;
					}
					break;
				}
			}
		}
	}

	public StringListEditor()
	{
		Delegate22.delegate22_61(this);
	}

	[DebuggerNonUserCode]
	void Form.Dispose(bool disposing)
	{
		try
		{
			if (!disposing)
			{
				return;
			}
			while (true)
			{
				int num = 1996765540;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x7F55C01Du) % 4)
					{
					case 3u:
						Delegate22.delegate22_4(icontainer_0);
						num = (int)(num2 * 2116579984) ^ -649609501;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (icontainer_0 != null)
						{
							num3 = 47138001;
							num4 = 47138001;
						}
						else
						{
							num3 = 1000144244;
							num4 = 1000144244;
						}
						num = num3 ^ (int)(num2 * 829856799);
						continue;
					}
					default:
						return;
					case 0u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
		finally
		{
			Delegate5.delegate5_3(this, disposing);
		}
	}

	[DebuggerStepThrough]
	private void method_0()
	{
		ComponentResourceManager componentResourceManager = (ComponentResourceManager)Delegate7.delegate7_4(Delegate9.delegate9_0(typeof(StringListEditor).TypeHandle));
		while (true)
		{
			int num = -1222297628;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xF7E26FD3u) % 21)
				{
				case 20u:
					((ToolStrip)Delegate7.delegate7_240(this)).ImageScalingSize = new Size(32, 32);
					ToolStrip_0.Items.AddRange(new ToolStripItem[2] { ToolStripButton_0, ToolStripButton_1 });
					num = (int)(num2 * 454337146) ^ -1663259397;
					continue;
				case 19u:
					base.Controls.Add(ToolStrip_0);
					num = (int)((num2 * 915084761) ^ 0x23524679);
					continue;
				case 18u:
					base.Name = global::_003CModule_003E.smethod_18<string>(4029414273u, 486419234u);
					num = (int)((num2 * 171495379) ^ 0x5C377C00);
					continue;
				case 17u:
					ToolStripButton_1.Name = global::_003CModule_003E.smethod_18<string>(3356633221u, 767093462u);
					num = ((int)num2 * -990907613) ^ 0x4688E89B;
					continue;
				case 16u:
					base.Controls.Add(TextBox_0);
					num = (int)(num2 * 1267699076) ^ -1592538486;
					continue;
				case 15u:
					Delegate8.delegate8_284(this, Delegate3.delegate3_67());
					Delegate8.delegate8_285(this, Delegate3.delegate3_24());
					num = (int)((num2 * 626669058) ^ 0x55DB2AB1);
					continue;
				case 14u:
					ToolStripButton_0.Image = GClass0.Bitmap_1;
					componentResourceManager.ApplyResources(ToolStripButton_0, global::_003CModule_003E.smethod_20<string>(2161750859u, 44415767u));
					num = ((int)num2 * -872348227) ^ 0x17E5E0C5;
					continue;
				case 13u:
					base.MinimizeBox = false;
					num = ((int)num2 * -1986783670) ^ 0xD638FF0;
					continue;
				case 11u:
					Delegate8.delegate8_286(this, Delegate3.delegate3_24());
					Delegate22.delegate22_5(Delegate7.delegate7_240(this));
					num = ((int)num2 * -1181122158) ^ -1783060804;
					continue;
				case 10u:
					Delegate45.delegate45_0(Delegate7.delegate7_240(this), ToolStripGripStyle.Hidden);
					num = (int)((num2 * 1721601610) ^ 0x2CD72B5);
					continue;
				case 9u:
					ToolStripButton_1.Alignment = ToolStripItemAlignment.Right;
					ToolStripButton_1.Image = GClass0.Bitmap_14;
					componentResourceManager.ApplyResources(ToolStripButton_1, global::_003CModule_003E.smethod_22<string>(2530870500u, 4217626421u));
					num = ((int)num2 * -1232821176) ^ 0x278F0AB7;
					continue;
				case 8u:
					ToolStrip_0.PerformLayout();
					ResumeLayout(performLayout: false);
					PerformLayout();
					num = (int)(num2 * 82011743) ^ -27090148;
					continue;
				case 7u:
					ToolStrip_0.Name = global::_003CModule_003E.smethod_21<string>(418596119u, 1949113088u);
					num = ((int)num2 * -394801581) ^ -710357428;
					continue;
				case 6u:
					ToolStripButton_0.Name = global::_003CModule_003E.smethod_18<string>(2114696134u, 2287225968u);
					num = ((int)num2 * -1661496330) ^ -1083278573;
					continue;
				case 5u:
					Delegate22.delegate22_7(this);
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_241(this), global::_003CModule_003E.smethod_22<string>(3090063178u, 2432876410u));
					Delegate30.delegate30_0(Delegate7.delegate7_241(this), global::_003CModule_003E.smethod_22<string>(3090063178u, 2016965154u));
					Delegate27.delegate27_0(componentResourceManager, Delegate7.delegate7_240(this), global::_003CModule_003E.smethod_18<string>(2886412852u, 1477257984u));
					num = (int)((num2 * 1058021377) ^ 0x6CC48FD8);
					continue;
				case 4u:
					componentResourceManager.ApplyResources(this, global::_003CModule_003E.smethod_20<string>(1152083978u, 2959999758u));
					base.AutoScaleMode = AutoScaleMode.Font;
					num = (int)((num2 * 1407905225) ^ 0x3BDEC07B);
					continue;
				case 2u:
					base.ShowIcon = false;
					ToolStrip_0.ResumeLayout(performLayout: false);
					num = ((int)num2 * -1938523269) ^ -1358796690;
					continue;
				case 1u:
					Delegate8.delegate8_283(this, Delegate3.delegate3_28());
					num = ((int)num2 * -942973951) ^ 0x7E2FDD16;
					continue;
				case 0u:
					base.FormBorderStyle = FormBorderStyle.FixedDialog;
					base.MaximizeBox = false;
					num = ((int)num2 * -637287499) ^ -226371051;
					continue;
				default:
					return;
				case 12u:
					break;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	private void method_1(object sender, EventArgs e)
	{
		Delegate195.delegate195_0(this, DialogResult.Cancel);
		Delegate22.delegate22_11(this);
	}

	private void method_2(object sender, EventArgs e)
	{
		Delegate195.delegate195_0(this, DialogResult.OK);
		Delegate22.delegate22_11(this);
	}

	public void method_3(string string_0)
	{
		Delegate4.smethod_0(Delegate7.delegate7_241(this), Delegate70.smethod_0((object)string_0, new char[1] { ';' }));
		Delegate196.delegate196_0(Delegate7.delegate7_241(this), Delegate17.delegate17_26(Delegate7.delegate7_241(this)), 0);
	}

	public string method_4()
	{
		string text = "";
		string[] array = Delegate113.delegate113_0(Delegate7.delegate7_241(this));
		string text2 = default(string);
		int num3 = default(int);
		while (true)
		{
			int num = -1996411668;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xF1307393u) % 11)
				{
				case 10u:
					text = Delegate71.delegate71_0(text, text2, global::_003CModule_003E.smethod_21<string>(838673625u, 3050325187u));
					num = ((int)num2 * -896838966) ^ -486662063;
					continue;
				case 9u:
				{
					int num5;
					int num6;
					if (Delegate17.delegate17_7(text2) > 0)
					{
						num5 = 274684464;
						num6 = 274684464;
					}
					else
					{
						num5 = 492381171;
						num6 = 492381171;
					}
					num = num5 ^ ((int)num2 * -679605316);
					continue;
				}
				case 8u:
				{
					int num7;
					int num8;
					if (Delegate17.delegate17_7(text) <= 0)
					{
						num7 = 1052035951;
						num8 = 1052035951;
					}
					else
					{
						num7 = 589968826;
						num8 = 589968826;
					}
					num = num7 ^ ((int)num2 * -301965955);
					continue;
				}
				case 7u:
					num3 = checked(num3 + 1);
					num = -103385553;
					continue;
				case 6u:
					num = (int)(num2 * 1588443345) ^ -2003203873;
					continue;
				case 4u:
					text2 = array[num3];
					Delegate76.delegate76_0(text2, global::_003CModule_003E.smethod_21<string>(2978191527u, 2126785908u), "");
					num = -1058786988;
					continue;
				case 3u:
				{
					int num4;
					if (num3 >= array.Length)
					{
						num = -2096611251;
						num4 = -2096611251;
					}
					else
					{
						num = -1172816620;
						num4 = -1172816620;
					}
					continue;
				}
				case 2u:
					text = Delegate77.delegate77_1(text, checked(Delegate17.delegate17_7(text) - 1), 1);
					num = (int)((num2 * 921096371) ^ 0x58B9C634);
					continue;
				case 1u:
					num3 = 0;
					num = ((int)num2 * -264531344) ^ 0x56B08DF3;
					continue;
				case 5u:
					break;
				default:
					return text;
				}
				break;
			}
		}
	}
}
