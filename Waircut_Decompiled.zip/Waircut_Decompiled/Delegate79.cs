internal delegate ulong Delegate79(string string_0, int int_0);
