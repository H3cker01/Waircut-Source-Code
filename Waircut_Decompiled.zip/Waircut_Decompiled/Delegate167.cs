using System.Windows.Forms;

internal delegate void Delegate167(object object_0, ProgressBarStyle progressBarStyle_0);
