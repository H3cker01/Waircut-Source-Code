using System;
using System.Collections.Generic;
using System.ComponentModel;
using ns0;
using ns1;

public class GClass16<T> : Comparer<T>
{
	private PropertyDescriptor propertyDescriptor_0;

	private ListSortDirection listSortDirection_0;

	public GClass16(PropertyDescriptor propertyDescriptor_1, ListSortDirection listSortDirection_1)
	{
		propertyDescriptor_0 = propertyDescriptor_1;
		listSortDirection_0 = listSortDirection_1;
	}

	int Comparer<T>.Compare(T x, T y)
	{
		object object_ = Delegate7.delegate7_2(method_4(x, Delegate15.delegate15_38(propertyDescriptor_0)));
		object object_2 = Delegate7.delegate7_2(method_4(y, Delegate15.delegate15_38(propertyDescriptor_0)));
		int result = default(int);
		while (true)
		{
			int num = 1009262209;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x4BFD98F7u) % 6)
				{
				case 4u:
					result = method_3(Delegate7.delegate7_2(object_), Delegate7.delegate7_2(object_2));
					num = 1614725811;
					continue;
				case 3u:
					result = method_2(Delegate7.delegate7_2(object_), Delegate7.delegate7_2(object_2));
					num = (int)((num2 * 1071129517) ^ 0x31C03F7);
					continue;
				case 2u:
				{
					int num3;
					int num4;
					if (listSortDirection_0 == ListSortDirection.Ascending)
					{
						num3 = -1594571590;
						num4 = -1594571590;
					}
					else
					{
						num3 = -2138212083;
						num4 = -2138212083;
					}
					num = num3 ^ (int)(num2 * 1318574106);
					continue;
				}
				case 1u:
					num = (int)((num2 * 1548649895) ^ 0x72AB27D8);
					continue;
				case 5u:
					break;
				default:
					return result;
				}
				break;
			}
		}
	}

	public bool method_0(T gparam_0, T gparam_1)
	{
		return gparam_0.Equals(gparam_1);
	}

	public int method_1(T gparam_0)
	{
		return gparam_0.GetHashCode();
	}

	private int method_2(object object_0, object object_1)
	{
		if (object_0 is IComparable)
		{
			goto IL_0063;
		}
		goto IL_00e4;
		IL_0063:
		int num = -38700380;
		goto IL_00a4;
		IL_00a4:
		int result = default(int);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)num ^ 0x8A78B956u) % 8)
			{
			case 7u:
				result = Delegate194.delegate194_0(Delegate15.delegate15_8(object_0), Delegate15.delegate15_8(object_1));
				num = -2135283169;
				continue;
			case 6u:
				num = (int)((num2 * 1740529563) ^ 0x620C30D5);
				continue;
			case 5u:
				num = (int)((num2 * 1425648750) ^ 0x54614929);
				continue;
			case 3u:
				break;
			case 2u:
				result = Delegate102.delegate102_1((IComparable)object_0, Delegate7.delegate7_2(object_1));
				num = ((int)num2 * -140050483) ^ -1384119775;
				continue;
			case 0u:
				result = 0;
				num = ((int)num2 * -681834958) ^ 0x18208868;
				continue;
			case 4u:
				goto IL_00e4;
			default:
				return result;
			}
			break;
		}
		goto IL_0063;
		IL_00e4:
		int num3;
		if (!Delegate10.delegate10_3(object_0, Delegate7.delegate7_2(object_1)))
		{
			num = -1640825391;
			num3 = -1640825391;
		}
		else
		{
			num = -1493724106;
			num3 = -1493724106;
		}
		goto IL_00a4;
	}

	private int method_3(object object_0, object object_1)
	{
		return checked(method_2(Delegate7.delegate7_2(object_0), Delegate7.delegate7_2(object_1)) * -1);
	}

	private object method_4(T gparam_0, string string_0)
	{
		return Delegate112.delegate112_1(Delegate24.delegate24_4(gparam_0.GetType(), string_0), gparam_0, null);
	}
}
