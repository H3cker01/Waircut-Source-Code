using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[ComImport]
[CoClass(typeof(object))]
[CompilerGenerated]
[TypeIdentifier]
[Guid("EE7D19C0-5F06-441C-A498-ED29010A1B3A")]
public interface GInterface11 : GInterface0
{
}
