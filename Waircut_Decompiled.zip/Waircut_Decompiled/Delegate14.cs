using System;

internal delegate void Delegate14(Exception exception_0);
