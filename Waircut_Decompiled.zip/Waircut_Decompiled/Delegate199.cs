internal delegate byte[] Delegate199();
