using System.Windows.Forms;

internal delegate void Delegate166(object object_0, ControlStyles controlStyles_0, bool bool_0);
