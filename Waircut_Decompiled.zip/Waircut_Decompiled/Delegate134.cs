internal delegate string Delegate134(byte[] byte_0);
