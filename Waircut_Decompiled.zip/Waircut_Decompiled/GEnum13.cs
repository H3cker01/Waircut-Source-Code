using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
[TypeIdentifier("c9178c19-99cf-4f6d-85c6-3ef5a176f9fb", "JSWSCAPILib.JswDeviceType")]
public enum GEnum13
{
	JswDeviceType_Unknown,
	JswDeviceType_WiFi,
	JswDeviceType_NonWiFi
}
