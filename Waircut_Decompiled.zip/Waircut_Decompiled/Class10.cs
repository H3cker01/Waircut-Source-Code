using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
internal class Class10
{
	private static ResourceManager resourceManager_0;

	private static CultureInfo cultureInfo_0;

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager_0
	{
		get
		{
			if (Delegate10.delegate10_2(resourceManager_0, null))
			{
				while (true)
				{
					int num = 1380136710;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x56208661u) % 3)
						{
						case 2u:
							resourceManager_0 = (ResourceManager)Delegate16.delegate16_1(global::_003CModule_003E.smethod_20<string>(2235609249u, 3412957912u), Delegate7.delegate7_3(Delegate9.delegate9_0(typeof(Class10).TypeHandle)));
							num = ((int)num2 * -422254286) ^ 0x7173D35B;
							continue;
						case 0u:
							break;
						default:
							goto end_IL_0075;
						}
						break;
					}
					continue;
					end_IL_0075:
					break;
				}
			}
			return resourceManager_0;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo CultureInfo_0
	{
		get
		{
			return cultureInfo_0;
		}
		set
		{
			cultureInfo_0 = value;
		}
	}

	internal static string String_0 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(2652118226u, 675850951u), cultureInfo_0);

	internal static string String_1 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_20<string>(2975424329u, 4003847784u), cultureInfo_0);

	internal static string String_2 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_22<string>(2389382424u, 2352433731u), cultureInfo_0);

	internal static string String_3 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(3549766090u, 1441176597u), cultureInfo_0);

	internal static string String_4 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_18<string>(2568733422u, 2482151716u), cultureInfo_0);

	internal static string String_5 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_20<string>(771444592u, 839980588u), cultureInfo_0);

	internal static string String_6 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_18<string>(3345139491u, 244249055u), cultureInfo_0);

	internal static string String_7 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(2199981112u, 753501542u), cultureInfo_0);

	internal static string String_8 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_22<string>(1221676135u, 103230210u), cultureInfo_0);

	internal static string String_9 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(2134027010u, 3581582206u), cultureInfo_0);

	internal static string String_10 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(618349238u, 1284381643u), cultureInfo_0);

	internal static string String_11 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_18<string>(1742859520u, 4020959812u), cultureInfo_0);

	internal static string String_12 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(3055255177u, 1512692498u), cultureInfo_0);

	internal static string String_13 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_18<string>(1586640436u, 2881720714u), cultureInfo_0);

	internal static string String_14 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_18<string>(3501358575u, 679681645u), cultureInfo_0);

	internal static string String_15 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_20<string>(1413732997u, 2865253410u), cultureInfo_0);

	internal static string String_16 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_22<string>(763505668u, 809865430u), cultureInfo_0);

	internal static string String_17 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_22<string>(4116281391u, 304574549u), cultureInfo_0);

	internal static string String_18 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_22<string>(2032234168u, 1819621705u), cultureInfo_0);

	internal static string String_19 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(1010895812u, 1263427414u), cultureInfo_0);

	internal static string String_20 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_18<string>(4274638410u, 1014080444u), cultureInfo_0);

	internal static string String_21 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(1327753108u, 1260839015u), cultureInfo_0);

	internal static string String_22 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(1373591566u, 707368473u), cultureInfo_0);

	internal static string String_23 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(3042456012u, 1689696046u), cultureInfo_0);

	internal static string String_24 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(3066484929u, 2892596914u), cultureInfo_0);

	internal static string String_25 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(3043494076u, 1546500771u), cultureInfo_0);

	internal static string String_26 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(3405151766u, 3137487619u), cultureInfo_0);

	internal static string String_27 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(1823519892u, 1977106995u), cultureInfo_0);

	internal static string String_28 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(164855310u, 844220270u), cultureInfo_0);

	internal static string String_29 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_22<string>(2083935446u, 815591017u), cultureInfo_0);

	internal static string String_30 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(2055366788u, 2322455580u), cultureInfo_0);

	internal static string String_31 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_22<string>(1245146429u, 2921585039u), cultureInfo_0);

	internal static string String_32 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_22<string>(2210808296u, 408152442u), cultureInfo_0);

	internal static string String_33 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(1753880912u, 669600792u), cultureInfo_0);

	internal static string String_34 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_18<string>(1428858235u, 671699824u), cultureInfo_0);

	internal static string String_35 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_20<string>(2091686065u, 299735001u), cultureInfo_0);

	internal static string String_36 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(2098983074u, 1047867426u), cultureInfo_0);

	internal static string String_37 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_22<string>(3150619524u, 415929523u), cultureInfo_0);

	internal static string String_38 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(2801406495u, 3125536109u), cultureInfo_0);

	internal static string String_39 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_18<string>(2418766806u, 3158440262u), cultureInfo_0);

	internal static string String_40 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_22<string>(2055704462u, 3547648868u), cultureInfo_0);

	internal static string String_41 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_20<string>(4202872784u, 1699244903u), cultureInfo_0);

	internal static string String_42 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(1120304082u, 1978281652u), cultureInfo_0);

	internal static string String_43 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(3838994738u, 13376141u), cultureInfo_0);

	internal static string String_44 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(625203719u, 3383279317u), cultureInfo_0);

	internal static string String_45 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_18<string>(3918984877u, 3681707389u), cultureInfo_0);

	internal static string String_46 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_20<string>(2995623489u, 2796994406u), cultureInfo_0);

	internal static string String_47 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_20<string>(3735438569u, 2152888941u), cultureInfo_0);

	internal static string String_48 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_18<string>(3351391959u, 1631568174u), cultureInfo_0);

	internal static string String_49 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(602212866u, 2916846157u), cultureInfo_0);

	internal static string String_50 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_18<string>(505611784u, 1230270144u), cultureInfo_0);

	internal static string String_51 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_22<string>(2513874929u, 2980108930u), cultureInfo_0);

	internal static string String_52 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(3526798003u, 2996847915u), cultureInfo_0);

	internal static string String_53 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(182186378u, 1026630889u), cultureInfo_0);

	internal static string String_54 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_20<string>(1916831875u, 3079633995u), cultureInfo_0);

	internal static string String_55 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(951194172u, 1309459838u), cultureInfo_0);

	internal static string String_56 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(3664529594u, 560775262u), cultureInfo_0);

	internal static string String_57 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_18<string>(3502921692u, 3630261858u), cultureInfo_0);

	internal static string String_58 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_20<string>(3771103232u, 602248598u), cultureInfo_0);

	internal static string String_59 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(3469090531u, 3885603954u), cultureInfo_0);

	internal static string String_60 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_20<string>(3288203514u, 584160681u), cultureInfo_0);

	internal static string String_61 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(2025515968u, 1721737162u), cultureInfo_0);

	internal static string String_62 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_20<string>(714316237u, 1983128428u), cultureInfo_0);

	internal static string String_63 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(1750052786u, 1173767752u), cultureInfo_0);

	internal static string String_64 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(417754693u, 3843971531u), cultureInfo_0);

	internal static string String_65 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(740157984u, 3944608953u), cultureInfo_0);

	internal static string String_66 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(3423108825u, 2891141274u), cultureInfo_0);

	internal static string String_67 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_20<string>(4043484097u, 3793283198u), cultureInfo_0);

	internal static string String_68 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_18<string>(1951672671u, 307505474u), cultureInfo_0);

	internal static string String_69 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(4107575187u, 1171091356u), cultureInfo_0);

	internal static string String_70 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(762963562u, 3899776022u), cultureInfo_0);

	internal static string String_71 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(3476298984u, 1517078891u), cultureInfo_0);

	internal static string String_72 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_18<string>(3504484809u, 2956335816u), cultureInfo_0);

	internal static string String_73 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_20<string>(375339703u, 3875035381u), cultureInfo_0);

	internal static string String_74 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_19<string>(1788101517u, 3562410721u), cultureInfo_0);

	internal static string String_75 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_21<string>(1437856051u, 3670117557u), cultureInfo_0);

	internal static string String_76 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_22<string>(2257748884u, 1309566815u), cultureInfo_0);

	internal static string String_77 => Delegate18.delegate18_0(Delegate3.delegate3_3(), global::_003CModule_003E.smethod_20<string>(3945957422u, 3768815779u), cultureInfo_0);

	internal Class10()
	{
	}
}
