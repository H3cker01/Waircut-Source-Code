using System.ServiceProcess;

internal delegate ServiceControllerStatus Delegate197(object object_0);
