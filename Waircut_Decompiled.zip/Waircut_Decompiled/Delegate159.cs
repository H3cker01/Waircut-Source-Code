using System.Net;

internal delegate void Delegate159(SecurityProtocolType securityProtocolType_0);
