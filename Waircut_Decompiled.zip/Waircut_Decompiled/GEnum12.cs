using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
[TypeIdentifier("c9178c19-99cf-4f6d-85c6-3ef5a176f9fb", "JSWSCAPILib.JswDevicePasswordID")]
public enum GEnum12
{
	JswDevicePasswordID_Default,
	JswDevicePasswordID_UserSpecified,
	JswDevicePasswordID_MachineSpecified,
	JswDevicePasswordID_Rekey,
	JswDevicePasswordID_PushButton,
	JswDevicePasswordID_RegistrarSpecified
}
