internal delegate void Delegate157(int int_0);
