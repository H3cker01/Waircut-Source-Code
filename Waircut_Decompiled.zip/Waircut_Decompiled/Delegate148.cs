internal delegate object Delegate148(object object_0, ref GInterface5 ginterface5_0, GEnum9 genum9_0);
