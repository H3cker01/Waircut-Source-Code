internal delegate byte[] Delegate86(object object_0, byte[] byte_0);
