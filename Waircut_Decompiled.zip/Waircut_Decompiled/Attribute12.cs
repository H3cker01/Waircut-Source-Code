using System;

internal class Attribute12 : Attribute
{
	internal readonly int int_0;

	internal Attribute12(int int_1)
	{
		while (true)
		{
			int num = 322593734;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x2A5FD5A0u) % 3)
				{
				case 1u:
					goto IL_0008;
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
				IL_0008:
				int_0 = ((int_1 - -17917998) ^ -1654253015) * 801361337;
				num = ((int)num2 * -217306349) ^ -1668006710;
			}
		}
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
