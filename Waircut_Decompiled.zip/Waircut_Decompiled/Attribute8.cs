using System;

internal class Attribute8 : Attribute
{
	internal readonly int int_0;

	internal Attribute8(int int_1)
	{
		int_0 = (661161278 - int_1 * -143186501) ^ -2078698242;
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
