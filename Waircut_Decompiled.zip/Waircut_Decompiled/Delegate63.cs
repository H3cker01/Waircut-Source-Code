using System.Collections.Generic;

internal delegate object Delegate63(object object_0, ref List<GClass1.GClass2> list_0);
