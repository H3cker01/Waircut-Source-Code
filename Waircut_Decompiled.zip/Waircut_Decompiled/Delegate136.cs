internal delegate GEnum13 Delegate136(object object_0);
