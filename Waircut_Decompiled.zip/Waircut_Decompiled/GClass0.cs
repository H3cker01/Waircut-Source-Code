using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

[StandardModule]
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
[HideModuleName]
public sealed class GClass0
{
	private static ResourceManager resourceManager_0;

	private static CultureInfo cultureInfo_0;

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	public static ResourceManager ResourceManager_0
	{
		get
		{
			if (Delegate10.delegate10_2(resourceManager_0, null))
			{
				while (true)
				{
					int num = -1348602827;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num ^ 0x84D7DD63u) % 3)
						{
						case 1u:
							resourceManager_0 = (ResourceManager)Delegate16.delegate16_1(global::_003CModule_003E.smethod_20<string>(262347525u, 1886873521u), Delegate7.delegate7_3(Delegate9.delegate9_0(typeof(GClass0).TypeHandle)));
							num = ((int)num2 * -220509766) ^ -236847862;
							continue;
						case 2u:
							break;
						default:
							goto end_IL_0075;
						}
						break;
					}
					continue;
					end_IL_0075:
					break;
				}
			}
			return resourceManager_0;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	public static CultureInfo CultureInfo_0
	{
		get
		{
			return cultureInfo_0;
		}
		set
		{
			cultureInfo_0 = value;
		}
	}

	public static Bitmap Bitmap_0 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_21<string>(3338567393u, 2941174447u), cultureInfo_0));

	public static Bitmap Bitmap_1 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(2687688367u, 2121441163u), cultureInfo_0));

	public static Bitmap Bitmap_2 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_19<string>(1027809321u, 1441815216u), cultureInfo_0));

	public static Bitmap Bitmap_3 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(2093823702u, 1406142321u), cultureInfo_0));

	public static Bitmap Bitmap_4 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_20<string>(489596413u, 1044712008u), cultureInfo_0));

	public static Bitmap Bitmap_5 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(2255368539u, 1860514140u), cultureInfo_0));

	public static Bitmap Bitmap_6 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_21<string>(290067149u, 4006205248u), cultureInfo_0));

	public static Bitmap Bitmap_7 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_19<string>(3088944433u, 3301170029u), cultureInfo_0));

	public static Bitmap Bitmap_8 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(2404698753u, 3305796504u), cultureInfo_0));

	public static Bitmap Bitmap_9 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(333761530u, 7931407u), cultureInfo_0));

	public static Bitmap Bitmap_10 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(298194166u, 1174341188u), cultureInfo_0));

	public static Bitmap Bitmap_11 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(2788710578u, 1673937721u), cultureInfo_0));

	public static Bitmap Bitmap_12 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_19<string>(2893256508u, 1419681999u), cultureInfo_0));

	public static byte[] Byte_0 => (byte[])Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(1949921561u, 3077532523u), cultureInfo_0));

	public static Bitmap Bitmap_13 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_20<string>(1003427137u, 1196999892u), cultureInfo_0));

	public static Bitmap Bitmap_14 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(2559354720u, 2778390365u), cultureInfo_0));

	public static Bitmap Bitmap_15 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_20<string>(1743242217u, 3036369899u), cultureInfo_0));

	public static Bitmap Bitmap_16 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_21<string>(1196806534u, 727410731u), cultureInfo_0));

	public static Bitmap Bitmap_17 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_21<string>(202834577u, 540159113u), cultureInfo_0));

	public static Bitmap Bitmap_18 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_19<string>(2547862364u, 116735925u), cultureInfo_0));

	public static Bitmap Bitmap_19 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(2307069817u, 1374959665u), cultureInfo_0));

	public static string String_0 => Delegate18.delegate18_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(3906479941u, 549996718u), cultureInfo_0);

	public static Bitmap Bitmap_20 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(1835542718u, 1934898950u), cultureInfo_0));

	public static Bitmap Bitmap_21 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_19<string>(3492081384u, 2539247347u), cultureInfo_0));

	public static Bitmap Bitmap_22 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(1370011700u, 2619939182u), cultureInfo_0));

	public static Bitmap Bitmap_23 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(800855665u, 3363375484u), cultureInfo_0));

	public static Bitmap Bitmap_24 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(904480682u, 269015046u), cultureInfo_0));

	public static Bitmap Bitmap_25 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(335324647u, 4285696646u), cultureInfo_0));

	public static Bitmap Bitmap_26 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_19<string>(2847274802u, 2076890345u), cultureInfo_0));

	public static Bitmap Bitmap_27 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(220642249u, 1697421746u), cultureInfo_0));

	public static Bitmap Bitmap_28 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(2712447570u, 3577738586u), cultureInfo_0));

	public static Bitmap Bitmap_29 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_20<string>(2647179641u, 4273278233u), cultureInfo_0));

	public static Bitmap Bitmap_30 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(2838031511u, 3854401852u), cultureInfo_0));

	public static Bitmap Bitmap_31 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(2278838833u, 1843211187u), cultureInfo_0));

	public static Bitmap Bitmap_32 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_20<string>(1794372383u, 4025685089u), cultureInfo_0));

	public static Bitmap Bitmap_33 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_19<string>(474966151u, 4177209870u), cultureInfo_0));

	public static Bitmap Bitmap_34 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_19<string>(774378589u, 3471322163u), cultureInfo_0));

	public static Bitmap Bitmap_35 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_19<string>(2685807482u, 1361564919u), cultureInfo_0));

	public static Bitmap Bitmap_36 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(3074353571u, 3101563154u), cultureInfo_0));

	public static Bitmap Bitmap_37 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(3881245295u, 1719388374u), cultureInfo_0));

	public static Bitmap Bitmap_38 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_20<string>(458665407u, 928399969u), cultureInfo_0));

	public static Bitmap Bitmap_39 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_19<string>(129572007u, 1425897909u), cultureInfo_0));

	public static Bitmap Bitmap_40 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(1264823566u, 3834761424u), cultureInfo_0));

	public static Bitmap Bitmap_41 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(2506760653u, 1844694745u), cultureInfo_0));

	public static Bitmap Bitmap_42 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_20<string>(3900825445u, 3346084502u), cultureInfo_0));

	public static Bitmap Bitmap_43 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_20<string>(715580769u, 3175209885u), cultureInfo_0));

	public static Bitmap Bitmap_44 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(230136513u, 219001328u), cultureInfo_0));

	public static Bitmap Bitmap_45 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(1771347433u, 2526314177u), cultureInfo_0));

	public static Bitmap Bitmap_46 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_20<string>(3176475868u, 1176077598u), cultureInfo_0));

	public static Bitmap Bitmap_47 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_19<string>(83590301u, 1188224694u), cultureInfo_0));

	public static Bitmap Bitmap_48 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(3903353707u, 2248791677u), cultureInfo_0));

	public static Bitmap Bitmap_49 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(2863882150u, 2614334225u), cultureInfo_0));

	public static Bitmap Bitmap_50 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(3829544017u, 2529504020u), cultureInfo_0));

	public static Bitmap Bitmap_51 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(3166948783u, 3229718112u), cultureInfo_0));

	public static Bitmap Bitmap_52 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_21<string>(1979579794u, 400556361u), cultureInfo_0));

	public static Bitmap Bitmap_53 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(2607756105u, 1807604942u), cultureInfo_0));

	public static Bitmap Bitmap_54 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(803305221u, 1468140727u), cultureInfo_0));

	public static Bitmap Bitmap_55 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_19<string>(3318852963u, 905758510u), cultureInfo_0));

	public static Bitmap Bitmap_56 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_22<string>(3014225294u, 646935228u), cultureInfo_0));

	public static Bitmap Bitmap_57 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_19<string>(2823752600u, 2392073543u), cultureInfo_0));

	public static Bitmap Bitmap_58 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_19<string>(3940668692u, 3628104561u), cultureInfo_0));

	public static Bitmap Bitmap_59 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_21<string>(1935963508u, 876622434u), cultureInfo_0));

	public static Bitmap Bitmap_60 => (Bitmap)Delegate7.delegate7_2(Delegate19.delegate19_0(Delegate3.delegate3_4(), global::_003CModule_003E.smethod_18<string>(4064262142u, 2004287851u), cultureInfo_0));
}
