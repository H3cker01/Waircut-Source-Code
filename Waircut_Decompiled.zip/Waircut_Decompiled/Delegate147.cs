internal delegate void Delegate147(object object_0, ref GInterface5 ginterface5_0);
