using System;

internal delegate string Delegate151(Array array_0, Array array_1);
