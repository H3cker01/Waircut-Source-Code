internal delegate string Delegate15(object object_0);
