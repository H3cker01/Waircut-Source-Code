internal delegate string Delegate71(string string_0, string string_1, string string_2);
