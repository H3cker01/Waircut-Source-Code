using System;

internal class Attribute13 : Attribute
{
	internal readonly int int_0;

	internal Attribute13(int int_1)
	{
		int_0 = -int_1 * 1331003331;
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
