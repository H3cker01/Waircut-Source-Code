using System;

internal delegate string Delegate150(Array array_0, string string_0);
