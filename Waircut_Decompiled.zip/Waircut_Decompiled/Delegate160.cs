using System.Text.RegularExpressions;

internal delegate object Delegate160(string string_0, RegexOptions regexOptions_0);
