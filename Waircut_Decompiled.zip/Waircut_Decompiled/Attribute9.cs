using System;

internal class Attribute9 : Attribute
{
	internal readonly int int_0;

	internal Attribute9(int int_1)
	{
		int_0 = -(int_1 - 971696965);
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
