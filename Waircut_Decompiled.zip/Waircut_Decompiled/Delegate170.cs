internal delegate int Delegate170(object object_0, int int_0, int int_1);
