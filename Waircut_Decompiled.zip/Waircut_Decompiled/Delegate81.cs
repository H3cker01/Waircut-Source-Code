internal delegate string Delegate81(string string_0);
