using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using ns1;

public class GClass14 : Label
{
	public enum GEnum7
	{
		horizontal,
		vertical
	}

	[CompilerGenerated]
	[AccessedThroughProperty("tick")]
	private Timer timer_0;

	private int int_0;

	private int int_1;

	private SizeF sizeF_0;

	private List<string> list_0;

	private GEnum7 genum7_0;

	private virtual Timer Timer_0
	{
		[CompilerGenerated]
		get
		{
			return timer_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler object_ = [SpecialName] (object sender, EventArgs e) =>
			{
				Delegate22.delegate22_60(this);
			};
			Timer timer = timer_0;
			if (timer != null)
			{
				goto IL_001a;
			}
			goto IL_00bc;
			IL_001a:
			int num = -1492757384;
			goto IL_008f;
			IL_008f:
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xBA9006A4u) % 7)
				{
				case 6u:
					break;
				case 5u:
					timer = timer_0;
					num = (int)((num2 * 1203315305) ^ 0x1EBD781B);
					continue;
				case 2u:
					Delegate8.delegate8_94(timer, object_);
					num = ((int)num2 * -643772114) ^ -23342606;
					continue;
				case 1u:
				{
					int num3;
					int num4;
					if (timer == null)
					{
						num3 = 917917795;
						num4 = 917917795;
					}
					else
					{
						num3 = 303263932;
						num4 = 303263932;
					}
					num = num3 ^ ((int)num2 * -1059608888);
					continue;
				}
				case 0u:
					Delegate8.delegate8_95(timer, object_);
					num = ((int)num2 * -460384132) ^ 0x7FCC27B3;
					continue;
				default:
					return;
				case 4u:
					goto IL_00bc;
				case 3u:
					return;
				}
				break;
			}
			goto IL_001a;
			IL_00bc:
			timer_0 = value;
			num = -1987276747;
			goto IL_008f;
		}
	}

	[Category("Behavior")]
	[EditorBrowsable(EditorBrowsableState.Always)]
	[Browsable(true)]
	public int Int32_0
	{
		get
		{
			return Delegate17.delegate17_6(Delegate7.delegate7_239(this));
		}
		set
		{
			Delegate32.delegate32_1(Delegate7.delegate7_239(this), value);
		}
	}

	[Browsable(true)]
	[Category("Appearance")]
	[EditorBrowsable(EditorBrowsableState.Always)]
	public GEnum7 GEnum7_0
	{
		get
		{
			return genum7_0;
		}
		set
		{
			genum7_0 = value;
		}
	}

	public GClass14()
	{
		Delegate8.delegate8_282(this, Delegate3.delegate3_107());
		int_0 = Delegate17.delegate17_20(this);
		checked
		{
			int_1 = (int)Math.Round(((float)Delegate17.delegate17_21(this) - sizeF_0.Height) / 2f);
			list_0 = new List<string>();
			DoubleBuffered = true;
			int_0 = base.Width;
			Timer_0.Interval = 200;
			Timer_0.Start();
			if (GEnum7_0 == GEnum7.vertical)
			{
				int_1 = (int)Math.Round((double)base.Height / 2.0);
			}
		}
	}

	void Label.OnPaint(PaintEventArgs e)
	{
		Delegate22.delegate22_59(this);
		SolidBrush solidBrush = (SolidBrush)Delegate188.delegate188_0(Delegate187.delegate187_0(this));
		try
		{
			GEnum7 gEnum = genum7_0;
			string current2 = default(string);
			ContentAlignment contentAlignment = default(ContentAlignment);
			while (true)
			{
				int num = 1871243571;
				while (true)
				{
					int num5;
					uint num2;
					switch ((num2 = (uint)num ^ 0x2B11CB76u) % 5)
					{
					case 4u:
					{
						int num6;
						int num7;
						if (gEnum == GEnum7.horizontal)
						{
							num6 = 783165760;
							num7 = 783165760;
						}
						else
						{
							num6 = 1686858519;
							num7 = 1686858519;
						}
						num = num6 ^ (int)(num2 * 490228186);
						continue;
					}
					case 0u:
						if (gEnum != GEnum7.vertical)
						{
							num = (int)(num2 * 2146516250) ^ -1105949574;
							continue;
						}
						goto IL_01a0;
					case 2u:
						break;
					case 1u:
						return;
					default:
						{
							string string_ = "";
							using (List<string>.Enumerator enumerator = list_0.GetEnumerator())
							{
								while (true)
								{
									IL_0130:
									int num3 = 342957982;
									while (true)
									{
										switch ((num2 = (uint)num3 ^ 0x2B11CB76u) % 5)
										{
										case 3u:
											num3 = ((int)num2 * -359541622) ^ 0x3303F43C;
											continue;
										case 1u:
										{
											int num4;
											if (!enumerator.MoveNext())
											{
												num3 = 1511919359;
												num4 = 1511919359;
											}
											else
											{
												num3 = 487810448;
												num4 = 487810448;
											}
											continue;
										}
										case 0u:
										{
											string current = enumerator.Current;
											string_ = Delegate71.delegate71_0(string_, current, global::_003CModule_003E.smethod_19<string>(1037976375u, 3455946260u));
											num3 = 854135084;
											continue;
										}
										default:
											goto end_IL_010a;
										case 4u:
											break;
										case 2u:
											goto end_IL_010a;
										}
										goto IL_0130;
										continue;
										end_IL_010a:
										break;
									}
									break;
								}
							}
							sizeF_0 = Delegate189.delegate189_0(Delegate7.delegate7_236(e), string_, Delegate7.delegate7_237(this));
							Delegate190.delegate190_0(Delegate7.delegate7_236(e), string_, Delegate7.delegate7_237(this), solidBrush, int_0, int_1);
							goto IL_01f8;
						}
						IL_01f8:
						num5 = 1489130024;
						goto IL_01d6;
						IL_01a0:
						sizeF_0 = Delegate189.delegate189_0(Delegate7.delegate7_236(e), Delegate15.delegate15_37(this), Delegate7.delegate7_237(this));
						num5 = 1372047649;
						goto IL_01d6;
						IL_01d6:
						switch ((num2 = (uint)num5 ^ 0x2B11CB76u) % 4)
						{
						case 1u:
							break;
						case 0u:
							goto IL_01f8;
						default:
						{
							int num8 = int_1;
							using List<string>.Enumerator enumerator2 = list_0.GetEnumerator();
							while (true)
							{
								int num9;
								int num10;
								if (enumerator2.MoveNext())
								{
									num9 = 1957064643;
									num10 = 1957064643;
								}
								else
								{
									num9 = 74636460;
									num10 = 74636460;
								}
								while (true)
								{
									switch ((num2 = (uint)num9 ^ 0x2B11CB76u) % 24)
									{
									case 23u:
										e.Graphics.DrawString(current2, Font, solidBrush, int_0, num8);
										num9 = 505020507;
										continue;
									case 22u:
										num9 = 1957064643;
										continue;
									case 21u:
										num8 = checked((int)Math.Round((double)num8 + (double)e.Graphics.MeasureString(current2, Font).Height * 1.3));
										num9 = (int)((num2 * 1343635256) ^ 0x3F8565FA);
										continue;
									case 20u:
									{
										int num15;
										int num16;
										if (contentAlignment > ContentAlignment.MiddleCenter)
										{
											num15 = 2092722043;
											num16 = 2092722043;
										}
										else
										{
											num15 = 1610045281;
											num16 = 1610045281;
										}
										num9 = num15 ^ ((int)num2 * -114272757);
										continue;
									}
									case 19u:
										num9 = ((int)num2 * -1664775641) ^ -1588118652;
										continue;
									case 17u:
										contentAlignment = Delegate191.delegate191_0(this);
										num9 = (int)((num2 * 745181603) ^ 0x400C3E01);
										continue;
									case 16u:
										goto IL_02ff;
									case 15u:
										num9 = (int)((num2 * 1852695292) ^ 0x1E7B31D);
										continue;
									case 14u:
									{
										int num20;
										int num21;
										if (contentAlignment != ContentAlignment.MiddleLeft)
										{
											num20 = -1275013333;
											num21 = -1275013333;
										}
										else
										{
											num20 = -1321219140;
											num21 = -1321219140;
										}
										num9 = num20 ^ ((int)num2 * -905749188);
										continue;
									}
									case 13u:
									{
										int num17;
										int num18;
										if (contentAlignment != ContentAlignment.MiddleCenter)
										{
											num17 = -342341562;
											num18 = -342341562;
										}
										else
										{
											num17 = -322514693;
											num18 = -322514693;
										}
										num9 = num17 ^ (int)(num2 * 369514306);
										continue;
									}
									case 11u:
										switch (contentAlignment)
										{
										case (ContentAlignment)3:
											break;
										case ContentAlignment.TopRight:
											goto IL_02ff;
										default:
											goto IL_03cd;
										case ContentAlignment.TopLeft:
											goto IL_03e0;
										case ContentAlignment.TopCenter:
											goto IL_0404;
										}
										goto case 23u;
									case 10u:
										goto IL_03e0;
									case 7u:
										goto IL_0404;
									case 9u:
									{
										int num24;
										if (contentAlignment > ContentAlignment.BottomLeft)
										{
											num9 = 614397018;
											num24 = 614397018;
										}
										else
										{
											num9 = 1728838574;
											num24 = 1728838574;
										}
										continue;
									}
									case 8u:
										num9 = (int)(num2 * 2035026488) ^ -1136589223;
										continue;
									case 6u:
									{
										int num22;
										int num23;
										if (contentAlignment != ContentAlignment.BottomLeft)
										{
											num22 = -1959566622;
											num23 = -1959566622;
										}
										else
										{
											num22 = -1083528808;
											num23 = -1083528808;
										}
										num9 = num22 ^ ((int)num2 * -96990214);
										continue;
									}
									case 5u:
										current2 = enumerator2.Current;
										num9 = 1871123671;
										continue;
									case 4u:
									{
										int num19;
										if (contentAlignment != ContentAlignment.BottomCenter)
										{
											num9 = 476518823;
											num19 = 476518823;
										}
										else
										{
											num9 = 1453865809;
											num19 = 1453865809;
										}
										continue;
									}
									case 3u:
										num9 = ((int)num2 * -994048469) ^ -743562816;
										continue;
									case 2u:
										num9 = (int)((num2 * 1632941010) ^ 0x6D22C94D);
										continue;
									case 1u:
									{
										int num13;
										int num14;
										if (contentAlignment != ContentAlignment.BottomRight)
										{
											num13 = 517606859;
											num14 = 517606859;
										}
										else
										{
											num13 = 1596141360;
											num14 = 1596141360;
										}
										num9 = num13 ^ ((int)num2 * -1957262378);
										continue;
									}
									case 0u:
									{
										int num11;
										int num12;
										if (contentAlignment != ContentAlignment.MiddleRight)
										{
											num11 = 1066815216;
											num12 = 1066815216;
										}
										else
										{
											num11 = 1240966238;
											num12 = 1240966238;
										}
										num9 = num11 ^ (int)(num2 * 1574650177);
										continue;
									}
									default:
										return;
									case 12u:
										break;
									case 18u:
										return;
										IL_03e0:
										int_0 = Delegate192.delegate192_0(this).Left;
										num9 = 922328777;
										continue;
										IL_03cd:
										num9 = (int)((num2 * 1739230133) ^ 0x1D9583B7);
										continue;
										IL_0404:
										int_0 = checked((int)Math.Round(((float)base.Width - e.Graphics.MeasureString(current2, Font).Width) / 2f));
										num9 = 559789337;
										continue;
										IL_02ff:
										int_0 = checked((int)Math.Round((float)base.Width - e.Graphics.MeasureString(current2, Font).Width - (float)base.Margin.Right));
										num9 = 601793773;
										continue;
									}
									break;
								}
							}
						}
						case 2u:
							return;
						}
						goto IL_01a0;
					}
					break;
				}
			}
		}
		finally
		{
			if (solidBrush != null)
			{
				while (true)
				{
					IL_062a:
					int num25 = 1994858402;
					while (true)
					{
						uint num2;
						switch ((num2 = (uint)num25 ^ 0x2B11CB76u) % 3)
						{
						case 1u:
							goto IL_05f8;
						default:
							goto end_IL_060c;
						case 2u:
							break;
						case 0u:
							goto end_IL_060c;
						}
						goto IL_062a;
						IL_05f8:
						((IDisposable)solidBrush).Dispose();
						num25 = (int)((num2 * 497899631) ^ 0x383E3A22);
						continue;
						end_IL_060c:
						break;
					}
					break;
				}
			}
		}
	}

	private void method_0()
	{
		string text = "";
		char[] char_ = new char[2] { ' ', '\r' };
		string[] array = Delegate70.delegate70_0(Delegate15.delegate15_37(this), char_);
		Graphics object_ = (Graphics)Delegate7.delegate7_238(this);
		list_0.Clear();
		string[] array2 = array;
		int num3 = default(int);
		string text2 = default(string);
		while (true)
		{
			int num = -925701345;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xE22AF94Eu) % 14)
				{
				case 13u:
					text2 = array2[num3];
					num = -1219593450;
					continue;
				case 12u:
					list_0.Add(text);
					num = ((int)num2 * -246051052) ^ -1972774917;
					continue;
				case 11u:
					list_0.Add(text);
					text2 = text2.Replace(global::_003CModule_003E.smethod_18<string>(3822164239u, 1369214926u), "");
					text2 = text2.Replace(global::_003CModule_003E.smethod_22<string>(1844804972u, 3245082382u), "");
					text2 = text2.Replace(global::_003CModule_003E.smethod_18<string>(2151107120u, 3353208275u), "");
					num = -1755933772;
					continue;
				case 10u:
					text = text2 + global::_003CModule_003E.smethod_18<string>(1286707204u, 922914896u);
					num = ((int)num2 * -420844832) ^ 0x6B5A36EC;
					continue;
				case 8u:
					num3 = checked(num3 + 1);
					num = -1916849643;
					continue;
				case 6u:
				{
					int num7;
					int num8;
					if (Operators.CompareString(text, "", TextCompare: false) == 0)
					{
						num7 = 996498853;
						num8 = 996498853;
					}
					else
					{
						num7 = 527590568;
						num8 = 527590568;
					}
					num = num7 ^ (int)(num2 * 1068711013);
					continue;
				}
				case 5u:
					num3 = 0;
					num = (int)(num2 * 476225646) ^ -602008526;
					continue;
				case 4u:
				{
					int num5;
					int num6;
					if ((Delegate189.delegate189_0(object_, Delegate57.delegate57_1(text, text2), Delegate7.delegate7_237(this)).Width < (float)base.Width) & !text2.Contains(global::_003CModule_003E.smethod_20<string>(2403200718u, 4155352805u)) & !text2.Contains(global::_003CModule_003E.smethod_19<string>(3896812382u, 3792828750u)) & !text2.Contains(global::_003CModule_003E.smethod_18<string>(2151107120u, 4206046077u)))
					{
						num5 = -1740282569;
						num6 = -1740282569;
					}
					else
					{
						num5 = -283954119;
						num6 = -283954119;
					}
					num = num5 ^ (int)(num2 * 1521985456);
					continue;
				}
				case 3u:
				{
					int num4;
					if (num3 >= array2.Length)
					{
						num = -799217752;
						num4 = -799217752;
					}
					else
					{
						num = -1374807425;
						num4 = -1374807425;
					}
					continue;
				}
				case 2u:
					num = (int)((num2 * 1567121451) ^ 0x222FEDD2);
					continue;
				case 1u:
					text = text + text2 + global::_003CModule_003E.smethod_19<string>(1037976375u, 3915521698u);
					num = ((int)num2 * -251468264) ^ -992190228;
					continue;
				case 0u:
					num = ((int)num2 * -1348600926) ^ 0x7179CEB1;
					continue;
				default:
					return;
				case 9u:
					break;
				case 7u:
					return;
				}
				break;
			}
		}
	}

	private void method_1()
	{
		Delegate22.delegate22_54(Delegate7.delegate7_239(this));
		GEnum7 gEnum = default(GEnum7);
		while (true)
		{
			int num = 1472795813;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x3C1209F1u) % 17)
				{
				case 16u:
					int_1 = base.Height;
					num = (int)(num2 * 1281515016) ^ -1668905125;
					continue;
				case 15u:
				{
					int num7;
					int num8;
					if ((double)int_1 < 0.0 - (double)checked((list_0.Count + 1) * Font.Height) * 1.3)
					{
						num7 = -274421401;
						num8 = -274421401;
					}
					else
					{
						num7 = -1441799421;
						num8 = -1441799421;
					}
					num = num7 ^ ((int)num2 * -742155533);
					continue;
				}
				case 14u:
				{
					gEnum = genum7_0;
					int num9;
					int num10;
					if (gEnum != 0)
					{
						num9 = 74144844;
						num10 = 74144844;
					}
					else
					{
						num9 = 667290825;
						num10 = 667290825;
					}
					num = num9 ^ ((int)num2 * -1602473924);
					continue;
				}
				case 12u:
					num = ((int)num2 * -1861232862) ^ -765539329;
					continue;
				case 10u:
					int_0 = base.Width;
					num = (int)((num2 * 173908484) ^ 0xE463A01);
					continue;
				case 9u:
					int_0 = 0;
					num = 2098913594;
					continue;
				case 8u:
					checked
					{
						int_0--;
						num = 828274784;
						continue;
					}
				case 7u:
					num = (int)(num2 * 1476013869) ^ -69005026;
					continue;
				case 6u:
				{
					int num5;
					int num6;
					if (gEnum == GEnum7.vertical)
					{
						num5 = -770851300;
						num6 = -770851300;
					}
					else
					{
						num5 = -1287229872;
						num6 = -1287229872;
					}
					num = num5 ^ ((int)num2 * -442009397);
					continue;
				}
				case 5u:
					Invalidate();
					num = 2060987481;
					continue;
				case 4u:
					num = (int)((num2 * 1440241382) ^ 0x24B6DC1B);
					continue;
				case 3u:
					int_1 = checked((int)Delegate69.delegate69_0((double)(Delegate17.delegate17_21(this) - Delegate17.delegate17_25(Delegate7.delegate7_237(this))) / 2.0));
					num = 1319674091;
					continue;
				case 2u:
				{
					int num3;
					int num4;
					if ((float)int_0 < 0f - sizeF_0.Width)
					{
						num3 = 198106598;
						num4 = 198106598;
					}
					else
					{
						num3 = 1923110476;
						num4 = 1923110476;
					}
					num = num3 ^ (int)(num2 * 1280340939);
					continue;
				}
				case 1u:
					Timer_0.Start();
					num = ((int)num2 * -94555754) ^ -2086443735;
					continue;
				case 0u:
					checked
					{
						int_1--;
						num = 1979745379;
						continue;
					}
				default:
					return;
				case 13u:
					break;
				case 11u:
					return;
				}
				break;
			}
		}
	}

	[SpecialName]
	[CompilerGenerated]
	private void method_2(object sender, EventArgs e)
	{
		Delegate22.delegate22_60(this);
	}
}
