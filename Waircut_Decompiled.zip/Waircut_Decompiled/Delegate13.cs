internal delegate void Delegate13(object object_0, object object_1, object object_2);
