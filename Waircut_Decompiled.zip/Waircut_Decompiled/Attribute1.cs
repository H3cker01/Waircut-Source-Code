using System;

internal class Attribute1 : Attribute
{
	internal readonly int int_0;

	internal Attribute1(int int_1)
	{
		int_0 = int_1 * -689797635 * -908629331 * -2114843379;
	}

	public virtual int vmethod_0()
	{
		return int_0;
	}
}
