internal delegate byte[] Delegate85(object object_0, string string_0);
