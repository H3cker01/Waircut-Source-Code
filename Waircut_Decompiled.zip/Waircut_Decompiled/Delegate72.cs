internal delegate int Delegate72(string string_0, int int_0);
