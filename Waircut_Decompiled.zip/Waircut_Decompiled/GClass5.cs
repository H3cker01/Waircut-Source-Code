using System.Runtime.CompilerServices;
using System.Threading;
using ns1;

public class GClass5 : GInterface4
{
	public delegate void GDelegate0(GEnum8 @event, string evtString, string message);

	public delegate void GDelegate1(int threadID, string _message);

	public string string_0;

	[CompilerGenerated]
	private GDelegate0 gdelegate0_0;

	[CompilerGenerated]
	private GDelegate1 gdelegate1_0;

	public event GDelegate0 Event_0
	{
		[CompilerGenerated]
		add
		{
			GDelegate0 gDelegate = gdelegate0_0;
			GDelegate0 gDelegate2 = default(GDelegate0);
			while (true)
			{
				int num = -1578593939;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0xAB7B71A8u) % 4)
					{
					case 1u:
						gDelegate2 = gDelegate;
						num = -1020369392;
						continue;
					case 0u:
					{
						GDelegate0 value2 = (GDelegate0)Delegate95.delegate95_0(gDelegate2, value);
						gDelegate = Interlocked.CompareExchange(ref gdelegate0_0, value2, gDelegate2);
						int num3;
						int num4;
						if ((object)gDelegate == gDelegate2)
						{
							num3 = -73734218;
							num4 = -73734218;
						}
						else
						{
							num3 = -348631979;
							num4 = -348631979;
						}
						num = num3 ^ ((int)num2 * -270962479);
						continue;
					}
					default:
						return;
					case 3u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
		[CompilerGenerated]
		remove
		{
			GDelegate0 gDelegate = gdelegate0_0;
			GDelegate0 gDelegate2 = default(GDelegate0);
			GDelegate0 value2 = default(GDelegate0);
			while (true)
			{
				int num = -896646892;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x97FDFB14u) % 5)
					{
					case 4u:
						gDelegate2 = gDelegate;
						num = -805624633;
						continue;
					case 3u:
						value2 = (GDelegate0)Delegate95.delegate95_1(gDelegate2, value);
						num = ((int)num2 * -1475780527) ^ 0x40A5C338;
						continue;
					case 1u:
					{
						gDelegate = Interlocked.CompareExchange(ref gdelegate0_0, value2, gDelegate2);
						int num3;
						int num4;
						if ((object)gDelegate != gDelegate2)
						{
							num3 = 770837403;
							num4 = 770837403;
						}
						else
						{
							num3 = 1701205689;
							num4 = 1701205689;
						}
						num = num3 ^ ((int)num2 * -831674015);
						continue;
					}
					default:
						return;
					case 0u:
						break;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	public event GDelegate1 Event_1
	{
		[CompilerGenerated]
		add
		{
			GDelegate1 gDelegate = gdelegate1_0;
			GDelegate1 value2 = default(GDelegate1);
			GDelegate1 gDelegate2 = default(GDelegate1);
			while (true)
			{
				int num = 1955306617;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x7DA7E26Eu) % 5)
					{
					case 3u:
					{
						gDelegate = Interlocked.CompareExchange(ref gdelegate1_0, value2, gDelegate2);
						int num3;
						int num4;
						if ((object)gDelegate != gDelegate2)
						{
							num3 = -2110226743;
							num4 = -2110226743;
						}
						else
						{
							num3 = -906567270;
							num4 = -906567270;
						}
						num = num3 ^ ((int)num2 * -480533080);
						continue;
					}
					case 2u:
						gDelegate2 = gDelegate;
						num = 1374841541;
						continue;
					case 1u:
						value2 = (GDelegate1)Delegate95.delegate95_0(gDelegate2, value);
						num = (int)(num2 * 705110987) ^ -803273655;
						continue;
					default:
						return;
					case 4u:
						break;
					case 0u:
						return;
					}
					break;
				}
			}
		}
		[CompilerGenerated]
		remove
		{
			GDelegate1 gDelegate = gdelegate1_0;
			GDelegate1 value2 = default(GDelegate1);
			GDelegate1 gDelegate2 = default(GDelegate1);
			while (true)
			{
				int num = 1054931873;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)num ^ 0x3209AB3Eu) % 6)
					{
					case 5u:
						gDelegate = Interlocked.CompareExchange(ref gdelegate1_0, value2, gDelegate2);
						num = (int)((num2 * 1205743839) ^ 0x704E8ECA);
						continue;
					case 3u:
					{
						int num3;
						int num4;
						if ((object)gDelegate != gDelegate2)
						{
							num3 = 288585071;
							num4 = 288585071;
						}
						else
						{
							num3 = 1456267536;
							num4 = 1456267536;
						}
						num = num3 ^ (int)(num2 * 2060418730);
						continue;
					}
					case 1u:
						gDelegate2 = gDelegate;
						num = 615077802;
						continue;
					case 0u:
						value2 = (GDelegate1)Delegate95.delegate95_1(gDelegate2, value);
						num = ((int)num2 * -1362725725) ^ 0x5964FA3;
						continue;
					default:
						return;
					case 2u:
						break;
					case 4u:
						return;
					}
					break;
				}
			}
		}
	}

	public GClass5()
	{
		while (true)
		{
			int num = 304204036;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x6C1E8FDFu) % 3)
				{
				case 1u:
					goto IL_0008;
				default:
					return;
				case 0u:
					break;
				case 2u:
					return;
				}
				break;
				IL_0008:
				string_0 = "";
				num = (int)(num2 * 1701347188) ^ -1921616749;
			}
		}
	}

	void GInterface4.OnJswApiEvent(GEnum8 @event, string evtString)
	{
		GDelegate0 gDelegate = default(GDelegate0);
		while (true)
		{
			int num = -1583155146;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0xC0AD0856u) % 9)
				{
				case 8u:
				{
					ref string reference = ref string_0;
					reference = Delegate57.delegate57_1(reference, global::_003CModule_003E.smethod_21<string>(2806046271u, 1439523012u));
					num = -1322793774;
					continue;
				}
				case 7u:
				{
					int num5;
					int num6;
					if (@event != GEnum8.JswApiEvt_AdapterRemoved)
					{
						num5 = 153687651;
						num6 = 153687651;
					}
					else
					{
						num5 = 1659513201;
						num6 = 1659513201;
					}
					num = num5 ^ ((int)num2 * -1131832130);
					continue;
				}
				case 6u:
				{
					int num7;
					int num8;
					if (gDelegate == null)
					{
						num7 = -1745120896;
						num8 = -1745120896;
					}
					else
					{
						num7 = -145508785;
						num8 = -145508785;
					}
					num = num7 ^ (int)(num2 * 1375088065);
					continue;
				}
				case 4u:
					gDelegate(@event, evtString, string_0);
					num = (int)((num2 * 500226944) ^ 0x7F413387);
					continue;
				case 3u:
				{
					ref string reference2 = ref string_0;
					reference2 = Delegate57.delegate57_1(reference2, global::_003CModule_003E.smethod_22<string>(2932245843u, 1529175301u));
					num = (int)((num2 * 1434993742) ^ 0x679964EE);
					continue;
				}
				case 2u:
					gDelegate = gdelegate0_0;
					num = -147881327;
					continue;
				case 0u:
				{
					int num3;
					int num4;
					if (@event != GEnum8.JswApiEvt_AdapterAdded)
					{
						num3 = 1268632074;
						num4 = 1268632074;
					}
					else
					{
						num3 = 1949073724;
						num4 = 1949073724;
					}
					num = num3 ^ ((int)num2 * -1367564168);
					continue;
				}
				default:
					return;
				case 5u:
					break;
				case 1u:
					return;
				}
				break;
			}
		}
	}

	void GInterface4.OnJswApiTraceMessage(int threadID, string message)
	{
		GDelegate1 gDelegate = gdelegate1_0;
		while (true)
		{
			int num = 497894866;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)num ^ 0x571A243Fu) % 4)
				{
				case 2u:
					gDelegate(threadID, message);
					num = ((int)num2 * -1989181298) ^ 0x37A1552B;
					continue;
				case 1u:
				{
					int num3;
					int num4;
					if (gDelegate == null)
					{
						num3 = -1587899893;
						num4 = -1587899893;
					}
					else
					{
						num3 = -1774849623;
						num4 = -1774849623;
					}
					num = num3 ^ (int)(num2 * 285592188);
					continue;
				}
				default:
					return;
				case 3u:
					break;
				case 0u:
					return;
				}
				break;
			}
		}
	}
}
