internal delegate int Delegate74(string string_0);
