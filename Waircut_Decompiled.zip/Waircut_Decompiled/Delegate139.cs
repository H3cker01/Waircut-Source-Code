internal delegate object Delegate139(object object_0, bool bool_0);
